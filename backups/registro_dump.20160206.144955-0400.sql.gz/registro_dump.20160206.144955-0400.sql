--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: registroibpr; Type: DATABASE; Schema: -; Owner: marcel
--

CREATE DATABASE registroibpr WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE registroibpr OWNER TO marcel;

\connect registroibpr

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: checks; Type: TABLE; Schema: public; Owner: marcel; Tablespace: 
--

CREATE TABLE checks (
    id integer NOT NULL,
    number integer,
    amount numeric(9,2) NOT NULL,
    description text,
    church_id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.checks OWNER TO marcel;

--
-- Name: checks_id_seq; Type: SEQUENCE; Schema: public; Owner: marcel
--

CREATE SEQUENCE checks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.checks_id_seq OWNER TO marcel;

--
-- Name: checks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marcel
--

ALTER SEQUENCE checks_id_seq OWNED BY checks.id;


--
-- Name: churches; Type: TABLE; Schema: public; Owner: marcel; Tablespace: 
--

CREATE TABLE churches (
    id integer NOT NULL,
    "position" integer,
    nth integer DEFAULT 0,
    prefix character varying(255) DEFAULT 'Iglesia Bautista de'::character varying,
    name character varying(255) NOT NULL,
    nickname character varying(255),
    town character varying(255),
    size integer DEFAULT 0,
    notes text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.churches OWNER TO marcel;

--
-- Name: churches_id_seq; Type: SEQUENCE; Schema: public; Owner: marcel
--

CREATE SEQUENCE churches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.churches_id_seq OWNER TO marcel;

--
-- Name: churches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marcel
--

ALTER SEQUENCE churches_id_seq OWNED BY churches.id;


--
-- Name: people; Type: TABLE; Schema: public; Owner: marcel; Tablespace: 
--

CREATE TABLE people (
    id integer NOT NULL,
    salutation integer,
    name character varying(255) NOT NULL,
    lastnames character varying(255) NOT NULL,
    sex boolean NOT NULL,
    role integer NOT NULL,
    description text,
    attended boolean DEFAULT false,
    printed boolean DEFAULT false,
    materials boolean DEFAULT false,
    church_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.people OWNER TO marcel;

--
-- Name: people_id_seq; Type: SEQUENCE; Schema: public; Owner: marcel
--

CREATE SEQUENCE people_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.people_id_seq OWNER TO marcel;

--
-- Name: people_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marcel
--

ALTER SEQUENCE people_id_seq OWNED BY people.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: marcel; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO marcel;

--
-- Name: versions; Type: TABLE; Schema: public; Owner: marcel; Tablespace: 
--

CREATE TABLE versions (
    id integer NOT NULL,
    item_type character varying(255) NOT NULL,
    item_id integer NOT NULL,
    event character varying(255) NOT NULL,
    whodunnit character varying(255),
    object text,
    created_at timestamp without time zone
);


ALTER TABLE public.versions OWNER TO marcel;

--
-- Name: versions_id_seq; Type: SEQUENCE; Schema: public; Owner: marcel
--

CREATE SEQUENCE versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.versions_id_seq OWNER TO marcel;

--
-- Name: versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marcel
--

ALTER SEQUENCE versions_id_seq OWNED BY versions.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: marcel
--

ALTER TABLE ONLY checks ALTER COLUMN id SET DEFAULT nextval('checks_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: marcel
--

ALTER TABLE ONLY churches ALTER COLUMN id SET DEFAULT nextval('churches_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: marcel
--

ALTER TABLE ONLY people ALTER COLUMN id SET DEFAULT nextval('people_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: marcel
--

ALTER TABLE ONLY versions ALTER COLUMN id SET DEFAULT nextval('versions_id_seq'::regclass);


--
-- Data for Name: checks; Type: TABLE DATA; Schema: public; Owner: marcel
--

INSERT INTO checks VALUES (1, 14652, 125.00, '', 103, '2015-02-24 01:21:39.715528', '2015-02-24 01:21:39.715528');
INSERT INTO checks VALUES (2, 9226, 75.00, '', 105, '2015-02-24 01:23:13.969563', '2015-02-24 01:23:13.969563');
INSERT INTO checks VALUES (3, 16766, 125.00, 'Pagó 6-febrero-2015', 109, '2015-02-24 01:30:55.87832', '2015-02-24 01:31:24.075276');
INSERT INTO checks VALUES (4, 4683, 50.00, 'Pagó 10-febrer0-2015', 12, '2015-02-24 01:40:25.870939', '2015-02-24 01:40:25.870939');
INSERT INTO checks VALUES (5, 40, 75.00, 'Pago 5-febrero-2015', 123, '2015-02-24 01:43:19.618534', '2015-02-24 01:43:19.618534');
INSERT INTO checks VALUES (6, 14836, 175.00, 'Pago 30-enero-2015', 107, '2015-02-24 01:48:40.58787', '2015-02-24 01:48:40.58787');
INSERT INTO checks VALUES (7, 2594, 75.00, 'Recibido 5-febrero-2015', 113, '2015-02-24 01:54:18.601953', '2015-02-24 01:54:45.952991');
INSERT INTO checks VALUES (8, 24496, 325.00, '', 13, '2015-02-24 02:19:44.588789', '2015-02-24 02:19:44.588789');
INSERT INTO checks VALUES (9, 3353, 150.00, 'Recibido 13-febrero-2015', 52, '2015-02-24 02:31:36.763363', '2015-02-24 02:32:04.575217');
INSERT INTO checks VALUES (10, 14697, 175.00, 'Recibido 6-febrero-2015', 60, '2015-02-24 02:38:19.292961', '2015-02-24 02:38:19.292961');
INSERT INTO checks VALUES (11, 2735, 100.00, 'Recibido 5-febrero-2015  Balance $25.00', 56, '2015-02-24 02:44:41.807723', '2015-02-24 02:44:41.807723');
INSERT INTO checks VALUES (12, 11897, 100.00, '15/01/2015', 42, '2015-02-24 14:20:37.47591', '2015-02-24 14:20:37.47591');
INSERT INTO checks VALUES (13, 1295, 200.00, '02/09/2015', 69, '2015-02-24 14:38:44.973039', '2015-02-24 14:38:44.973039');
INSERT INTO checks VALUES (14, 3776, 25.00, '', 67, '2015-02-24 14:40:06.2477', '2015-02-24 14:40:06.2477');
INSERT INTO checks VALUES (15, NULL, 300.00, 'Ref. PDD0Q21315173352', 84, '2015-02-24 14:48:15.864611', '2015-02-24 14:48:15.864611');
INSERT INTO checks VALUES (16, 1378, 75.00, '', 21, '2015-02-24 14:52:32.776465', '2015-02-24 14:52:32.776465');
INSERT INTO checks VALUES (17, 3821, 75.00, '', 68, '2015-02-24 14:57:39.190401', '2015-02-24 14:57:39.190401');
INSERT INTO checks VALUES (18, 13515, 75.00, '', 83, '2015-02-27 02:39:49.732', '2015-02-27 02:39:49.732');
INSERT INTO checks VALUES (20, 3945, 125.00, '', 51, '2015-03-02 19:27:49.918688', '2015-03-02 19:27:49.918688');
INSERT INTO checks VALUES (21, 4476, 100.00, '', 75, '2015-03-02 19:53:55.350522', '2015-03-02 19:53:55.350522');
INSERT INTO checks VALUES (22, 36399, 75.00, '', 14, '2015-03-02 20:08:12.06735', '2015-03-02 20:08:12.06735');
INSERT INTO checks VALUES (23, 2594, 75.00, '', 20, '2015-03-02 20:08:49.31333', '2015-03-02 20:08:49.31333');
INSERT INTO checks VALUES (24, 2593, 25.00, '', 20, '2015-03-02 20:09:01.971344', '2015-03-02 20:09:01.971344');
INSERT INTO checks VALUES (25, 218, 125.00, '', 37, '2015-03-02 20:09:33.587228', '2015-03-02 20:09:33.587228');
INSERT INTO checks VALUES (26, 12806, 100.00, '', 53, '2015-03-02 20:12:45.812923', '2015-03-02 20:12:45.812923');
INSERT INTO checks VALUES (27, 9965, 100.00, '', 76, '2015-03-02 20:14:35.873214', '2015-03-02 20:14:35.873214');
INSERT INTO checks VALUES (28, 5014, 100.00, '', 91, '2015-03-02 20:15:53.187239', '2015-03-02 20:15:53.187239');
INSERT INTO checks VALUES (29, 3199, 75.00, '', 17, '2015-03-02 20:21:41.782128', '2015-03-02 20:21:41.782128');
INSERT INTO checks VALUES (30, 5640, 125.00, 'Recibido 3-2-2015', 99, '2015-03-05 10:53:03.312029', '2015-03-05 10:53:03.312029');
INSERT INTO checks VALUES (31, 9828, 100.00, '', 29, '2015-03-05 10:54:39.861683', '2015-03-05 10:54:39.861683');
INSERT INTO checks VALUES (32, 9698, 125.00, 'RECIBIDO 3-5-2015', 23, '2015-03-05 11:27:40.942055', '2015-03-05 11:28:22.101704');
INSERT INTO checks VALUES (33, 4569, 100.00, 'RECIBIDO 3-5-15', 24, '2015-03-05 11:34:04.402383', '2015-03-05 11:34:04.402383');
INSERT INTO checks VALUES (34, 9269, 50.00, 'RECIBIDO 3-5-15', 50, '2015-03-05 11:34:47.696353', '2015-03-05 11:34:47.696353');
INSERT INTO checks VALUES (35, 760, 75.00, '', 27, '2015-03-05 11:56:29.036636', '2015-03-05 11:56:29.036636');
INSERT INTO checks VALUES (36, 4494, 75.00, '', 86, '2015-03-05 12:13:29.138098', '2015-03-05 12:13:29.138098');
INSERT INTO checks VALUES (37, 6540, 100.00, 'RECIBIDO 3-5-15', 96, '2015-03-05 12:17:48.935931', '2015-03-05 12:17:48.935931');
INSERT INTO checks VALUES (38, 1740, 50.00, '', 2, '2015-03-05 12:21:12.194276', '2015-03-05 12:21:12.194276');
INSERT INTO checks VALUES (39, 11206, 150.00, 'RECIBIDO 3-5-15', 33, '2015-03-05 12:24:08.050943', '2015-03-05 12:24:08.050943');
INSERT INTO checks VALUES (40, 8416, 100.00, '', 7, '2015-03-05 12:48:13.344093', '2015-03-05 12:48:13.344093');
INSERT INTO checks VALUES (41, 5438, 100.00, '', 106, '2015-03-05 12:49:35.766254', '2015-03-05 12:49:35.766254');
INSERT INTO checks VALUES (42, 11263, 150.00, '', 48, '2015-03-05 12:52:48.806748', '2015-03-05 12:52:48.806748');
INSERT INTO checks VALUES (43, 0, 100.00, '', 26, '2015-03-05 12:54:45.065849', '2015-03-05 12:54:45.065849');
INSERT INTO checks VALUES (45, 1043, 25.00, '', 64, '2015-03-05 12:57:35.416701', '2015-03-05 12:57:35.416701');
INSERT INTO checks VALUES (46, 2201, 75.00, '', 102, '2015-03-05 13:00:39.944217', '2015-03-05 13:00:39.944217');
INSERT INTO checks VALUES (47, 3312, 25.00, '', 34, '2015-03-05 13:01:24.078903', '2015-03-05 13:01:24.078903');
INSERT INTO checks VALUES (48, 6489, 50.00, '', 80, '2015-03-05 13:03:14.665572', '2015-03-05 13:03:14.665572');
INSERT INTO checks VALUES (49, 0, 50.00, 'PAGO CASH', 43, '2015-03-05 13:05:12.620638', '2015-03-05 13:05:44.136241');
INSERT INTO checks VALUES (50, 4243, 75.00, '', 35, '2015-03-05 13:13:03.27623', '2015-03-05 13:13:03.27623');
INSERT INTO checks VALUES (52, 1008, 50.00, '', 124, '2015-03-05 13:20:44.024314', '2015-03-05 13:20:44.024314');
INSERT INTO checks VALUES (53, 1959, 25.00, '', 9, '2015-03-05 13:23:08.721491', '2015-03-05 13:23:08.721491');
INSERT INTO checks VALUES (54, 1959, 75.00, '', 62, '2015-03-05 13:23:33.055981', '2015-03-05 13:23:33.055981');
INSERT INTO checks VALUES (55, 2299, 75.00, '', 87, '2015-03-05 13:25:44.626089', '2015-03-05 13:25:44.626089');
INSERT INTO checks VALUES (56, 0, 50.00, 'Cash', 77, '2015-03-05 13:28:24.728661', '2015-03-05 13:28:24.728661');
INSERT INTO checks VALUES (57, 12399, 100.00, '', 32, '2015-03-05 13:29:52.491252', '2015-03-05 13:29:52.491252');
INSERT INTO checks VALUES (58, 6697, 100.00, '', 82, '2015-03-05 13:38:55.71181', '2015-03-05 13:38:55.71181');
INSERT INTO checks VALUES (59, 3100, 175.00, '', 1, '2015-03-05 13:39:23.327257', '2015-03-05 13:39:23.327257');
INSERT INTO checks VALUES (60, 11672, 50.00, '', 66, '2015-03-05 13:40:13.762797', '2015-03-05 13:40:13.762797');
INSERT INTO checks VALUES (61, 9327, 125.00, '', 41, '2015-03-05 14:04:37.788068', '2015-03-05 14:12:01.910103');
INSERT INTO checks VALUES (62, 1070, 25.00, '', 64, '2015-03-05 15:08:25.055528', '2015-03-05 15:08:25.055528');
INSERT INTO checks VALUES (63, 1609, 75.00, '', 97, '2015-03-05 17:09:52.185893', '2015-03-05 17:09:52.185893');
INSERT INTO checks VALUES (64, 1211, 50.00, '', 127, '2015-03-05 17:11:53.610642', '2015-03-05 17:11:53.610642');
INSERT INTO checks VALUES (65, 5189, 75.00, '', 10, '2015-03-05 17:37:20.682263', '2015-03-05 17:37:20.682263');
INSERT INTO checks VALUES (66, 1001, 50.00, '', 71, '2015-03-06 12:11:01.221413', '2015-03-06 12:11:01.221413');
INSERT INTO checks VALUES (67, 1001, 50.00, '', 71, '2015-03-06 12:11:02.162027', '2015-03-06 12:11:02.162027');
INSERT INTO checks VALUES (68, 0, 25.00, 'CASH', 116, '2015-03-06 12:11:50.628222', '2015-03-06 12:11:50.628222');
INSERT INTO checks VALUES (69, 3440, 75.00, '', 40, '2015-03-06 12:17:09.383222', '2015-03-06 12:17:09.383222');
INSERT INTO checks VALUES (70, 0, 50.00, 'CASH', 46, '2015-03-06 12:44:50.728741', '2015-03-06 12:44:50.728741');
INSERT INTO checks VALUES (71, 1113, 75.00, '', 54, '2015-03-06 13:28:42.565702', '2015-03-06 13:28:42.565702');


--
-- Name: checks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marcel
--

SELECT pg_catalog.setval('checks_id_seq', 71, true);


--
-- Data for Name: churches; Type: TABLE DATA; Schema: public; Owner: marcel
--

INSERT INTO churches VALUES (2, 11, 0, 'Iglesia Bautista de', 'Belén', '', 'Canóvanas', 1, NULL, '2014-03-04 15:14:57.140922', '2014-03-04 15:14:57.140922');
INSERT INTO churches VALUES (3, 36, 0, 'Iglesia Bautista de', 'Cupey', 'Venus Gardens', 'San Juan', 3, NULL, '2014-03-04 15:14:57.147675', '2014-03-04 15:14:57.147675');
INSERT INTO churches VALUES (5, 1, 1, 'Iglesia Bautista de', 'Adjuntas', '', 'Adjuntas', 1, NULL, '2014-03-04 15:14:57.14938', '2014-03-04 15:14:57.14938');
INSERT INTO churches VALUES (6, 111, 0, 'Iglesia Bautista de', 'Yahuecas', 'Yahuecas Arriba', 'Adjuntas', 1, NULL, '2014-03-04 15:14:57.151158', '2014-03-04 15:14:57.151158');
INSERT INTO churches VALUES (7, 2, 0, 'Iglesia Bautista de', 'Aguas Buenas', '', 'Aguas Buenas', 2, NULL, '2014-03-04 15:14:57.152687', '2014-03-04 15:14:57.152687');
INSERT INTO churches VALUES (8, 10, 0, 'Iglesia Bautista de', 'Bayamoncito', '', 'Aguas Buenas', 3, NULL, '2014-03-04 15:14:57.154161', '2014-03-04 15:14:57.154161');
INSERT INTO churches VALUES (9, 95, 0, 'Iglesia Bautista ', 'Reconciliación', 'Pajuil', 'Arecibo', 1, NULL, '2014-03-04 15:14:57.155515', '2014-03-04 15:14:57.155515');
INSERT INTO churches VALUES (10, 6, 0, 'Iglesia Bautista de', 'Barranquitas', '', 'Barranquitas', 2, NULL, '2014-03-04 15:14:57.156882', '2014-03-04 15:14:57.156882');
INSERT INTO churches VALUES (11, 9, 1, 'Iglesia Bautista de', 'Bayamón', '', 'Bayamón', 2, NULL, '2014-03-04 15:14:57.1581', '2014-03-04 15:14:57.1581');
INSERT INTO churches VALUES (12, 42, 0, 'Iglesia Bautista ', 'El Redentor', '', 'Bayamón', 2, NULL, '2014-03-04 15:14:57.159322', '2014-03-04 15:14:57.159322');
INSERT INTO churches VALUES (13, 16, 1, 'Iglesia Bautista de', 'Caguas', '', 'Caguas', 3, NULL, '2014-03-04 15:14:57.160513', '2014-03-04 15:14:57.160513');
INSERT INTO churches VALUES (14, 17, 2, 'Iglesia Bautista de', 'Caguas', '', 'Caguas', 3, NULL, '2014-03-04 15:14:57.161614', '2014-03-04 15:14:57.161614');
INSERT INTO churches VALUES (15, 43, 0, 'Iglesia Bautista ', 'El Verbo de Dios', '', 'Caguas', 1, NULL, '2014-03-04 15:14:57.162717', '2014-03-04 15:14:57.162717');
INSERT INTO churches VALUES (16, 65, 0, 'Iglesia Bautista de', 'Las Cruces', '', 'Caguas', 3, NULL, '2014-03-04 15:14:57.16381', '2014-03-04 15:14:57.16381');
INSERT INTO churches VALUES (17, 60, 0, 'Iglesia Bautista ', 'La Esperanza', 'Villa Esperanza', 'Caguas', 2, NULL, '2014-03-04 15:14:57.164867', '2014-03-04 15:14:57.164867');
INSERT INTO churches VALUES (18, 19, 0, 'Iglesia Bautista de', 'Canóvanas', '', 'Canóvanas', 3, NULL, '2014-03-04 15:14:57.165962', '2014-03-04 15:14:57.165962');
INSERT INTO churches VALUES (19, 53, 0, 'Iglesia Bautista ', 'Hosanna', 'San Isidro', 'Canóvanas', 2, NULL, '2014-03-04 15:14:57.167007', '2014-03-04 15:14:57.167007');
INSERT INTO churches VALUES (20, 69, 0, 'Iglesia Bautista de', 'Lomas', '', 'Canóvanas', 3, NULL, '2014-03-04 15:14:57.168099', '2014-03-04 15:14:57.168099');
INSERT INTO churches VALUES (21, 84, 0, 'Iglesia Bautista de', 'Peniel', '', 'Canóvanas', 1, NULL, '2014-03-04 15:14:57.169212', '2014-03-04 15:14:57.169212');
INSERT INTO churches VALUES (22, 5, 0, 'Iglesia Bautista de', 'Antioquía', 'Canovanillas', 'Carolina', 1, NULL, '2014-03-04 15:14:57.170294', '2014-03-04 15:14:57.170294');
INSERT INTO churches VALUES (23, 7, 0, 'Iglesia Bautista de', 'Barrazas', '', 'Carolina', 3, NULL, '2014-03-04 15:14:57.171423', '2014-03-04 15:14:57.171423');
INSERT INTO churches VALUES (24, 15, 0, 'Iglesia Bautista de', 'Cacao', '', 'Carolina', 2, NULL, '2014-03-04 15:14:57.172543', '2014-03-04 15:14:57.172543');
INSERT INTO churches VALUES (25, 20, 1, 'Iglesia Bautista de', 'Carolina', '', 'Carolina', 3, NULL, '2014-03-04 15:14:57.17361', '2014-03-04 15:14:57.17361');
INSERT INTO churches VALUES (26, 27, 0, 'Iglesia Bautista de', 'Cedros', '', 'Carolina', 2, NULL, '2014-03-04 15:14:57.174724', '2014-03-04 15:14:57.174724');
INSERT INTO churches VALUES (27, 22, 0, 'Iglesia Bautista ', 'Los Ángeles', 'Los Ángeles', 'Carolina', 1, NULL, '2014-03-04 15:14:57.175774', '2014-03-04 15:14:57.175774');
INSERT INTO churches VALUES (28, 71, 0, 'Iglesia Bautista', 'Luz de Salvación de Buenaventura', '', 'Carolina', 3, NULL, '2014-03-04 15:14:57.176893', '2014-03-04 15:14:57.176893');
INSERT INTO churches VALUES (29, 77, 0, 'Iglesia Bautista de', 'Metrópolis', '', 'Carolina', 3, NULL, '2014-03-04 15:14:57.177967', '2014-03-04 15:14:57.177967');
INSERT INTO churches VALUES (30, 80, 0, 'Iglesia Bautista ', 'Oasis de Bendición', 'Villa Fontana', 'Carolina', 3, NULL, '2014-03-04 15:14:57.179014', '2014-03-04 15:14:57.179014');
INSERT INTO churches VALUES (31, 97, 0, 'Iglesia Bautista de', 'Rolling Hills', '', 'Carolina', 1, NULL, '2014-03-04 15:14:57.180067', '2014-03-04 15:14:57.180067');
INSERT INTO churches VALUES (32, 101, 0, 'Iglesia Bautista de', 'San Antón', '', 'Carolina', 3, NULL, '2014-03-04 15:14:57.181115', '2014-03-04 15:14:57.181115');
INSERT INTO churches VALUES (33, 26, 1, 'Iglesia Bautista de', 'Cayey', 'Montellano', 'Cayey', 3, NULL, '2014-03-04 15:14:57.182157', '2014-03-04 15:14:57.182157');
INSERT INTO churches VALUES (34, 106, 0, 'Iglesia Bautista de', 'Toíta', '', 'Cayey', 2, NULL, '2014-03-04 15:14:57.183256', '2014-03-04 15:14:57.183256');
INSERT INTO churches VALUES (35, 67, 0, 'Iglesia Bautista ', 'Las Vegas-Farallón Unida', '', 'Cayey', 2, NULL, '2014-03-04 15:14:57.184309', '2014-03-04 15:14:57.184309');
INSERT INTO churches VALUES (36, 30, 1, 'Iglesia Bautista de', 'Cidra', '', 'Cidra', 3, NULL, '2014-03-04 15:14:57.185366', '2014-03-04 15:14:57.185366');
INSERT INTO churches VALUES (37, 31, 2, 'Iglesia Bautista de', 'Cidra', '', 'Cidra', 2, NULL, '2014-03-04 15:14:57.186414', '2014-03-04 15:14:57.186414');
INSERT INTO churches VALUES (38, 61, 0, 'Iglesia Bautista ', 'La Nueva Ebenezer', 'Rincón', 'Cidra', 2, NULL, '2014-03-04 15:14:57.187483', '2014-03-04 15:14:57.187483');
INSERT INTO churches VALUES (39, 32, 1, 'Iglesia Bautista de', 'Coamo', '', 'Coamo', 2, NULL, '2014-03-04 15:14:57.188544', '2014-03-04 15:14:57.188544');
INSERT INTO churches VALUES (40, 33, 1, 'Bautista de', 'Corozal', '', 'Corozal', 1, NULL, '2014-03-04 15:14:57.189609', '2014-03-04 15:14:57.189609');
INSERT INTO churches VALUES (41, 37, 1, 'Iglesia Bautista de', 'Dorado', '', 'Dorado', 3, NULL, '2014-03-04 15:14:57.190879', '2014-03-04 15:14:57.190879');
INSERT INTO churches VALUES (42, 44, 1, 'Iglesia Bautista de', 'Fajardo', '', 'Fajardo', 3, NULL, '2014-03-04 15:14:57.19201', '2014-03-04 15:14:57.19201');
INSERT INTO churches VALUES (43, 62, 0, 'Iglesia Bautista', 'La Nueva Jerusalén', '', 'Fajardo', 1, NULL, '2014-03-04 15:14:57.193105', '2014-03-04 15:14:57.193105');
INSERT INTO churches VALUES (46, 47, 0, 'Iglesia Bautista de', 'Guayama Corazón', 'Corazón', 'Guayama', 1, NULL, '2014-03-04 15:14:57.19531', '2014-03-04 15:14:57.19531');
INSERT INTO churches VALUES (47, 48, 0, 'Iglesia Bautista de', 'Guayanilla', '', 'Guayanilla', 2, NULL, '2014-03-04 15:14:57.196359', '2014-03-04 15:14:57.196359');
INSERT INTO churches VALUES (48, 49, 0, 'Iglesia Bautista de', 'Guaynabo', '', 'Guaynabo', 3, NULL, '2014-03-04 15:14:57.197405', '2014-03-04 15:14:57.197405');
INSERT INTO churches VALUES (50, 28, 0, 'Iglesia Bautista de', 'Celada', '', 'Gurabo', 2, NULL, '2014-03-04 15:14:57.199499', '2014-03-04 15:14:57.199499');
INSERT INTO churches VALUES (51, 40, 0, 'Iglesia Bautista de', 'El Cielito', 'Navarro', 'Gurabo', 3, NULL, '2014-03-04 15:14:57.200591', '2014-03-04 15:14:57.200591');
INSERT INTO churches VALUES (52, 38, 0, 'Iglesia Bautista ', 'Ebenezer', '', 'Gurabo', 2, NULL, '2014-03-04 15:14:57.201707', '2014-03-04 15:14:57.201707');
INSERT INTO churches VALUES (53, 50, 1, 'Iglesia Bautista de', 'Gurabo', '', 'Gurabo', 3, NULL, '2014-03-04 15:14:57.202808', '2014-03-04 15:14:57.202808');
INSERT INTO churches VALUES (55, 52, 0, 'Iglesia Bautista de', 'Hato Nuevo', '', 'Gurabo', 3, NULL, '2014-03-04 15:14:57.204994', '2014-03-04 15:14:57.204994');
INSERT INTO churches VALUES (56, 73, 0, 'Iglesia Bautista de', 'Mamey', '', 'Gurabo', 3, NULL, '2014-03-04 15:14:57.20605', '2014-03-04 15:14:57.20605');
INSERT INTO churches VALUES (57, 74, 0, 'Iglesia Bautista de', 'Masas II', '', 'Gurabo', 1, NULL, '2014-03-04 15:14:57.207092', '2014-03-04 15:14:57.207092');
INSERT INTO churches VALUES (58, 54, 0, 'Iglesia Bautista de', 'Humacao', '', 'Humacao', 3, NULL, '2014-03-04 15:14:57.208231', '2014-03-04 15:14:57.208231');
INSERT INTO churches VALUES (59, 59, 0, 'Iglesia Bautista ', 'La Ciudad Deseada', 'Cantagallo', 'Juncos', 1, NULL, '2014-03-04 15:14:57.209269', '2014-03-04 15:14:57.209269');
INSERT INTO churches VALUES (60, 58, 1, 'Iglesia Bautista de', 'Juncos', '', 'Juncos', 3, NULL, '2014-03-04 15:14:57.210329', '2014-03-04 15:14:57.210329');
INSERT INTO churches VALUES (61, 63, 0, 'Iglesia Bautista ', 'La Placita', '', 'Juncos', 0, NULL, '2014-03-04 15:14:57.211396', '2014-03-04 15:14:57.211396');
INSERT INTO churches VALUES (62, 81, 0, 'Iglesia Bautista ', 'Oasis de Paz', 'Lirios', 'Juncos', 1, NULL, '2014-03-04 15:14:57.212605', '2014-03-04 15:14:57.212605');
INSERT INTO churches VALUES (63, 25, 0, 'Iglesia Bautista de', 'Castañer', '', 'Lares', 1, NULL, '2014-03-04 15:14:57.213668', '2014-03-04 15:14:57.213668');
INSERT INTO churches VALUES (64, 66, 0, 'Iglesia Bautista de', 'Las Piedras', 'Arenas', 'Las Piedras', 1, NULL, '2014-03-04 15:14:57.214743', '2014-03-04 15:14:57.214743');
INSERT INTO churches VALUES (65, 96, 0, 'Iglesia Bautista ', 'Restauración Las Piedras', '', 'Las Piedras', 3, NULL, '2014-03-04 15:14:57.215784', '2014-03-04 15:14:57.215784');
INSERT INTO churches VALUES (66, 76, 0, 'Iglesia Bautista de', 'Medianía Alta', '', 'Loíza', 0, NULL, '2014-03-04 15:14:57.21683', '2014-03-04 15:14:57.21683');
INSERT INTO churches VALUES (67, 68, 0, 'Iglesia Bautista de', 'Loí­za', '', 'Loíza', 2, NULL, '2014-03-04 15:14:57.218024', '2014-03-04 15:14:57.218024');
INSERT INTO churches VALUES (68, 109, 0, 'Iglesia Bautista de', 'Villas de Loíza', '', 'Canóvanas', 2, NULL, '2014-03-04 15:14:57.219064', '2014-03-04 15:14:57.219064');
INSERT INTO churches VALUES (69, 57, 0, 'Iglesia Bautista de', 'Jerusalén', 'Mata de Plátano', 'Luquillo', 3, NULL, '2014-03-04 15:14:57.220107', '2014-03-04 15:14:57.220107');
INSERT INTO churches VALUES (70, 70, 0, 'Iglesia Bautista de', 'Luquillo Mar', '', 'Luquillo', 3, NULL, '2014-03-04 15:14:57.221156', '2014-03-04 15:14:57.221156');
INSERT INTO churches VALUES (71, 75, 0, 'Iglesia Bautista de', 'Mayagüez', '', 'Mayagüez', 1, NULL, '2014-03-04 15:14:57.222209', '2014-03-04 15:14:57.222209');
INSERT INTO churches VALUES (72, 78, 0, 'Iglesia Bautista de', 'Morovis', '', 'Morovis', 1, NULL, '2014-03-04 15:14:57.223646', '2014-03-04 15:14:57.223646');
INSERT INTO churches VALUES (75, 82, 1, 'Iglesia Bautista de', 'Orocovis', '', 'Orocovis', 2, NULL, '2014-03-04 15:14:57.225185', '2014-03-04 15:14:57.225185');
INSERT INTO churches VALUES (76, 86, 1, 'Iglesia Bautista de', 'Ponce', '', 'Ponce', 1, NULL, '2014-03-04 15:14:57.226479', '2014-03-04 15:14:57.226479');
INSERT INTO churches VALUES (49, 108, NULL, 'Iglesia Bautista', 'Unida El Salvador', 'Monacillos', 'San Juan', 2, '', '2014-03-04 15:14:57.198448', '2014-03-07 14:48:32.269695');
INSERT INTO churches VALUES (77, 85, 0, 'Primera Iglesia Bautista', 'Playa de Ponce', '', 'Ponce', 2, NULL, '2014-03-04 15:14:57.227659', '2014-03-04 15:14:57.227659');
INSERT INTO churches VALUES (78, 34, 0, 'Iglesia Bautista de', 'Corral Viejo', '', 'Ponce', 1, NULL, '2014-03-04 15:14:57.228907', '2014-03-04 15:14:57.228907');
INSERT INTO churches VALUES (79, 87, 2, 'Iglesia Bautista de', 'Ponce', '', 'Ponce', 0, NULL, '2014-03-04 15:14:57.23001', '2014-03-04 15:14:57.23001');
INSERT INTO churches VALUES (80, 88, 3, 'Iglesia Bautista de', 'Ponce', '', 'Ponce', 3, NULL, '2014-03-04 15:14:57.231249', '2014-03-04 15:14:57.231249');
INSERT INTO churches VALUES (81, 64, 0, 'Iglesia Bautista ', 'La Roca', '', 'Quebradillas', 0, NULL, '2014-03-04 15:14:57.232327', '2014-03-04 15:14:57.232327');
INSERT INTO churches VALUES (82, 14, 0, 'Iglesia Bautista ', 'Bethel', 'Malpica', 'Río Grande', 3, NULL, '2014-03-04 15:14:57.233418', '2014-03-04 15:14:57.233418');
INSERT INTO churches VALUES (83, 51, 0, 'Iglesia Bautista de', 'Guzmán Arriba', '', 'Río Grande', 2, NULL, '2014-03-04 15:14:57.234484', '2014-03-04 15:14:57.234484');
INSERT INTO churches VALUES (84, 83, 0, 'Iglesia Bautista de', 'Palmer', '', 'Río Grande', 3, NULL, '2014-03-04 15:14:57.235609', '2014-03-04 15:14:57.235609');
INSERT INTO churches VALUES (85, 93, 1, 'Iglesia Bautista de', 'Rí­o Grande', '', 'Río Grande', 3, NULL, '2014-03-04 15:14:57.236668', '2014-03-04 15:14:57.236668');
INSERT INTO churches VALUES (86, 102, 0, 'Iglesia Bautista de', 'San Lorenzo', '', 'San Lorenzo', 2, NULL, '2014-03-04 15:14:57.237762', '2014-03-04 15:14:57.237762');
INSERT INTO churches VALUES (87, 55, 0, 'Iglesia Bautista de', 'Jagual', '', 'San Lorenzo', 1, NULL, '2014-03-04 15:14:57.238806', '2014-03-04 15:14:57.238806');
INSERT INTO churches VALUES (89, 21, 0, 'Iglesia Bautista de', 'Carraí­zo', '', 'Trujillo Alto', 2, NULL, '2014-03-04 15:14:57.239854', '2014-03-04 15:14:57.239854');
INSERT INTO churches VALUES (90, 41, 0, 'Iglesia Bautista ', 'El Lago', '', 'Trujillo Alto', 2, NULL, '2014-03-04 15:14:57.240889', '2014-03-04 15:14:57.240889');
INSERT INTO churches VALUES (91, 72, 0, 'Iglesia Bautista ', 'Luz del Mundo', '', 'Trujillo Alto', 3, NULL, '2014-03-04 15:14:57.24196', '2014-03-04 15:14:57.24196');
INSERT INTO churches VALUES (92, 100, 0, 'Iglesia Bautista de', 'Saint Just', '', 'Trujillo Alto', 0, NULL, '2014-03-04 15:14:57.243014', '2014-03-04 15:14:57.243014');
INSERT INTO churches VALUES (93, 104, 0, 'Iglesia Bautista de', 'Sión', 'Quebrada Negrito', 'Trujillo Alto', 2, NULL, '2014-03-04 15:14:57.244093', '2014-03-04 15:14:57.244093');
INSERT INTO churches VALUES (94, 107, 0, 'Iglesia Bautista de', 'Trujillo Alto', '', 'Trujillo Alto', 2, NULL, '2014-03-04 15:14:57.245144', '2014-03-04 15:14:57.245144');
INSERT INTO churches VALUES (95, 12, 0, 'Iglesia Bautista ', 'Berea', '', 'Yabucoa', 0, NULL, '2014-03-04 15:14:57.246182', '2014-03-04 15:14:57.246182');
INSERT INTO churches VALUES (96, 110, 1, 'Iglesia Bautista de', 'Yabucoa', 'Juan Martí­n', 'Yabucoa', 2, NULL, '2014-03-04 15:14:57.247256', '2014-03-04 15:14:57.247256');
INSERT INTO churches VALUES (97, 3, 0, 'Iglesia Bautista de', 'Almácigo', '', 'Yauco', 1, NULL, '2014-03-04 15:14:57.248334', '2014-03-04 15:14:57.248334');
INSERT INTO churches VALUES (98, 24, 0, 'Iglesia Bautista ', 'Casa de Oración de Carrizales', '', 'Yauco', 2, NULL, '2014-03-04 15:14:57.249377', '2014-03-04 15:14:57.249377');
INSERT INTO churches VALUES (99, 112, 1, 'Iglesia Bautista de', 'Yauco', 'Jácanas', 'Yauco', 3, NULL, '2014-03-04 15:14:57.250432', '2014-03-04 15:14:57.250432');
INSERT INTO churches VALUES (100, 4, 0, 'Iglesia Bautista de', 'Altamesa', '', 'San Juan', 1, NULL, '2014-03-04 15:14:57.251482', '2014-03-04 15:14:57.251482');
INSERT INTO churches VALUES (102, 13, 0, 'Iglesia Bautista ', 'Betesda', '', 'San Juan', 2, NULL, '2014-03-04 15:14:57.25251', '2014-03-04 15:14:57.25251');
INSERT INTO churches VALUES (103, 35, 0, 'Iglesia Bautista de', 'Country Club', '', 'San Juan', 3, NULL, '2014-03-04 15:14:57.253565', '2014-03-04 15:14:57.253565');
INSERT INTO churches VALUES (105, 45, 0, 'Iglesia Bautista ', 'Getsemaní­ de Colinas Verdes', '', 'San Juan', 2, NULL, '2014-03-04 15:14:57.254678', '2014-03-04 15:14:57.254678');
INSERT INTO churches VALUES (106, 89, 0, 'Iglesia Bautista de', 'Puerta de Tierra', '', 'San Juan', 2, NULL, '2014-03-04 15:14:57.255795', '2014-03-04 15:14:57.255795');
INSERT INTO churches VALUES (107, 90, 0, 'Iglesia Bautista de', 'Puerto Nuevo', '', 'San Juan', 3, NULL, '2014-03-04 15:14:57.256852', '2014-03-04 15:14:57.256852');
INSERT INTO churches VALUES (108, 92, 0, 'Iglesia Bautista de', 'Quintana', '', 'San Juan', 3, NULL, '2014-03-04 15:14:57.257902', '2014-03-04 15:14:57.257902');
INSERT INTO churches VALUES (109, 94, 1, 'Iglesia Bautista de', 'Rí­o Piedras', '', 'San Juan', 3, NULL, '2014-03-04 15:14:57.25895', '2014-03-04 15:14:57.25895');
INSERT INTO churches VALUES (110, 98, 0, 'Iglesia Bautista de', 'Roosevelt', '', 'San Juan', 2, NULL, '2014-03-04 15:14:57.259999', '2014-03-04 15:14:57.259999');
INSERT INTO churches VALUES (111, 99, 0, 'Iglesia Bautista de', 'Sabana Llana', '', 'San Juan', 1, NULL, '2014-03-04 15:14:57.261054', '2014-03-04 15:14:57.261054');
INSERT INTO churches VALUES (112, 103, 1, 'Iglesia Bautista de', 'Santurce', '', 'San Juan', 2, NULL, '2014-03-04 15:14:57.262093', '2014-03-04 15:14:57.262093');
INSERT INTO churches VALUES (113, 29, 0, 'Iglesia Bautista', 'Central de Villa Las Lomas', '', 'San Juan', 2, NULL, '2014-03-04 15:14:57.263151', '2014-03-04 15:14:57.263151');
INSERT INTO churches VALUES (114, 23, 0, 'Iglesia Bautista', 'Casa de Dios', 'Santa Cruz', 'Islas Vírgenes', 1, NULL, '2014-03-04 15:14:57.264209', '2014-03-04 15:14:57.264209');
INSERT INTO churches VALUES (116, 56, 0, 'Iglesia Bautista de', 'Jaguas', '', 'Gurabo', 1, NULL, '2014-03-04 15:14:57.265303', '2014-03-04 15:14:57.265303');
INSERT INTO churches VALUES (117, 105, 0, 'Iglesia Bautista de ', 'Sinaí Guánica', '', 'Guánica', 2, NULL, '2014-03-04 15:14:57.266333', '2014-03-04 15:14:57.266333');
INSERT INTO churches VALUES (118, 0, 0, '', 'Junta Directiva UJBPR', '', '', 0, NULL, '2014-03-04 15:14:57.26738', '2014-03-04 15:14:57.26738');
INSERT INTO churches VALUES (119, 0, 0, '', 'Ministerios de Mujeres Bautistas de PR', '', '', 0, NULL, '2014-03-04 15:14:57.268461', '2014-03-04 15:14:57.268461');
INSERT INTO churches VALUES (120, 0, 0, '', 'Ministerio de Hombres Bautistas de PR', '', '', 0, NULL, '2014-03-04 15:14:57.269571', '2014-03-04 15:14:57.269571');
INSERT INTO churches VALUES (121, 0, 0, '', 'Concilio Ministerial', '', '', 0, NULL, '2014-03-04 15:14:57.270659', '2014-03-04 15:14:57.270659');
INSERT INTO churches VALUES (122, 0, 0, '', 'Ministerios Adultos Mayores', '', '', 0, NULL, '2014-03-04 15:14:57.271711', '2014-03-04 15:14:57.271711');
INSERT INTO churches VALUES (123, 39, 0, 'Iglesia Bautista de', 'Ebenezer de Levittown Lakes', '', 'Toa Baja', 0, NULL, '2014-03-04 15:14:57.272752', '2014-03-04 15:14:57.272752');
INSERT INTO churches VALUES (124, 79, 1, 'Iglesia Bautista de', 'Naguabo', '', 'Naguabo', 0, NULL, '2014-03-04 15:14:57.273831', '2014-03-04 15:14:57.273831');
INSERT INTO churches VALUES (125, 8, 1, 'Iglesia Bautista de', 'Barrio Obrero', '', 'San Juan', 0, NULL, '2014-03-04 15:14:57.274898', '2014-03-04 15:14:57.274898');
INSERT INTO churches VALUES (126, 113, 0, 'Iglesia Bautista de', 'Faro de Luz', '', 'Río Grande', 0, NULL, '2014-03-04 15:14:57.275971', '2014-03-04 15:14:57.275971');
INSERT INTO churches VALUES (1, 18, 0, 'Iglesia Bautista de', 'Campo Rico', NULL, 'Canóvanas', 0, NULL, '2014-03-05 12:19:16.930414', '2014-03-05 12:20:01.832083');
INSERT INTO churches VALUES (54, 91, NULL, 'Iglesia Bautista de', 'Quebrada', '', 'Gurabo', 1, '', '2014-03-04 15:14:57.203929', '2015-02-28 19:25:41.256119');
INSERT INTO churches VALUES (45, 46, 1, 'Iglesia Bautista de', 'Guayama', '', 'Guayama', 2, '', '2014-03-04 15:14:57.194239', '2015-02-28 19:25:58.59266');
INSERT INTO churches VALUES (127, NULL, 1, 'Iglesia Bautista de', 'Maunabo', '', 'Maunabo', 0, NULL, '2015-03-05 16:46:20.605412', '2015-03-05 16:46:20.605412');


--
-- Name: churches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marcel
--

SELECT pg_catalog.setval('churches_id_seq', 127, true);


--
-- Data for Name: people; Type: TABLE DATA; Schema: public; Owner: marcel
--

INSERT INTO people VALUES (305, 1, 'Luz C.', 'Abreu', false, 3, '', false, true, false, 90, '2015-03-02 19:20:31.7761', '2015-03-02 19:22:07.720385');
INSERT INTO people VALUES (458, 0, 'Rodolfo', 'Castillo', true, 3, '', true, true, true, 48, '2015-03-04 21:30:50.350742', '2015-03-05 12:23:54.429761');
INSERT INTO people VALUES (158, NULL, 'Fernando ', 'Barreto Cardona ', true, 3, '', true, true, true, 25, '2015-02-24 13:32:55.491074', '2015-03-05 12:54:20.960318');
INSERT INTO people VALUES (532, 0, 'Miguel ', 'Bonnet ', true, 5, 'Representante de las IBRD de IBaredo', true, true, true, NULL, '2015-03-05 14:05:36.999307', '2015-03-05 14:14:00.223351');
INSERT INTO people VALUES (319, NULL, 'Lilliam', 'Mas Birriel', false, 3, '', true, true, true, 49, '2015-03-02 19:34:27.418925', '2015-03-05 13:04:54.998608');
INSERT INTO people VALUES (534, NULL, 'Karen', 'Rosado', false, 3, '', true, true, true, 5, '2015-03-05 14:11:42.914838', '2015-03-05 14:14:00.352855');
INSERT INTO people VALUES (301, NULL, 'Sonia ', 'Nieves ', true, 1, '', true, true, true, 85, '2015-03-02 19:18:34.403674', '2015-03-05 14:18:34.88871');
INSERT INTO people VALUES (527, NULL, 'Ramón O.', 'Martínez', true, 5, 'Comité Organizador', true, true, true, 12, '2015-03-05 13:44:27.324028', '2015-03-05 13:44:52.842515');
INSERT INTO people VALUES (94, 0, 'Mario ', 'Rodas ', true, 0, '', true, true, true, 59, '2015-02-24 02:24:44.088983', '2015-03-05 12:26:05.592381');
INSERT INTO people VALUES (1, 1, 'Roy ', 'Acosta ', true, 0, '', true, true, true, 108, '2015-02-23 22:21:49.889093', '2015-03-05 12:14:03.594369');
INSERT INTO people VALUES (315, NULL, 'Carlos W.', 'Filippetti', true, 3, '', true, true, true, 80, '2015-03-02 19:32:08.017509', '2015-03-05 12:57:12.514347');
INSERT INTO people VALUES (303, NULL, 'Mayra ', 'Rivera ', false, 3, '', true, true, true, 85, '2015-03-02 19:19:17.181209', '2015-03-05 12:28:41.550643');
INSERT INTO people VALUES (459, NULL, 'Alma', 'Maldonado', false, 3, '', true, true, true, 48, '2015-03-04 21:31:38.650802', '2015-03-05 12:28:56.025192');
INSERT INTO people VALUES (302, NULL, 'Ana ', 'Diaz ', false, 3, '', true, true, true, 85, '2015-03-02 19:18:55.910737', '2015-03-05 12:16:54.632955');
INSERT INTO people VALUES (308, NULL, 'Aida B.', 'Cruz ', false, 3, '', true, true, true, 51, '2015-03-02 19:26:14.724721', '2015-03-05 13:07:13.184357');
INSERT INTO people VALUES (353, 0, 'Pedro', 'Boria Ortiz', true, 1, '', false, true, false, 55, '2015-03-04 11:05:18.260131', '2015-03-04 20:52:30.295598');
INSERT INTO people VALUES (354, NULL, 'Ramón', 'García', true, 3, '', true, true, true, 55, '2015-03-04 11:05:35.219957', '2015-03-06 12:30:16.819936');
INSERT INTO people VALUES (460, NULL, 'Damaris', 'Pizarro', false, 3, '', true, true, true, 48, '2015-03-04 21:32:21.357256', '2015-03-05 12:34:06.485574');
INSERT INTO people VALUES (316, NULL, 'Daisy ', 'Cruz Torres', false, 3, '', true, true, true, 80, '2015-03-02 19:32:29.77724', '2015-03-05 12:57:17.910709');
INSERT INTO people VALUES (368, 1, 'Francisco ', 'Ortiz', true, 5, 'Presidente, Universidad Teológica del Caribe', false, true, false, NULL, '2015-03-04 19:27:33.555304', '2015-03-04 19:36:17.915003');
INSERT INTO people VALUES (314, 1, 'Jaime ', 'Galarza Sierra', true, 4, 'Representante Distrito', true, true, true, 80, '2015-03-02 19:31:39.242967', '2015-03-05 12:57:21.400301');
INSERT INTO people VALUES (323, NULL, 'Anamaría', 'Gallardo', false, 3, '', true, true, true, 102, '2015-03-02 19:43:37.463487', '2015-03-05 12:36:44.364676');
INSERT INTO people VALUES (352, 1, 'Luis F.', 'Alicea Caraballo', true, 0, '', true, true, true, 55, '2015-03-04 11:04:46.844147', '2015-03-05 15:04:17.527836');
INSERT INTO people VALUES (449, NULL, 'José', 'Martínez', true, 5, 'Logos', false, true, false, NULL, '2015-03-04 20:16:29.018027', '2015-03-04 20:19:56.656612');
INSERT INTO people VALUES (450, NULL, 'Danny', 'Martinez', true, 5, 'Seguros Danny Martinez', false, true, false, NULL, '2015-03-04 20:16:37.986405', '2015-03-04 20:19:56.66386');
INSERT INTO people VALUES (452, NULL, 'Leo S.', 'Thorn', true, 5, 'Associate General Sec. ABC', false, true, false, NULL, '2015-03-04 20:18:41.617982', '2015-03-04 20:19:56.675956');
INSERT INTO people VALUES (453, 1, 'Roy', 'Medley', true, 5, 'Secretario General ABC', false, true, false, NULL, '2015-03-04 20:19:56.100619', '2015-03-04 20:21:00.239263');
INSERT INTO people VALUES (356, NULL, 'Maribel', 'Boria', false, 3, '', true, true, true, 55, '2015-03-04 11:06:18.367635', '2015-03-05 11:50:06.023029');
INSERT INTO people VALUES (371, 1, 'Ingrid', 'Roldán', false, 5, 'Misionera en Panamá', true, true, true, NULL, '2015-03-04 19:35:02.98798', '2015-03-05 11:13:53.883716');
INSERT INTO people VALUES (372, NULL, 'José', 'Candelaria', true, 4, 'Tesorero', true, true, true, NULL, '2015-03-04 19:35:09.740009', '2015-03-05 13:08:20.418143');
INSERT INTO people VALUES (376, NULL, 'Brunilda', 'Gónzalez', false, 4, 'Secretaria', true, true, true, 58, '2015-03-04 19:36:34.458007', '2015-03-05 11:19:58.14752');
INSERT INTO people VALUES (135, NULL, 'Irving ', 'Rivera ', true, 3, '', true, true, true, 23, '2015-02-24 02:52:29.814474', '2015-03-05 11:55:07.159825');
INSERT INTO people VALUES (173, 0, 'Margarita ', 'Santana ', false, 0, '', true, true, true, 24, '2015-02-24 14:00:34.174153', '2015-03-05 11:31:21.549503');
INSERT INTO people VALUES (313, NULL, 'Ramón', 'Negrón', true, 3, '', true, true, true, 2, '2015-03-02 19:30:39.762878', '2015-03-05 12:18:38.610046');
INSERT INTO people VALUES (12, NULL, 'Mary Leen ', 'Marrero', false, 3, '', true, true, true, 103, '2015-02-24 01:18:51.363156', '2015-03-05 11:33:33.959336');
INSERT INTO people VALUES (461, NULL, 'Virgina', 'Laporte', false, 3, '', true, true, true, 72, '2015-03-05 11:10:56.890901', '2015-03-05 11:40:43.251883');
INSERT INTO people VALUES (462, NULL, 'Maria', 'Estela', false, 3, '', true, true, true, 72, '2015-03-05 11:11:28.821418', '2015-03-05 11:40:43.360009');
INSERT INTO people VALUES (463, 0, 'Luz D.', 'Rivera', false, 0, '', true, true, true, 72, '2015-03-05 11:12:16.885277', '2015-03-05 11:40:43.364546');
INSERT INTO people VALUES (307, NULL, 'Lizette ', 'Vázquez ', false, 0, '', true, true, true, 51, '2015-03-02 19:25:50.298034', '2015-03-05 11:55:58.83656');
INSERT INTO people VALUES (355, NULL, 'Julio', 'Fuentes', true, 3, '', true, true, true, 55, '2015-03-04 11:05:56.397368', '2015-03-05 11:46:36.339818');
INSERT INTO people VALUES (312, 0, 'Carlos I.', 'López ', true, 0, '', true, true, true, 2, '2015-03-02 19:30:21.919239', '2015-03-05 12:18:40.29206');
INSERT INTO people VALUES (322, 0, 'Eva ', 'Agosto', false, 0, '', true, true, true, 102, '2015-03-02 19:42:38.81102', '2015-03-05 12:37:00.026507');
INSERT INTO people VALUES (311, NULL, 'José M.', 'Colón', true, 3, '', true, true, true, 51, '2015-03-02 19:27:20.512037', '2015-03-05 11:58:33.37424');
INSERT INTO people VALUES (446, 0, 'Felipe', 'Candelaria', true, 4, 'Representante en ABC', true, true, true, NULL, '2015-03-04 20:12:48.643667', '2015-03-05 12:19:29.204303');
INSERT INTO people VALUES (310, NULL, 'Adalberto', 'Barbosa', false, 3, '', true, true, true, 51, '2015-03-02 19:26:55.393258', '2015-03-05 11:58:59.686401');
INSERT INTO people VALUES (95, NULL, 'Maribel ', 'González ', false, 3, '', true, true, true, 59, '2015-02-24 02:25:06.878867', '2015-03-05 13:02:41.292226');
INSERT INTO people VALUES (343, 1, 'Ruth A.', 'Martínez', false, 4, 'Representante General', true, true, true, 58, '2015-03-04 10:57:00.490612', '2015-03-05 12:02:47.665433');
INSERT INTO people VALUES (344, 1, 'Clemente', 'Flores', true, 1, '', true, true, true, 58, '2015-03-04 10:57:43.865004', '2015-03-05 12:50:37.994082');
INSERT INTO people VALUES (346, 0, 'Carmen W.', 'Lebrón', false, 1, '', true, true, true, 58, '2015-03-04 11:00:06.930223', '2015-03-05 12:03:23.290504');
INSERT INTO people VALUES (309, NULL, 'Nilza ', 'Rivera ', false, 3, '', true, true, true, 51, '2015-03-02 19:26:35.216231', '2015-03-05 12:04:58.348317');
INSERT INTO people VALUES (378, 1, 'Julio', 'Gónzalez', true, 4, 'Vocal', true, true, true, NULL, '2015-03-04 19:39:38.442108', '2015-03-05 13:28:50.053977');
INSERT INTO people VALUES (318, NULL, 'José M. ', 'Birriel', true, 3, '', true, true, true, 49, '2015-03-02 19:33:54.654529', '2015-03-05 13:04:37.222485');
INSERT INTO people VALUES (320, NULL, 'Ivonne ', 'Díaz Lombardo', false, 3, '', true, true, true, 49, '2015-03-02 19:36:14.365341', '2015-03-05 13:04:47.34855');
INSERT INTO people VALUES (524, NULL, 'Carlos', 'Nuñez', true, 0, 'misión patillas', true, true, true, 112, '2015-03-05 13:36:13.035129', '2015-03-05 13:44:52.815782');
INSERT INTO people VALUES (525, 0, 'Rosa', 'Meléndez Hesford', false, 0, '', true, true, true, 108, '2015-03-05 13:38:35.024048', '2015-03-05 13:44:52.824878');
INSERT INTO people VALUES (526, NULL, 'Olga', 'Quiñones', false, 5, '', true, true, true, 84, '2015-03-05 13:40:27.940214', '2015-03-05 13:44:52.834634');
INSERT INTO people VALUES (528, NULL, 'Carmen ', 'Quiros', false, 3, '', true, true, true, 78, '2015-03-05 13:50:47.132906', '2015-03-05 13:57:56.291484');
INSERT INTO people VALUES (529, NULL, 'Saribel', 'Sánchez', false, 3, '', true, true, true, 19, '2015-03-05 13:50:49.028085', '2015-03-05 13:57:56.495986');
INSERT INTO people VALUES (530, 0, 'Adelaida', 'Vázquez', false, 5, 'Misión Bautista Puente de Salvación', true, true, true, NULL, '2015-03-05 13:51:06.695452', '2015-03-05 13:57:56.505145');
INSERT INTO people VALUES (531, 3, 'Juan', 'León', true, 5, 'Parlamentarista', true, true, true, NULL, '2015-03-05 13:56:09.235463', '2015-03-05 13:57:56.517391');
INSERT INTO people VALUES (304, NULL, 'Judith ', 'Castro', false, 3, '', true, true, true, 85, '2015-03-02 19:19:39.72653', '2015-03-05 14:06:36.813682');
INSERT INTO people VALUES (374, 1, 'Madeline', 'Flores', false, 5, 'Misionera en República Dominicana', true, true, true, NULL, '2015-03-04 19:36:12.138507', '2015-03-05 14:02:41.835937');
INSERT INTO people VALUES (533, 0, 'José', 'Ortiz Charriez', true, 0, '', true, true, true, 5, '2015-03-05 14:10:04.559612', '2015-03-05 14:14:00.340747');
INSERT INTO people VALUES (106, 0, 'Miguel A. ', 'Sánchez ', true, 1, '', true, true, true, 52, '2015-02-24 02:31:01.728234', '2015-03-05 14:13:14.264898');
INSERT INTO people VALUES (300, 1, 'Miguel ', 'Acosta ', true, 0, '', true, true, true, 85, '2015-03-02 19:17:29.658572', '2015-03-05 14:07:11.246103');
INSERT INTO people VALUES (451, NULL, 'Jim ', 'Wiegner', true, 5, 'Ministerios Internacionales', false, true, false, NULL, '2015-03-04 20:17:52.985921', '2015-03-05 14:14:00.348329');
INSERT INTO people VALUES (535, NULL, 'Jennifer', 'Rosado', false, 3, '', true, true, true, 5, '2015-03-05 14:13:41.265463', '2015-03-05 14:14:00.362305');
INSERT INTO people VALUES (536, NULL, 'Belkis', 'Gil', false, 5, 'Representante de las IBRD de IBaredo', true, true, true, NULL, '2015-03-05 14:14:55.178302', '2015-03-05 14:44:03.078455');
INSERT INTO people VALUES (448, 2, 'Manuel', 'Sarrias', true, 5, 'Ministro Ejecutivo España', true, true, true, NULL, '2015-03-04 20:15:42.059218', '2015-03-05 14:34:53.366429');
INSERT INTO people VALUES (380, 1, 'Dr. Daniel Luis ', 'Flores', true, 2, '', true, true, true, NULL, '2015-03-04 19:42:34.058117', '2015-03-05 15:05:06.323021');
INSERT INTO people VALUES (370, 1, 'Dra. Doris', 'García', true, 5, 'Presidenta, SEPR', true, true, true, NULL, '2015-03-04 19:34:30.906062', '2015-03-05 15:08:55.955588');
INSERT INTO people VALUES (373, 1, 'Deliris', 'Carrión', false, 5, 'Misionera en Haíti', true, true, true, NULL, '2015-03-04 19:35:40.2799', '2015-03-05 15:21:09.686484');
INSERT INTO people VALUES (321, 1, 'Carmen Z.', 'Díaz', false, 2, '', true, true, true, 77, '2015-03-02 19:41:17.833786', '2015-03-05 16:54:40.666629');
INSERT INTO people VALUES (549, 0, 'José', 'Torres', true, 0, '', true, true, true, 38, '2015-03-06 12:39:31.774863', '2015-03-06 12:40:21.560256');
INSERT INTO people VALUES (550, 0, 'Victor R.', 'Medina', true, 0, '', true, true, true, 46, '2015-03-06 12:41:18.183018', '2015-03-06 13:11:14.290426');
INSERT INTO people VALUES (551, NULL, 'Marcial ', 'Morales', true, 3, '', true, true, true, 46, '2015-03-06 12:41:53.058655', '2015-03-06 13:11:14.437537');
INSERT INTO people VALUES (369, 1, 'Heriberto', 'Martínez', true, 5, 'Secretario, SBPR', true, true, false, NULL, '2015-03-04 19:31:21.974401', '2015-03-06 13:51:52.719894');
INSERT INTO people VALUES (552, NULL, 'Maria A.', 'Molina', false, 3, '', true, true, true, 95, '2015-03-06 15:05:11.084802', '2015-03-06 15:30:22.258657');
INSERT INTO people VALUES (553, 1, 'Eddie', 'Cruz', true, 5, 'Director Asociado Ejecutivo ABC USA', true, true, true, NULL, '2015-03-06 15:30:48.911573', '2015-03-06 16:00:24.509812');
INSERT INTO people VALUES (226, 0, 'Hilda G.', 'Acosta Rivera', false, 0, '', true, true, true, 97, '2015-02-24 15:02:58.244599', '2015-03-05 11:21:25.429161');
INSERT INTO people VALUES (227, NULL, 'Sheyla ', 'Quiros Vazquez ', false, 3, '', true, true, true, 97, '2015-02-24 15:03:30.84962', '2015-03-05 12:44:12.857328');
INSERT INTO people VALUES (420, 0, 'Rafael', 'Rodriguez', true, 2, '', false, true, false, NULL, '2015-03-04 19:58:28.334312', '2015-03-04 21:20:59.57615');
INSERT INTO people VALUES (416, 0, 'Jose A.', 'Velasquez', true, 2, '', false, true, false, NULL, '2015-03-04 19:57:16.001068', '2015-03-04 21:22:12.485321');
INSERT INTO people VALUES (405, 1, 'Dr. Cristino', 'Diaz Montañez', true, 2, '', false, true, false, NULL, '2015-03-04 19:53:29.169968', '2015-03-04 21:17:41.750198');
INSERT INTO people VALUES (384, 1, 'Clodomiro', 'Crespo', true, 2, '', false, true, false, NULL, '2015-03-04 19:45:01.239306', '2015-03-04 19:47:19.087865');
INSERT INTO people VALUES (399, 1, 'Dr. Evaldo C.', 'Roura Ortiz', true, 2, '', false, true, false, NULL, '2015-03-04 19:51:53.742181', '2015-03-04 19:52:26.000355');
INSERT INTO people VALUES (389, 1, 'Irma Violeta', 'Cruz', false, 2, '', false, true, false, NULL, '2015-03-04 19:47:45.753261', '2015-03-04 19:50:22.399431');
INSERT INTO people VALUES (391, 1, 'Tomás', 'Rojas', true, 2, '', false, true, false, NULL, '2015-03-04 19:48:58.443066', '2015-03-04 19:50:22.462458');
INSERT INTO people VALUES (392, 1, 'Petra A.', 'Urbina', false, 2, '', false, true, false, NULL, '2015-03-04 19:49:24.950424', '2015-03-04 19:50:22.466864');
INSERT INTO people VALUES (394, 1, 'Miguel', 'Alvarado', true, 2, '', false, true, false, NULL, '2015-03-04 19:49:48.674176', '2015-03-04 19:50:22.482605');
INSERT INTO people VALUES (409, 1, 'Fela', 'Barrueto', false, 5, 'National Coodinator PRAM', false, true, false, NULL, '2015-03-04 19:55:04.161644', '2015-03-04 20:34:19.730849');
INSERT INTO people VALUES (395, 1, 'José F.', 'López', true, 2, '', false, true, false, NULL, '2015-03-04 19:50:20.385193', '2015-03-04 19:52:25.966816');
INSERT INTO people VALUES (396, 1, 'rafael', 'davila', true, 2, '', false, true, false, NULL, '2015-03-04 19:50:37.73566', '2015-03-04 19:52:25.973337');
INSERT INTO people VALUES (400, 0, 'Pedro', 'Parrilla', true, 2, '', false, true, false, NULL, '2015-03-04 19:52:22.289306', '2015-03-04 19:54:29.304023');
INSERT INTO people VALUES (402, 1, 'Dr. Héctor Manuel', 'Rivera', true, 2, '', false, true, false, NULL, '2015-03-04 19:52:46.470247', '2015-03-04 19:54:29.364653');
INSERT INTO people VALUES (403, 1, 'Daniel', 'Flores', true, 4, 'Representante Distrito', false, true, false, NULL, '2015-03-04 19:53:15.717243', '2015-03-04 19:54:29.370507');
INSERT INTO people VALUES (404, 1, 'José', 'Flores', true, 2, '', false, true, false, NULL, '2015-03-04 19:53:21.128695', '2015-03-04 19:54:29.379964');
INSERT INTO people VALUES (406, 1, 'Eva', 'Barreto', false, 2, '', false, true, false, NULL, '2015-03-04 19:53:39.96168', '2015-03-04 19:56:32.550672');
INSERT INTO people VALUES (407, 1, 'roberto', 'pabellon', true, 2, '', false, true, false, NULL, '2015-03-04 19:54:36.710823', '2015-03-04 19:56:32.875109');
INSERT INTO people VALUES (408, 1, 'Luis A.', 'Navarro', true, 2, '', false, true, false, NULL, '2015-03-04 19:54:57.360982', '2015-03-04 19:56:32.886626');
INSERT INTO people VALUES (410, 0, 'Rafael', 'Dávila', true, 2, '', false, true, false, NULL, '2015-03-04 19:55:26.102035', '2015-03-04 19:56:32.899249');
INSERT INTO people VALUES (415, 1, 'Dra. Julia', 'Batista', false, 2, '', false, true, false, NULL, '2015-03-04 19:57:11.327825', '2015-03-04 19:57:36.173455');
INSERT INTO people VALUES (171, NULL, 'Rebeca', 'Castro', false, 3, 'Sustituto', false, true, false, 20, '2015-02-24 13:56:21.984322', '2015-03-02 19:22:52.353402');
INSERT INTO people VALUES (287, 1, 'Efraín ', 'Rosario ', true, 0, '', false, true, false, 27, '2015-02-27 02:29:25.417229', '2015-03-02 19:22:52.380678');
INSERT INTO people VALUES (36, NULL, 'Vivian ', 'Pagán', false, 3, '', false, true, false, 107, '2015-02-24 01:44:56.280726', '2015-03-02 19:23:22.46378');
INSERT INTO people VALUES (333, NULL, 'Lourdes ', 'Santana', false, 3, '', true, true, true, 91, '2015-03-02 19:52:28.083547', '2015-03-05 10:56:29.932432');
INSERT INTO people VALUES (69, 0, 'Juan C. ', 'Navarro ', true, 4, 'Comisión de Mayordomía y Misiones', true, true, true, 37, '2015-02-24 02:06:47.609568', '2015-03-05 11:07:00.477653');
INSERT INTO people VALUES (286, 2, 'Alejandrina ', 'Ortiz ', false, 3, '', true, true, true, 119, '2015-02-25 14:50:38.256213', '2015-03-05 12:28:57.075013');
INSERT INTO people VALUES (290, NULL, 'María D.', 'Nuñez ', false, 3, '', true, true, true, 75, '2015-02-27 02:35:45.393998', '2015-03-05 11:16:09.020374');
INSERT INTO people VALUES (361, NULL, 'Ana R.', 'Torres Montañez', false, 3, '', true, true, true, 16, '2015-03-04 11:15:12.3003', '2015-03-05 11:40:12.550322');
INSERT INTO people VALUES (363, NULL, 'Gloria', 'Ríos Rolón', false, 3, '', true, true, true, 16, '2015-03-04 11:17:44.881599', '2015-03-05 11:43:55.118002');
INSERT INTO people VALUES (288, NULL, 'Rosa ', 'Capellán ', false, 3, '', true, true, true, 27, '2015-02-27 02:30:14.499799', '2015-03-05 15:17:11.811704');
INSERT INTO people VALUES (289, 1, 'Angel L. ', 'Pabellón', true, 0, '', true, true, true, 75, '2015-02-27 02:34:55.182295', '2015-03-05 11:54:20.972587');
INSERT INTO people VALUES (362, NULL, 'Pedro P.', 'Santiago Romero', true, 3, '', true, true, true, 16, '2015-03-04 11:17:12.15985', '2015-03-05 11:56:16.013534');
INSERT INTO people VALUES (401, NULL, 'Alfredo ', 'Laboy', true, 4, 'Representante Distrito', true, true, true, NULL, '2015-03-04 19:52:32.052594', '2015-03-05 11:58:34.006212');
INSERT INTO people VALUES (464, NULL, 'Marylin D.', 'Soto Quintana', false, 3, '', true, true, true, 27, '2015-03-05 11:50:43.333068', '2015-03-05 12:05:47.188118');
INSERT INTO people VALUES (338, NULL, 'Pedro J.', 'Morales', false, 3, '', true, true, true, 29, '2015-03-02 19:55:39.350618', '2015-03-05 12:00:53.477454');
INSERT INTO people VALUES (465, 1, 'Guillermo', 'Diaz', true, 0, '', true, true, true, 30, '2015-03-05 12:00:01.198987', '2015-03-05 12:10:51.770912');
INSERT INTO people VALUES (413, 0, 'Migdalia', 'Núñez', false, 2, '', true, true, true, NULL, '2015-03-04 19:56:46.628594', '2015-03-06 12:10:19.636343');
INSERT INTO people VALUES (365, NULL, 'Ada', 'Serrano', false, 3, '', true, true, true, 48, '2015-03-04 11:19:51.909843', '2015-03-05 12:06:36.948884');
INSERT INTO people VALUES (398, 1, 'arcadio', 'gonzalez', true, 2, '', true, true, true, NULL, '2015-03-04 19:51:28.532266', '2015-03-05 12:09:33.768478');
INSERT INTO people VALUES (39, NULL, 'José ', 'Armenteros ', true, 3, '', true, true, true, 107, '2015-02-24 01:46:09.753433', '2015-03-05 12:20:52.415354');
INSERT INTO people VALUES (271, NULL, 'Eddie ', 'Diaz', true, 4, 'Representante Distrito', true, true, true, 108, '2015-02-24 17:43:15.014054', '2015-03-05 12:23:32.834099');
INSERT INTO people VALUES (35, NULL, 'Carlos ', 'Maldonado ', true, 3, '', true, true, true, 107, '2015-02-24 01:44:21.294952', '2015-03-05 12:26:10.903765');
INSERT INTO people VALUES (40, NULL, 'Margarita ', 'Fígaro', false, 3, '', true, true, true, 107, '2015-02-24 01:46:45.493396', '2015-03-05 12:26:42.350992');
INSERT INTO people VALUES (38, NULL, 'María de los A. ', 'Torres ', false, 3, '', true, true, true, 107, '2015-02-24 01:45:45.277971', '2015-03-05 12:27:22.303329');
INSERT INTO people VALUES (37, NULL, 'Fernando ', 'Toro ', true, 3, '', true, true, true, 107, '2015-02-24 01:45:18.35002', '2015-03-05 12:27:33.916522');
INSERT INTO people VALUES (324, NULL, 'Milagros ', 'Ortíz', false, 3, '', true, true, true, 102, '2015-03-02 19:44:00.21575', '2015-03-05 12:36:48.664419');
INSERT INTO people VALUES (87, NULL, 'Edgardo ', 'Miranda ', true, 3, '', true, true, true, 13, '2015-02-24 02:17:00.753889', '2015-03-05 12:40:15.595106');
INSERT INTO people VALUES (358, 0, 'David A.', 'González', true, 0, '', true, true, true, 16, '2015-03-04 11:13:02.826787', '2015-03-05 12:47:31.332724');
INSERT INTO people VALUES (388, 1, 'Mayra', 'Giovannetti', false, 5, 'Misionera en Nicaragua', true, true, true, NULL, '2015-03-04 19:46:44.155826', '2015-03-05 12:49:04.121558');
INSERT INTO people VALUES (89, NULL, 'Aurelina ', 'Roldán ', false, 3, '', true, true, true, 13, '2015-02-24 02:17:55.397238', '2015-03-05 12:51:29.696702');
INSERT INTO people VALUES (284, 6, 'Daniel ', 'Santos', true, 3, '', true, true, true, 120, '2015-02-25 14:49:00.280008', '2015-03-05 12:52:38.734601');
INSERT INTO people VALUES (76, 3, 'Alfredo ', 'Méndez ', true, 3, '', true, true, true, 64, '2015-02-24 02:11:21.043451', '2015-03-05 12:55:42.237046');
INSERT INTO people VALUES (335, 0, 'Jesús E. ', 'García', true, 0, '', true, true, true, 29, '2015-03-02 19:54:39.652549', '2015-03-05 12:56:17.618701');
INSERT INTO people VALUES (337, NULL, 'Ricartel ', 'Rivera', true, 3, '', true, true, true, 29, '2015-03-02 19:55:18.703264', '2015-03-05 12:56:23.619406');
INSERT INTO people VALUES (334, NULL, 'Luz D.', 'Lamboy', false, 3, '', true, true, true, 91, '2015-03-02 19:52:43.96399', '2015-03-05 12:56:39.777556');
INSERT INTO people VALUES (285, NULL, 'Awilda ', 'Bonilla', false, 3, '', true, true, true, 122, '2015-02-25 14:49:25.742138', '2015-03-05 13:00:40.314646');
INSERT INTO people VALUES (291, NULL, 'Julio ', 'Cintrón', true, 3, '', true, true, true, 75, '2015-02-27 02:36:13.132308', '2015-03-05 13:13:10.355942');
INSERT INTO people VALUES (330, 1, 'David ', 'Casillas', true, 2, '', true, true, true, 108, '2015-03-02 19:48:26.89733', '2015-03-05 13:24:53.679492');
INSERT INTO people VALUES (91, 1, 'Edwin ', 'Rivera ', true, 0, '', true, true, true, 14, '2015-02-24 02:22:48.675203', '2015-03-05 13:25:34.395692');
INSERT INTO people VALUES (331, 0, 'Marcela ', 'Ortíz', false, 0, '', true, true, true, 91, '2015-03-02 19:51:47.102612', '2015-03-05 13:28:21.492077');
INSERT INTO people VALUES (332, 0, 'Julio ', 'Graciani', true, 0, '', true, true, true, 91, '2015-03-02 19:52:12.063683', '2015-03-05 13:28:33.837471');
INSERT INTO people VALUES (411, NULL, 'José', 'Pérez', true, 4, 'Representante Distrito', true, true, true, NULL, '2015-03-04 19:55:52.843474', '2015-03-05 14:02:09.232269');
INSERT INTO people VALUES (325, 0, 'Zoraida ', 'Rivera Morales', false, 0, '', true, true, true, 41, '2015-03-02 19:46:12.671406', '2015-03-05 14:07:25.435384');
INSERT INTO people VALUES (328, NULL, 'Ruth ', 'Rosa', false, 3, '', true, true, true, 41, '2015-03-02 19:47:10.836208', '2015-03-05 14:07:52.471794');
INSERT INTO people VALUES (34, 1, 'Heriberto ', 'Muñoz ', true, 0, '', true, true, true, 107, '2015-02-24 01:43:56.325452', '2015-03-05 14:09:11.176592');
INSERT INTO people VALUES (418, 1, 'Miriam', 'Chacón Peralta', false, 5, 'Representante Regional MMBB', true, true, true, NULL, '2015-03-04 19:57:59.789934', '2015-03-05 14:20:48.091451');
INSERT INTO people VALUES (390, 1, 'Salvador', 'Orellana', true, 5, 'Coord. Nac. Minist. Inter.ABHMS', true, true, true, NULL, '2015-03-04 19:48:37.386472', '2015-03-05 14:22:13.657729');
INSERT INTO people VALUES (78, 1, 'César ', 'Maurás ', true, 0, '', true, true, true, 13, '2015-02-24 02:12:58.693612', '2015-03-05 14:29:12.653329');
INSERT INTO people VALUES (382, 1, 'Carlos ', 'Gomez', true, 2, '', true, true, true, NULL, '2015-03-04 19:43:50.921234', '2015-03-05 14:56:18.957269');
INSERT INTO people VALUES (381, NULL, 'Alexandra', 'Zavala', true, 4, 'Representante General', true, true, true, NULL, '2015-03-04 19:43:36.645025', '2015-03-05 15:03:56.198094');
INSERT INTO people VALUES (77, NULL, 'Lorenzo A. ', 'Fuentes ', true, 3, '', true, true, true, 64, '2015-02-24 02:11:56.858646', '2015-03-05 15:06:16.09595');
INSERT INTO people VALUES (422, 1, 'Don', 'Ng', true, 5, 'Presidente IBA', true, true, true, NULL, '2015-03-04 19:58:55.198491', '2015-03-05 15:58:10.464027');
INSERT INTO people VALUES (327, NULL, 'Carmelo ', 'Rivera ', true, 3, '', true, true, true, 41, '2015-03-02 19:46:51.495269', '2015-03-05 16:50:55.601657');
INSERT INTO people VALUES (240, NULL, 'Priscilla ', 'Esteves Ponde de León', false, 3, '', true, true, true, 71, '2015-02-24 15:11:09.635891', '2015-03-06 12:05:19.464816');
INSERT INTO people VALUES (339, NULL, 'Rubén', 'Jiménez ', true, 3, '', true, true, true, 75, '2015-03-02 20:00:08.946664', '2015-03-06 13:23:06.458529');
INSERT INTO people VALUES (336, NULL, 'Alexander ', 'Cruz ', true, 3, '', true, true, true, 29, '2015-03-02 19:54:54.858849', '2015-03-06 13:45:58.174014');
INSERT INTO people VALUES (393, NULL, 'Gonzalo', 'Alers', true, 4, 'Representante Distrito', true, true, true, NULL, '2015-03-04 19:49:31.948319', '2015-03-07 12:23:04.861598');
INSERT INTO people VALUES (326, 0, 'Luis O.', 'Arizmendi', true, 1, '', true, true, true, 41, '2015-03-02 19:46:33.155905', '2015-03-07 12:35:29.709482');
INSERT INTO people VALUES (329, NULL, 'Elena ', 'Rivera', false, 3, '', true, true, true, 41, '2015-03-02 19:47:39.758229', '2015-03-07 13:11:42.907862');
INSERT INTO people VALUES (377, 0, 'Walleska', 'Febres', false, 5, 'Misionera en Colombia', true, true, true, NULL, '2015-03-04 19:37:09.32306', '2015-03-05 11:23:53.689883');
INSERT INTO people VALUES (442, 3, 'Raymond', 'Martínez', true, 4, 'Comisión de Planificación', false, true, false, NULL, '2015-03-04 20:11:17.805466', '2015-03-05 12:00:33.780348');
INSERT INTO people VALUES (419, 0, 'Santiago', 'Sánchez', true, 2, '', false, true, false, NULL, '2015-03-04 19:58:00.163474', '2015-03-04 19:59:39.479058');
INSERT INTO people VALUES (349, NULL, 'Francisca', 'Rodríguez', false, 3, '', true, true, true, 58, '2015-03-04 11:03:01.35714', '2015-03-05 12:02:02.945348');
INSERT INTO people VALUES (421, 0, 'Plácido', 'Reyes', true, 2, '', false, true, false, NULL, '2015-03-04 19:58:52.62585', '2015-03-04 19:59:39.494951');
INSERT INTO people VALUES (351, NULL, 'Francisca', 'Alicea', false, 3, '', true, true, true, 58, '2015-03-04 11:03:46.627915', '2015-03-05 12:02:05.98952');
INSERT INTO people VALUES (348, NULL, 'Juan', 'Figueroa', true, 3, '', true, true, true, 58, '2015-03-04 11:02:42.315908', '2015-03-05 12:02:36.701626');
INSERT INTO people VALUES (350, NULL, 'Myrna', 'Villafranca', false, 3, '', true, true, true, 58, '2015-03-04 11:03:24.913737', '2015-03-05 12:02:40.688717');
INSERT INTO people VALUES (417, NULL, 'José L.', 'Alicea', true, 4, 'Representante Distrito', true, true, true, NULL, '2015-03-04 19:57:32.710282', '2015-03-05 12:04:15.152758');
INSERT INTO people VALUES (466, NULL, 'Frank', 'Perez', true, 3, '', true, true, true, 30, '2015-03-05 12:00:35.185212', '2015-03-05 12:10:51.721817');
INSERT INTO people VALUES (345, 0, 'Margarita', 'Rodríguez', false, 1, '', true, true, true, 58, '2015-03-04 10:59:22.645046', '2015-03-05 12:31:25.600853');
INSERT INTO people VALUES (306, NULL, 'Lymaris ', 'Diaz', false, 3, '', false, true, false, 90, '2015-03-02 19:22:26.869249', '2015-03-05 13:27:41.672973');
INSERT INTO people VALUES (201, 0, 'Susana ', 'Rivera ', false, 0, '', true, true, true, 67, '2015-02-24 14:39:41.628178', '2015-03-05 13:27:45.662323');
INSERT INTO people VALUES (367, NULL, 'Margarita', 'Ramírez', false, 4, 'Presidenta IBPR', true, true, true, NULL, '2015-03-04 19:08:30.862204', '2015-03-05 14:26:51.634572');
INSERT INTO people VALUES (537, NULL, 'Damaris', 'Diaz', false, 5, '', true, true, true, NULL, '2015-03-05 14:36:21.966876', '2015-03-05 14:44:03.54525');
INSERT INTO people VALUES (447, NULL, 'Mary', 'Weaver', false, 5, 'Asistente Admin. M.I.', true, true, true, NULL, '2015-03-04 20:14:55.937201', '2015-03-05 14:53:55.849807');
INSERT INTO people VALUES (539, 0, 'Felix ', 'Veléz', true, 0, '', true, true, true, 63, '2015-03-05 15:08:08.745526', '2015-03-05 15:26:07.328318');
INSERT INTO people VALUES (540, NULL, 'María C.', 'Torres Rodríguez', false, 3, '', false, true, false, 112, '2015-03-05 15:39:27.615587', '2015-03-05 16:09:10.565282');
INSERT INTO people VALUES (541, 3, 'Josué', 'Gómez', true, 4, '', true, true, true, NULL, '2015-03-05 15:48:45.698732', '2015-03-05 16:09:10.911921');
INSERT INTO people VALUES (454, NULL, 'Dr. Reid', 'Trulson', true, 5, 'Director Ejecutivo M.I.', false, true, false, NULL, '2015-03-04 20:20:06.703008', '2015-03-04 20:22:03.810009');
INSERT INTO people VALUES (379, 1, 'Esteban', 'González Doble', true, 5, 'Pastor General IDCPR', false, true, false, NULL, '2015-03-04 19:40:24.852969', '2015-03-04 19:44:15.644367');
INSERT INTO people VALUES (43, NULL, 'Luciano ', 'Ortiz ', true, 3, '', true, true, true, 110, '2015-02-24 01:50:05.172259', '2015-03-05 12:50:03.698973');
INSERT INTO people VALUES (5, NULL, 'Mary ', 'Vázquez ', false, 3, '', true, true, true, 108, '2015-02-23 22:24:15.398515', '2015-03-05 12:51:12.140363');
INSERT INTO people VALUES (27, 0, 'Migdalia ', 'Flores ', false, 0, '', true, true, true, 100, '2015-02-24 01:37:45.571485', '2015-03-05 13:00:03.207023');
INSERT INTO people VALUES (364, 1, 'Héctor F', 'Soto', true, 5, 'Secretario Interino CIPR', true, true, true, NULL, '2015-03-04 11:19:31.038158', '2015-03-06 14:51:41.825449');
INSERT INTO people VALUES (457, 0, 'Héctor', 'Soto', true, 0, '', true, true, true, 48, '2015-03-04 20:46:17.064976', '2015-03-05 13:00:16.838394');
INSERT INTO people VALUES (4, NULL, 'Luis ', 'Vázquez ', true, 3, '', true, true, true, 108, '2015-02-23 22:23:49.805825', '2015-03-05 12:42:47.69388');
INSERT INTO people VALUES (3, NULL, 'José', 'Tejeda ', true, 3, '', true, true, true, 108, '2015-02-23 22:23:11.598545', '2015-03-05 12:14:23.485457');
INSERT INTO people VALUES (276, NULL, 'Efraín', 'Dávila ', true, 3, '', true, true, true, 32, '2015-02-25 13:23:47.195972', '2015-03-05 13:21:21.69681');
INSERT INTO people VALUES (56, NULL, 'Héctor N. ', 'López ', true, 3, '', true, true, true, 10, '2015-02-24 01:58:53.431612', '2015-03-05 11:55:41.411255');
INSERT INTO people VALUES (79, 1, 'Angel ', 'Cruz ', true, 1, '', true, true, true, 13, '2015-02-24 02:13:25.268081', '2015-03-05 12:21:08.402664');
INSERT INTO people VALUES (28, NULL, 'Angel ', 'Pérez ', true, 3, '', true, true, true, 100, '2015-02-24 01:38:14.145202', '2015-03-05 13:00:28.723232');
INSERT INTO people VALUES (341, NULL, 'Bonifacio ', 'Del Valle', true, 3, '', false, true, false, 86, '2015-03-02 20:20:58.471397', '2015-03-05 12:28:55.834408');
INSERT INTO people VALUES (52, NULL, 'Wilfredo ', 'Mercado ', true, 3, '', true, true, true, 7, '2015-02-24 01:56:28.001371', '2015-03-05 15:37:36.30211');
INSERT INTO people VALUES (360, NULL, 'José A.', 'Ortiz Rivera', true, 3, '', true, true, true, 16, '2015-03-04 11:14:22.501926', '2015-03-05 11:58:28.7337');
INSERT INTO people VALUES (385, 1, 'Paulita', 'Matos De Garcia', false, 2, '', true, true, true, NULL, '2015-03-04 19:46:07.861347', '2015-03-05 13:44:52.807249');
INSERT INTO people VALUES (397, 1, 'Félix', 'Rivera', true, 2, '', false, true, false, NULL, '2015-03-04 19:50:48.030418', '2015-03-04 19:52:25.978528');
INSERT INTO people VALUES (82, NULL, 'Alba ', 'Martín ', false, 3, '', true, true, true, 13, '2015-02-24 02:14:48.42626', '2015-03-05 12:43:08.709616');
INSERT INTO people VALUES (542, NULL, 'María E.', 'Lozada', false, 3, '', true, true, true, 127, '2015-03-05 16:48:10.197718', '2015-03-05 17:17:16.142822');
INSERT INTO people VALUES (90, 1, 'Félix ', 'Rivera ', true, 2, '', true, true, true, 13, '2015-02-24 02:18:41.545225', '2015-03-05 12:53:15.77463');
INSERT INTO people VALUES (81, 1, 'Héctor A. ', 'Rivera ', true, 1, '', true, true, true, 13, '2015-02-24 02:14:22.852503', '2015-03-05 14:04:35.0725');
INSERT INTO people VALUES (46, NULL, 'Amelia ', 'Colón', false, 3, '', true, true, true, 112, '2015-02-24 01:51:58.62218', '2015-03-05 12:43:36.274039');
INSERT INTO people VALUES (543, NULL, 'Héctor', 'Fonseca', true, 3, '', true, true, true, 127, '2015-03-05 16:48:35.884359', '2015-03-05 17:17:16.255969');
INSERT INTO people VALUES (55, 0, 'Geraldo ', 'Méndez ', true, 0, '', true, true, true, 10, '2015-02-24 01:58:31.251653', '2015-03-05 12:37:00.874257');
INSERT INTO people VALUES (412, 0, 'Victor', 'Vázquez', true, 2, '', false, true, false, NULL, '2015-03-04 19:55:55.483161', '2015-03-04 19:57:36.083325');
INSERT INTO people VALUES (25, NULL, 'Zoraida ', 'Derieux ', false, 3, '', true, true, true, 109, '2015-02-24 01:28:40.668004', '2015-03-05 13:03:49.317454');
INSERT INTO people VALUES (23, NULL, 'Juan C.', 'Rivera ', true, 3, '', false, true, false, 109, '2015-02-24 01:27:43.735306', '2015-03-02 19:23:33.186561');
INSERT INTO people VALUES (47, NULL, 'Ana Petra ', 'Félix ', false, 3, '', false, true, false, 112, '2015-02-24 01:52:30.066319', '2015-03-02 19:23:41.358417');
INSERT INTO people VALUES (456, 0, 'Dr. Aidsan', 'Wright Riggins III', true, 5, '', false, true, false, NULL, '2015-03-04 20:24:09.805368', '2015-03-04 20:27:11.095014');
INSERT INTO people VALUES (455, NULL, 'Dr. Reg ', 'Mills', true, 5, 'Presidente Ministerios Internacionales', false, true, false, NULL, '2015-03-04 20:23:33.059731', '2015-03-04 20:27:11.101468');
INSERT INTO people VALUES (92, NULL, 'Juan R.', 'Flusa ', true, 3, '', true, true, true, 14, '2015-02-24 02:23:11.719046', '2015-03-05 11:05:59.998761');
INSERT INTO people VALUES (342, NULL, 'Luz ', 'Maldonado', false, 3, '', true, true, true, 86, '2015-03-02 20:21:12.416348', '2015-03-05 12:05:48.326584');
INSERT INTO people VALUES (383, 1, 'Ketley', 'Pierre', false, 5, 'Misionera en Nicaragua', true, true, true, NULL, '2015-03-04 19:43:54.519804', '2015-03-05 11:13:32.512838');
INSERT INTO people VALUES (340, 0, 'Luis R. ', 'Figueroa', true, 0, '', true, true, true, 86, '2015-03-02 20:20:35.244301', '2015-03-05 12:05:48.340586');
INSERT INTO people VALUES (57, NULL, 'Lillian', 'Rivera ', false, 3, '', true, true, true, 10, '2015-02-24 01:59:18.740724', '2015-03-05 11:15:07.481956');
INSERT INTO people VALUES (357, NULL, 'Edgardo', 'López', true, 3, '', true, true, true, 55, '2015-03-04 11:06:38.050754', '2015-03-05 11:30:23.194067');
INSERT INTO people VALUES (176, NULL, 'Juan ', 'Morales ', true, 3, '', true, true, true, 24, '2015-02-24 14:03:23.99237', '2015-03-05 11:32:27.209433');
INSERT INTO people VALUES (83, NULL, 'Noemí ', 'Ortiz ', false, 3, '', true, true, true, 13, '2015-02-24 02:15:12.64589', '2015-03-05 12:39:05.515325');
INSERT INTO people VALUES (175, NULL, 'Marisol ', 'Sanchez ', false, 3, '', true, true, true, 24, '2015-02-24 14:03:07.962388', '2015-03-05 11:34:15.669758');
INSERT INTO people VALUES (366, NULL, 'Nelson', 'Ortiz', true, 3, '', true, true, true, 48, '2015-03-04 11:20:18.775498', '2015-03-05 12:08:49.957617');
INSERT INTO people VALUES (359, NULL, 'María V.', 'Colón Alvarado', false, 3, '', true, true, true, 16, '2015-03-04 11:13:47.821593', '2015-03-05 11:44:29.352843');
INSERT INTO people VALUES (467, NULL, 'Maria V.', 'Coris', false, 3, '', true, true, true, 38, '2015-03-05 12:06:15.58626', '2015-03-05 12:10:51.77496');
INSERT INTO people VALUES (88, NULL, 'Angel ', 'Sierra ', true, 3, '', true, true, true, 13, '2015-02-24 02:17:31.008629', '2015-03-05 11:50:01.561419');
INSERT INTO people VALUES (53, NULL, 'Domingo ', 'Carrasquillo ', true, 3, '', true, true, true, 7, '2015-02-24 01:56:49.327954', '2015-03-05 12:45:55.815135');
INSERT INTO people VALUES (468, NULL, 'Haydee ', 'Molina', false, 3, 'Delegada', true, true, true, 38, '2015-03-05 12:07:59.292427', '2015-03-05 12:10:51.782066');
INSERT INTO people VALUES (469, NULL, 'Betty ', 'Hernández', false, 3, '', true, true, true, 125, '2015-03-05 12:09:50.841544', '2015-03-05 12:10:51.789464');
INSERT INTO people VALUES (470, NULL, 'Carmen', 'García', false, 3, '', true, true, true, 125, '2015-03-05 12:10:48.615878', '2015-03-05 12:10:51.796326');
INSERT INTO people VALUES (51, 1, 'Ramón L. ', 'Díaz ', true, 0, '', true, true, true, 7, '2015-02-24 01:56:07.756014', '2015-03-05 12:53:34.042392');
INSERT INTO people VALUES (44, 0, 'Carlos J. ', 'Montalvo ', true, 0, '', true, true, true, 112, '2015-02-24 01:51:09.641324', '2015-03-05 14:11:05.369116');
INSERT INTO people VALUES (41, 1, 'Joel ', 'Velázquez ', true, 0, '', true, true, true, 110, '2015-02-24 01:49:18.955261', '2015-03-05 13:04:30.641333');
INSERT INTO people VALUES (24, NULL, 'Nubia G.', 'Santos ', true, 3, '', true, true, true, 109, '2015-02-24 01:28:09.897945', '2015-03-05 12:55:11.545557');
INSERT INTO people VALUES (54, NULL, 'Israel ', 'Cotto ', true, 3, '', true, true, true, 7, '2015-02-24 01:57:09.233216', '2015-03-05 12:47:20.94519');
INSERT INTO people VALUES (274, NULL, 'Ramonita', 'Martinez', false, 3, '', true, true, true, 32, '2015-02-25 13:22:58.907116', '2015-03-05 13:27:41.66258');
INSERT INTO people VALUES (42, NULL, 'Angel ', 'Torres ', true, 3, '', true, true, true, 110, '2015-02-24 01:49:43.059036', '2015-03-05 12:48:31.930482');
INSERT INTO people VALUES (85, NULL, 'Aida I. ', 'López ', false, 3, '', true, true, true, 13, '2015-02-24 02:16:06.984407', '2015-03-05 13:15:58.880554');
INSERT INTO people VALUES (414, 6, 'Héctor ', 'González', true, 5, 'Consejero Hispano, ABCCU/WMS', true, true, true, NULL, '2015-03-04 19:57:00.711374', '2015-03-05 12:58:51.627508');
INSERT INTO people VALUES (45, NULL, 'Leticia ', 'Santaella ', false, 4, '', true, true, true, 112, '2015-02-24 01:51:34.052136', '2015-03-05 14:11:57.181552');
INSERT INTO people VALUES (93, NULL, 'Oscar ', 'Lausell ', true, 3, '', true, true, true, 14, '2015-02-24 02:23:34.71096', '2015-03-05 12:59:03.322466');
INSERT INTO people VALUES (317, 1, 'Miladys ', 'Oliveras', false, 4, 'Representante Distrito', true, true, true, 49, '2015-03-02 19:33:26.920211', '2015-03-05 13:27:55.104568');
INSERT INTO people VALUES (275, NULL, 'Diana ', 'Alomar', false, 3, '', true, true, true, 32, '2015-02-25 13:23:22.91189', '2015-03-05 13:18:57.575429');
INSERT INTO people VALUES (22, 0, 'Laura ', 'Ayala ', false, 0, '', true, true, true, 109, '2015-02-24 01:27:13.149274', '2015-03-05 13:19:28.741414');
INSERT INTO people VALUES (283, NULL, 'Daniris ', 'Sánchez ', false, 3, '', true, true, true, 118, '2015-02-25 14:48:04.168582', '2015-03-05 14:16:18.220289');
INSERT INTO people VALUES (26, NULL, 'José D. ', 'Colón', true, 3, '', true, true, true, 109, '2015-02-24 01:29:09.930154', '2015-03-05 13:19:31.503655');
INSERT INTO people VALUES (84, NULL, 'Reinaldo ', 'Robles ', true, 3, '', true, true, true, 13, '2015-02-24 02:15:41.375244', '2015-03-05 13:35:17.748399');
INSERT INTO people VALUES (387, NULL, 'Julio', 'Quiros', true, 4, 'Representante General', true, true, true, NULL, '2015-03-04 19:46:11.562372', '2015-03-05 14:31:43.201383');
INSERT INTO people VALUES (386, 1, 'José', 'Norat Rodríguez', true, 5, 'Dir. Area Iberoamérica-Caribe Minist. Inter.', true, true, true, NULL, '2015-03-04 19:46:11.213459', '2015-03-05 15:05:59.349884');
INSERT INTO people VALUES (134, 0, 'Lizette ', 'Hernández ', false, 0, '', true, true, true, 23, '2015-02-24 02:52:08.030117', '2015-03-06 17:26:29.269563');
INSERT INTO people VALUES (136, NULL, 'Luz D. ', 'Lozada ', false, 3, '', true, true, true, 23, '2015-02-24 02:52:52.625027', '2015-03-05 11:47:15.695745');
INSERT INTO people VALUES (179, 1, 'Angel ', 'Mundo', true, 1, '', false, true, false, 1, '2015-02-24 14:07:06.346536', '2015-03-02 19:21:10.23049');
INSERT INTO people VALUES (18, NULL, 'Jennie ', 'Cintrón ', false, 3, '', false, true, false, 3, '2015-02-24 01:25:06.338216', '2015-03-02 19:22:00.386517');
INSERT INTO people VALUES (172, NULL, 'Cecilio', 'Rivera', true, 3, 'Sustituto', false, true, false, 20, '2015-02-24 13:58:26.021753', '2015-03-02 19:22:47.473414');
INSERT INTO people VALUES (170, NULL, 'Nilsa ', 'Muñoz', false, 3, '', false, true, false, 20, '2015-02-24 13:55:46.930581', '2015-03-02 19:22:50.787643');
INSERT INTO people VALUES (75, NULL, 'David ', 'Calderón ', true, 3, '', true, true, true, 40, '2015-02-24 02:10:31.344285', '2015-03-06 12:13:59.893306');
INSERT INTO people VALUES (225, 0, 'Francisco', 'Pinto', true, 2, '', false, true, false, 1, '2015-02-24 15:01:44.624629', '2015-03-02 19:21:10.298194');
INSERT INTO people VALUES (471, NULL, 'José ', 'Rodríguez Dieppa', true, 3, '', true, true, true, 54, '2015-03-05 12:27:42.225096', '2015-03-05 13:07:24.577621');
INSERT INTO people VALUES (259, NULL, 'Irma', 'González', false, 3, '', true, true, true, 18, '2015-02-24 15:32:15.70409', '2015-03-05 11:54:09.730297');
INSERT INTO people VALUES (70, NULL, 'Zoraida I. ', 'Serrano', false, 3, '', true, true, true, 37, '2015-02-24 02:07:15.106485', '2015-03-05 11:06:47.769656');
INSERT INTO people VALUES (71, NULL, 'Dora ', 'Cruz ', false, 3, '', true, true, true, 37, '2015-02-24 02:07:36.947044', '2015-03-05 11:06:54.082434');
INSERT INTO people VALUES (166, 0, 'Pedro', 'González', true, 0, '', true, true, true, 20, '2015-02-24 13:52:46.225562', '2015-03-05 11:11:26.34652');
INSERT INTO people VALUES (9, NULL, 'Wilfredo ', 'Torres ', true, 3, '', true, true, true, 105, '2015-02-23 22:27:06.708956', '2015-03-05 11:22:06.176099');
INSERT INTO people VALUES (118, NULL, 'Wilda ', 'Lugo ', false, 3, '', true, true, true, 60, '2015-02-24 02:37:32.520058', '2015-03-05 11:22:47.013679');
INSERT INTO people VALUES (125, NULL, 'Félix J. ', 'Colón ', true, 3, '', true, true, true, 56, '2015-02-24 02:42:20.49519', '2015-03-05 11:31:32.452549');
INSERT INTO people VALUES (123, 4, 'Sonia ', 'Villodas', false, 3, '', true, true, true, 56, '2015-02-24 02:41:19.738212', '2015-03-05 11:32:14.499707');
INSERT INTO people VALUES (13, NULL, 'Noel ', 'Ortiz ', true, 3, '', true, true, true, 103, '2015-02-24 01:19:13.409094', '2015-03-05 11:33:54.751209');
INSERT INTO people VALUES (159, NULL, 'Carlos ', 'Rodriguez Delannoy', true, 3, '', true, true, true, 25, '2015-02-24 13:33:17.399365', '2015-03-05 11:41:05.598369');
INSERT INTO people VALUES (73, NULL, 'Yolaris ', 'Negrón ', false, 3, '', true, true, true, 37, '2015-02-24 02:08:54.002502', '2015-03-05 11:42:53.656199');
INSERT INTO people VALUES (130, 0, 'Ulbencio ', 'Rivera ', true, 0, '', true, true, true, 65, '2015-02-24 02:47:50.485002', '2015-03-05 11:44:06.175658');
INSERT INTO people VALUES (184, NULL, 'Carlos ', 'Febo ', true, 3, '', true, true, true, 1, '2015-02-24 14:10:25.178415', '2015-03-05 11:55:30.640752');
INSERT INTO people VALUES (181, NULL, 'Luis ', 'Rosario ', true, 3, '', true, true, true, 1, '2015-02-24 14:09:15.743096', '2015-03-05 11:55:57.340375');
INSERT INTO people VALUES (50, NULL, 'Ahmed ', 'Díaz ', true, 3, '', true, true, true, 113, '2015-02-24 01:53:49.390545', '2015-03-05 11:59:15.666795');
INSERT INTO people VALUES (49, NULL, 'Víctor ', 'Rivera ', true, 3, '', true, true, true, 113, '2015-02-24 01:53:29.17058', '2015-03-05 11:59:46.479053');
INSERT INTO people VALUES (61, NULL, 'José A. ', 'Cotto ', true, 3, '', true, true, true, 33, '2015-02-24 02:01:25.367756', '2015-03-05 11:59:47.851783');
INSERT INTO people VALUES (63, NULL, 'María del C. ', 'Meléndez ', false, 3, '', true, true, true, 33, '2015-02-24 02:02:14.53627', '2015-03-05 11:59:59.580424');
INSERT INTO people VALUES (64, NULL, 'Emérito ', 'Sánchez ', true, 3, '', true, true, true, 33, '2015-02-24 02:02:38.334079', '2015-03-05 12:00:52.689175');
INSERT INTO people VALUES (8, NULL, 'Rómulo ', 'Ortiz ', true, 3, '', true, true, true, 105, '2015-02-23 22:26:41.58849', '2015-03-05 12:04:12.054928');
INSERT INTO people VALUES (133, NULL, 'Lizvette ', 'Rodríguez ', false, 3, '', true, true, true, 65, '2015-02-24 02:49:09.238478', '2015-03-05 12:07:32.82807');
INSERT INTO people VALUES (6, 1, 'Eneida ', 'Angleró', false, 0, '', true, true, true, 105, '2015-02-23 22:25:35.265226', '2015-03-05 12:17:17.973449');
INSERT INTO people VALUES (183, NULL, 'Saúl ', 'Castillo', true, 3, '', true, true, true, 1, '2015-02-24 14:10:04.471921', '2015-03-05 12:18:09.881764');
INSERT INTO people VALUES (182, NULL, 'Luis ', 'Osorio', true, 3, '', true, true, true, 1, '2015-02-24 14:09:37.573035', '2015-03-05 12:21:39.940406');
INSERT INTO people VALUES (59, NULL, 'Antonio ', 'Cabrera ', true, 3, '', true, true, false, 33, '2015-02-24 02:00:30.777975', '2015-03-05 12:23:15.879021');
INSERT INTO people VALUES (62, NULL, 'Jorge L. ', 'Oquendo ', true, 3, '', true, true, true, 33, '2015-02-24 02:01:45.24657', '2015-03-05 12:22:44.513934');
INSERT INTO people VALUES (60, NULL, 'Angel L.', 'Colon', true, 3, '', true, true, true, 33, '2015-02-24 02:00:59.14507', '2015-03-05 12:28:56.009842');
INSERT INTO people VALUES (472, NULL, 'Maribel', 'Barbosa', true, 3, '', true, true, true, 54, '2015-03-05 12:28:18.600277', '2015-03-05 12:28:56.051718');
INSERT INTO people VALUES (132, NULL, 'Marisabel ', 'Beltrán ', false, 3, '', true, true, false, 65, '2015-02-24 02:48:45.523712', '2015-03-05 12:43:25.792829');
INSERT INTO people VALUES (124, NULL, 'Lilybeth ', 'Bosch', false, 3, '', true, true, true, 56, '2015-02-24 02:41:48.368594', '2015-03-05 12:51:12.921955');
INSERT INTO people VALUES (122, 0, 'Alberto J. ', 'Díaz ', true, 4, 'Vice Presidente', true, true, true, 56, '2015-02-24 02:40:50.078129', '2015-03-05 12:31:57.166928');
INSERT INTO people VALUES (160, NULL, 'Carlos ', 'Dominguez Cristobal', true, 3, '', true, true, true, 25, '2015-02-24 13:33:40.851015', '2015-03-05 12:38:00.618047');
INSERT INTO people VALUES (66, 1, 'Jaime ', 'Rodríguez ', true, 0, '', true, true, true, 36, '2015-02-24 02:05:02.059083', '2015-03-05 12:40:17.077085');
INSERT INTO people VALUES (67, NULL, 'Cristina ', 'Báez ', false, 3, '', true, true, true, 36, '2015-02-24 02:05:28.776187', '2015-03-05 12:41:04.162777');
INSERT INTO people VALUES (161, NULL, 'Gladys ', 'Linares Estrada', false, 3, '', true, true, true, 25, '2015-02-24 13:34:03.070512', '2015-03-05 12:42:48.357036');
INSERT INTO people VALUES (74, NULL, 'Luis ', 'López ', true, 3, '', true, true, true, 40, '2015-02-24 02:09:58.047775', '2015-03-06 12:14:03.12658');
INSERT INTO people VALUES (149, NULL, 'José A. ', 'Fernández ', true, 3, '', true, true, true, 25, '2015-02-24 04:40:17.711563', '2015-03-05 12:45:09.065483');
INSERT INTO people VALUES (16, NULL, 'Zoraida ', 'Rivera ', false, 3, '', true, true, true, 103, '2015-02-24 01:20:55.459826', '2015-03-05 12:45:11.128804');
INSERT INTO people VALUES (142, 1, 'Carmen M. ', 'Arroyo ', false, 1, '', true, true, true, 25, '2015-02-24 04:34:25.075862', '2015-03-05 12:46:43.538618');
INSERT INTO people VALUES (65, 1, 'Benigno ', 'Torres ', true, 2, '', true, true, true, 33, '2015-02-24 02:03:03.022471', '2015-03-05 12:50:45.85968');
INSERT INTO people VALUES (72, NULL, 'Fredeswilda ', 'Vargas ', false, 3, '', true, true, true, 37, '2015-02-24 02:08:16.27727', '2015-03-05 12:52:08.26546');
INSERT INTO people VALUES (148, NULL, 'Carmen ', 'Morales ', false, 3, '', true, true, true, 25, '2015-02-24 04:39:28.23007', '2015-03-05 12:55:39.670005');
INSERT INTO people VALUES (48, 1, 'Jimmy ', 'Vargas ', true, 0, '', true, true, true, 113, '2015-02-24 01:53:09.270001', '2015-03-05 12:59:26.147253');
INSERT INTO people VALUES (153, NULL, 'Lillian', 'Rivera Morales', false, 3, '', true, true, true, 25, '2015-02-24 13:26:47.056805', '2015-03-05 14:06:18.905265');
INSERT INTO people VALUES (169, NULL, 'Sonia ', 'Lugo', false, 3, '', true, true, true, 20, '2015-02-24 13:55:28.176248', '2015-03-05 13:03:22.067231');
INSERT INTO people VALUES (10, 1, 'Miriam ', 'Rodríguez de Gutiérrez', false, 2, '', true, true, true, 103, '2015-02-24 01:17:20.485002', '2015-03-05 13:05:23.271637');
INSERT INTO people VALUES (138, 1, 'Carmen C. ', 'Adames ', false, 0, '', true, true, true, 25, '2015-02-24 04:30:24.198051', '2015-03-05 13:11:23.293717');
INSERT INTO people VALUES (30, NULL, 'Albertina', 'Camacho', false, 3, '', true, true, true, 12, '2015-02-24 01:39:31.364703', '2015-03-05 13:16:32.153563');
INSERT INTO people VALUES (224, 1, 'Efrain ', 'Figueroa', true, 2, '', true, true, true, 1, '2015-02-24 15:01:02.222804', '2015-03-05 13:11:46.478036');
INSERT INTO people VALUES (127, 0, 'Gladys ', 'Morales ', false, 0, '', true, true, true, 124, '2015-02-24 02:45:36.537569', '2015-03-05 13:16:44.101767');
INSERT INTO people VALUES (14, NULL, 'Pedro ', 'Gely ', true, 3, '', true, true, true, 103, '2015-02-24 01:19:45.854266', '2015-03-05 13:16:58.248426');
INSERT INTO people VALUES (128, NULL, 'Margarita ', 'Chico ', false, 3, '', true, true, true, 124, '2015-02-24 02:46:03.776806', '2015-03-05 13:17:31.796534');
INSERT INTO people VALUES (7, NULL, 'Yamalis ', 'González ', false, 3, '', true, true, true, 105, '2015-02-23 22:26:10.39241', '2015-03-05 13:22:18.762534');
INSERT INTO people VALUES (154, 1, 'Madelyn ', 'Figueroa Alamo', false, 1, '', true, true, true, 25, '2015-02-24 13:30:40.268446', '2015-03-05 13:25:10.789152');
INSERT INTO people VALUES (146, 0, 'Alicia E. ', 'Liard ', false, 1, '', true, true, true, 25, '2015-02-24 04:37:52.518536', '2015-03-05 13:25:49.386314');
INSERT INTO people VALUES (20, NULL, 'Samuel ', 'Encarnación', true, 3, '', true, true, true, 3, '2015-02-24 01:26:07.105439', '2015-03-05 13:29:08.697805');
INSERT INTO people VALUES (177, 1, 'Irma ', 'Pastrana ', false, 0, '', true, true, true, 1, '2015-02-24 14:06:06.140412', '2015-03-05 13:32:05.781659');
INSERT INTO people VALUES (180, NULL, 'Aida I. ', 'Torres', false, 3, '', true, true, true, 1, '2015-02-24 14:08:52.759995', '2015-03-05 13:32:30.600411');
INSERT INTO people VALUES (11, NULL, 'Jessica ', 'Lugo ', false, 3, '', true, true, true, 103, '2015-02-24 01:17:56.120307', '2015-03-05 13:33:19.926109');
INSERT INTO people VALUES (178, 0, 'Pedro ', 'Castro', true, 2, '', true, true, true, 1, '2015-02-24 14:06:33.86769', '2015-03-05 13:35:22.192461');
INSERT INTO people VALUES (96, NULL, 'Joanne', 'Carrillo ', false, 3, '', true, true, true, 59, '2015-02-24 02:25:30.268758', '2015-03-05 13:36:12.752201');
INSERT INTO people VALUES (31, 0, 'Hipólito ', 'Félix ', true, 0, '', true, true, true, 123, '2015-02-24 01:41:36.181148', '2015-03-05 13:48:04.025212');
INSERT INTO people VALUES (33, NULL, 'Awilda ', 'Hernández ', false, 3, '', false, true, false, 123, '2015-02-24 01:42:32.458934', '2015-03-05 13:49:18.685694');
INSERT INTO people VALUES (32, NULL, 'Lydia ', 'Camacho ', false, 3, '', true, true, true, 123, '2015-02-24 01:42:07.441078', '2015-03-05 13:49:23.273694');
INSERT INTO people VALUES (143, 1, 'Luis R. ', 'Quiñones ', true, 1, '', true, true, true, 25, '2015-02-24 04:35:16.49935', '2015-03-05 14:06:11.043749');
INSERT INTO people VALUES (21, NULL, 'Miguel A. ', 'Rivera ', true, 3, '', true, true, true, 3, '2015-02-24 01:26:30.75285', '2015-03-05 14:17:51.01698');
INSERT INTO people VALUES (19, NULL, 'José A. ', 'Flores ', true, 3, '', true, true, true, 3, '2015-02-24 01:25:39.803808', '2015-03-05 14:17:54.184328');
INSERT INTO people VALUES (80, 1, 'Yamina ', 'Apolinaris ', false, 1, '', true, true, true, 13, '2015-02-24 02:13:57.475449', '2015-03-05 14:50:48.013628');
INSERT INTO people VALUES (131, 0, 'Glenda L. ', 'De León ', false, 1, '', true, true, true, 65, '2015-02-24 02:48:14.616949', '2015-03-05 15:09:12.630767');
INSERT INTO people VALUES (223, 1, 'Myrna I. ', 'Ramos', false, 1, '', true, true, true, 1, '2015-02-24 15:00:38.844886', '2015-03-05 15:28:21.874945');
INSERT INTO people VALUES (139, 1, 'Juan E. ', 'Matias ', true, 1, '', true, true, true, 25, '2015-02-24 04:31:25.127264', '2015-03-05 16:53:43.5087');
INSERT INTO people VALUES (17, 1, 'David ', 'Valentín ', true, 0, '', true, true, true, 3, '2015-02-24 01:24:22.065414', '2015-03-05 17:50:46.246627');
INSERT INTO people VALUES (126, NULL, 'Abner E. ', 'Cotto ', true, 3, '', true, true, true, 56, '2015-02-24 02:42:55.836961', '2015-03-05 18:17:05.697695');
INSERT INTO people VALUES (167, NULL, 'Francisco ', 'Medina ', false, 3, '', true, true, true, 20, '2015-02-24 13:54:46.987425', '2015-03-05 18:31:29.078408');
INSERT INTO people VALUES (168, NULL, 'Lilliana ', 'Landrón', false, 3, '', true, true, true, 20, '2015-02-24 13:55:10.76219', '2015-03-05 19:07:05.793429');
INSERT INTO people VALUES (174, 0, 'Rosalba ', 'Velez', false, 3, '', true, true, true, 24, '2015-02-24 14:01:17.186728', '2015-03-06 12:43:09.017525');
INSERT INTO people VALUES (103, NULL, 'Samuel ', 'Acevedo ', true, 3, '', true, true, false, 52, '2015-02-24 02:29:30.896712', '2015-03-05 13:05:18.891345');
INSERT INTO people VALUES (114, NULL, 'Carmen ', 'Leduc ', false, 3, '', true, true, false, 60, '2015-02-24 02:35:59.457418', '2015-03-07 16:15:30.65415');
INSERT INTO people VALUES (202, 1, 'Aniceto', 'Sustache', true, 0, '', false, true, false, 66, '2015-02-24 14:41:07.88743', '2015-03-02 19:22:59.31297');
INSERT INTO people VALUES (212, NULL, 'María del C.', 'Lanzo', false, 3, '', false, true, false, 84, '2015-02-24 14:45:35.727958', '2015-03-02 19:23:10.301234');
INSERT INTO people VALUES (206, NULL, 'Nilsa L. ', 'Torres Correa', true, 3, '', false, true, false, 84, '2015-02-24 14:43:11.47927', '2015-03-02 19:23:10.310314');
INSERT INTO people VALUES (215, NULL, 'Pedro ', 'Carrasquillo ', true, 3, '', false, true, false, 84, '2015-02-24 14:46:39.863971', '2015-03-02 19:23:10.314219');
INSERT INTO people VALUES (254, NULL, 'Noel Yamil', 'Pacheco Alvarez ', true, 3, '', true, true, true, 99, '2015-02-24 15:26:06.338909', '2015-03-06 14:48:18.311225');
INSERT INTO people VALUES (242, NULL, 'Maribel ', 'Colón', true, 3, '', true, true, true, 76, '2015-02-24 15:12:49.333038', '2015-03-05 12:25:51.423526');
INSERT INTO people VALUES (117, NULL, 'Carmen L. ', 'Santos ', false, 3, '', true, true, true, 60, '2015-02-24 02:37:12.731568', '2015-03-05 10:57:29.981966');
INSERT INTO people VALUES (104, NULL, 'Roberto ', 'Rodríguez ', true, 3, '', true, true, true, 52, '2015-02-24 02:30:03.651506', '2015-03-05 11:05:55.122231');
INSERT INTO people VALUES (256, NULL, 'Miguel ', 'Vázquez ', true, 3, '', true, true, true, 18, '2015-02-24 15:31:15.04761', '2015-03-05 11:13:59.234058');
INSERT INTO people VALUES (219, NULL, 'Victor', 'Marquez', true, 3, '', true, true, true, 21, '2015-02-24 14:51:58.885631', '2015-03-05 14:14:00.332515');
INSERT INTO people VALUES (250, NULL, 'Elsa I. ', 'Mercado Torres', false, 3, '', true, true, true, 99, '2015-02-24 15:17:04.962409', '2015-03-05 11:15:13.223799');
INSERT INTO people VALUES (251, NULL, 'Clarissa', 'Rodríguez', false, 3, '', true, true, true, 99, '2015-02-24 15:17:40.919683', '2015-03-05 11:26:41.536153');
INSERT INTO people VALUES (280, NULL, 'Lydia ', 'Del Valle', false, 3, '', true, true, true, 11, '2015-02-25 14:46:00.734214', '2015-03-05 11:33:28.400186');
INSERT INTO people VALUES (100, NULL, 'José A. ', 'Boria ', true, 3, '', true, true, true, 50, '2015-02-24 02:27:18.420492', '2015-03-05 11:40:38.662888');
INSERT INTO people VALUES (115, NULL, 'Jossie ', 'Cardona ', false, 3, '', true, true, true, 60, '2015-02-24 02:36:19.732517', '2015-03-05 11:41:03.476935');
INSERT INTO people VALUES (253, NULL, 'Marta ', 'Ayala Vega ', false, 3, '', true, true, true, 99, '2015-02-24 15:18:59.956187', '2015-03-05 11:42:50.240139');
INSERT INTO people VALUES (248, 1, 'Juan Nelson', 'Medina', true, 0, '', true, true, true, 99, '2015-02-24 15:16:16.155526', '2015-03-05 12:05:47.069879');
INSERT INTO people VALUES (116, NULL, 'Daniel ', 'Cardona ', true, 3, '', true, true, true, 60, '2015-02-24 02:36:47.171359', '2015-03-05 11:45:32.084054');
INSERT INTO people VALUES (257, NULL, 'Matilde ', 'Dávila ', false, 3, '', true, true, true, 18, '2015-02-24 15:31:36.90614', '2015-03-05 11:53:58.727114');
INSERT INTO people VALUES (260, NULL, 'Libertad ', 'Carrión ', false, 3, '', true, true, true, 18, '2015-02-24 15:32:33.980877', '2015-03-05 11:54:21.421881');
INSERT INTO people VALUES (263, NULL, 'Evelyn ', 'Cruz ', false, 3, '', true, true, true, 96, '2015-02-24 15:37:12.574595', '2015-03-05 11:54:38.05801');
INSERT INTO people VALUES (205, 1, 'Luz E.', 'Rodríguez', false, 1, '', true, true, true, 84, '2015-02-24 14:42:43.920366', '2015-03-05 12:08:30.510324');
INSERT INTO people VALUES (261, NULL, 'Carmen I.', 'Fontanez ', false, 3, '', true, true, true, 96, '2015-02-24 15:36:45.081695', '2015-03-05 12:15:12.751571');
INSERT INTO people VALUES (262, NULL, 'Luis ', 'Beltran ', true, 3, '', true, true, true, 96, '2015-02-24 15:36:59.766195', '2015-03-05 12:16:52.97392');
INSERT INTO people VALUES (105, 4, 'Nayda ', 'Márquez', true, 3, '', true, true, true, 52, '2015-02-24 02:30:38.332964', '2015-03-05 12:22:05.031295');
INSERT INTO people VALUES (243, NULL, 'Minerva ', 'Costa ', false, 3, '', true, true, true, 76, '2015-02-24 15:13:14.962885', '2015-03-05 12:25:52.667783');
INSERT INTO people VALUES (244, NULL, 'Delma ', 'Lananze', false, 3, '', true, true, true, 76, '2015-02-24 15:13:38.480586', '2015-03-05 12:25:50.045735');
INSERT INTO people VALUES (473, NULL, 'Luz E.', 'García', false, 3, '', true, true, true, 54, '2015-03-05 12:29:12.894792', '2015-03-05 12:34:59.969669');
INSERT INTO people VALUES (145, 0, 'Margot ', 'Camacho ', false, 1, '', true, true, true, 25, '2015-02-24 04:37:06.046467', '2015-03-05 12:29:54.053296');
INSERT INTO people VALUES (157, NULL, 'Sonia ', 'García Hernández ', false, 3, '', true, true, true, 25, '2015-02-24 13:32:21.484489', '2015-03-05 12:36:55.165311');
INSERT INTO people VALUES (151, NULL, 'Maria E.', 'Rivera Melendez ', false, 3, '', true, true, true, 25, '2015-02-24 13:25:34.789697', '2015-03-05 12:35:02.508693');
INSERT INTO people VALUES (150, NULL, 'Milagros ', 'Pizarrro', false, 3, '', true, true, true, 25, '2015-02-24 13:22:38.515628', '2015-03-05 12:35:53.480893');
INSERT INTO people VALUES (2, NULL, 'Susano ', 'Luzunaris ', true, 3, '', true, true, true, 108, '2015-02-23 22:22:37.697968', '2015-03-06 15:30:22.202553');
INSERT INTO people VALUES (208, NULL, 'Anita ', 'González', false, 3, '', true, true, true, 84, '2015-02-24 14:43:53.101388', '2015-03-05 12:43:18.325913');
INSERT INTO people VALUES (216, 1, 'Jose ', 'Calo Castro', true, 0, '', true, true, true, 84, '2015-02-24 14:46:58.269313', '2015-03-05 12:40:21.607091');
INSERT INTO people VALUES (211, NULL, 'Glorielis', 'Flores Rodriguez ', false, 3, '', true, true, true, 84, '2015-02-24 14:45:14.699725', '2015-03-05 12:40:50.358591');
INSERT INTO people VALUES (207, NULL, 'Migdalia ', 'Quiñones Pizarro', false, 3, '', true, true, true, 84, '2015-02-24 14:43:36.159235', '2015-03-05 12:41:43.613925');
INSERT INTO people VALUES (156, NULL, 'Norma ', 'Valentin Guerrero', false, 3, '', true, true, true, 25, '2015-02-24 13:31:44.768649', '2015-03-05 12:42:04.635588');
INSERT INTO people VALUES (214, NULL, 'Antonia ', 'Urbina ', false, 3, '', true, true, true, 84, '2015-02-24 14:46:22.77843', '2015-03-05 12:44:08.570077');
INSERT INTO people VALUES (213, NULL, 'Emma ', 'Figueroa Agosto', false, 3, '', true, true, true, 84, '2015-02-24 14:46:01.725059', '2015-03-05 12:44:12.396941');
INSERT INTO people VALUES (210, NULL, 'Ismael ', 'González', true, 3, '', true, true, true, 84, '2015-02-24 14:44:40.125466', '2015-03-05 12:44:19.282155');
INSERT INTO people VALUES (155, NULL, 'Angela ', 'Arroyo Santiago', false, 3, '', true, true, true, 25, '2015-02-24 13:31:13.682457', '2015-03-05 12:45:12.578629');
INSERT INTO people VALUES (99, NULL, 'Idalia ', 'García ', false, 3, '', true, true, true, 50, '2015-02-24 02:26:53.654669', '2015-03-05 12:46:46.017835');
INSERT INTO people VALUES (164, NULL, 'Sonia ', 'Casillas ', false, 3, '', true, true, true, 26, '2015-02-24 13:51:15.708854', '2015-03-05 12:52:50.285214');
INSERT INTO people VALUES (120, NULL, 'Providencia ', 'Hernández ', false, 3, '', true, true, true, 15, '2015-02-24 02:39:44.622382', '2015-03-05 12:53:08.119379');
INSERT INTO people VALUES (86, NULL, 'Aurelio ', 'Ríos ', true, 3, '', true, true, true, 13, '2015-02-24 02:16:38.054947', '2015-03-05 12:53:09.729103');
INSERT INTO people VALUES (121, NULL, 'Audrey ', 'Viera ', false, 3, '', true, true, true, 15, '2015-02-24 02:40:13.362635', '2015-03-05 12:54:13.779653');
INSERT INTO people VALUES (147, NULL, 'Mario ', 'Moya ', true, 3, '', true, true, true, 25, '2015-02-24 04:38:43.989795', '2015-03-05 12:55:00.965563');
INSERT INTO people VALUES (246, NULL, 'Raquel ', 'López Rodríguez ', false, 3, '', true, true, true, 6, '2015-02-24 15:14:41.256116', '2015-03-05 13:00:30.970414');
INSERT INTO people VALUES (247, NULL, 'Roberto ', 'Vera Monroig', true, 3, '', true, true, true, 6, '2015-02-24 15:15:22.012673', '2015-03-05 13:00:33.425033');
INSERT INTO people VALUES (220, 1, 'Elsa ', 'Rivera Martínez ', false, 0, '', true, true, true, 68, '2015-02-24 14:54:01.686913', '2015-03-05 13:34:48.513184');
INSERT INTO people VALUES (140, 1, 'Marilyn ', 'Ortiz ', true, 1, '', true, true, true, 25, '2015-02-24 04:32:32.978955', '2015-03-05 13:12:12.51188');
INSERT INTO people VALUES (101, 1, 'Juan ', 'Vergara ', true, 0, '', true, true, true, 52, '2015-02-24 02:28:47.997609', '2015-03-05 13:13:37.198301');
INSERT INTO people VALUES (119, 0, 'Blanca ', 'Velázquez ', false, 0, '', true, true, true, 15, '2015-02-24 02:39:10.397961', '2015-03-05 13:14:04.335194');
INSERT INTO people VALUES (97, 0, 'Carmen P. ', 'Pérez ', false, 0, '', true, true, true, 50, '2015-02-24 02:26:09.98951', '2015-03-05 13:14:06.904409');
INSERT INTO people VALUES (109, NULL, 'Vacilio ', 'Del Valle ', true, 3, '', true, true, true, 87, '2015-02-24 02:33:49.139829', '2015-03-05 13:18:50.884791');
INSERT INTO people VALUES (107, 0, 'Catalino', 'Colón ', true, 0, '', true, true, true, 87, '2015-02-24 02:32:59.759045', '2015-03-05 13:19:10.969766');
INSERT INTO people VALUES (110, NULL, 'Wanda ', 'Acevedo ', false, 3, '', true, true, true, 87, '2015-02-24 02:34:06.462161', '2015-03-05 15:14:31.223288');
INSERT INTO people VALUES (217, 0, 'Abraham', 'Morales ', true, 0, '', true, true, true, 21, '2015-02-24 14:51:21.886829', '2015-03-05 13:21:04.003661');
INSERT INTO people VALUES (218, NULL, 'Johnny ', 'Rivera', true, 3, '', true, true, true, 21, '2015-02-24 14:51:45.799248', '2015-03-05 13:21:55.504051');
INSERT INTO people VALUES (273, 0, 'Rolando ', 'Pabellón ', true, 0, '', true, true, true, 32, '2015-02-25 13:22:35.132459', '2015-03-05 13:23:15.591058');
INSERT INTO people VALUES (141, 1, 'María E. ', 'Calderón ', false, 1, '', true, true, true, 25, '2015-02-24 04:33:33.087962', '2015-03-05 13:24:14.130692');
INSERT INTO people VALUES (163, NULL, 'Neris ', 'Carrasquillo ', false, 3, '', true, true, true, 26, '2015-02-24 13:50:59.0368', '2015-03-05 13:26:20.678311');
INSERT INTO people VALUES (98, 0, 'Emma ', 'Méndez ', false, 1, '', true, true, true, 50, '2015-02-24 02:26:31.869154', '2015-03-05 13:27:57.658568');
INSERT INTO people VALUES (165, NULL, 'Maria V.', 'Birriel ', false, 3, '', false, true, false, 26, '2015-02-24 13:51:43.982194', '2015-03-05 13:44:52.692699');
INSERT INTO people VALUES (221, NULL, 'Lained ', 'Bonano ', false, 3, '', true, true, true, 68, '2015-02-24 14:55:06.388086', '2015-03-05 13:30:00.637113');
INSERT INTO people VALUES (222, NULL, 'María ', 'Viera', false, 3, '', true, true, true, 68, '2015-02-24 14:56:17.092857', '2015-03-05 13:31:45.152913');
INSERT INTO people VALUES (162, 0, 'Nilsa ', 'Rodríguez Casillas', false, 0, '', true, true, true, 26, '2015-02-24 13:50:27.216163', '2015-03-05 13:34:24.899008');
INSERT INTO people VALUES (249, NULL, 'Yolanda ', 'Orengo Montes', false, 3, '', true, true, true, 99, '2015-02-24 15:16:47.614559', '2015-03-05 13:57:56.513317');
INSERT INTO people VALUES (204, NULL, 'Iris ', 'Colon Padilla ', false, 3, '', true, true, true, 66, '2015-02-24 14:42:04.139904', '2015-03-05 13:35:43.352948');
INSERT INTO people VALUES (203, NULL, 'Maria ', 'Quiñones ', false, 3, '', true, true, true, 66, '2015-02-24 14:41:40.761442', '2015-03-05 13:35:45.260159');
INSERT INTO people VALUES (152, NULL, 'Victor ', 'Rivera Santiago', true, 3, '', true, true, true, 25, '2015-02-24 13:26:17.801431', '2015-03-05 13:48:27.103729');
INSERT INTO people VALUES (111, 1, 'Edwin ', 'Mojica ', true, 4, 'Vocal', true, true, false, 60, '2015-02-24 02:34:40.419461', '2015-03-05 14:27:36.403258');
INSERT INTO people VALUES (102, NULL, 'Marisol ', 'Rosa ', true, 3, '', true, true, true, 52, '2015-02-24 02:29:10.040047', '2015-03-05 14:12:38.936809');
INSERT INTO people VALUES (241, 1, 'Magda ', 'Aguirre', false, 0, '', true, true, true, 76, '2015-02-24 15:12:09.346928', '2015-03-05 14:13:22.723843');
INSERT INTO people VALUES (267, NULL, 'Wanda I. ', 'Rentas Morales ', false, 5, '', true, true, false, 10, '2015-02-24 17:29:51.385662', '2015-03-05 15:00:14.235206');
INSERT INTO people VALUES (245, 0, 'Luis ', 'Serrano', true, 4, 'Representante General', true, true, true, 6, '2015-02-24 15:14:15.607845', '2015-03-05 14:45:08.32091');
INSERT INTO people VALUES (209, NULL, 'Víctor ', 'Valentín', true, 3, '', true, true, true, 84, '2015-02-24 14:44:22.637707', '2015-03-05 15:04:39.81251');
INSERT INTO people VALUES (112, 1, 'Norma I. ', 'Torres ', false, 2, '', true, true, true, 60, '2015-02-24 02:35:11.391098', '2015-03-05 15:24:34.332748');
INSERT INTO people VALUES (144, 0, 'Omar A. ', 'Santiago ', true, 1, '', true, true, true, 25, '2015-02-24 04:36:11.543037', '2015-03-05 16:19:41.71359');
INSERT INTO people VALUES (239, NULL, 'Robert ', 'Quintero Negrón', true, 3, '', true, true, true, 71, '2015-02-24 15:10:43.116616', '2015-03-06 12:05:59.954789');
INSERT INTO people VALUES (281, NULL, 'Carmen ', 'Zayas ', false, 3, '', false, true, false, 11, '2015-02-25 14:46:16.166752', '2015-03-02 19:20:52.902454');
INSERT INTO people VALUES (258, NULL, 'Miguel ', 'Carrasquillo ', true, 3, '', true, true, true, 18, '2015-02-24 15:31:57.720168', '2015-03-05 12:29:25.891939');
INSERT INTO people VALUES (268, 1, 'Carmen J.', 'Pagan ', false, 3, 'Sustituto', true, true, true, 103, '2015-02-24 17:33:42.65932', '2015-03-05 15:05:09.01363');
INSERT INTO people VALUES (423, 1, 'Luis', 'Ortiz', true, 2, '', false, true, false, NULL, '2015-03-04 19:59:14.085644', '2015-03-04 19:59:39.508207');
INSERT INTO people VALUES (424, 1, 'Dr. Efraín', 'Figueroa', true, 2, '', false, true, false, NULL, '2015-03-04 19:59:57.444176', '2015-03-04 20:02:42.796117');
INSERT INTO people VALUES (428, 1, 'Dr. David', 'Casillas', true, 2, '', false, true, false, NULL, '2015-03-04 20:01:27.472776', '2015-03-04 20:02:42.84836');
INSERT INTO people VALUES (429, 1, 'Jorge L.', 'Aledo', true, 2, '', false, true, false, NULL, '2015-03-04 20:01:53.792872', '2015-03-04 20:02:42.880533');
INSERT INTO people VALUES (430, NULL, 'Angelique', 'Acevedo', false, 4, 'Representante Distrito', false, true, false, NULL, '2015-03-04 20:01:55.722466', '2015-03-04 20:03:46.190454');
INSERT INTO people VALUES (432, 0, 'Georgina', 'Rodríguez', false, 2, '', false, true, false, NULL, '2015-03-04 20:02:23.24062', '2015-03-04 20:03:46.294663');
INSERT INTO people VALUES (433, 1, 'José A.', 'Alicea', true, 2, '', false, true, false, NULL, '2015-03-04 20:02:54.856394', '2015-03-04 20:03:46.303612');
INSERT INTO people VALUES (434, NULL, 'José', 'Cirio', true, 4, 'Representante Distrito', false, true, false, NULL, '2015-03-04 20:03:00.229594', '2015-03-04 20:03:46.307336');
INSERT INTO people VALUES (426, 0, 'Elpidio', 'Jiménez', true, 2, '', false, true, false, NULL, '2015-03-04 20:01:00.327583', '2015-03-04 20:04:17.270139');
INSERT INTO people VALUES (200, NULL, 'Minerva ', 'Rivera', false, 3, '', false, true, false, 69, '2015-02-24 14:37:42.741944', '2015-03-04 20:27:11.08668');
INSERT INTO people VALUES (278, 0, 'Germán ', 'Malavé', true, 0, '', true, true, true, 11, '2015-02-25 14:45:14.416172', '2015-03-06 12:40:21.507912');
INSERT INTO people VALUES (279, NULL, 'Lilliam ', 'Santos ', false, 3, '', true, true, true, 11, '2015-02-25 14:45:41.268414', '2015-03-05 12:29:30.977196');
INSERT INTO people VALUES (480, 0, 'Elias', 'Ramirez', true, 0, '', true, true, true, 92, '2015-03-05 12:36:34.927282', '2015-03-05 12:43:08.689594');
INSERT INTO people VALUES (230, NULL, 'Norma I.', 'Pérez', false, 3, '', true, true, true, 39, '2015-02-24 15:05:16.436013', '2015-03-05 12:30:16.393801');
INSERT INTO people VALUES (482, NULL, 'Eutimia ', 'Santiago', false, 3, '', false, true, false, 92, '2015-03-05 12:37:26.111157', '2015-03-05 12:43:08.696739');
INSERT INTO people VALUES (269, 0, 'Ramon ', 'Arroyo', true, 0, '', true, true, true, 40, '2015-02-24 17:40:29.026992', '2015-03-05 12:30:42.541685');
INSERT INTO people VALUES (272, NULL, 'Debora ', 'Varona Guerrero', false, 4, '', true, true, true, 3, '2015-02-24 18:10:46.12455', '2015-03-06 14:05:36.107868');
INSERT INTO people VALUES (228, NULL, 'Hector M. ', 'González ', true, 3, '', true, true, true, 97, '2015-02-24 15:04:05.736746', '2015-03-05 12:43:53.836313');
INSERT INTO people VALUES (229, NULL, 'Lucy ', 'Muñoz', false, 3, '', true, true, true, 39, '2015-02-24 15:04:56.866984', '2015-03-05 12:32:28.091249');
INSERT INTO people VALUES (137, NULL, 'Grisel ', 'Díaz ', false, 3, '', true, true, true, 23, '2015-02-24 02:53:15.800547', '2015-03-05 11:01:54.468972');
INSERT INTO people VALUES (444, 1, 'Lydia', 'Rivas', false, 4, 'Ministra Ejecutiva Asociada', true, true, false, NULL, '2015-03-04 20:12:18.772563', '2015-03-05 11:09:34.051576');
INSERT INTO people VALUES (29, NULL, 'Carmen N. ', 'Negrón ', false, 3, '', true, true, true, 12, '2015-02-24 01:39:08.318674', '2015-03-05 12:35:00.134037');
INSERT INTO people VALUES (113, NULL, 'Maria de los A. ', 'Rolón', false, 3, '', true, true, true, 60, '2015-02-24 02:35:37.036285', '2015-03-05 11:27:05.116051');
INSERT INTO people VALUES (474, NULL, 'José A.', 'Montalvo', true, 3, '', true, true, true, 17, '2015-03-05 12:32:18.729196', '2015-03-05 12:35:00.141825');
INSERT INTO people VALUES (264, NULL, 'Luis A. ', 'Poggi', true, 3, '', true, true, true, 96, '2015-02-24 15:37:27.835344', '2015-03-05 11:38:58.829582');
INSERT INTO people VALUES (475, NULL, 'Felix', 'Dones', true, 3, '', true, true, true, 17, '2015-03-05 12:33:06.602482', '2015-03-05 12:35:00.152029');
INSERT INTO people VALUES (425, 1, 'Rubén', 'Figueroa', true, 2, '', true, true, true, NULL, '2015-03-04 20:00:24.971762', '2015-03-05 11:41:50.031777');
INSERT INTO people VALUES (293, NULL, 'Diana ', 'Medina ', false, 4, '', true, true, true, 98, '2015-02-27 02:37:49.971019', '2015-03-05 15:30:58.834247');
INSERT INTO people VALUES (477, NULL, 'Betzaida ', 'Rodríguez', true, 1, '', true, true, true, 70, '2015-03-05 12:34:16.566383', '2015-03-05 12:35:00.166907');
INSERT INTO people VALUES (270, 4, 'Arturo J. ', 'Siaca', true, 3, '', true, true, true, 36, '2015-02-24 17:41:40.122104', '2015-03-05 12:12:55.084238');
INSERT INTO people VALUES (68, NULL, 'Daniel ', 'Santos ', true, 3, '', true, true, true, 36, '2015-02-24 02:05:58.200172', '2015-03-05 13:03:17.911474');
INSERT INTO people VALUES (435, 1, 'Aida', 'Castillo', false, 2, '', true, true, true, NULL, '2015-03-04 20:03:16.083663', '2015-03-05 12:19:47.741196');
INSERT INTO people VALUES (478, 0, 'Efrain', 'Torres', true, 0, '', true, true, true, 17, '2015-03-05 12:34:48.451627', '2015-03-05 12:38:04.162887');
INSERT INTO people VALUES (476, NULL, 'Carmen', 'Diaz', true, 3, '', true, true, true, 17, '2015-03-05 12:34:11.166891', '2015-03-05 12:38:04.337126');
INSERT INTO people VALUES (479, NULL, 'Ilia', 'Rivera', false, 3, '', true, true, true, 70, '2015-03-05 12:35:43.313739', '2015-03-05 12:38:04.777328');
INSERT INTO people VALUES (292, 0, 'Karilyn ', 'Galarza ', false, 0, '', true, true, true, 98, '2015-02-27 02:37:13.680893', '2015-03-05 15:32:51.268005');
INSERT INTO people VALUES (481, NULL, 'Angelique', 'Acevedo', false, 3, '', true, true, true, 70, '2015-03-05 12:36:43.818287', '2015-03-05 12:38:04.789293');
INSERT INTO people VALUES (441, NULL, 'Gloria ', 'Vázquez', false, 4, 'Comisión de Eduación Cristiana', true, true, true, NULL, '2015-03-04 20:09:32.032224', '2015-03-05 16:27:22.981632');
INSERT INTO people VALUES (196, NULL, 'Jossie ', 'Sostre', false, 3, '', true, true, true, 69, '2015-02-24 14:35:32.238243', '2015-03-05 13:08:31.086703');
INSERT INTO people VALUES (199, NULL, 'David ', 'Morales ', true, 3, '', true, true, true, 69, '2015-02-24 14:36:58.831092', '2015-03-05 13:18:37.102852');
INSERT INTO people VALUES (544, 0, 'María M.', 'Maysonet', false, 2, '', true, true, true, 123, '2015-03-05 17:17:45.981067', '2015-03-05 17:47:18.766632');
INSERT INTO people VALUES (483, NULL, 'Luis', 'Feliborty', true, 3, '', false, true, false, 92, '2015-03-05 12:38:05.332101', '2015-03-05 13:31:45.158846');
INSERT INTO people VALUES (545, 1, 'Pedro', 'Hernández Cortés', true, 2, '', true, true, true, 53, '2015-03-05 17:43:14.912393', '2015-03-05 17:47:18.945985');
INSERT INTO people VALUES (436, 0, 'Mercedes', 'Ortiz', false, 2, '', true, true, true, NULL, '2015-03-04 20:03:38.673185', '2015-03-05 13:32:25.152284');
INSERT INTO people VALUES (440, NULL, 'Luis', 'Coreano', true, 4, 'Comisión de Evangelismo', true, true, true, NULL, '2015-03-04 20:08:19.010844', '2015-03-05 13:52:21.885173');
INSERT INTO people VALUES (445, 1, 'Noelia', 'Rodríguez', false, 4, 'Ministra Ejecutiva Asociada', true, true, true, NULL, '2015-03-04 20:12:43.119888', '2015-03-05 19:13:57.209115');
INSERT INTO people VALUES (282, 1, 'Dr. Anibal ', 'Cruz ', true, 3, '', true, true, true, 121, '2015-02-25 14:47:11.251809', '2015-03-05 14:16:44.998896');
INSERT INTO people VALUES (443, 1, 'Dr. Roberto', 'Dieppa Baéz', true, 4, 'Ministro Ejecutivo', true, true, true, NULL, '2015-03-04 20:11:24.743812', '2015-03-05 14:27:10.213059');
INSERT INTO people VALUES (546, NULL, 'Heriberto', 'Del Valle', true, 3, '', true, true, true, 87, '2015-03-05 19:16:44.970557', '2015-03-05 19:16:44.970557');
INSERT INTO people VALUES (484, NULL, 'Doris', 'Díaz', false, 0, '', true, true, true, 70, '2015-03-05 12:40:14.532288', '2015-03-05 12:43:08.705331');
INSERT INTO people VALUES (485, NULL, 'Daniel', 'Pérez', true, 3, '', true, true, true, 34, '2015-03-05 12:42:27.976789', '2015-03-05 12:43:08.718568');
INSERT INTO people VALUES (486, 0, 'Ramón', 'Rivera', true, 3, '', false, true, false, 106, '2015-03-05 12:48:48.557431', '2015-03-05 12:51:12.478063');
INSERT INTO people VALUES (548, 0, 'Luis', 'Soto', true, 0, '', true, true, true, 125, '2015-03-06 12:06:37.744966', '2015-03-06 12:40:21.387656');
INSERT INTO people VALUES (547, NULL, 'Edwin', 'Cancel', true, 3, '', true, true, true, 116, '2015-03-06 11:35:20.713531', '2015-03-06 12:40:21.441835');
INSERT INTO people VALUES (488, NULL, 'Lucy', 'Falero', false, 3, '', true, true, true, 106, '2015-03-05 12:50:36.762007', '2015-03-05 12:51:21.981991');
INSERT INTO people VALUES (490, NULL, 'Carmen', 'Avilés', false, 3, '', true, true, true, 106, '2015-03-05 12:51:03.182242', '2015-03-05 13:00:16.772793');
INSERT INTO people VALUES (489, NULL, 'Dorcas ', 'Santiago Gonzalez', false, 3, '', true, true, true, 78, '2015-03-05 12:50:43.491764', '2015-03-05 17:17:16.262949');
INSERT INTO people VALUES (487, NULL, 'Heriberto ', 'Rivera Pabon', true, 0, '', true, true, true, 78, '2015-03-05 12:49:48.909547', '2015-03-05 17:17:16.272779');
INSERT INTO people VALUES (499, NULL, 'Richard D', 'Braden Feliciano', true, 3, '', true, true, true, 43, '2015-03-05 13:03:09.861203', '2015-03-06 12:40:21.536037');
INSERT INTO people VALUES (492, NULL, 'Carmelo', 'Garcia', true, 3, '', true, true, true, 28, '2015-03-05 12:59:05.928902', '2015-03-05 13:00:16.84545');
INSERT INTO people VALUES (494, NULL, 'Evelyn', 'De Jesús', false, 3, '', true, true, true, 28, '2015-03-05 12:59:44.557784', '2015-03-05 13:00:16.860448');
INSERT INTO people VALUES (495, NULL, 'Carmin', 'Figueroa', false, 3, '', true, true, true, 62, '2015-03-05 12:59:49.993938', '2015-03-05 13:00:38.361231');
INSERT INTO people VALUES (491, 0, 'María E.', 'García', false, 3, '', true, true, true, 62, '2015-03-05 12:58:40.007822', '2015-03-05 13:05:21.241871');
INSERT INTO people VALUES (496, NULL, 'Migdalia ', 'Rivera', false, 3, '', true, true, true, 28, '2015-03-05 13:00:09.175655', '2015-03-05 13:05:21.283867');
INSERT INTO people VALUES (497, 0, 'Victor', 'Monzon', true, 0, '', true, true, true, 28, '2015-03-05 13:00:37.952783', '2015-03-05 13:05:21.308986');
INSERT INTO people VALUES (501, NULL, 'Carmín', 'Rodríguez', false, 3, '', true, true, true, 35, '2015-03-05 13:05:38.226445', '2015-03-05 13:07:24.686694');
INSERT INTO people VALUES (500, 1, 'Yolanda', 'Ortiz', false, 2, '', true, true, true, 35, '2015-03-05 13:04:25.476127', '2015-03-05 13:12:38.773675');
INSERT INTO people VALUES (493, NULL, 'Héctor', 'López', true, 3, '', true, true, true, 62, '2015-03-05 12:59:14.380473', '2015-03-05 13:29:29.235182');
INSERT INTO people VALUES (498, NULL, 'Jose M ', 'Cariño', true, 0, '', true, true, true, 43, '2015-03-05 13:02:15.031993', '2015-03-05 15:26:07.269421');
INSERT INTO people VALUES (502, NULL, 'Elizabeth', 'Rodríguez', false, 3, '', true, true, true, 35, '2015-03-05 13:06:17.438532', '2015-03-05 13:07:24.701991');
INSERT INTO people VALUES (503, NULL, 'José', 'Nolasco', true, 3, '', true, true, true, 95, '2015-03-05 13:07:03.83', '2015-03-05 13:09:13.199943');
INSERT INTO people VALUES (504, NULL, 'Kenyi', 'Negrón', true, 3, '', true, true, true, 35, '2015-03-05 13:07:13.61338', '2015-03-06 15:30:22.242581');
INSERT INTO people VALUES (505, NULL, 'Rafael', 'Lebrón', true, 3, '', true, true, true, 95, '2015-03-05 13:08:14.657405', '2015-03-06 15:30:22.249615');
INSERT INTO people VALUES (508, NULL, 'Rafael', 'Dávila', true, 0, '', true, true, true, 126, '2015-03-05 13:13:04.886243', '2015-03-05 13:16:32.48787');
INSERT INTO people VALUES (506, NULL, 'Leftie', 'Millán', true, 3, '', false, true, false, 95, '2015-03-05 13:08:52.28262', '2015-03-05 13:16:32.910233');
INSERT INTO people VALUES (509, NULL, 'Eli Samuel', 'Morales', true, 3, '', true, true, true, 53, '2015-03-05 13:16:29.505474', '2015-03-05 13:18:37.093539');
INSERT INTO people VALUES (510, NULL, 'Priscila', 'Morales', false, 3, '', true, true, true, 53, '2015-03-05 13:16:53.763294', '2015-03-05 13:18:37.109599');
INSERT INTO people VALUES (511, NULL, 'Josue', 'Gonzalez', true, 5, '', true, true, true, 45, '2015-03-05 13:18:08.428148', '2015-03-05 13:18:37.118648');
INSERT INTO people VALUES (512, 1, 'Kemley', 'Rhodes', false, 3, '', true, true, true, 9, '2015-03-05 13:19:21.784568', '2015-03-05 13:27:41.031977');
INSERT INTO people VALUES (507, NULL, 'Neftalí', 'Saldaña', true, 3, '', false, true, false, 23, '2015-03-05 13:10:34.93391', '2015-03-06 17:27:07.563119');
INSERT INTO people VALUES (190, NULL, 'Joel ', 'Roldán Oquendo ', true, 3, '', true, true, true, 83, '2015-02-24 14:26:26.019892', '2015-03-05 10:59:39.911235');
INSERT INTO people VALUES (195, NULL, 'Arelys ', 'Ortiz', false, 3, '', true, true, true, 69, '2015-02-24 14:34:57.882413', '2015-03-05 13:27:41.266167');
INSERT INTO people VALUES (191, NULL, 'Raúl ', 'Matos Castilo', true, 3, '', true, true, true, 83, '2015-02-24 14:26:50.425779', '2015-03-05 11:38:49.441601');
INSERT INTO people VALUES (513, NULL, 'Wilfredo', 'Morales, CPA', true, 5, 'Misión Bautista Kissimmee', true, true, true, NULL, '2015-03-05 13:25:32.452347', '2015-03-05 13:27:41.677446');
INSERT INTO people VALUES (255, 0, 'Edgardo ', 'Caraballo', true, 4, 'Representante Distrito', true, true, true, 18, '2015-02-24 15:30:51.289108', '2015-03-05 11:47:07.168845');
INSERT INTO people VALUES (514, NULL, 'Ana N.', 'Montañez', false, 3, '', true, true, true, 111, '2015-03-05 13:26:47.165493', '2015-03-05 13:27:41.685016');
INSERT INTO people VALUES (188, NULL, 'Anidalia ', 'Rivera', false, 3, '', true, true, true, 42, '2015-02-24 14:19:32.496052', '2015-03-05 12:05:52.077109');
INSERT INTO people VALUES (187, NULL, 'Ada N.', 'Quiñones', false, 3, '', true, true, true, 42, '2015-02-24 14:19:01.547741', '2015-03-05 12:08:28.477766');
INSERT INTO people VALUES (294, 4, 'Nilda E. ', 'García ', false, 3, '', true, true, true, 83, '2015-02-27 02:39:11.936961', '2015-03-05 12:24:38.607725');
INSERT INTO people VALUES (515, NULL, 'Jose A.', 'Sanabria', true, 3, '', true, true, true, 77, '2015-03-05 13:26:48.833022', '2015-03-05 13:31:45.101496');
INSERT INTO people VALUES (185, 0, 'Javier E. ', 'Sosa Rodríguez', true, 0, '', true, true, true, 42, '2015-02-24 14:18:03.475814', '2015-03-05 12:45:17.925739');
INSERT INTO people VALUES (516, NULL, 'Rebecca', 'Morales', false, 5, 'Misión Bautista Kissimme', false, true, false, NULL, '2015-03-05 13:27:24.216283', '2015-03-05 13:31:45.130411');
INSERT INTO people VALUES (517, NULL, 'Jose', 'Tricoche', true, 3, '', true, true, true, 77, '2015-03-05 13:27:26.382803', '2015-03-05 13:31:45.137826');
INSERT INTO people VALUES (518, NULL, 'Daysi', 'Crespo Ramos', false, 0, '', true, true, true, 111, '2015-03-05 13:28:35.201341', '2015-03-05 13:31:45.145116');
INSERT INTO people VALUES (296, 1, 'Félix ', 'López ', true, 2, '', true, true, true, 53, '2015-02-27 02:44:42.000719', '2015-03-05 13:06:37.387161');
INSERT INTO people VALUES (519, NULL, 'Marilu', 'Dones', false, 0, '', true, true, true, 82, '2015-03-05 13:31:24.916843', '2015-03-05 13:34:48.446593');
INSERT INTO people VALUES (520, NULL, 'Carlos ', 'Reyes', true, 1, '', true, true, true, 82, '2015-03-05 13:31:51.836493', '2015-03-05 13:34:48.494521');
INSERT INTO people VALUES (521, NULL, 'Dolores', 'Marquez', false, 3, '', true, true, true, 82, '2015-03-05 13:32:15.245989', '2015-03-05 13:34:48.50045');
INSERT INTO people VALUES (522, NULL, 'Ydsia', 'Reyes', false, 3, '', true, true, true, 82, '2015-03-05 13:32:40.44871', '2015-03-05 13:34:48.50874');
INSERT INTO people VALUES (427, 2, 'Laura', 'Miraz', false, 5, 'Directora Ejec. Asociada, Board Staff Services', false, true, false, NULL, '2015-03-04 20:01:05.908035', '2015-03-04 20:34:19.744261');
INSERT INTO people VALUES (523, NULL, 'Zavier', 'Báez', true, 0, '', true, true, true, 35, '2015-03-05 13:34:40.147305', '2015-03-05 13:34:48.521705');
INSERT INTO people VALUES (186, NULL, 'Félix A.', 'Torres', true, 3, '', true, true, true, 42, '2015-02-24 14:18:37.60102', '2015-03-06 12:40:21.480308');
INSERT INTO people VALUES (232, NULL, 'Nilma Y. ', 'Agosto García', false, 5, '', false, true, false, 45, '2015-02-24 15:06:56.720207', '2015-03-02 19:22:19.251675');
INSERT INTO people VALUES (236, NULL, 'Maria C. ', 'Gómez García', false, 3, 'Sustituto', true, true, true, 45, '2015-02-24 15:08:43.89609', '2015-03-05 13:39:46.481047');
INSERT INTO people VALUES (234, NULL, 'Digna ', 'Valdés Laboy', false, 3, '', true, true, true, 45, '2015-02-24 15:07:44.27617', '2015-03-05 13:40:37.488103');
INSERT INTO people VALUES (298, NULL, 'Rebeca ', 'Rivera ', false, 3, '', true, true, true, 53, '2015-02-27 02:46:06.542945', '2015-03-05 13:42:29.689886');
INSERT INTO people VALUES (194, NULL, 'Maria ', 'Charles ', false, 3, '', true, true, true, 19, '2015-02-24 14:32:01.785633', '2015-03-05 13:47:29.621726');
INSERT INTO people VALUES (265, NULL, 'Angel M. ', 'García', true, 1, '', false, true, false, 69, '2015-02-24 15:40:47.634235', '2015-03-02 19:22:32.333288');
INSERT INTO people VALUES (193, NULL, 'Nilda ', 'García', false, 3, '', true, true, true, 19, '2015-02-24 14:28:49.381875', '2015-03-05 13:47:35.078067');
INSERT INTO people VALUES (431, NULL, 'Stan', 'Slade', true, 5, 'Consultor Mundial MI', false, true, false, NULL, '2015-03-04 20:02:22.961', '2015-03-04 20:41:23.430721');
INSERT INTO people VALUES (233, NULL, 'David ', 'Soto Cardona ', true, 3, '', false, true, false, 45, '2015-02-24 15:07:18.502531', '2015-03-04 20:34:19.620151');
INSERT INTO people VALUES (297, NULL, 'María ', 'Díaz Castillo', false, 3, '', true, true, true, 53, '2015-02-27 02:45:46.184223', '2015-03-05 13:57:56.525597');
INSERT INTO people VALUES (238, 0, 'Carlos A. ', 'Padilla Rivera ', true, 0, '', true, true, true, 47, '2015-02-24 15:09:45.918708', '2015-03-05 14:26:27.220069');
INSERT INTO people VALUES (231, 0, 'Celis ', 'Zambrana Batista', false, 0, '', true, true, true, 45, '2015-02-24 15:06:14.599552', '2015-03-05 13:14:44.789613');
INSERT INTO people VALUES (235, NULL, 'Luis ', 'Berrios Bones ', true, 3, '', true, true, true, 45, '2015-02-24 15:08:07.300651', '2015-03-05 13:15:56.12409');
INSERT INTO people VALUES (197, NULL, 'Daisy ', 'García', false, 3, '', true, true, true, 69, '2015-02-24 14:36:01.266279', '2015-03-05 13:16:32.917676');
INSERT INTO people VALUES (237, NULL, 'Santos ', 'Torres Padilla ', true, 3, 'Sustituto', true, true, true, 45, '2015-02-24 15:09:04.911706', '2015-03-05 13:17:06.242286');
INSERT INTO people VALUES (295, 1, 'José A. ', 'López', true, 0, '', true, true, true, 53, '2015-02-27 02:44:15.396685', '2015-03-05 13:18:27.550387');
INSERT INTO people VALUES (198, NULL, 'Antonio ', 'Freire', true, 3, '', true, true, true, 69, '2015-02-24 14:36:33.922822', '2015-03-05 13:18:37.086056');
INSERT INTO people VALUES (299, NULL, 'Isabel ', 'Calderón ', true, 3, '', true, true, true, 53, '2015-02-27 02:46:30.932917', '2015-03-05 13:23:55.653647');


--
-- Name: people_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marcel
--

SELECT pg_catalog.setval('people_id_seq', 553, true);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: marcel
--

INSERT INTO schema_migrations VALUES ('20140223001756');
INSERT INTO schema_migrations VALUES ('20140223002342');
INSERT INTO schema_migrations VALUES ('20140223004552');
INSERT INTO schema_migrations VALUES ('20140305014602');
INSERT INTO schema_migrations VALUES ('20140306012307');


--
-- Data for Name: versions; Type: TABLE DATA; Schema: public; Owner: marcel
--

INSERT INTO versions VALUES (1, 'Person', 1, 'create', NULL, NULL, '2015-02-23 22:21:49.901745');
INSERT INTO versions VALUES (2, 'Person', 2, 'create', NULL, NULL, '2015-02-23 22:22:37.699667');
INSERT INTO versions VALUES (3, 'Person', 3, 'create', NULL, NULL, '2015-02-23 22:23:11.600129');
INSERT INTO versions VALUES (4, 'Person', 4, 'create', NULL, NULL, '2015-02-23 22:23:49.80735');
INSERT INTO versions VALUES (5, 'Person', 5, 'create', NULL, NULL, '2015-02-23 22:24:15.400077');
INSERT INTO versions VALUES (6, 'Person', 6, 'create', NULL, NULL, '2015-02-23 22:25:35.266899');
INSERT INTO versions VALUES (7, 'Person', 7, 'create', NULL, NULL, '2015-02-23 22:26:10.39383');
INSERT INTO versions VALUES (8, 'Person', 8, 'create', NULL, NULL, '2015-02-23 22:26:41.589916');
INSERT INTO versions VALUES (9, 'Person', 9, 'create', NULL, NULL, '2015-02-23 22:27:06.710312');
INSERT INTO versions VALUES (10, 'Person', 10, 'create', NULL, NULL, '2015-02-24 01:17:20.486627');
INSERT INTO versions VALUES (11, 'Person', 11, 'create', NULL, NULL, '2015-02-24 01:17:56.12176');
INSERT INTO versions VALUES (12, 'Person', 12, 'create', NULL, NULL, '2015-02-24 01:18:51.364555');
INSERT INTO versions VALUES (13, 'Person', 13, 'create', NULL, NULL, '2015-02-24 01:19:13.410593');
INSERT INTO versions VALUES (14, 'Person', 14, 'create', NULL, NULL, '2015-02-24 01:19:45.855661');
INSERT INTO versions VALUES (15, 'Person', 15, 'create', NULL, NULL, '2015-02-24 01:20:22.246963');
INSERT INTO versions VALUES (16, 'Person', 16, 'create', NULL, NULL, '2015-02-24 01:20:55.461292');
INSERT INTO versions VALUES (17, 'Check', 1, 'create', NULL, NULL, '2015-02-24 01:21:39.718015');
INSERT INTO versions VALUES (18, 'Person', 15, 'destroy', NULL, '---
id: 15
salutation: 
name: ''Zoraida ''
lastnames: ''Rivera ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 103
created_at: 2015-02-24 01:20:22.245553000 Z
updated_at: 2015-02-24 01:20:22.245553000 Z
', '2015-02-24 01:22:09.972554');
INSERT INTO versions VALUES (19, 'Check', 2, 'create', NULL, NULL, '2015-02-24 01:23:13.970975');
INSERT INTO versions VALUES (20, 'Person', 17, 'create', NULL, NULL, '2015-02-24 01:24:22.066956');
INSERT INTO versions VALUES (21, 'Person', 18, 'create', NULL, NULL, '2015-02-24 01:25:06.339546');
INSERT INTO versions VALUES (22, 'Person', 19, 'create', NULL, NULL, '2015-02-24 01:25:39.805253');
INSERT INTO versions VALUES (23, 'Person', 20, 'create', NULL, NULL, '2015-02-24 01:26:07.106909');
INSERT INTO versions VALUES (24, 'Person', 21, 'create', NULL, NULL, '2015-02-24 01:26:30.754324');
INSERT INTO versions VALUES (25, 'Person', 22, 'create', NULL, NULL, '2015-02-24 01:27:13.15084');
INSERT INTO versions VALUES (26, 'Person', 23, 'create', NULL, NULL, '2015-02-24 01:27:43.736633');
INSERT INTO versions VALUES (27, 'Person', 24, 'create', NULL, NULL, '2015-02-24 01:28:09.899319');
INSERT INTO versions VALUES (28, 'Person', 25, 'create', NULL, NULL, '2015-02-24 01:28:40.669437');
INSERT INTO versions VALUES (29, 'Person', 26, 'create', NULL, NULL, '2015-02-24 01:29:09.931762');
INSERT INTO versions VALUES (30, 'Person', 23, 'update', NULL, '---
id: 23
salutation: 
name: ''Juan C ''
lastnames: ''Rivera ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 109
created_at: 2015-02-24 01:27:43.735306000 Z
updated_at: 2015-02-24 01:27:43.735306000 Z
', '2015-02-24 01:30:11.04792');
INSERT INTO versions VALUES (31, 'Check', 3, 'create', NULL, NULL, '2015-02-24 01:30:55.879659');
INSERT INTO versions VALUES (32, 'Check', 3, 'update', NULL, '---
id: 3
number: 16766
amount: 125.0
description: ''''
church_id: 109
created_at: 2015-02-24 01:30:55.878320000 Z
updated_at: 2015-02-24 01:30:55.878320000 Z
', '2015-02-24 01:31:24.07793');
INSERT INTO versions VALUES (33, 'Person', 27, 'create', NULL, NULL, '2015-02-24 01:37:45.572934');
INSERT INTO versions VALUES (34, 'Person', 28, 'create', NULL, NULL, '2015-02-24 01:38:14.146665');
INSERT INTO versions VALUES (35, 'Person', 29, 'create', NULL, NULL, '2015-02-24 01:39:08.320145');
INSERT INTO versions VALUES (36, 'Person', 30, 'create', NULL, NULL, '2015-02-24 01:39:31.366065');
INSERT INTO versions VALUES (37, 'Check', 4, 'create', NULL, NULL, '2015-02-24 01:40:25.872369');
INSERT INTO versions VALUES (38, 'Person', 31, 'create', NULL, NULL, '2015-02-24 01:41:36.18275');
INSERT INTO versions VALUES (39, 'Person', 32, 'create', NULL, NULL, '2015-02-24 01:42:07.442615');
INSERT INTO versions VALUES (40, 'Person', 33, 'create', NULL, NULL, '2015-02-24 01:42:32.460378');
INSERT INTO versions VALUES (41, 'Check', 5, 'create', NULL, NULL, '2015-02-24 01:43:19.619947');
INSERT INTO versions VALUES (42, 'Person', 34, 'create', NULL, NULL, '2015-02-24 01:43:56.326921');
INSERT INTO versions VALUES (43, 'Person', 35, 'create', NULL, NULL, '2015-02-24 01:44:21.296323');
INSERT INTO versions VALUES (44, 'Person', 36, 'create', NULL, NULL, '2015-02-24 01:44:56.282279');
INSERT INTO versions VALUES (45, 'Person', 37, 'create', NULL, NULL, '2015-02-24 01:45:18.351672');
INSERT INTO versions VALUES (46, 'Person', 38, 'create', NULL, NULL, '2015-02-24 01:45:45.279442');
INSERT INTO versions VALUES (47, 'Person', 39, 'create', NULL, NULL, '2015-02-24 01:46:09.754894');
INSERT INTO versions VALUES (48, 'Person', 40, 'create', NULL, NULL, '2015-02-24 01:46:45.494842');
INSERT INTO versions VALUES (49, 'Check', 6, 'create', NULL, NULL, '2015-02-24 01:48:40.589248');
INSERT INTO versions VALUES (50, 'Person', 41, 'create', NULL, NULL, '2015-02-24 01:49:18.956842');
INSERT INTO versions VALUES (51, 'Person', 42, 'create', NULL, NULL, '2015-02-24 01:49:43.060769');
INSERT INTO versions VALUES (52, 'Person', 43, 'create', NULL, NULL, '2015-02-24 01:50:05.17372');
INSERT INTO versions VALUES (53, 'Person', 44, 'create', NULL, NULL, '2015-02-24 01:51:09.642834');
INSERT INTO versions VALUES (54, 'Person', 45, 'create', NULL, NULL, '2015-02-24 01:51:34.053568');
INSERT INTO versions VALUES (55, 'Person', 46, 'create', NULL, NULL, '2015-02-24 01:51:58.623805');
INSERT INTO versions VALUES (56, 'Person', 47, 'create', NULL, NULL, '2015-02-24 01:52:30.067777');
INSERT INTO versions VALUES (57, 'Person', 48, 'create', NULL, NULL, '2015-02-24 01:53:09.271451');
INSERT INTO versions VALUES (58, 'Person', 49, 'create', NULL, NULL, '2015-02-24 01:53:29.172016');
INSERT INTO versions VALUES (59, 'Person', 50, 'create', NULL, NULL, '2015-02-24 01:53:49.392172');
INSERT INTO versions VALUES (60, 'Check', 7, 'create', NULL, NULL, '2015-02-24 01:54:18.603347');
INSERT INTO versions VALUES (61, 'Check', 7, 'update', NULL, '---
id: 7
number: 2594
amount: 75.0
description: ''''
church_id: 113
created_at: 2015-02-24 01:54:18.601953000 Z
updated_at: 2015-02-24 01:54:18.601953000 Z
', '2015-02-24 01:54:45.955145');
INSERT INTO versions VALUES (62, 'Person', 51, 'create', NULL, NULL, '2015-02-24 01:56:07.757841');
INSERT INTO versions VALUES (63, 'Person', 52, 'create', NULL, NULL, '2015-02-24 01:56:28.002852');
INSERT INTO versions VALUES (64, 'Person', 53, 'create', NULL, NULL, '2015-02-24 01:56:49.329393');
INSERT INTO versions VALUES (65, 'Person', 54, 'create', NULL, NULL, '2015-02-24 01:57:09.234681');
INSERT INTO versions VALUES (66, 'Person', 55, 'create', NULL, NULL, '2015-02-24 01:58:31.253179');
INSERT INTO versions VALUES (67, 'Person', 56, 'create', NULL, NULL, '2015-02-24 01:58:53.433009');
INSERT INTO versions VALUES (68, 'Person', 57, 'create', NULL, NULL, '2015-02-24 01:59:18.742186');
INSERT INTO versions VALUES (69, 'Person', 58, 'create', NULL, NULL, '2015-02-24 02:00:09.304152');
INSERT INTO versions VALUES (70, 'Person', 59, 'create', NULL, NULL, '2015-02-24 02:00:30.779435');
INSERT INTO versions VALUES (71, 'Person', 60, 'create', NULL, NULL, '2015-02-24 02:00:59.146573');
INSERT INTO versions VALUES (72, 'Person', 61, 'create', NULL, NULL, '2015-02-24 02:01:25.369135');
INSERT INTO versions VALUES (73, 'Person', 62, 'create', NULL, NULL, '2015-02-24 02:01:45.247966');
INSERT INTO versions VALUES (74, 'Person', 63, 'create', NULL, NULL, '2015-02-24 02:02:14.537637');
INSERT INTO versions VALUES (75, 'Person', 64, 'create', NULL, NULL, '2015-02-24 02:02:38.335515');
INSERT INTO versions VALUES (76, 'Person', 65, 'create', NULL, NULL, '2015-02-24 02:03:03.024245');
INSERT INTO versions VALUES (77, 'Person', 65, 'update', NULL, '---
id: 65
salutation: 1
name: ''Benigno ''
lastnames: ''Torres ''
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-02-24 02:03:03.022471000 Z
updated_at: 2015-02-24 02:03:03.022471000 Z
', '2015-02-24 02:03:54.748409');
INSERT INTO versions VALUES (78, 'Person', 66, 'create', NULL, NULL, '2015-02-24 02:05:02.060645');
INSERT INTO versions VALUES (79, 'Person', 67, 'create', NULL, NULL, '2015-02-24 02:05:28.777575');
INSERT INTO versions VALUES (80, 'Person', 68, 'create', NULL, NULL, '2015-02-24 02:05:58.201675');
INSERT INTO versions VALUES (81, 'Person', 69, 'create', NULL, NULL, '2015-02-24 02:06:47.611025');
INSERT INTO versions VALUES (82, 'Person', 70, 'create', NULL, NULL, '2015-02-24 02:07:15.108041');
INSERT INTO versions VALUES (83, 'Person', 71, 'create', NULL, NULL, '2015-02-24 02:07:36.948529');
INSERT INTO versions VALUES (84, 'Person', 72, 'create', NULL, NULL, '2015-02-24 02:08:16.278744');
INSERT INTO versions VALUES (85, 'Person', 73, 'create', NULL, NULL, '2015-02-24 02:08:54.003985');
INSERT INTO versions VALUES (86, 'Person', 74, 'create', NULL, NULL, '2015-02-24 02:09:58.049222');
INSERT INTO versions VALUES (87, 'Person', 75, 'create', NULL, NULL, '2015-02-24 02:10:31.345772');
INSERT INTO versions VALUES (88, 'Person', 76, 'create', NULL, NULL, '2015-02-24 02:11:21.045009');
INSERT INTO versions VALUES (89, 'Person', 77, 'create', NULL, NULL, '2015-02-24 02:11:56.860112');
INSERT INTO versions VALUES (90, 'Person', 78, 'create', NULL, NULL, '2015-02-24 02:12:58.695113');
INSERT INTO versions VALUES (91, 'Person', 79, 'create', NULL, NULL, '2015-02-24 02:13:25.269547');
INSERT INTO versions VALUES (92, 'Person', 80, 'create', NULL, NULL, '2015-02-24 02:13:57.476863');
INSERT INTO versions VALUES (93, 'Person', 81, 'create', NULL, NULL, '2015-02-24 02:14:22.854026');
INSERT INTO versions VALUES (94, 'Person', 82, 'create', NULL, NULL, '2015-02-24 02:14:48.427723');
INSERT INTO versions VALUES (95, 'Person', 83, 'create', NULL, NULL, '2015-02-24 02:15:12.647318');
INSERT INTO versions VALUES (96, 'Person', 84, 'create', NULL, NULL, '2015-02-24 02:15:41.376716');
INSERT INTO versions VALUES (97, 'Person', 85, 'create', NULL, NULL, '2015-02-24 02:16:06.985908');
INSERT INTO versions VALUES (98, 'Person', 86, 'create', NULL, NULL, '2015-02-24 02:16:38.056363');
INSERT INTO versions VALUES (99, 'Person', 87, 'create', NULL, NULL, '2015-02-24 02:17:00.755377');
INSERT INTO versions VALUES (100, 'Person', 88, 'create', NULL, NULL, '2015-02-24 02:17:31.010378');
INSERT INTO versions VALUES (101, 'Person', 89, 'create', NULL, NULL, '2015-02-24 02:17:55.398765');
INSERT INTO versions VALUES (102, 'Person', 90, 'create', NULL, NULL, '2015-02-24 02:18:41.546845');
INSERT INTO versions VALUES (103, 'Check', 8, 'create', NULL, NULL, '2015-02-24 02:19:44.590197');
INSERT INTO versions VALUES (104, 'Person', 91, 'create', NULL, NULL, '2015-02-24 02:22:48.676859');
INSERT INTO versions VALUES (105, 'Person', 92, 'create', NULL, NULL, '2015-02-24 02:23:11.720458');
INSERT INTO versions VALUES (106, 'Person', 93, 'create', NULL, NULL, '2015-02-24 02:23:34.712691');
INSERT INTO versions VALUES (107, 'Person', 94, 'create', NULL, NULL, '2015-02-24 02:24:44.09048');
INSERT INTO versions VALUES (108, 'Person', 95, 'create', NULL, NULL, '2015-02-24 02:25:06.880322');
INSERT INTO versions VALUES (109, 'Person', 96, 'create', NULL, NULL, '2015-02-24 02:25:30.270239');
INSERT INTO versions VALUES (110, 'Person', 97, 'create', NULL, NULL, '2015-02-24 02:26:09.99092');
INSERT INTO versions VALUES (111, 'Person', 98, 'create', NULL, NULL, '2015-02-24 02:26:31.870618');
INSERT INTO versions VALUES (112, 'Person', 99, 'create', NULL, NULL, '2015-02-24 02:26:53.656163');
INSERT INTO versions VALUES (113, 'Person', 100, 'create', NULL, NULL, '2015-02-24 02:27:18.422051');
INSERT INTO versions VALUES (114, 'Person', 101, 'create', NULL, NULL, '2015-02-24 02:28:47.99973');
INSERT INTO versions VALUES (115, 'Person', 102, 'create', NULL, NULL, '2015-02-24 02:29:10.041458');
INSERT INTO versions VALUES (116, 'Person', 103, 'create', NULL, NULL, '2015-02-24 02:29:30.898235');
INSERT INTO versions VALUES (117, 'Person', 104, 'create', NULL, NULL, '2015-02-24 02:30:03.653599');
INSERT INTO versions VALUES (118, 'Person', 105, 'create', NULL, NULL, '2015-02-24 02:30:38.334674');
INSERT INTO versions VALUES (119, 'Person', 106, 'create', NULL, NULL, '2015-02-24 02:31:01.729791');
INSERT INTO versions VALUES (120, 'Check', 9, 'create', NULL, NULL, '2015-02-24 02:31:36.764952');
INSERT INTO versions VALUES (121, 'Check', 9, 'update', NULL, '---
id: 9
number: 3353
amount: 150.0
description: ''''
church_id: 52
created_at: 2015-02-24 02:31:36.763363000 Z
updated_at: 2015-02-24 02:31:36.763363000 Z
', '2015-02-24 02:32:04.577361');
INSERT INTO versions VALUES (122, 'Person', 107, 'create', NULL, NULL, '2015-02-24 02:32:59.76088');
INSERT INTO versions VALUES (123, 'Person', 108, 'create', NULL, NULL, '2015-02-24 02:33:19.630873');
INSERT INTO versions VALUES (124, 'Person', 109, 'create', NULL, NULL, '2015-02-24 02:33:49.141266');
INSERT INTO versions VALUES (125, 'Person', 110, 'create', NULL, NULL, '2015-02-24 02:34:06.463615');
INSERT INTO versions VALUES (126, 'Person', 111, 'create', NULL, NULL, '2015-02-24 02:34:40.420902');
INSERT INTO versions VALUES (127, 'Person', 112, 'create', NULL, NULL, '2015-02-24 02:35:11.392678');
INSERT INTO versions VALUES (128, 'Person', 113, 'create', NULL, NULL, '2015-02-24 02:35:37.037745');
INSERT INTO versions VALUES (129, 'Person', 114, 'create', NULL, NULL, '2015-02-24 02:35:59.458846');
INSERT INTO versions VALUES (130, 'Person', 115, 'create', NULL, NULL, '2015-02-24 02:36:19.733987');
INSERT INTO versions VALUES (131, 'Person', 116, 'create', NULL, NULL, '2015-02-24 02:36:47.172787');
INSERT INTO versions VALUES (132, 'Person', 117, 'create', NULL, NULL, '2015-02-24 02:37:12.733112');
INSERT INTO versions VALUES (133, 'Person', 118, 'create', NULL, NULL, '2015-02-24 02:37:32.521526');
INSERT INTO versions VALUES (134, 'Check', 10, 'create', NULL, NULL, '2015-02-24 02:38:19.294466');
INSERT INTO versions VALUES (135, 'Person', 119, 'create', NULL, NULL, '2015-02-24 02:39:10.399414');
INSERT INTO versions VALUES (136, 'Person', 120, 'create', NULL, NULL, '2015-02-24 02:39:44.623836');
INSERT INTO versions VALUES (137, 'Person', 121, 'create', NULL, NULL, '2015-02-24 02:40:13.364407');
INSERT INTO versions VALUES (138, 'Person', 122, 'create', NULL, NULL, '2015-02-24 02:40:50.080239');
INSERT INTO versions VALUES (139, 'Person', 123, 'create', NULL, NULL, '2015-02-24 02:41:19.739725');
INSERT INTO versions VALUES (140, 'Person', 124, 'create', NULL, NULL, '2015-02-24 02:41:48.370063');
INSERT INTO versions VALUES (141, 'Person', 125, 'create', NULL, NULL, '2015-02-24 02:42:20.49695');
INSERT INTO versions VALUES (142, 'Person', 126, 'create', NULL, NULL, '2015-02-24 02:42:55.83851');
INSERT INTO versions VALUES (143, 'Check', 11, 'create', NULL, NULL, '2015-02-24 02:44:41.809206');
INSERT INTO versions VALUES (144, 'Person', 127, 'create', NULL, NULL, '2015-02-24 02:45:36.539014');
INSERT INTO versions VALUES (145, 'Person', 128, 'create', NULL, NULL, '2015-02-24 02:46:03.77818');
INSERT INTO versions VALUES (146, 'Person', 129, 'create', NULL, NULL, '2015-02-24 02:46:39.452835');
INSERT INTO versions VALUES (147, 'Person', 130, 'create', NULL, NULL, '2015-02-24 02:47:50.486513');
INSERT INTO versions VALUES (148, 'Person', 131, 'create', NULL, NULL, '2015-02-24 02:48:14.618443');
INSERT INTO versions VALUES (149, 'Person', 132, 'create', NULL, NULL, '2015-02-24 02:48:45.525139');
INSERT INTO versions VALUES (150, 'Person', 133, 'create', NULL, NULL, '2015-02-24 02:49:09.239835');
INSERT INTO versions VALUES (151, 'Person', 134, 'create', NULL, NULL, '2015-02-24 02:52:08.031716');
INSERT INTO versions VALUES (152, 'Person', 135, 'create', NULL, NULL, '2015-02-24 02:52:29.815935');
INSERT INTO versions VALUES (153, 'Person', 136, 'create', NULL, NULL, '2015-02-24 02:52:52.626386');
INSERT INTO versions VALUES (154, 'Person', 137, 'create', NULL, NULL, '2015-02-24 02:53:15.80197');
INSERT INTO versions VALUES (155, 'Person', 138, 'create', NULL, NULL, '2015-02-24 04:30:24.199759');
INSERT INTO versions VALUES (156, 'Person', 139, 'create', NULL, NULL, '2015-02-24 04:31:25.128997');
INSERT INTO versions VALUES (157, 'Person', 140, 'create', NULL, NULL, '2015-02-24 04:32:32.980474');
INSERT INTO versions VALUES (158, 'Person', 141, 'create', NULL, NULL, '2015-02-24 04:33:33.089332');
INSERT INTO versions VALUES (159, 'Person', 142, 'create', NULL, NULL, '2015-02-24 04:34:25.077273');
INSERT INTO versions VALUES (160, 'Person', 143, 'create', NULL, NULL, '2015-02-24 04:35:16.500817');
INSERT INTO versions VALUES (161, 'Person', 144, 'create', NULL, NULL, '2015-02-24 04:36:11.544534');
INSERT INTO versions VALUES (162, 'Person', 145, 'create', NULL, NULL, '2015-02-24 04:37:06.047981');
INSERT INTO versions VALUES (163, 'Person', 146, 'create', NULL, NULL, '2015-02-24 04:37:52.520168');
INSERT INTO versions VALUES (164, 'Person', 147, 'create', NULL, NULL, '2015-02-24 04:38:43.992218');
INSERT INTO versions VALUES (165, 'Person', 148, 'create', NULL, NULL, '2015-02-24 04:39:28.231812');
INSERT INTO versions VALUES (166, 'Person', 149, 'create', NULL, NULL, '2015-02-24 04:40:17.713045');
INSERT INTO versions VALUES (167, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 04:37:52.518536000 Z
', '2015-02-24 11:46:38.002538');
INSERT INTO versions VALUES (168, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:46:37.999776000 Z
', '2015-02-24 11:46:40.295241');
INSERT INTO versions VALUES (169, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:46:40.292341000 Z
', '2015-02-24 11:46:42.116302');
INSERT INTO versions VALUES (170, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:46:42.114299000 Z
', '2015-02-24 11:46:43.220322');
INSERT INTO versions VALUES (171, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:46:43.217077000 Z
', '2015-02-24 11:46:47.516684');
INSERT INTO versions VALUES (172, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:46:47.514111000 Z
', '2015-02-24 11:53:58.238955');
INSERT INTO versions VALUES (173, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:53:58.235747000 Z
', '2015-02-24 11:53:59.44038');
INSERT INTO versions VALUES (174, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:53:59.438244000 Z
', '2015-02-24 11:54:00.903114');
INSERT INTO versions VALUES (175, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:00.900951000 Z
', '2015-02-24 11:54:02.702871');
INSERT INTO versions VALUES (176, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:02.700718000 Z
', '2015-02-24 11:54:03.684528');
INSERT INTO versions VALUES (177, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:03.681401000 Z
', '2015-02-24 11:54:04.886565');
INSERT INTO versions VALUES (178, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:04.884076000 Z
', '2015-02-24 11:54:05.774973');
INSERT INTO versions VALUES (179, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:05.772188000 Z
', '2015-02-24 11:54:06.696389');
INSERT INTO versions VALUES (180, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:06.694427000 Z
', '2015-02-24 11:54:07.607898');
INSERT INTO versions VALUES (181, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:07.605728000 Z
', '2015-02-24 11:54:13.435703');
INSERT INTO versions VALUES (182, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:13.433344000 Z
', '2015-02-24 11:54:14.323893');
INSERT INTO versions VALUES (183, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:14.321943000 Z
', '2015-02-24 11:54:15.077901');
INSERT INTO versions VALUES (184, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:15.075681000 Z
', '2015-02-24 11:54:19.028317');
INSERT INTO versions VALUES (185, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:19.025839000 Z
', '2015-02-24 11:54:20.568488');
INSERT INTO versions VALUES (186, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:20.565654000 Z
', '2015-02-24 11:54:25.30584');
INSERT INTO versions VALUES (187, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:25.302562000 Z
', '2015-02-24 11:54:29.454923');
INSERT INTO versions VALUES (188, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:29.452886000 Z
', '2015-02-24 11:55:05.279387');
INSERT INTO versions VALUES (189, 'Person', 150, 'create', NULL, NULL, '2015-02-24 13:22:38.517374');
INSERT INTO versions VALUES (190, 'Person', 151, 'create', NULL, NULL, '2015-02-24 13:25:34.791304');
INSERT INTO versions VALUES (191, 'Person', 152, 'create', NULL, NULL, '2015-02-24 13:26:17.802922');
INSERT INTO versions VALUES (192, 'Person', 153, 'create', NULL, NULL, '2015-02-24 13:26:47.058171');
INSERT INTO versions VALUES (193, 'Person', 153, 'update', NULL, '---
id: 153
salutation: 
name: Lillian
lastnames: Rivera Morales
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:26:47.056805000 Z
updated_at: 2015-02-24 13:26:47.056805000 Z
', '2015-02-24 13:27:22.978194');
INSERT INTO versions VALUES (194, 'Person', 154, 'create', NULL, NULL, '2015-02-24 13:30:40.270092');
INSERT INTO versions VALUES (195, 'Person', 155, 'create', NULL, NULL, '2015-02-24 13:31:13.6839');
INSERT INTO versions VALUES (196, 'Person', 156, 'create', NULL, NULL, '2015-02-24 13:31:44.770139');
INSERT INTO versions VALUES (197, 'Person', 157, 'create', NULL, NULL, '2015-02-24 13:32:21.485896');
INSERT INTO versions VALUES (198, 'Person', 158, 'create', NULL, NULL, '2015-02-24 13:32:55.492542');
INSERT INTO versions VALUES (199, 'Person', 159, 'create', NULL, NULL, '2015-02-24 13:33:17.400851');
INSERT INTO versions VALUES (200, 'Person', 160, 'create', NULL, NULL, '2015-02-24 13:33:40.852475');
INSERT INTO versions VALUES (201, 'Person', 161, 'create', NULL, NULL, '2015-02-24 13:34:03.072028');
INSERT INTO versions VALUES (202, 'Person', 162, 'create', NULL, NULL, '2015-02-24 13:50:27.218475');
INSERT INTO versions VALUES (203, 'Person', 163, 'create', NULL, NULL, '2015-02-24 13:50:59.038312');
INSERT INTO versions VALUES (204, 'Person', 164, 'create', NULL, NULL, '2015-02-24 13:51:15.710274');
INSERT INTO versions VALUES (205, 'Person', 165, 'create', NULL, NULL, '2015-02-24 13:51:43.983766');
INSERT INTO versions VALUES (206, 'Person', 166, 'create', NULL, NULL, '2015-02-24 13:52:46.227022');
INSERT INTO versions VALUES (207, 'Person', 167, 'create', NULL, NULL, '2015-02-24 13:54:46.989559');
INSERT INTO versions VALUES (208, 'Person', 168, 'create', NULL, NULL, '2015-02-24 13:55:10.763636');
INSERT INTO versions VALUES (209, 'Person', 169, 'create', NULL, NULL, '2015-02-24 13:55:28.177839');
INSERT INTO versions VALUES (210, 'Person', 170, 'create', NULL, NULL, '2015-02-24 13:55:46.932084');
INSERT INTO versions VALUES (211, 'Person', 171, 'create', NULL, NULL, '2015-02-24 13:56:21.985752');
INSERT INTO versions VALUES (212, 'Person', 172, 'create', NULL, NULL, '2015-02-24 13:58:26.023248');
INSERT INTO versions VALUES (213, 'Person', 173, 'create', NULL, NULL, '2015-02-24 14:00:34.17568');
INSERT INTO versions VALUES (214, 'Person', 174, 'create', NULL, NULL, '2015-02-24 14:01:17.188198');
INSERT INTO versions VALUES (215, 'Person', 174, 'update', NULL, '---
id: 174
salutation: 0
name: ''Rosalba ''
lastnames: Vila
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 24
created_at: 2015-02-24 14:01:17.186728000 Z
updated_at: 2015-02-24 14:01:17.186728000 Z
', '2015-02-24 14:01:55.519213');
INSERT INTO versions VALUES (216, 'Person', 175, 'create', NULL, NULL, '2015-02-24 14:03:07.963799');
INSERT INTO versions VALUES (217, 'Person', 176, 'create', NULL, NULL, '2015-02-24 14:03:23.993745');
INSERT INTO versions VALUES (218, 'Person', 177, 'create', NULL, NULL, '2015-02-24 14:06:06.142529');
INSERT INTO versions VALUES (219, 'Person', 178, 'create', NULL, NULL, '2015-02-24 14:06:33.869547');
INSERT INTO versions VALUES (220, 'Person', 179, 'create', NULL, NULL, '2015-02-24 14:07:06.34803');
INSERT INTO versions VALUES (221, 'Person', 180, 'create', NULL, NULL, '2015-02-24 14:08:52.761461');
INSERT INTO versions VALUES (222, 'Person', 181, 'create', NULL, NULL, '2015-02-24 14:09:15.74451');
INSERT INTO versions VALUES (223, 'Person', 182, 'create', NULL, NULL, '2015-02-24 14:09:37.57454');
INSERT INTO versions VALUES (224, 'Person', 183, 'create', NULL, NULL, '2015-02-24 14:10:04.473562');
INSERT INTO versions VALUES (225, 'Person', 184, 'create', NULL, NULL, '2015-02-24 14:10:25.179844');
INSERT INTO versions VALUES (226, 'Person', 185, 'create', NULL, NULL, '2015-02-24 14:18:03.477371');
INSERT INTO versions VALUES (227, 'Person', 186, 'create', NULL, NULL, '2015-02-24 14:18:37.602559');
INSERT INTO versions VALUES (228, 'Person', 187, 'create', NULL, NULL, '2015-02-24 14:19:01.549231');
INSERT INTO versions VALUES (229, 'Person', 188, 'create', NULL, NULL, '2015-02-24 14:19:32.497465');
INSERT INTO versions VALUES (230, 'Check', 12, 'create', NULL, NULL, '2015-02-24 14:20:37.477361');
INSERT INTO versions VALUES (231, 'Person', 189, 'create', NULL, NULL, '2015-02-24 14:24:45.330794');
INSERT INTO versions VALUES (232, 'Person', 190, 'create', NULL, NULL, '2015-02-24 14:26:26.021491');
INSERT INTO versions VALUES (233, 'Person', 191, 'create', NULL, NULL, '2015-02-24 14:26:50.4275');
INSERT INTO versions VALUES (234, 'Person', 192, 'create', NULL, NULL, '2015-02-24 14:28:11.785658');
INSERT INTO versions VALUES (235, 'Person', 193, 'create', NULL, NULL, '2015-02-24 14:28:49.383363');
INSERT INTO versions VALUES (236, 'Person', 194, 'create', NULL, NULL, '2015-02-24 14:32:01.787631');
INSERT INTO versions VALUES (237, 'Person', 195, 'create', NULL, NULL, '2015-02-24 14:34:57.884085');
INSERT INTO versions VALUES (238, 'Person', 196, 'create', NULL, NULL, '2015-02-24 14:35:32.23974');
INSERT INTO versions VALUES (239, 'Person', 197, 'create', NULL, NULL, '2015-02-24 14:36:01.267754');
INSERT INTO versions VALUES (240, 'Person', 198, 'create', NULL, NULL, '2015-02-24 14:36:33.924204');
INSERT INTO versions VALUES (241, 'Person', 199, 'create', NULL, NULL, '2015-02-24 14:36:58.832552');
INSERT INTO versions VALUES (242, 'Person', 200, 'create', NULL, NULL, '2015-02-24 14:37:42.743459');
INSERT INTO versions VALUES (243, 'Check', 13, 'create', NULL, NULL, '2015-02-24 14:38:44.974435');
INSERT INTO versions VALUES (244, 'Person', 201, 'create', NULL, NULL, '2015-02-24 14:39:41.629697');
INSERT INTO versions VALUES (245, 'Check', 14, 'create', NULL, NULL, '2015-02-24 14:40:06.249185');
INSERT INTO versions VALUES (246, 'Person', 202, 'create', NULL, NULL, '2015-02-24 14:41:07.88917');
INSERT INTO versions VALUES (247, 'Person', 203, 'create', NULL, NULL, '2015-02-24 14:41:40.762995');
INSERT INTO versions VALUES (248, 'Person', 204, 'create', NULL, NULL, '2015-02-24 14:42:04.141506');
INSERT INTO versions VALUES (249, 'Person', 205, 'create', NULL, NULL, '2015-02-24 14:42:43.921755');
INSERT INTO versions VALUES (250, 'Person', 206, 'create', NULL, NULL, '2015-02-24 14:43:11.480913');
INSERT INTO versions VALUES (251, 'Person', 207, 'create', NULL, NULL, '2015-02-24 14:43:36.160917');
INSERT INTO versions VALUES (252, 'Person', 208, 'create', NULL, NULL, '2015-02-24 14:43:53.103039');
INSERT INTO versions VALUES (253, 'Person', 209, 'create', NULL, NULL, '2015-02-24 14:44:22.639564');
INSERT INTO versions VALUES (254, 'Person', 210, 'create', NULL, NULL, '2015-02-24 14:44:40.126982');
INSERT INTO versions VALUES (255, 'Person', 211, 'create', NULL, NULL, '2015-02-24 14:45:14.701311');
INSERT INTO versions VALUES (256, 'Person', 212, 'create', NULL, NULL, '2015-02-24 14:45:35.729465');
INSERT INTO versions VALUES (257, 'Person', 213, 'create', NULL, NULL, '2015-02-24 14:46:01.726522');
INSERT INTO versions VALUES (258, 'Person', 214, 'create', NULL, NULL, '2015-02-24 14:46:22.78016');
INSERT INTO versions VALUES (259, 'Person', 215, 'create', NULL, NULL, '2015-02-24 14:46:39.865416');
INSERT INTO versions VALUES (260, 'Person', 216, 'create', NULL, NULL, '2015-02-24 14:46:58.270888');
INSERT INTO versions VALUES (261, 'Person', 205, 'update', NULL, '---
id: 205
salutation: 1
name: Luz E.
lastnames: Rodríguez
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 84
created_at: 2015-02-24 14:42:43.920366000 Z
updated_at: 2015-02-24 14:42:43.920366000 Z
', '2015-02-24 14:47:16.12489');
INSERT INTO versions VALUES (262, 'Check', 15, 'create', NULL, NULL, '2015-02-24 14:48:15.866233');
INSERT INTO versions VALUES (263, 'Person', 189, 'destroy', NULL, '---
id: 189
salutation: 0
name: ''Nilsa E. ''
lastnames: García García
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 83
created_at: 2015-02-24 14:24:45.329288000 Z
updated_at: 2015-02-24 14:24:45.329288000 Z
', '2015-02-24 14:50:11.859041');
INSERT INTO versions VALUES (264, 'Person', 217, 'create', NULL, NULL, '2015-02-24 14:51:21.888396');
INSERT INTO versions VALUES (265, 'Person', 218, 'create', NULL, NULL, '2015-02-24 14:51:45.800687');
INSERT INTO versions VALUES (266, 'Person', 219, 'create', NULL, NULL, '2015-02-24 14:51:58.887121');
INSERT INTO versions VALUES (267, 'Check', 16, 'create', NULL, NULL, '2015-02-24 14:52:32.777828');
INSERT INTO versions VALUES (268, 'Person', 220, 'create', NULL, NULL, '2015-02-24 14:54:01.688405');
INSERT INTO versions VALUES (269, 'Person', 221, 'create', NULL, NULL, '2015-02-24 14:55:06.389431');
INSERT INTO versions VALUES (270, 'Person', 222, 'create', NULL, NULL, '2015-02-24 14:56:17.094444');
INSERT INTO versions VALUES (271, 'Check', 17, 'create', NULL, NULL, '2015-02-24 14:57:39.191883');
INSERT INTO versions VALUES (272, 'Person', 223, 'create', NULL, NULL, '2015-02-24 15:00:38.846428');
INSERT INTO versions VALUES (273, 'Person', 224, 'create', NULL, NULL, '2015-02-24 15:01:02.224339');
INSERT INTO versions VALUES (274, 'Person', 225, 'create', NULL, NULL, '2015-02-24 15:01:44.626128');
INSERT INTO versions VALUES (275, 'Person', 226, 'create', NULL, NULL, '2015-02-24 15:02:58.246178');
INSERT INTO versions VALUES (276, 'Person', 227, 'create', NULL, NULL, '2015-02-24 15:03:30.851255');
INSERT INTO versions VALUES (277, 'Person', 228, 'create', NULL, NULL, '2015-02-24 15:04:05.738242');
INSERT INTO versions VALUES (278, 'Person', 229, 'create', NULL, NULL, '2015-02-24 15:04:56.868511');
INSERT INTO versions VALUES (279, 'Person', 230, 'create', NULL, NULL, '2015-02-24 15:05:16.437552');
INSERT INTO versions VALUES (280, 'Person', 231, 'create', NULL, NULL, '2015-02-24 15:06:14.601159');
INSERT INTO versions VALUES (281, 'Person', 232, 'create', NULL, NULL, '2015-02-24 15:06:56.721672');
INSERT INTO versions VALUES (282, 'Person', 233, 'create', NULL, NULL, '2015-02-24 15:07:18.50397');
INSERT INTO versions VALUES (283, 'Person', 234, 'create', NULL, NULL, '2015-02-24 15:07:44.277752');
INSERT INTO versions VALUES (284, 'Person', 235, 'create', NULL, NULL, '2015-02-24 15:08:07.302391');
INSERT INTO versions VALUES (285, 'Person', 236, 'create', NULL, NULL, '2015-02-24 15:08:43.897686');
INSERT INTO versions VALUES (286, 'Person', 237, 'create', NULL, NULL, '2015-02-24 15:09:04.913212');
INSERT INTO versions VALUES (287, 'Person', 238, 'create', NULL, NULL, '2015-02-24 15:09:45.920205');
INSERT INTO versions VALUES (288, 'Person', 239, 'create', NULL, NULL, '2015-02-24 15:10:43.118174');
INSERT INTO versions VALUES (289, 'Person', 240, 'create', NULL, NULL, '2015-02-24 15:11:09.637334');
INSERT INTO versions VALUES (290, 'Person', 241, 'create', NULL, NULL, '2015-02-24 15:12:09.348457');
INSERT INTO versions VALUES (291, 'Person', 242, 'create', NULL, NULL, '2015-02-24 15:12:49.334472');
INSERT INTO versions VALUES (292, 'Person', 243, 'create', NULL, NULL, '2015-02-24 15:13:14.964399');
INSERT INTO versions VALUES (293, 'Person', 244, 'create', NULL, NULL, '2015-02-24 15:13:38.482052');
INSERT INTO versions VALUES (294, 'Person', 245, 'create', NULL, NULL, '2015-02-24 15:14:15.609322');
INSERT INTO versions VALUES (295, 'Person', 246, 'create', NULL, NULL, '2015-02-24 15:14:41.257614');
INSERT INTO versions VALUES (296, 'Person', 247, 'create', NULL, NULL, '2015-02-24 15:15:22.014131');
INSERT INTO versions VALUES (297, 'Person', 248, 'create', NULL, NULL, '2015-02-24 15:16:16.159813');
INSERT INTO versions VALUES (298, 'Person', 249, 'create', NULL, NULL, '2015-02-24 15:16:47.616154');
INSERT INTO versions VALUES (299, 'Person', 250, 'create', NULL, NULL, '2015-02-24 15:17:04.963835');
INSERT INTO versions VALUES (300, 'Person', 251, 'create', NULL, NULL, '2015-02-24 15:17:40.921135');
INSERT INTO versions VALUES (301, 'Person', 252, 'create', NULL, NULL, '2015-02-24 15:18:21.474507');
INSERT INTO versions VALUES (302, 'Person', 253, 'create', NULL, NULL, '2015-02-24 15:18:59.957656');
INSERT INTO versions VALUES (303, 'Person', 254, 'create', NULL, NULL, '2015-02-24 15:26:06.340561');
INSERT INTO versions VALUES (304, 'Person', 251, 'update', NULL, '---
id: 251
salutation: 
name: ''Noel ''
lastnames: ''Pacheco Eraticelli ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 99
created_at: 2015-02-24 15:17:40.919683000 Z
updated_at: 2015-02-24 15:17:40.919683000 Z
', '2015-02-24 15:27:46.080326');
INSERT INTO versions VALUES (305, 'Person', 255, 'create', NULL, NULL, '2015-02-24 15:30:51.290699');
INSERT INTO versions VALUES (306, 'Person', 256, 'create', NULL, NULL, '2015-02-24 15:31:15.049025');
INSERT INTO versions VALUES (307, 'Person', 257, 'create', NULL, NULL, '2015-02-24 15:31:36.907533');
INSERT INTO versions VALUES (308, 'Person', 258, 'create', NULL, NULL, '2015-02-24 15:31:57.72166');
INSERT INTO versions VALUES (309, 'Person', 259, 'create', NULL, NULL, '2015-02-24 15:32:15.705645');
INSERT INTO versions VALUES (310, 'Person', 260, 'create', NULL, NULL, '2015-02-24 15:32:33.982301');
INSERT INTO versions VALUES (311, 'Person', 252, 'destroy', NULL, '---
id: 252
salutation: 
name: ''Noel Y. ''
lastnames: Pachecho Alvarez
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 96
created_at: 2015-02-24 15:18:21.472994000 Z
updated_at: 2015-02-24 15:18:21.472994000 Z
', '2015-02-24 15:36:22.857055');
INSERT INTO versions VALUES (312, 'Person', 261, 'create', NULL, NULL, '2015-02-24 15:36:45.083292');
INSERT INTO versions VALUES (313, 'Person', 262, 'create', NULL, NULL, '2015-02-24 15:36:59.767852');
INSERT INTO versions VALUES (314, 'Person', 263, 'create', NULL, NULL, '2015-02-24 15:37:12.576007');
INSERT INTO versions VALUES (315, 'Person', 264, 'create', NULL, NULL, '2015-02-24 15:37:27.836773');
INSERT INTO versions VALUES (316, 'Person', 265, 'create', NULL, NULL, '2015-02-24 15:40:47.635891');
INSERT INTO versions VALUES (317, 'Person', 266, 'create', NULL, NULL, '2015-02-24 15:41:10.185748');
INSERT INTO versions VALUES (318, 'Person', 174, 'update', NULL, '---
id: 174
salutation: 0
name: ''Rosalba ''
lastnames: Velez
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 24
created_at: 2015-02-24 14:01:17.186728000 Z
updated_at: 2015-02-24 14:01:55.517084000 Z
', '2015-02-24 15:42:41.682034');
INSERT INTO versions VALUES (319, 'Person', 267, 'create', NULL, NULL, '2015-02-24 17:29:51.387223');
INSERT INTO versions VALUES (320, 'Person', 268, 'create', NULL, NULL, '2015-02-24 17:33:42.66097');
INSERT INTO versions VALUES (321, 'Person', 269, 'create', NULL, NULL, '2015-02-24 17:40:29.028543');
INSERT INTO versions VALUES (322, 'Person', 270, 'create', NULL, NULL, '2015-02-24 17:41:40.123577');
INSERT INTO versions VALUES (323, 'Person', 271, 'create', NULL, NULL, '2015-02-24 17:43:15.015575');
INSERT INTO versions VALUES (324, 'Person', 2, 'update', NULL, '---
id: 2
salutation: 
name: ''Susana ''
lastnames: ''Luzunaris ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 108
created_at: 2015-02-23 22:22:37.697968000 Z
updated_at: 2015-02-23 22:22:37.697968000 Z
', '2015-02-24 17:44:05.229226');
INSERT INTO versions VALUES (325, 'Person', 265, 'update', NULL, '---
id: 265
salutation: 
name: ''Angel M. ''
lastnames: García
sex: true
role: 5
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 15:40:47.634235000 Z
updated_at: 2015-02-24 15:40:47.634235000 Z
', '2015-02-24 17:46:07.912253');
INSERT INTO versions VALUES (326, 'Person', 174, 'update', NULL, '---
id: 174
salutation: 0
name: ''Rosalba ''
lastnames: Velez
sex: false
role: 5
description: ''''
attended: false
printed: false
materials: false
church_id: 24
created_at: 2015-02-24 14:01:17.186728000 Z
updated_at: 2015-02-24 15:42:41.679711000 Z
', '2015-02-24 17:48:37.173496');
INSERT INTO versions VALUES (327, 'Person', 223, 'update', NULL, '---
id: 223
salutation: 1
name: ''Myrna I. ''
lastnames: Ramos
sex: false
role: 5
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 15:00:38.844886000 Z
updated_at: 2015-02-24 15:00:38.844886000 Z
', '2015-02-24 17:49:13.573554');
INSERT INTO versions VALUES (328, 'Person', 224, 'update', NULL, '---
id: 224
salutation: 1
name: ''Efrain ''
lastnames: Figueroa
sex: true
role: 5
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 15:01:02.222804000 Z
updated_at: 2015-02-24 15:01:02.222804000 Z
', '2015-02-24 17:49:30.481476');
INSERT INTO versions VALUES (329, 'Person', 272, 'create', NULL, NULL, '2015-02-24 18:10:46.126249');
INSERT INTO versions VALUES (330, 'Person', 273, 'create', NULL, NULL, '2015-02-25 13:22:35.135787');
INSERT INTO versions VALUES (331, 'Person', 274, 'create', NULL, NULL, '2015-02-25 13:22:58.908577');
INSERT INTO versions VALUES (332, 'Person', 275, 'create', NULL, NULL, '2015-02-25 13:23:22.913372');
INSERT INTO versions VALUES (333, 'Person', 276, 'create', NULL, NULL, '2015-02-25 13:23:47.198443');
INSERT INTO versions VALUES (334, 'Person', 277, 'create', NULL, NULL, '2015-02-25 13:25:23.920632');
INSERT INTO versions VALUES (335, 'Person', 278, 'create', NULL, NULL, '2015-02-25 14:45:14.4178');
INSERT INTO versions VALUES (336, 'Person', 279, 'create', NULL, NULL, '2015-02-25 14:45:41.270174');
INSERT INTO versions VALUES (337, 'Person', 280, 'create', NULL, NULL, '2015-02-25 14:46:00.735577');
INSERT INTO versions VALUES (338, 'Person', 281, 'create', NULL, NULL, '2015-02-25 14:46:16.168164');
INSERT INTO versions VALUES (339, 'Person', 282, 'create', NULL, NULL, '2015-02-25 14:47:11.253243');
INSERT INTO versions VALUES (340, 'Person', 283, 'create', NULL, NULL, '2015-02-25 14:48:04.170148');
INSERT INTO versions VALUES (341, 'Person', 284, 'create', NULL, NULL, '2015-02-25 14:49:00.281499');
INSERT INTO versions VALUES (342, 'Person', 285, 'create', NULL, NULL, '2015-02-25 14:49:25.743587');
INSERT INTO versions VALUES (343, 'Person', 286, 'create', NULL, NULL, '2015-02-25 14:50:38.257691');
INSERT INTO versions VALUES (344, 'Person', 192, 'update', NULL, '---
id: 192
salutation: 0
name: ''Abigail ''
lastnames: Castro
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 19
created_at: 2015-02-24 14:28:11.784210000 Z
updated_at: 2015-02-24 14:28:11.784210000 Z
', '2015-02-25 15:59:25.132557');
INSERT INTO versions VALUES (345, 'Person', 192, 'update', NULL, '---
id: 192
salutation: 0
name: ''Abigail ''
lastnames: Castro
sex: false
role: 0
description: ''''
attended: true
printed: false
materials: false
church_id: 19
created_at: 2015-02-24 14:28:11.784210000 Z
updated_at: 2015-02-25 15:59:25.129215000 Z
', '2015-02-25 16:00:44.664447');
INSERT INTO versions VALUES (346, 'Person', 287, 'create', NULL, NULL, '2015-02-27 02:29:25.419496');
INSERT INTO versions VALUES (347, 'Person', 288, 'create', NULL, NULL, '2015-02-27 02:30:14.501311');
INSERT INTO versions VALUES (348, 'Person', 289, 'create', NULL, NULL, '2015-02-27 02:34:55.183835');
INSERT INTO versions VALUES (349, 'Person', 290, 'create', NULL, NULL, '2015-02-27 02:35:45.395556');
INSERT INTO versions VALUES (350, 'Person', 291, 'create', NULL, NULL, '2015-02-27 02:36:13.133725');
INSERT INTO versions VALUES (351, 'Person', 292, 'create', NULL, NULL, '2015-02-27 02:37:13.682411');
INSERT INTO versions VALUES (352, 'Person', 293, 'create', NULL, NULL, '2015-02-27 02:37:49.972586');
INSERT INTO versions VALUES (353, 'Person', 294, 'create', NULL, NULL, '2015-02-27 02:39:11.938511');
INSERT INTO versions VALUES (354, 'Check', 18, 'create', NULL, NULL, '2015-02-27 02:39:49.734162');
INSERT INTO versions VALUES (355, 'Person', 295, 'create', NULL, NULL, '2015-02-27 02:44:15.3983');
INSERT INTO versions VALUES (356, 'Person', 296, 'create', NULL, NULL, '2015-02-27 02:44:42.002263');
INSERT INTO versions VALUES (357, 'Person', 297, 'create', NULL, NULL, '2015-02-27 02:45:46.185789');
INSERT INTO versions VALUES (358, 'Person', 298, 'create', NULL, NULL, '2015-02-27 02:46:06.544391');
INSERT INTO versions VALUES (359, 'Person', 299, 'create', NULL, NULL, '2015-02-27 02:46:30.934281');
INSERT INTO versions VALUES (360, 'Church', 54, 'update', NULL, '---
id: 54
position: 91
nth: 
prefix: Iglesia Bautista de
name: Quebrada
nickname: ''''
town: Gurabo
size: 1
notes: El 7 marzo Malcom Diaz sustituyo a Misael
created_at: 2014-03-04 15:14:57.203929000 Z
updated_at: 2014-03-07 14:58:35.687457000 Z
', '2015-02-28 19:25:41.260291');
INSERT INTO versions VALUES (875, 'Person', 311, 'create', NULL, NULL, '2015-03-02 19:27:20.519145');
INSERT INTO versions VALUES (876, 'Check', 20, 'create', NULL, NULL, '2015-03-02 19:27:49.959404');
INSERT INTO versions VALUES (877, 'Person', 312, 'create', NULL, NULL, '2015-03-02 19:30:21.926001');
INSERT INTO versions VALUES (878, 'Person', 313, 'create', NULL, NULL, '2015-03-02 19:30:39.769087');
INSERT INTO versions VALUES (361, 'Church', 45, 'update', NULL, '---
id: 45
position: 46
nth: 1
prefix: Iglesia Bautista de
name: Guayama
nickname: ''''
town: Guayama
size: 2
notes: Felicita sustituyo a Maria el jueves.
created_at: 2014-03-04 15:14:57.194239000 Z
updated_at: 2014-03-07 14:01:39.723034000 Z
', '2015-02-28 19:25:58.595678');
INSERT INTO versions VALUES (362, 'Person', 192, 'update', NULL, '---
id: 192
salutation: 0
name: ''Abigail ''
lastnames: Castro
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 19
created_at: 2015-02-24 14:28:11.784210000 Z
updated_at: 2015-02-25 16:00:44.662146000 Z
', '2015-02-28 19:27:38.786914');
INSERT INTO versions VALUES (363, 'Person', 192, 'update', NULL, '---
id: 192
salutation: 0
name: ''Abigail ''
lastnames: Castro
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 19
created_at: 2015-02-24 14:28:11.784210000 Z
updated_at: 2015-02-28 19:27:38.784317000 Z
', '2015-02-28 19:27:39.695117');
INSERT INTO versions VALUES (364, 'Check', 19, 'create', NULL, NULL, '2015-03-01 12:50:06.735234');
INSERT INTO versions VALUES (365, 'Check', 19, 'destroy', NULL, '---
id: 19
number: 
amount: 2000.0
description: ''''
church_id: 5
created_at: 2015-03-01 12:50:06.725857000 Z
updated_at: 2015-03-01 12:50:06.725857000 Z
', '2015-03-01 12:50:15.599803');
INSERT INTO versions VALUES (366, 'Person', 53, 'update', NULL, '---
id: 53
salutation: 
name: ''Domingo ''
lastnames: ''Carrasquillo ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 7
created_at: 2015-02-24 01:56:49.327954000 Z
updated_at: 2015-02-24 01:56:49.327954000 Z
', '2015-03-01 23:30:33.606595');
INSERT INTO versions VALUES (367, 'Person', 54, 'update', NULL, '---
id: 54
salutation: 
name: ''Israel ''
lastnames: ''Cotto ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 7
created_at: 2015-02-24 01:57:09.233216000 Z
updated_at: 2015-02-24 01:57:09.233216000 Z
', '2015-03-01 23:30:33.695931');
INSERT INTO versions VALUES (368, 'Person', 51, 'update', NULL, '---
id: 51
salutation: 1
name: ''Ramón L. ''
lastnames: ''Díaz ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 7
created_at: 2015-02-24 01:56:07.756014000 Z
updated_at: 2015-02-24 01:56:07.756014000 Z
', '2015-03-01 23:30:33.749');
INSERT INTO versions VALUES (369, 'Person', 52, 'update', NULL, '---
id: 52
salutation: 
name: ''Wilfredo ''
lastnames: ''Mercado ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 7
created_at: 2015-02-24 01:56:28.001371000 Z
updated_at: 2015-02-24 01:56:28.001371000 Z
', '2015-03-01 23:30:33.765516');
INSERT INTO versions VALUES (370, 'Person', 228, 'update', NULL, '---
id: 228
salutation: 
name: ''Hector M. ''
lastnames: ''González ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 97
created_at: 2015-02-24 15:04:05.736746000 Z
updated_at: 2015-02-24 15:04:05.736746000 Z
', '2015-03-01 23:30:33.782343');
INSERT INTO versions VALUES (371, 'Person', 226, 'update', NULL, '---
id: 226
salutation: 0
name: Hilda G.
lastnames: Acosta Rivera
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 97
created_at: 2015-02-24 15:02:58.244599000 Z
updated_at: 2015-02-24 15:02:58.244599000 Z
', '2015-03-01 23:30:33.798228');
INSERT INTO versions VALUES (372, 'Person', 227, 'update', NULL, '---
id: 227
salutation: 
name: ''Sheyla ''
lastnames: ''Quiros Vazquez ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 97
created_at: 2015-02-24 15:03:30.849620000 Z
updated_at: 2015-02-24 15:03:30.849620000 Z
', '2015-03-01 23:30:42.559811');
INSERT INTO versions VALUES (373, 'Person', 28, 'update', NULL, '---
id: 28
salutation: 
name: ''Angel ''
lastnames: ''Pérez ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 100
created_at: 2015-02-24 01:38:14.145202000 Z
updated_at: 2015-02-24 01:38:14.145202000 Z
', '2015-03-01 23:30:42.608587');
INSERT INTO versions VALUES (374, 'Person', 27, 'update', NULL, '---
id: 27
salutation: 0
name: ''Migdalia ''
lastnames: ''Flores ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 100
created_at: 2015-02-24 01:37:45.571485000 Z
updated_at: 2015-02-24 01:37:45.571485000 Z
', '2015-03-01 23:30:42.640491');
INSERT INTO versions VALUES (375, 'Person', 55, 'update', NULL, '---
id: 55
salutation: 0
name: ''Geraldo ''
lastnames: ''Méndez ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 10
created_at: 2015-02-24 01:58:31.251653000 Z
updated_at: 2015-02-24 01:58:31.251653000 Z
', '2015-03-01 23:30:42.667309');
INSERT INTO versions VALUES (376, 'Person', 56, 'update', NULL, '---
id: 56
salutation: 
name: ''Héctor N. ''
lastnames: ''López ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 10
created_at: 2015-02-24 01:58:53.431612000 Z
updated_at: 2015-02-24 01:58:53.431612000 Z
', '2015-03-01 23:30:42.700977');
INSERT INTO versions VALUES (377, 'Person', 57, 'update', NULL, '---
id: 57
salutation: 
name: Lillian
lastnames: ''Rivera ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 10
created_at: 2015-02-24 01:59:18.740724000 Z
updated_at: 2015-02-24 01:59:18.740724000 Z
', '2015-03-01 23:30:42.716505');
INSERT INTO versions VALUES (378, 'Person', 267, 'update', NULL, '---
id: 267
salutation: 
name: ''Wanda I. ''
lastnames: ''Rentas Morales ''
sex: false
role: 5
description: ''''
attended: false
printed: false
materials: false
church_id: 10
created_at: 2015-02-24 17:29:51.385662000 Z
updated_at: 2015-02-24 17:29:51.385662000 Z
', '2015-03-01 23:30:44.378499');
INSERT INTO versions VALUES (379, 'Person', 137, 'update', NULL, '---
id: 137
salutation: 
name: ''Grisel ''
lastnames: ''Díaz ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 23
created_at: 2015-02-24 02:53:15.800547000 Z
updated_at: 2015-02-24 02:53:15.800547000 Z
', '2015-03-01 23:30:44.405065');
INSERT INTO versions VALUES (380, 'Person', 135, 'update', NULL, '---
id: 135
salutation: 
name: ''Irving ''
lastnames: ''Rivera ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 23
created_at: 2015-02-24 02:52:29.814474000 Z
updated_at: 2015-02-24 02:52:29.814474000 Z
', '2015-03-01 23:30:44.417771');
INSERT INTO versions VALUES (381, 'Person', 134, 'update', NULL, '---
id: 134
salutation: 0
name: ''Lizette ''
lastnames: ''Hernández ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 23
created_at: 2015-02-24 02:52:08.030117000 Z
updated_at: 2015-02-24 02:52:08.030117000 Z
', '2015-03-01 23:30:44.472846');
INSERT INTO versions VALUES (382, 'Person', 136, 'update', NULL, '---
id: 136
salutation: 
name: ''Luz D. ''
lastnames: ''Lozada ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 23
created_at: 2015-02-24 02:52:52.625027000 Z
updated_at: 2015-02-24 02:52:52.625027000 Z
', '2015-03-01 23:30:44.484266');
INSERT INTO versions VALUES (383, 'Person', 281, 'update', NULL, '---
id: 281
salutation: 
name: ''Carmen ''
lastnames: ''Zayas ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 11
created_at: 2015-02-25 14:46:16.166752000 Z
updated_at: 2015-02-25 14:46:16.166752000 Z
', '2015-03-01 23:30:44.490926');
INSERT INTO versions VALUES (384, 'Person', 278, 'update', NULL, '---
id: 278
salutation: 0
name: ''Germán ''
lastnames: Malavé
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 11
created_at: 2015-02-25 14:45:14.416172000 Z
updated_at: 2015-02-25 14:45:14.416172000 Z
', '2015-03-01 23:30:46.287166');
INSERT INTO versions VALUES (385, 'Person', 279, 'update', NULL, '---
id: 279
salutation: 
name: ''Lilliam ''
lastnames: ''Santos ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 11
created_at: 2015-02-25 14:45:41.268414000 Z
updated_at: 2015-02-25 14:45:41.268414000 Z
', '2015-03-01 23:30:46.630639');
INSERT INTO versions VALUES (386, 'Person', 280, 'update', NULL, '---
id: 280
salutation: 
name: ''Lydia ''
lastnames: Del Valle
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 11
created_at: 2015-02-25 14:46:00.734214000 Z
updated_at: 2015-02-25 14:46:00.734214000 Z
', '2015-03-01 23:30:46.642531');
INSERT INTO versions VALUES (879, 'Person', 314, 'create', NULL, NULL, '2015-03-02 19:31:39.248604');
INSERT INTO versions VALUES (880, 'Person', 315, 'create', NULL, NULL, '2015-03-02 19:32:08.023596');
INSERT INTO versions VALUES (881, 'Person', 316, 'create', NULL, NULL, '2015-03-02 19:32:29.783674');
INSERT INTO versions VALUES (888, 'Person', 317, 'create', NULL, NULL, '2015-03-02 19:33:26.926531');
INSERT INTO versions VALUES (889, 'Person', 318, 'create', NULL, NULL, '2015-03-02 19:33:54.660073');
INSERT INTO versions VALUES (387, 'Person', 176, 'update', NULL, '---
id: 176
salutation: 
name: ''Juan ''
lastnames: ''Morales ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 24
created_at: 2015-02-24 14:03:23.992370000 Z
updated_at: 2015-02-24 14:03:23.992370000 Z
', '2015-03-01 23:30:46.654756');
INSERT INTO versions VALUES (388, 'Person', 173, 'update', NULL, '---
id: 173
salutation: 0
name: ''Margarita ''
lastnames: ''Santana ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 24
created_at: 2015-02-24 14:00:34.174153000 Z
updated_at: 2015-02-24 14:00:34.174153000 Z
', '2015-03-01 23:30:46.68088');
INSERT INTO versions VALUES (389, 'Person', 175, 'update', NULL, '---
id: 175
salutation: 
name: ''Marisol ''
lastnames: ''Sanchez ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 24
created_at: 2015-02-24 14:03:07.962388000 Z
updated_at: 2015-02-24 14:03:07.962388000 Z
', '2015-03-01 23:30:46.693112');
INSERT INTO versions VALUES (390, 'Person', 174, 'update', NULL, '---
id: 174
salutation: 0
name: ''Rosalba ''
lastnames: Velez
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 24
created_at: 2015-02-24 14:01:17.186728000 Z
updated_at: 2015-02-24 17:48:37.171553000 Z
', '2015-03-01 23:30:48.303477');
INSERT INTO versions VALUES (391, 'Person', 85, 'update', NULL, '---
id: 85
salutation: 
name: ''Aida I. ''
lastnames: ''López ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:16:06.984407000 Z
updated_at: 2015-02-24 02:16:06.984407000 Z
', '2015-03-01 23:30:48.357902');
INSERT INTO versions VALUES (392, 'Person', 82, 'update', NULL, '---
id: 82
salutation: 
name: ''Alba ''
lastnames: ''Marín ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:14:48.426260000 Z
updated_at: 2015-02-24 02:14:48.426260000 Z
', '2015-03-01 23:30:48.364977');
INSERT INTO versions VALUES (393, 'Person', 79, 'update', NULL, '---
id: 79
salutation: 1
name: ''Angel ''
lastnames: ''Cruz ''
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:13:25.268081000 Z
updated_at: 2015-02-24 02:13:25.268081000 Z
', '2015-03-01 23:30:48.37079');
INSERT INTO versions VALUES (394, 'Person', 88, 'update', NULL, '---
id: 88
salutation: 
name: ''Angel ''
lastnames: ''Sierra ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:17:31.008629000 Z
updated_at: 2015-02-24 02:17:31.008629000 Z
', '2015-03-01 23:30:48.376656');
INSERT INTO versions VALUES (395, 'Person', 89, 'update', NULL, '---
id: 89
salutation: 
name: ''Aurelina ''
lastnames: ''Roldán ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:17:55.397238000 Z
updated_at: 2015-02-24 02:17:55.397238000 Z
', '2015-03-01 23:30:48.382684');
INSERT INTO versions VALUES (396, 'Person', 86, 'update', NULL, '---
id: 86
salutation: 
name: ''Aurelio ''
lastnames: ''Ríos ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:16:38.054947000 Z
updated_at: 2015-02-24 02:16:38.054947000 Z
', '2015-03-01 23:30:50.026163');
INSERT INTO versions VALUES (397, 'Person', 78, 'update', NULL, '---
id: 78
salutation: 1
name: ''César ''
lastnames: ''Maurás ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:12:58.693612000 Z
updated_at: 2015-02-24 02:12:58.693612000 Z
', '2015-03-01 23:30:50.079788');
INSERT INTO versions VALUES (398, 'Person', 87, 'update', NULL, '---
id: 87
salutation: 
name: ''Edgardo ''
lastnames: ''Miranda ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:17:00.753889000 Z
updated_at: 2015-02-24 02:17:00.753889000 Z
', '2015-03-01 23:30:50.088811');
INSERT INTO versions VALUES (399, 'Person', 91, 'update', NULL, '---
id: 91
salutation: 1
name: ''Edwin ''
lastnames: ''Rivera ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 14
created_at: 2015-02-24 02:22:48.675203000 Z
updated_at: 2015-02-24 02:22:48.675203000 Z
', '2015-03-01 23:30:50.096201');
INSERT INTO versions VALUES (400, 'Person', 90, 'update', NULL, '---
id: 90
salutation: 1
name: ''Félix ''
lastnames: ''Rivera ''
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:18:41.545225000 Z
updated_at: 2015-02-24 02:18:41.545225000 Z
', '2015-03-01 23:30:50.101958');
INSERT INTO versions VALUES (401, 'Person', 81, 'update', NULL, '---
id: 81
salutation: 1
name: ''Héctor A. ''
lastnames: ''Rivera ''
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:14:22.852503000 Z
updated_at: 2015-02-24 02:14:22.852503000 Z
', '2015-03-01 23:30:50.108568');
INSERT INTO versions VALUES (402, 'Person', 92, 'update', NULL, '---
id: 92
salutation: 
name: Juan R.
lastnames: ''Flusa ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 14
created_at: 2015-02-24 02:23:11.719046000 Z
updated_at: 2015-02-24 02:23:11.719046000 Z
', '2015-03-01 23:30:51.721272');
INSERT INTO versions VALUES (403, 'Person', 83, 'update', NULL, '---
id: 83
salutation: 
name: ''Noemí ''
lastnames: ''Ortiz ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:15:12.645890000 Z
updated_at: 2015-02-24 02:15:12.645890000 Z
', '2015-03-01 23:30:51.820566');
INSERT INTO versions VALUES (404, 'Person', 93, 'update', NULL, '---
id: 93
salutation: 
name: ''Oscar ''
lastnames: ''Lausell ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 14
created_at: 2015-02-24 02:23:34.710960000 Z
updated_at: 2015-02-24 02:23:34.710960000 Z
', '2015-03-01 23:30:51.836031');
INSERT INTO versions VALUES (405, 'Person', 84, 'update', NULL, '---
id: 84
salutation: 
name: ''Reinaldo ''
lastnames: ''Robles ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:15:41.375244000 Z
updated_at: 2015-02-24 02:15:41.375244000 Z
', '2015-03-01 23:30:51.85175');
INSERT INTO versions VALUES (406, 'Person', 80, 'update', NULL, '---
id: 80
salutation: 1
name: ''Yamina ''
lastnames: ''Apolinaris ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:13:57.475449000 Z
updated_at: 2015-02-24 02:13:57.475449000 Z
', '2015-03-01 23:30:51.865678');
INSERT INTO versions VALUES (407, 'Person', 180, 'update', NULL, '---
id: 180
salutation: 
name: ''Aida I. ''
lastnames: Torres
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 14:08:52.759995000 Z
updated_at: 2015-02-24 14:08:52.759995000 Z
', '2015-03-01 23:30:51.879686');
INSERT INTO versions VALUES (408, 'Person', 179, 'update', NULL, '---
id: 179
salutation: 1
name: ''Angel ''
lastnames: Mundo
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 14:07:06.346536000 Z
updated_at: 2015-02-24 14:07:06.346536000 Z
', '2015-03-01 23:30:53.505252');
INSERT INTO versions VALUES (409, 'Person', 184, 'update', NULL, '---
id: 184
salutation: 
name: ''Carlos ''
lastnames: ''Febo ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 14:10:25.178415000 Z
updated_at: 2015-02-24 14:10:25.178415000 Z
', '2015-03-01 23:30:53.994672');
INSERT INTO versions VALUES (410, 'Person', 224, 'update', NULL, '---
id: 224
salutation: 1
name: ''Efrain ''
lastnames: Figueroa
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 15:01:02.222804000 Z
updated_at: 2015-02-24 17:49:30.479334000 Z
', '2015-03-01 23:30:54.39025');
INSERT INTO versions VALUES (411, 'Person', 225, 'update', NULL, '---
id: 225
salutation: 0
name: Francisco
lastnames: Pinto
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 15:01:44.624629000 Z
updated_at: 2015-02-24 15:01:44.624629000 Z
', '2015-03-01 23:30:54.406975');
INSERT INTO versions VALUES (412, 'Person', 177, 'update', NULL, '---
id: 177
salutation: 1
name: ''Irma ''
lastnames: ''Pastrana ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 14:06:06.140412000 Z
updated_at: 2015-02-24 14:06:06.140412000 Z
', '2015-03-01 23:30:54.422799');
INSERT INTO versions VALUES (413, 'Person', 182, 'update', NULL, '---
id: 182
salutation: 
name: ''Luis ''
lastnames: Osorio
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 14:09:37.573035000 Z
updated_at: 2015-02-24 14:09:37.573035000 Z
', '2015-03-01 23:30:54.435629');
INSERT INTO versions VALUES (414, 'Person', 181, 'update', NULL, '---
id: 181
salutation: 
name: ''Luis ''
lastnames: ''Rosario ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 14:09:15.743096000 Z
updated_at: 2015-02-24 14:09:15.743096000 Z
', '2015-03-01 23:30:56.138998');
INSERT INTO versions VALUES (415, 'Person', 223, 'update', NULL, '---
id: 223
salutation: 1
name: ''Myrna I. ''
lastnames: Ramos
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 15:00:38.844886000 Z
updated_at: 2015-02-24 17:49:13.571321000 Z
', '2015-03-01 23:30:56.253654');
INSERT INTO versions VALUES (416, 'Person', 178, 'update', NULL, '---
id: 178
salutation: 0
name: ''Pedro ''
lastnames: Castro
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 14:06:33.867690000 Z
updated_at: 2015-02-24 14:06:33.867690000 Z
', '2015-03-01 23:30:56.266028');
INSERT INTO versions VALUES (417, 'Person', 183, 'update', NULL, '---
id: 183
salutation: 
name: ''Saúl ''
lastnames: Castillo
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 14:10:04.471921000 Z
updated_at: 2015-02-24 14:10:04.471921000 Z
', '2015-03-01 23:30:56.277446');
INSERT INTO versions VALUES (418, 'Person', 259, 'update', NULL, '---
id: 259
salutation: 
name: ''Benjamín ''
lastnames: ''Ortiz ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 18
created_at: 2015-02-24 15:32:15.704090000 Z
updated_at: 2015-02-24 15:32:15.704090000 Z
', '2015-03-01 23:30:56.287627');
INSERT INTO versions VALUES (419, 'Person', 255, 'update', NULL, '---
id: 255
salutation: 0
name: ''Edgardo ''
lastnames: Caraballo
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 18
created_at: 2015-02-24 15:30:51.289108000 Z
updated_at: 2015-02-24 15:30:51.289108000 Z
', '2015-03-01 23:30:56.295475');
INSERT INTO versions VALUES (420, 'Person', 260, 'update', NULL, '---
id: 260
salutation: 
name: ''Libertad ''
lastnames: ''Carrión ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 18
created_at: 2015-02-24 15:32:33.980877000 Z
updated_at: 2015-02-24 15:32:33.980877000 Z
', '2015-03-01 23:30:58.357068');
INSERT INTO versions VALUES (421, 'Person', 257, 'update', NULL, '---
id: 257
salutation: 
name: ''Matilde ''
lastnames: ''Dávila ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 18
created_at: 2015-02-24 15:31:36.906140000 Z
updated_at: 2015-02-24 15:31:36.906140000 Z
', '2015-03-01 23:30:58.443803');
INSERT INTO versions VALUES (422, 'Person', 258, 'update', NULL, '---
id: 258
salutation: 
name: ''Miguel ''
lastnames: ''Carrasquillo ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 18
created_at: 2015-02-24 15:31:57.720168000 Z
updated_at: 2015-02-24 15:31:57.720168000 Z
', '2015-03-01 23:30:58.457015');
INSERT INTO versions VALUES (423, 'Person', 256, 'update', NULL, '---
id: 256
salutation: 
name: ''Miguel ''
lastnames: ''Vázquez ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 18
created_at: 2015-02-24 15:31:15.047610000 Z
updated_at: 2015-02-24 15:31:15.047610000 Z
', '2015-03-01 23:30:58.472776');
INSERT INTO versions VALUES (424, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:55:05.277009000 Z
', '2015-03-01 23:30:58.484462');
INSERT INTO versions VALUES (425, 'Person', 155, 'update', NULL, '---
id: 155
salutation: 
name: ''Angela ''
lastnames: Arroyo Santiago
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:31:13.682457000 Z
updated_at: 2015-02-24 13:31:13.682457000 Z
', '2015-03-01 23:30:58.497586');
INSERT INTO versions VALUES (426, 'Person', 160, 'update', NULL, '---
id: 160
salutation: 
name: ''Carlos ''
lastnames: Dominguez Cristobal
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:33:40.851015000 Z
updated_at: 2015-02-24 13:33:40.851015000 Z
', '2015-03-01 23:31:00.155466');
INSERT INTO versions VALUES (427, 'Person', 159, 'update', NULL, '---
id: 159
salutation: 
name: ''Carlos ''
lastnames: Rodriguez Delannoy
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:33:17.399365000 Z
updated_at: 2015-02-24 13:33:17.399365000 Z
', '2015-03-01 23:31:00.197327');
INSERT INTO versions VALUES (428, 'Person', 148, 'update', NULL, '---
id: 148
salutation: 
name: ''Carmen ''
lastnames: ''Morales ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:39:28.230070000 Z
updated_at: 2015-02-24 04:39:28.230070000 Z
', '2015-03-01 23:31:00.203736');
INSERT INTO versions VALUES (429, 'Person', 138, 'update', NULL, '---
id: 138
salutation: 1
name: ''Carmen C. ''
lastnames: ''Adames ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:30:24.198051000 Z
updated_at: 2015-02-24 04:30:24.198051000 Z
', '2015-03-01 23:31:00.208608');
INSERT INTO versions VALUES (430, 'Person', 142, 'update', NULL, '---
id: 142
salutation: 1
name: ''Carmen M. ''
lastnames: ''Arroyo ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:34:25.075862000 Z
updated_at: 2015-02-24 04:34:25.075862000 Z
', '2015-03-01 23:31:00.214201');
INSERT INTO versions VALUES (431, 'Person', 158, 'update', NULL, '---
id: 158
salutation: 
name: ''Fernando ''
lastnames: ''Barreto Cardona ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:32:55.491074000 Z
updated_at: 2015-02-24 13:32:55.491074000 Z
', '2015-03-01 23:31:00.220799');
INSERT INTO versions VALUES (432, 'Person', 161, 'update', NULL, '---
id: 161
salutation: 
name: ''Gladys ''
lastnames: Linares Estrada
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:34:03.070512000 Z
updated_at: 2015-02-24 13:34:03.070512000 Z
', '2015-03-01 23:31:01.946033');
INSERT INTO versions VALUES (433, 'Person', 149, 'update', NULL, '---
id: 149
salutation: 
name: ''José A. ''
lastnames: ''Fernández ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:40:17.711563000 Z
updated_at: 2015-02-24 04:40:17.711563000 Z
', '2015-03-01 23:31:02.330904');
INSERT INTO versions VALUES (434, 'Person', 139, 'update', NULL, '---
id: 139
salutation: 1
name: ''Juan E. ''
lastnames: ''Matias ''
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:31:25.127264000 Z
updated_at: 2015-02-24 04:31:25.127264000 Z
', '2015-03-01 23:31:02.351651');
INSERT INTO versions VALUES (435, 'Person', 153, 'update', NULL, '---
id: 153
salutation: 
name: Lillian
lastnames: Rivera Morales
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:26:47.056805000 Z
updated_at: 2015-02-24 13:27:22.975993000 Z
', '2015-03-01 23:31:02.364144');
INSERT INTO versions VALUES (436, 'Person', 143, 'update', NULL, '---
id: 143
salutation: 1
name: ''Luis R. ''
lastnames: ''Quiñones ''
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:35:16.499350000 Z
updated_at: 2015-02-24 04:35:16.499350000 Z
', '2015-03-01 23:31:02.383845');
INSERT INTO versions VALUES (437, 'Person', 154, 'update', NULL, '---
id: 154
salutation: 1
name: ''Madelyn ''
lastnames: Figueroa Alamo
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:30:40.268446000 Z
updated_at: 2015-02-24 13:30:40.268446000 Z
', '2015-03-01 23:31:02.397703');
INSERT INTO versions VALUES (890, 'Person', 319, 'create', NULL, NULL, '2015-03-02 19:34:27.424394');
INSERT INTO versions VALUES (891, 'Person', 320, 'create', NULL, NULL, '2015-03-02 19:36:14.368666');
INSERT INTO versions VALUES (892, 'Person', 321, 'create', NULL, NULL, '2015-03-02 19:41:17.839719');
INSERT INTO versions VALUES (899, 'Person', 322, 'create', NULL, NULL, '2015-03-02 19:42:38.816777');
INSERT INTO versions VALUES (438, 'Person', 145, 'update', NULL, '---
id: 145
salutation: 0
name: ''Margot ''
lastnames: ''Camacho ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:06.046467000 Z
updated_at: 2015-02-24 04:37:06.046467000 Z
', '2015-03-01 23:31:04.030787');
INSERT INTO versions VALUES (439, 'Person', 151, 'update', NULL, '---
id: 151
salutation: 
name: Maria E.
lastnames: ''Rivera Melendez ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:25:34.789697000 Z
updated_at: 2015-02-24 13:25:34.789697000 Z
', '2015-03-01 23:31:04.132389');
INSERT INTO versions VALUES (440, 'Person', 141, 'update', NULL, '---
id: 141
salutation: 1
name: ''María E. ''
lastnames: ''Calderón ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:33:33.087962000 Z
updated_at: 2015-02-24 04:33:33.087962000 Z
', '2015-03-01 23:31:04.151126');
INSERT INTO versions VALUES (441, 'Person', 140, 'update', NULL, '---
id: 140
salutation: 1
name: ''Marilyn ''
lastnames: ''Ortiz ''
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:32:32.978955000 Z
updated_at: 2015-02-24 04:32:32.978955000 Z
', '2015-03-01 23:31:04.163343');
INSERT INTO versions VALUES (442, 'Person', 147, 'update', NULL, '---
id: 147
salutation: 
name: ''Mario ''
lastnames: ''Moya ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:38:43.989795000 Z
updated_at: 2015-02-24 04:38:43.989795000 Z
', '2015-03-01 23:31:04.189218');
INSERT INTO versions VALUES (443, 'Person', 150, 'update', NULL, '---
id: 150
salutation: 
name: ''Milagros ''
lastnames: Pizarrro
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:22:38.515628000 Z
updated_at: 2015-02-24 13:22:38.515628000 Z
', '2015-03-01 23:31:04.971464');
INSERT INTO versions VALUES (444, 'Person', 156, 'update', NULL, '---
id: 156
salutation: 
name: ''Norma ''
lastnames: Valentin Guerrero
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:31:44.768649000 Z
updated_at: 2015-02-24 13:31:44.768649000 Z
', '2015-03-01 23:31:06.605781');
INSERT INTO versions VALUES (445, 'Person', 144, 'update', NULL, '---
id: 144
salutation: 0
name: ''Omar A. ''
lastnames: ''Santiago ''
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:36:11.543037000 Z
updated_at: 2015-02-24 04:36:11.543037000 Z
', '2015-03-01 23:31:06.612348');
INSERT INTO versions VALUES (446, 'Person', 157, 'update', NULL, '---
id: 157
salutation: 
name: ''Sonia ''
lastnames: ''García Hernández ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:32:21.484489000 Z
updated_at: 2015-02-24 13:32:21.484489000 Z
', '2015-03-01 23:31:06.61799');
INSERT INTO versions VALUES (447, 'Person', 152, 'update', NULL, '---
id: 152
salutation: 
name: ''Victor ''
lastnames: Rivera Santiago
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:26:17.801431000 Z
updated_at: 2015-02-24 13:26:17.801431000 Z
', '2015-03-01 23:31:06.623309');
INSERT INTO versions VALUES (448, 'Person', 293, 'update', NULL, '---
id: 293
salutation: 
name: ''Diana ''
lastnames: ''Medina ''
sex: false
role: 4
description: ''''
attended: false
printed: false
materials: false
church_id: 98
created_at: 2015-02-27 02:37:49.971019000 Z
updated_at: 2015-02-27 02:37:49.971019000 Z
', '2015-03-01 23:31:06.629409');
INSERT INTO versions VALUES (449, 'Person', 292, 'update', NULL, '---
id: 292
salutation: 0
name: ''Karilyn ''
lastnames: ''Galarza ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 98
created_at: 2015-02-27 02:37:13.680893000 Z
updated_at: 2015-02-27 02:37:13.680893000 Z
', '2015-03-01 23:31:06.635386');
INSERT INTO versions VALUES (450, 'Person', 60, 'update', NULL, '---
id: 60
salutation: 
name: ''Angel ''
lastnames: ''De Jesús ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 33
created_at: 2015-02-24 02:00:59.145070000 Z
updated_at: 2015-02-24 02:00:59.145070000 Z
', '2015-03-01 23:31:08.245711');
INSERT INTO versions VALUES (451, 'Person', 59, 'update', NULL, '---
id: 59
salutation: 
name: ''Antonio ''
lastnames: ''Cabrera ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 33
created_at: 2015-02-24 02:00:30.777975000 Z
updated_at: 2015-02-24 02:00:30.777975000 Z
', '2015-03-01 23:31:08.327588');
INSERT INTO versions VALUES (452, 'Person', 65, 'update', NULL, '---
id: 65
salutation: 1
name: ''Benigno ''
lastnames: ''Torres ''
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 33
created_at: 2015-02-24 02:03:03.022471000 Z
updated_at: 2015-02-24 02:03:54.746047000 Z
', '2015-03-01 23:31:08.343547');
INSERT INTO versions VALUES (453, 'Person', 64, 'update', NULL, '---
id: 64
salutation: 
name: ''Emérito ''
lastnames: ''Sánchez ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 33
created_at: 2015-02-24 02:02:38.334079000 Z
updated_at: 2015-02-24 02:02:38.334079000 Z
', '2015-03-01 23:31:08.348832');
INSERT INTO versions VALUES (454, 'Person', 58, 'update', NULL, '---
id: 58
salutation: 0
name: ''Jorge L. ''
lastnames: ''Cintrón ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 33
created_at: 2015-02-24 02:00:09.302735000 Z
updated_at: 2015-02-24 02:00:09.302735000 Z
', '2015-03-01 23:31:08.354384');
INSERT INTO versions VALUES (455, 'Person', 62, 'update', NULL, '---
id: 62
salutation: 
name: ''Jorge L. ''
lastnames: ''Oquendo ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 33
created_at: 2015-02-24 02:01:45.246570000 Z
updated_at: 2015-02-24 02:01:45.246570000 Z
', '2015-03-01 23:31:08.360863');
INSERT INTO versions VALUES (456, 'Person', 61, 'update', NULL, '---
id: 61
salutation: 
name: ''José A. ''
lastnames: ''Cotto ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 33
created_at: 2015-02-24 02:01:25.367756000 Z
updated_at: 2015-02-24 02:01:25.367756000 Z
', '2015-03-01 23:31:09.975896');
INSERT INTO versions VALUES (457, 'Person', 63, 'update', NULL, '---
id: 63
salutation: 
name: ''María del C. ''
lastnames: ''Meléndez ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 33
created_at: 2015-02-24 02:02:14.536270000 Z
updated_at: 2015-02-24 02:02:14.536270000 Z
', '2015-03-01 23:31:10.1046');
INSERT INTO versions VALUES (458, 'Person', 165, 'update', NULL, '---
id: 165
salutation: 
name: ''Margarita ''
lastnames: Rodríguez
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 26
created_at: 2015-02-24 13:51:43.982194000 Z
updated_at: 2015-02-24 13:51:43.982194000 Z
', '2015-03-01 23:31:10.117256');
INSERT INTO versions VALUES (459, 'Person', 163, 'update', NULL, '---
id: 163
salutation: 
name: ''Neris ''
lastnames: ''Carrasquillo ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 26
created_at: 2015-02-24 13:50:59.036800000 Z
updated_at: 2015-02-24 13:50:59.036800000 Z
', '2015-03-01 23:31:10.126139');
INSERT INTO versions VALUES (460, 'Person', 162, 'update', NULL, '---
id: 162
salutation: 0
name: ''Nilsa ''
lastnames: Rodríguez Casillas
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 26
created_at: 2015-02-24 13:50:27.216163000 Z
updated_at: 2015-02-24 13:50:27.216163000 Z
', '2015-03-01 23:31:10.13542');
INSERT INTO versions VALUES (461, 'Person', 164, 'update', NULL, '---
id: 164
salutation: 
name: ''Sonia ''
lastnames: ''Casillas ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 26
created_at: 2015-02-24 13:51:15.708854000 Z
updated_at: 2015-02-24 13:51:15.708854000 Z
', '2015-03-01 23:31:10.143852');
INSERT INTO versions VALUES (462, 'Person', 97, 'update', NULL, '---
id: 97
salutation: 0
name: ''Carmen P. ''
lastnames: ''Pérez ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 50
created_at: 2015-02-24 02:26:09.989510000 Z
updated_at: 2015-02-24 02:26:09.989510000 Z
', '2015-03-01 23:31:11.762695');
INSERT INTO versions VALUES (900, 'Person', 323, 'create', NULL, NULL, '2015-03-02 19:43:37.469008');
INSERT INTO versions VALUES (901, 'Person', 324, 'create', NULL, NULL, '2015-03-02 19:44:00.221798');
INSERT INTO versions VALUES (463, 'Person', 98, 'update', NULL, '---
id: 98
salutation: 0
name: ''Emma ''
lastnames: ''Méndez ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 50
created_at: 2015-02-24 02:26:31.869154000 Z
updated_at: 2015-02-24 02:26:31.869154000 Z
', '2015-03-01 23:31:11.887758');
INSERT INTO versions VALUES (464, 'Person', 99, 'update', NULL, '---
id: 99
salutation: 
name: ''Idalia ''
lastnames: ''García ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 50
created_at: 2015-02-24 02:26:53.654669000 Z
updated_at: 2015-02-24 02:26:53.654669000 Z
', '2015-03-01 23:31:11.901134');
INSERT INTO versions VALUES (465, 'Person', 100, 'update', NULL, '---
id: 100
salutation: 
name: ''José A. ''
lastnames: ''Boria ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 50
created_at: 2015-02-24 02:27:18.420492000 Z
updated_at: 2015-02-24 02:27:18.420492000 Z
', '2015-03-01 23:31:11.914219');
INSERT INTO versions VALUES (466, 'Person', 50, 'update', NULL, '---
id: 50
salutation: 
name: ''Ahmed ''
lastnames: ''Díaz ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 113
created_at: 2015-02-24 01:53:49.390545000 Z
updated_at: 2015-02-24 01:53:49.390545000 Z
', '2015-03-01 23:31:11.921842');
INSERT INTO versions VALUES (467, 'Person', 48, 'update', NULL, '---
id: 48
salutation: 1
name: ''Jimmy ''
lastnames: ''Vargas ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 113
created_at: 2015-02-24 01:53:09.270001000 Z
updated_at: 2015-02-24 01:53:09.270001000 Z
', '2015-03-01 23:31:11.928651');
INSERT INTO versions VALUES (468, 'Person', 49, 'update', NULL, '---
id: 49
salutation: 
name: ''Víctor ''
lastnames: ''Rivera ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 113
created_at: 2015-02-24 01:53:29.170580000 Z
updated_at: 2015-02-24 01:53:29.170580000 Z
', '2015-03-01 23:31:13.602284');
INSERT INTO versions VALUES (469, 'Person', 270, 'update', NULL, '---
id: 270
salutation: 4
name: ''Arturo J. ''
lastnames: Siaca
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 36
created_at: 2015-02-24 17:41:40.122104000 Z
updated_at: 2015-02-24 17:41:40.122104000 Z
', '2015-03-01 23:31:13.694292');
INSERT INTO versions VALUES (470, 'Person', 67, 'update', NULL, '---
id: 67
salutation: 
name: ''Cristina ''
lastnames: ''Báez ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 36
created_at: 2015-02-24 02:05:28.776187000 Z
updated_at: 2015-02-24 02:05:28.776187000 Z
', '2015-03-01 23:31:13.713155');
INSERT INTO versions VALUES (471, 'Person', 68, 'update', NULL, '---
id: 68
salutation: 
name: ''Daniel ''
lastnames: ''Santos ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 36
created_at: 2015-02-24 02:05:58.200172000 Z
updated_at: 2015-02-24 02:05:58.200172000 Z
', '2015-03-01 23:31:13.721871');
INSERT INTO versions VALUES (472, 'Person', 71, 'update', NULL, '---
id: 71
salutation: 
name: ''Dora ''
lastnames: ''Cruz ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 37
created_at: 2015-02-24 02:07:36.947044000 Z
updated_at: 2015-02-24 02:07:36.947044000 Z
', '2015-03-01 23:31:13.729822');
INSERT INTO versions VALUES (473, 'Person', 72, 'update', NULL, '---
id: 72
salutation: 
name: ''Fredeswilda ''
lastnames: ''Vargas ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 37
created_at: 2015-02-24 02:08:16.277270000 Z
updated_at: 2015-02-24 02:08:16.277270000 Z
', '2015-03-01 23:31:13.738591');
INSERT INTO versions VALUES (474, 'Person', 66, 'update', NULL, '---
id: 66
salutation: 1
name: ''Jaime ''
lastnames: ''Rodríguez ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 36
created_at: 2015-02-24 02:05:02.059083000 Z
updated_at: 2015-02-24 02:05:02.059083000 Z
', '2015-03-01 23:31:15.360725');
INSERT INTO versions VALUES (475, 'Person', 69, 'update', NULL, '---
id: 69
salutation: 0
name: ''Juan C. ''
lastnames: ''Navarro ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 37
created_at: 2015-02-24 02:06:47.609568000 Z
updated_at: 2015-02-24 02:06:47.609568000 Z
', '2015-03-01 23:31:15.440522');
INSERT INTO versions VALUES (476, 'Person', 73, 'update', NULL, '---
id: 73
salutation: 
name: ''Yolaris ''
lastnames: ''Negrón ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 37
created_at: 2015-02-24 02:08:54.002502000 Z
updated_at: 2015-02-24 02:08:54.002502000 Z
', '2015-03-01 23:31:15.455418');
INSERT INTO versions VALUES (477, 'Person', 70, 'update', NULL, '---
id: 70
salutation: 
name: ''Zoraida I. ''
lastnames: Serrano
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 37
created_at: 2015-02-24 02:07:15.106485000 Z
updated_at: 2015-02-24 02:07:15.106485000 Z
', '2015-03-01 23:31:15.465992');
INSERT INTO versions VALUES (478, 'Person', 229, 'update', NULL, '---
id: 229
salutation: 
name: ''Lucy ''
lastnames: Muñoz
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 39
created_at: 2015-02-24 15:04:56.866984000 Z
updated_at: 2015-02-24 15:04:56.866984000 Z
', '2015-03-01 23:31:15.478954');
INSERT INTO versions VALUES (479, 'Person', 230, 'update', NULL, '---
id: 230
salutation: 
name: Norma I.
lastnames: Pérez
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 39
created_at: 2015-02-24 15:05:16.436013000 Z
updated_at: 2015-02-24 15:05:16.436013000 Z
', '2015-03-01 23:31:15.489844');
INSERT INTO versions VALUES (480, 'Person', 282, 'update', NULL, '---
id: 282
salutation: 1
name: ''Dr. Anibal ''
lastnames: ''Cruz ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 121
created_at: 2015-02-25 14:47:11.251809000 Z
updated_at: 2015-02-25 14:47:11.251809000 Z
', '2015-03-01 23:31:17.111965');
INSERT INTO versions VALUES (481, 'Person', 75, 'update', NULL, '---
id: 75
salutation: 
name: ''David ''
lastnames: ''Calderón ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 40
created_at: 2015-02-24 02:10:31.344285000 Z
updated_at: 2015-02-24 02:10:31.344285000 Z
', '2015-03-01 23:31:17.768871');
INSERT INTO versions VALUES (482, 'Person', 74, 'update', NULL, '---
id: 74
salutation: 
name: ''Luis ''
lastnames: ''López ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 40
created_at: 2015-02-24 02:09:58.047775000 Z
updated_at: 2015-02-24 02:09:58.047775000 Z
', '2015-03-01 23:31:17.785962');
INSERT INTO versions VALUES (483, 'Person', 269, 'update', NULL, '---
id: 269
salutation: 0
name: ''Ramon ''
lastnames: Arroyo
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 40
created_at: 2015-02-24 17:40:29.026992000 Z
updated_at: 2015-02-24 17:40:29.026992000 Z
', '2015-03-01 23:31:17.798763');
INSERT INTO versions VALUES (484, 'Person', 268, 'update', NULL, '---
id: 268
salutation: 1
name: Carmen J.
lastnames: ''Pagan ''
sex: false
role: 3
description: Sustituto
attended: false
printed: false
materials: false
church_id: 103
created_at: 2015-02-24 17:33:42.659320000 Z
updated_at: 2015-02-24 17:33:42.659320000 Z
', '2015-03-01 23:31:17.809117');
INSERT INTO versions VALUES (485, 'Person', 11, 'update', NULL, '---
id: 11
salutation: 
name: ''Jessica ''
lastnames: ''Lugo ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 103
created_at: 2015-02-24 01:17:56.120307000 Z
updated_at: 2015-02-24 01:17:56.120307000 Z
', '2015-03-01 23:31:17.819146');
INSERT INTO versions VALUES (486, 'Person', 12, 'update', NULL, '---
id: 12
salutation: 
name: ''Mary Leen ''
lastnames: Marrero
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 103
created_at: 2015-02-24 01:18:51.363156000 Z
updated_at: 2015-02-24 01:18:51.363156000 Z
', '2015-03-01 23:31:19.453729');
INSERT INTO versions VALUES (487, 'Person', 10, 'update', NULL, '---
id: 10
salutation: 1
name: ''Miriam ''
lastnames: Rodríguez de Gutiérrez
sex: false
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 103
created_at: 2015-02-24 01:17:20.485002000 Z
updated_at: 2015-02-24 01:17:20.485002000 Z
', '2015-03-01 23:31:19.498917');
INSERT INTO versions VALUES (992, 'Person', 364, 'create', NULL, NULL, '2015-03-04 11:19:31.041611');
INSERT INTO versions VALUES (993, 'Person', 365, 'create', NULL, NULL, '2015-03-04 11:19:51.913862');
INSERT INTO versions VALUES (994, 'Person', 366, 'create', NULL, NULL, '2015-03-04 11:20:18.778488');
INSERT INTO versions VALUES (488, 'Person', 13, 'update', NULL, '---
id: 13
salutation: 
name: ''Noel ''
lastnames: ''Ortiz ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 103
created_at: 2015-02-24 01:19:13.409094000 Z
updated_at: 2015-02-24 01:19:13.409094000 Z
', '2015-03-01 23:31:19.508188');
INSERT INTO versions VALUES (489, 'Person', 14, 'update', NULL, '---
id: 14
salutation: 
name: ''Pedro ''
lastnames: ''Gely ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 103
created_at: 2015-02-24 01:19:45.854266000 Z
updated_at: 2015-02-24 01:19:45.854266000 Z
', '2015-03-01 23:31:19.526194');
INSERT INTO versions VALUES (490, 'Person', 16, 'update', NULL, '---
id: 16
salutation: 
name: ''Zoraida ''
lastnames: ''Rivera ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 103
created_at: 2015-02-24 01:20:55.459826000 Z
updated_at: 2015-02-24 01:20:55.459826000 Z
', '2015-03-01 23:31:19.539201');
INSERT INTO versions VALUES (491, 'Person', 17, 'update', NULL, '---
id: 17
salutation: 1
name: ''David ''
lastnames: ''Valentín ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 3
created_at: 2015-02-24 01:24:22.065414000 Z
updated_at: 2015-02-24 01:24:22.065414000 Z
', '2015-03-01 23:31:19.547359');
INSERT INTO versions VALUES (492, 'Person', 272, 'update', NULL, '---
id: 272
salutation: 
name: ''Debora ''
lastnames: Varona Guerrero
sex: false
role: 4
description: ''''
attended: false
printed: false
materials: false
church_id: 3
created_at: 2015-02-24 18:10:46.124550000 Z
updated_at: 2015-02-24 18:10:46.124550000 Z
', '2015-03-01 23:31:21.154615');
INSERT INTO versions VALUES (493, 'Person', 18, 'update', NULL, '---
id: 18
salutation: 
name: ''Jennie ''
lastnames: ''Cintrón ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 3
created_at: 2015-02-24 01:25:06.338216000 Z
updated_at: 2015-02-24 01:25:06.338216000 Z
', '2015-03-01 23:31:21.218723');
INSERT INTO versions VALUES (494, 'Person', 19, 'update', NULL, '---
id: 19
salutation: 
name: ''José A. ''
lastnames: ''Flores ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 3
created_at: 2015-02-24 01:25:39.803808000 Z
updated_at: 2015-02-24 01:25:39.803808000 Z
', '2015-03-01 23:31:21.233359');
INSERT INTO versions VALUES (495, 'Person', 21, 'update', NULL, '---
id: 21
salutation: 
name: ''Miguel A. ''
lastnames: ''Rivera ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 3
created_at: 2015-02-24 01:26:30.752850000 Z
updated_at: 2015-02-24 01:26:30.752850000 Z
', '2015-03-01 23:31:21.245532');
INSERT INTO versions VALUES (496, 'Person', 20, 'update', NULL, '---
id: 20
salutation: 
name: ''Samuel ''
lastnames: Encarnación
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 3
created_at: 2015-02-24 01:26:07.105439000 Z
updated_at: 2015-02-24 01:26:07.105439000 Z
', '2015-03-01 23:31:21.255022');
INSERT INTO versions VALUES (497, 'Person', 101, 'update', NULL, '---
id: 101
salutation: 1
name: ''Juan ''
lastnames: ''Vergara ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 52
created_at: 2015-02-24 02:28:47.997609000 Z
updated_at: 2015-02-24 02:28:47.997609000 Z
', '2015-03-01 23:31:21.263875');
INSERT INTO versions VALUES (498, 'Person', 102, 'update', NULL, '---
id: 102
salutation: 
name: ''Marisol ''
lastnames: ''Rosa ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 52
created_at: 2015-02-24 02:29:10.040047000 Z
updated_at: 2015-02-24 02:29:10.040047000 Z
', '2015-03-01 23:31:23.264393');
INSERT INTO versions VALUES (499, 'Person', 106, 'update', NULL, '---
id: 106
salutation: 0
name: ''Miguel A. ''
lastnames: ''Sánchez ''
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 52
created_at: 2015-02-24 02:31:01.728234000 Z
updated_at: 2015-02-24 02:31:01.728234000 Z
', '2015-03-01 23:31:23.299183');
INSERT INTO versions VALUES (500, 'Person', 105, 'update', NULL, '---
id: 105
salutation: 4
name: ''Nayda ''
lastnames: Márquez
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 52
created_at: 2015-02-24 02:30:38.332964000 Z
updated_at: 2015-02-24 02:30:38.332964000 Z
', '2015-03-01 23:31:23.305131');
INSERT INTO versions VALUES (501, 'Person', 104, 'update', NULL, '---
id: 104
salutation: 
name: ''Roberto ''
lastnames: ''Rodríguez ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 52
created_at: 2015-02-24 02:30:03.651506000 Z
updated_at: 2015-02-24 02:30:03.651506000 Z
', '2015-03-01 23:31:23.311169');
INSERT INTO versions VALUES (502, 'Person', 103, 'update', NULL, '---
id: 103
salutation: 
name: ''Samuel ''
lastnames: ''Acevedo ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 52
created_at: 2015-02-24 02:29:30.896712000 Z
updated_at: 2015-02-24 02:29:30.896712000 Z
', '2015-03-01 23:31:23.316895');
INSERT INTO versions VALUES (503, 'Person', 33, 'update', NULL, '---
id: 33
salutation: 
name: ''Awilda ''
lastnames: ''Hernández ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 123
created_at: 2015-02-24 01:42:32.458934000 Z
updated_at: 2015-02-24 01:42:32.458934000 Z
', '2015-03-01 23:31:23.322803');
INSERT INTO versions VALUES (504, 'Person', 31, 'update', NULL, '---
id: 31
salutation: 0
name: ''Hipólito ''
lastnames: ''Félix ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 123
created_at: 2015-02-24 01:41:36.181148000 Z
updated_at: 2015-02-24 01:41:36.181148000 Z
', '2015-03-01 23:31:25.048773');
INSERT INTO versions VALUES (505, 'Person', 32, 'update', NULL, '---
id: 32
salutation: 
name: ''Lydia ''
lastnames: ''Camacho ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 123
created_at: 2015-02-24 01:42:07.441078000 Z
updated_at: 2015-02-24 01:42:07.441078000 Z
', '2015-03-01 23:31:25.279875');
INSERT INTO versions VALUES (506, 'Person', 29, 'update', NULL, '---
id: 29
salutation: 
name: ''Carmen N. ''
lastnames: ''Negrón ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 12
created_at: 2015-02-24 01:39:08.318674000 Z
updated_at: 2015-02-24 01:39:08.318674000 Z
', '2015-03-01 23:31:25.298118');
INSERT INTO versions VALUES (507, 'Person', 30, 'update', NULL, '---
id: 30
salutation: 
name: ''Raquel ''
lastnames: ''Oquendo ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 12
created_at: 2015-02-24 01:39:31.364703000 Z
updated_at: 2015-02-24 01:39:31.364703000 Z
', '2015-03-01 23:31:25.315114');
INSERT INTO versions VALUES (508, 'Person', 121, 'update', NULL, '---
id: 121
salutation: 
name: ''Audrey ''
lastnames: ''Viera ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 15
created_at: 2015-02-24 02:40:13.362635000 Z
updated_at: 2015-02-24 02:40:13.362635000 Z
', '2015-03-01 23:31:25.350089');
INSERT INTO versions VALUES (509, 'Person', 119, 'update', NULL, '---
id: 119
salutation: 0
name: ''Blanca ''
lastnames: ''Velázquez ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 15
created_at: 2015-02-24 02:39:10.397961000 Z
updated_at: 2015-02-24 02:39:10.397961000 Z
', '2015-03-01 23:31:25.359796');
INSERT INTO versions VALUES (510, 'Person', 120, 'update', NULL, '---
id: 120
salutation: 
name: ''Providencia ''
lastnames: ''Hernández ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 15
created_at: 2015-02-24 02:39:44.622382000 Z
updated_at: 2015-02-24 02:39:44.622382000 Z
', '2015-03-01 23:31:27.071188');
INSERT INTO versions VALUES (511, 'Person', 187, 'update', NULL, '---
id: 187
salutation: 
name: Ada N.
lastnames: Quiñones
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 42
created_at: 2015-02-24 14:19:01.547741000 Z
updated_at: 2015-02-24 14:19:01.547741000 Z
', '2015-03-01 23:31:27.109869');
INSERT INTO versions VALUES (512, 'Person', 188, 'update', NULL, '---
id: 188
salutation: 
name: ''Anidalia ''
lastnames: Rivera
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 42
created_at: 2015-02-24 14:19:32.496052000 Z
updated_at: 2015-02-24 14:19:32.496052000 Z
', '2015-03-01 23:31:27.118145');
INSERT INTO versions VALUES (1178, 'Person', 432, 'create', NULL, NULL, '2015-03-04 20:02:23.243233');
INSERT INTO versions VALUES (1185, 'Person', 433, 'create', NULL, NULL, '2015-03-04 20:02:54.861841');
INSERT INTO versions VALUES (1186, 'Person', 434, 'create', NULL, NULL, '2015-03-04 20:03:00.245854');
INSERT INTO versions VALUES (1187, 'Person', 435, 'create', NULL, NULL, '2015-03-04 20:03:16.088761');
INSERT INTO versions VALUES (513, 'Person', 186, 'update', NULL, '---
id: 186
salutation: 
name: ''Carmen ''
lastnames: ''Johnson ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 42
created_at: 2015-02-24 14:18:37.601020000 Z
updated_at: 2015-02-24 14:18:37.601020000 Z
', '2015-03-01 23:31:27.124068');
INSERT INTO versions VALUES (514, 'Person', 185, 'update', NULL, '---
id: 185
salutation: 0
name: ''Javier E. ''
lastnames: Sosa Rodríguez
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 42
created_at: 2015-02-24 14:18:03.475814000 Z
updated_at: 2015-02-24 14:18:03.475814000 Z
', '2015-03-01 23:31:27.129982');
INSERT INTO versions VALUES (515, 'Person', 6, 'update', NULL, '---
id: 6
salutation: 1
name: ''Eneida ''
lastnames: Angleró
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 105
created_at: 2015-02-23 22:25:35.265226000 Z
updated_at: 2015-02-23 22:25:35.265226000 Z
', '2015-03-01 23:31:27.135818');
INSERT INTO versions VALUES (516, 'Person', 8, 'update', NULL, '---
id: 8
salutation: 
name: ''Rómulo ''
lastnames: ''Ortiz ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 105
created_at: 2015-02-23 22:26:41.588490000 Z
updated_at: 2015-02-23 22:26:41.588490000 Z
', '2015-03-01 23:31:28.747069');
INSERT INTO versions VALUES (517, 'Person', 9, 'update', NULL, '---
id: 9
salutation: 
name: ''Wilfredo ''
lastnames: ''Torres ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 105
created_at: 2015-02-23 22:27:06.708956000 Z
updated_at: 2015-02-23 22:27:06.708956000 Z
', '2015-03-01 23:31:28.874458');
INSERT INTO versions VALUES (518, 'Person', 7, 'update', NULL, '---
id: 7
salutation: 
name: ''Yamalis ''
lastnames: ''González ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 105
created_at: 2015-02-23 22:26:10.392410000 Z
updated_at: 2015-02-23 22:26:10.392410000 Z
', '2015-03-01 23:31:28.891075');
INSERT INTO versions VALUES (519, 'Person', 231, 'update', NULL, '---
id: 231
salutation: 0
name: ''Celis ''
lastnames: Zambrana Batista
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 45
created_at: 2015-02-24 15:06:14.599552000 Z
updated_at: 2015-02-24 15:06:14.599552000 Z
', '2015-03-01 23:31:28.901948');
INSERT INTO versions VALUES (520, 'Person', 233, 'update', NULL, '---
id: 233
salutation: 
name: ''David ''
lastnames: ''Soto Cardona ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 45
created_at: 2015-02-24 15:07:18.502531000 Z
updated_at: 2015-02-24 15:07:18.502531000 Z
', '2015-03-01 23:31:28.913123');
INSERT INTO versions VALUES (521, 'Person', 234, 'update', NULL, '---
id: 234
salutation: 
name: ''Digna ''
lastnames: Valdés Laboy
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 45
created_at: 2015-02-24 15:07:44.276170000 Z
updated_at: 2015-02-24 15:07:44.276170000 Z
', '2015-03-01 23:31:28.923813');
INSERT INTO versions VALUES (522, 'Person', 235, 'update', NULL, '---
id: 235
salutation: 
name: ''Luis ''
lastnames: ''Berrios Bones ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 45
created_at: 2015-02-24 15:08:07.300651000 Z
updated_at: 2015-02-24 15:08:07.300651000 Z
', '2015-03-01 23:31:30.550641');
INSERT INTO versions VALUES (523, 'Person', 236, 'update', NULL, '---
id: 236
salutation: 
name: ''Maria C. ''
lastnames: Gómez García
sex: false
role: 3
description: Sustituto
attended: false
printed: false
materials: false
church_id: 45
created_at: 2015-02-24 15:08:43.896090000 Z
updated_at: 2015-02-24 15:08:43.896090000 Z
', '2015-03-01 23:31:30.621702');
INSERT INTO versions VALUES (524, 'Person', 232, 'update', NULL, '---
id: 232
salutation: 
name: ''Nilma Y. ''
lastnames: Agosto García
sex: false
role: 5
description: ''''
attended: false
printed: false
materials: false
church_id: 45
created_at: 2015-02-24 15:06:56.720207000 Z
updated_at: 2015-02-24 15:06:56.720207000 Z
', '2015-03-01 23:31:30.636706');
INSERT INTO versions VALUES (525, 'Person', 237, 'update', NULL, '---
id: 237
salutation: 
name: ''Santos ''
lastnames: ''Torres Padilla ''
sex: true
role: 3
description: Sustituto
attended: false
printed: false
materials: false
church_id: 45
created_at: 2015-02-24 15:09:04.911706000 Z
updated_at: 2015-02-24 15:09:04.911706000 Z
', '2015-03-01 23:31:30.649761');
INSERT INTO versions VALUES (526, 'Person', 238, 'update', NULL, '---
id: 238
salutation: 0
name: ''Carlos A. ''
lastnames: ''Padilla Rivera ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 47
created_at: 2015-02-24 15:09:45.918708000 Z
updated_at: 2015-02-24 15:09:45.918708000 Z
', '2015-03-01 23:31:30.663149');
INSERT INTO versions VALUES (527, 'Person', 296, 'update', NULL, '---
id: 296
salutation: 1
name: ''Félix ''
lastnames: ''López ''
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 53
created_at: 2015-02-27 02:44:42.000719000 Z
updated_at: 2015-02-27 02:44:42.000719000 Z
', '2015-03-01 23:31:30.670457');
INSERT INTO versions VALUES (528, 'Person', 299, 'update', NULL, '---
id: 299
salutation: 
name: ''Isabel ''
lastnames: ''Calderón ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 53
created_at: 2015-02-27 02:46:30.932917000 Z
updated_at: 2015-02-27 02:46:30.932917000 Z
', '2015-03-01 23:31:32.301495');
INSERT INTO versions VALUES (529, 'Person', 295, 'update', NULL, '---
id: 295
salutation: 1
name: ''José A. ''
lastnames: López
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 53
created_at: 2015-02-27 02:44:15.396685000 Z
updated_at: 2015-02-27 02:44:15.396685000 Z
', '2015-03-01 23:31:32.319374');
INSERT INTO versions VALUES (530, 'Person', 297, 'update', NULL, '---
id: 297
salutation: 
name: ''María ''
lastnames: ''Castillo ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 53
created_at: 2015-02-27 02:45:46.184223000 Z
updated_at: 2015-02-27 02:45:46.184223000 Z
', '2015-03-01 23:31:32.33131');
INSERT INTO versions VALUES (531, 'Person', 298, 'update', NULL, '---
id: 298
salutation: 
name: ''Rebeca ''
lastnames: ''Rivera ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 53
created_at: 2015-02-27 02:46:06.542945000 Z
updated_at: 2015-02-27 02:46:06.542945000 Z
', '2015-03-01 23:31:32.339726');
INSERT INTO versions VALUES (532, 'Person', 190, 'update', NULL, '---
id: 190
salutation: 
name: ''Joel ''
lastnames: ''Roldán Oquendo ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 83
created_at: 2015-02-24 14:26:26.019892000 Z
updated_at: 2015-02-24 14:26:26.019892000 Z
', '2015-03-01 23:31:33.017798');
INSERT INTO versions VALUES (533, 'Person', 294, 'update', NULL, '---
id: 294
salutation: 4
name: ''Nilda E. ''
lastnames: ''García ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 83
created_at: 2015-02-27 02:39:11.936961000 Z
updated_at: 2015-02-27 02:39:11.936961000 Z
', '2015-03-01 23:31:33.042165');
INSERT INTO versions VALUES (534, 'Person', 191, 'update', NULL, '---
id: 191
salutation: 
name: ''Raúl ''
lastnames: Matos Castilo
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 83
created_at: 2015-02-24 14:26:50.425779000 Z
updated_at: 2015-02-24 14:26:50.425779000 Z
', '2015-03-01 23:31:34.689757');
INSERT INTO versions VALUES (535, 'Person', 192, 'update', NULL, '---
id: 192
salutation: 0
name: ''Abigail ''
lastnames: Castro
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 19
created_at: 2015-02-24 14:28:11.784210000 Z
updated_at: 2015-02-28 19:27:39.692859000 Z
', '2015-03-01 23:31:34.786519');
INSERT INTO versions VALUES (536, 'Person', 277, 'update', NULL, '---
id: 277
salutation: 
name: ''Daniel ''
lastnames: ''Pérez Medina ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 19
created_at: 2015-02-25 13:25:23.919180000 Z
updated_at: 2015-02-25 13:25:23.919180000 Z
', '2015-03-01 23:31:34.803441');
INSERT INTO versions VALUES (537, 'Person', 194, 'update', NULL, '---
id: 194
salutation: 
name: ''Maria ''
lastnames: ''Charles ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 19
created_at: 2015-02-24 14:32:01.785633000 Z
updated_at: 2015-02-24 14:32:01.785633000 Z
', '2015-03-01 23:31:34.813376');
INSERT INTO versions VALUES (1188, 'Person', 436, 'create', NULL, NULL, '2015-03-04 20:03:38.678685');
INSERT INTO versions VALUES (1195, 'Person', 437, 'create', NULL, NULL, '2015-03-04 20:03:46.890678');
INSERT INTO versions VALUES (538, 'Person', 193, 'update', NULL, '---
id: 193
salutation: 
name: ''Nilda ''
lastnames: García
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 19
created_at: 2015-02-24 14:28:49.381875000 Z
updated_at: 2015-02-24 14:28:49.381875000 Z
', '2015-03-01 23:31:34.822417');
INSERT INTO versions VALUES (539, 'Person', 107, 'update', NULL, '---
id: 107
salutation: 0
name: Catalino
lastnames: ''Colón ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 87
created_at: 2015-02-24 02:32:59.759045000 Z
updated_at: 2015-02-24 02:32:59.759045000 Z
', '2015-03-01 23:31:34.832914');
INSERT INTO versions VALUES (540, 'Person', 108, 'update', NULL, '---
id: 108
salutation: 
name: ''Heriberto ''
lastnames: ''Del Valle ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 87
created_at: 2015-02-24 02:33:19.629444000 Z
updated_at: 2015-02-24 02:33:19.629444000 Z
', '2015-03-01 23:31:36.439977');
INSERT INTO versions VALUES (541, 'Person', 109, 'update', NULL, '---
id: 109
salutation: 
name: ''Vacilio ''
lastnames: ''Del Valle ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 87
created_at: 2015-02-24 02:33:49.139829000 Z
updated_at: 2015-02-24 02:33:49.139829000 Z
', '2015-03-01 23:31:36.532804');
INSERT INTO versions VALUES (542, 'Person', 110, 'update', NULL, '---
id: 110
salutation: 
name: ''Wanda ''
lastnames: ''Acevedo ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 87
created_at: 2015-02-24 02:34:06.462161000 Z
updated_at: 2015-02-24 02:34:06.462161000 Z
', '2015-03-01 23:31:36.547052');
INSERT INTO versions VALUES (543, 'Person', 265, 'update', NULL, '---
id: 265
salutation: 
name: ''Angel M. ''
lastnames: García
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 15:40:47.634235000 Z
updated_at: 2015-02-24 17:46:07.909895000 Z
', '2015-03-01 23:31:36.555997');
INSERT INTO versions VALUES (544, 'Person', 198, 'update', NULL, '---
id: 198
salutation: 
name: ''Antonio ''
lastnames: Freire
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 14:36:33.922822000 Z
updated_at: 2015-02-24 14:36:33.922822000 Z
', '2015-03-01 23:31:36.56401');
INSERT INTO versions VALUES (545, 'Person', 195, 'update', NULL, '---
id: 195
salutation: 
name: ''Arelys ''
lastnames: Ortiz
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 14:34:57.882413000 Z
updated_at: 2015-02-24 14:34:57.882413000 Z
', '2015-03-01 23:31:36.572763');
INSERT INTO versions VALUES (546, 'Person', 197, 'update', NULL, '---
id: 197
salutation: 
name: ''Daisy ''
lastnames: García
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 14:36:01.266279000 Z
updated_at: 2015-02-24 14:36:01.266279000 Z
', '2015-03-01 23:31:38.175207');
INSERT INTO versions VALUES (547, 'Person', 199, 'update', NULL, '---
id: 199
salutation: 
name: ''David ''
lastnames: ''Morales ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 14:36:58.831092000 Z
updated_at: 2015-02-24 14:36:58.831092000 Z
', '2015-03-01 23:31:38.264829');
INSERT INTO versions VALUES (548, 'Person', 266, 'update', NULL, '---
id: 266
salutation: 
name: ''Deliris ''
lastnames: ''Carrión ''
sex: false
role: 5
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 15:41:10.184324000 Z
updated_at: 2015-02-24 15:41:10.184324000 Z
', '2015-03-01 23:31:38.282233');
INSERT INTO versions VALUES (549, 'Person', 196, 'update', NULL, '---
id: 196
salutation: 
name: ''Jossie ''
lastnames: Sostre
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 14:35:32.238243000 Z
updated_at: 2015-02-24 14:35:32.238243000 Z
', '2015-03-01 23:31:38.292052');
INSERT INTO versions VALUES (550, 'Person', 200, 'update', NULL, '---
id: 200
salutation: 
name: ''Minerva ''
lastnames: Rivera
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 14:37:42.741944000 Z
updated_at: 2015-02-24 14:37:42.741944000 Z
', '2015-03-01 23:31:38.302983');
INSERT INTO versions VALUES (551, 'Person', 114, 'update', NULL, '---
id: 114
salutation: 
name: ''Carmen ''
lastnames: ''Leduc ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 60
created_at: 2015-02-24 02:35:59.457418000 Z
updated_at: 2015-02-24 02:35:59.457418000 Z
', '2015-03-01 23:31:38.312496');
INSERT INTO versions VALUES (552, 'Person', 117, 'update', NULL, '---
id: 117
salutation: 
name: ''Carmen L. ''
lastnames: ''Santos ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 60
created_at: 2015-02-24 02:37:12.731568000 Z
updated_at: 2015-02-24 02:37:12.731568000 Z
', '2015-03-01 23:31:39.93028');
INSERT INTO versions VALUES (553, 'Person', 116, 'update', NULL, '---
id: 116
salutation: 
name: ''Daniel ''
lastnames: ''Cardona ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 60
created_at: 2015-02-24 02:36:47.171359000 Z
updated_at: 2015-02-24 02:36:47.171359000 Z
', '2015-03-01 23:31:40.612587');
INSERT INTO versions VALUES (554, 'Person', 111, 'update', NULL, '---
id: 111
salutation: 1
name: ''Edwin ''
lastnames: ''Mojica ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 60
created_at: 2015-02-24 02:34:40.419461000 Z
updated_at: 2015-02-24 02:34:40.419461000 Z
', '2015-03-01 23:31:40.628089');
INSERT INTO versions VALUES (555, 'Person', 115, 'update', NULL, '---
id: 115
salutation: 
name: ''Jossie ''
lastnames: ''Cardona ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 60
created_at: 2015-02-24 02:36:19.732517000 Z
updated_at: 2015-02-24 02:36:19.732517000 Z
', '2015-03-01 23:31:40.641756');
INSERT INTO versions VALUES (556, 'Person', 113, 'update', NULL, '---
id: 113
salutation: 
name: ''Maria de los A. ''
lastnames: Rolón
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 60
created_at: 2015-02-24 02:35:37.036285000 Z
updated_at: 2015-02-24 02:35:37.036285000 Z
', '2015-03-01 23:31:40.657367');
INSERT INTO versions VALUES (557, 'Person', 112, 'update', NULL, '---
id: 112
salutation: 1
name: ''Norma I. ''
lastnames: ''Torres ''
sex: false
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 60
created_at: 2015-02-24 02:35:11.391098000 Z
updated_at: 2015-02-24 02:35:11.391098000 Z
', '2015-03-01 23:31:40.670476');
INSERT INTO versions VALUES (558, 'Person', 300, 'create', NULL, NULL, '2015-03-02 19:17:29.754704');
INSERT INTO versions VALUES (559, 'Person', 301, 'create', NULL, NULL, '2015-03-02 19:18:34.410621');
INSERT INTO versions VALUES (560, 'Person', 302, 'create', NULL, NULL, '2015-03-02 19:18:55.916145');
INSERT INTO versions VALUES (561, 'Person', 303, 'create', NULL, NULL, '2015-03-02 19:19:17.187244');
INSERT INTO versions VALUES (562, 'Person', 304, 'create', NULL, NULL, '2015-03-02 19:19:39.732476');
INSERT INTO versions VALUES (563, 'Person', 305, 'create', NULL, NULL, '2015-03-02 19:20:31.778379');
INSERT INTO versions VALUES (564, 'Person', 53, 'update', NULL, '---
id: 53
salutation: 
name: ''Domingo ''
lastnames: ''Carrasquillo ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 7
created_at: 2015-02-24 01:56:49.327954000 Z
updated_at: 2015-03-01 23:30:32.817924000 Z
', '2015-03-02 19:20:45.215189');
INSERT INTO versions VALUES (565, 'Person', 54, 'update', NULL, '---
id: 54
salutation: 
name: ''Israel ''
lastnames: ''Cotto ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 7
created_at: 2015-02-24 01:57:09.233216000 Z
updated_at: 2015-03-01 23:30:33.684973000 Z
', '2015-03-02 19:20:45.299058');
INSERT INTO versions VALUES (566, 'Person', 51, 'update', NULL, '---
id: 51
salutation: 1
name: ''Ramón L. ''
lastnames: ''Díaz ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 7
created_at: 2015-02-24 01:56:07.756014000 Z
updated_at: 2015-03-01 23:30:33.702275000 Z
', '2015-03-02 19:20:45.354877');
INSERT INTO versions VALUES (567, 'Person', 52, 'update', NULL, '---
id: 52
salutation: 
name: ''Wilfredo ''
lastnames: ''Mercado ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 7
created_at: 2015-02-24 01:56:28.001371000 Z
updated_at: 2015-03-01 23:30:33.756000000 Z
', '2015-03-02 19:20:45.377761');
INSERT INTO versions VALUES (568, 'Person', 228, 'update', NULL, '---
id: 228
salutation: 
name: ''Hector M. ''
lastnames: ''González ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 97
created_at: 2015-02-24 15:04:05.736746000 Z
updated_at: 2015-03-01 23:30:33.772564000 Z
', '2015-03-02 19:20:45.390461');
INSERT INTO versions VALUES (569, 'Person', 226, 'update', NULL, '---
id: 226
salutation: 0
name: Hilda G.
lastnames: Acosta Rivera
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 97
created_at: 2015-02-24 15:02:58.244599000 Z
updated_at: 2015-03-01 23:30:33.788745000 Z
', '2015-03-02 19:20:45.406394');
INSERT INTO versions VALUES (570, 'Person', 227, 'update', NULL, '---
id: 227
salutation: 
name: ''Sheyla ''
lastnames: ''Quiros Vazquez ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 97
created_at: 2015-02-24 15:03:30.849620000 Z
updated_at: 2015-03-01 23:30:42.490168000 Z
', '2015-03-02 19:20:49.492163');
INSERT INTO versions VALUES (571, 'Person', 28, 'update', NULL, '---
id: 28
salutation: 
name: ''Angel ''
lastnames: ''Pérez ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 100
created_at: 2015-02-24 01:38:14.145202000 Z
updated_at: 2015-03-01 23:30:42.601582000 Z
', '2015-03-02 19:20:49.626683');
INSERT INTO versions VALUES (572, 'Person', 27, 'update', NULL, '---
id: 27
salutation: 0
name: ''Migdalia ''
lastnames: ''Flores ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 100
created_at: 2015-02-24 01:37:45.571485000 Z
updated_at: 2015-03-01 23:30:42.637211000 Z
', '2015-03-02 19:20:49.643219');
INSERT INTO versions VALUES (573, 'Person', 55, 'update', NULL, '---
id: 55
salutation: 0
name: ''Geraldo ''
lastnames: ''Méndez ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 10
created_at: 2015-02-24 01:58:31.251653000 Z
updated_at: 2015-03-01 23:30:42.663852000 Z
', '2015-03-02 19:20:49.650928');
INSERT INTO versions VALUES (574, 'Person', 56, 'update', NULL, '---
id: 56
salutation: 
name: ''Héctor N. ''
lastnames: ''López ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 10
created_at: 2015-02-24 01:58:53.431612000 Z
updated_at: 2015-03-01 23:30:42.683894000 Z
', '2015-03-02 19:20:49.657356');
INSERT INTO versions VALUES (575, 'Person', 57, 'update', NULL, '---
id: 57
salutation: 
name: Lillian
lastnames: ''Rivera ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 10
created_at: 2015-02-24 01:59:18.740724000 Z
updated_at: 2015-03-01 23:30:42.705679000 Z
', '2015-03-02 19:20:49.664948');
INSERT INTO versions VALUES (576, 'Person', 267, 'update', NULL, '---
id: 267
salutation: 
name: ''Wanda I. ''
lastnames: ''Rentas Morales ''
sex: false
role: 5
description: ''''
attended: false
printed: false
materials: false
church_id: 10
created_at: 2015-02-24 17:29:51.385662000 Z
updated_at: 2015-03-01 23:30:44.373485000 Z
', '2015-03-02 19:20:52.783478');
INSERT INTO versions VALUES (577, 'Person', 137, 'update', NULL, '---
id: 137
salutation: 
name: ''Grisel ''
lastnames: ''Díaz ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 23
created_at: 2015-02-24 02:53:15.800547000 Z
updated_at: 2015-03-01 23:30:44.400514000 Z
', '2015-03-02 19:20:52.868014');
INSERT INTO versions VALUES (578, 'Person', 135, 'update', NULL, '---
id: 135
salutation: 
name: ''Irving ''
lastnames: ''Rivera ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 23
created_at: 2015-02-24 02:52:29.814474000 Z
updated_at: 2015-03-01 23:30:44.414205000 Z
', '2015-03-02 19:20:52.885449');
INSERT INTO versions VALUES (579, 'Person', 134, 'update', NULL, '---
id: 134
salutation: 0
name: ''Lizette ''
lastnames: ''Hernández ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 23
created_at: 2015-02-24 02:52:08.030117000 Z
updated_at: 2015-03-01 23:30:44.451807000 Z
', '2015-03-02 19:20:52.892505');
INSERT INTO versions VALUES (580, 'Person', 136, 'update', NULL, '---
id: 136
salutation: 
name: ''Luz D. ''
lastnames: ''Lozada ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 23
created_at: 2015-02-24 02:52:52.625027000 Z
updated_at: 2015-03-01 23:30:44.476438000 Z
', '2015-03-02 19:20:52.899659');
INSERT INTO versions VALUES (581, 'Person', 281, 'update', NULL, '---
id: 281
salutation: 
name: ''Carmen ''
lastnames: ''Zayas ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 11
created_at: 2015-02-25 14:46:16.166752000 Z
updated_at: 2015-03-01 23:30:44.487174000 Z
', '2015-03-02 19:20:52.905498');
INSERT INTO versions VALUES (582, 'Person', 278, 'update', NULL, '---
id: 278
salutation: 0
name: ''Germán ''
lastnames: Malavé
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 11
created_at: 2015-02-25 14:45:14.416172000 Z
updated_at: 2015-03-01 23:30:46.282505000 Z
', '2015-03-02 19:20:56.171344');
INSERT INTO versions VALUES (583, 'Person', 279, 'update', NULL, '---
id: 279
salutation: 
name: ''Lilliam ''
lastnames: ''Santos ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 11
created_at: 2015-02-25 14:45:41.268414000 Z
updated_at: 2015-03-01 23:30:46.622577000 Z
', '2015-03-02 19:20:56.248379');
INSERT INTO versions VALUES (584, 'Person', 280, 'update', NULL, '---
id: 280
salutation: 
name: ''Lydia ''
lastnames: Del Valle
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 11
created_at: 2015-02-25 14:46:00.734214000 Z
updated_at: 2015-03-01 23:30:46.636091000 Z
', '2015-03-02 19:20:56.265179');
INSERT INTO versions VALUES (585, 'Person', 176, 'update', NULL, '---
id: 176
salutation: 
name: ''Juan ''
lastnames: ''Morales ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 24
created_at: 2015-02-24 14:03:23.992370000 Z
updated_at: 2015-03-01 23:30:46.647253000 Z
', '2015-03-02 19:20:56.279227');
INSERT INTO versions VALUES (586, 'Person', 173, 'update', NULL, '---
id: 173
salutation: 0
name: ''Margarita ''
lastnames: ''Santana ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 24
created_at: 2015-02-24 14:00:34.174153000 Z
updated_at: 2015-03-01 23:30:46.673266000 Z
', '2015-03-02 19:20:56.285556');
INSERT INTO versions VALUES (587, 'Person', 175, 'update', NULL, '---
id: 175
salutation: 
name: ''Marisol ''
lastnames: ''Sanchez ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 24
created_at: 2015-02-24 14:03:07.962388000 Z
updated_at: 2015-03-01 23:30:46.685532000 Z
', '2015-03-02 19:20:56.292405');
INSERT INTO versions VALUES (588, 'Person', 174, 'update', NULL, '---
id: 174
salutation: 0
name: ''Rosalba ''
lastnames: Velez
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 24
created_at: 2015-02-24 14:01:17.186728000 Z
updated_at: 2015-03-01 23:30:48.299800000 Z
', '2015-03-02 19:20:59.463419');
INSERT INTO versions VALUES (589, 'Person', 85, 'update', NULL, '---
id: 85
salutation: 
name: ''Aida I. ''
lastnames: ''López ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:16:06.984407000 Z
updated_at: 2015-03-01 23:30:48.354636000 Z
', '2015-03-02 19:20:59.623011');
INSERT INTO versions VALUES (590, 'Person', 82, 'update', NULL, '---
id: 82
salutation: 
name: ''Alba ''
lastnames: ''Marín ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:14:48.426260000 Z
updated_at: 2015-03-01 23:30:48.361524000 Z
', '2015-03-02 19:21:00.026631');
INSERT INTO versions VALUES (591, 'Person', 79, 'update', NULL, '---
id: 79
salutation: 1
name: ''Angel ''
lastnames: ''Cruz ''
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:13:25.268081000 Z
updated_at: 2015-03-01 23:30:48.367456000 Z
', '2015-03-02 19:21:00.03566');
INSERT INTO versions VALUES (592, 'Person', 88, 'update', NULL, '---
id: 88
salutation: 
name: ''Angel ''
lastnames: ''Sierra ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:17:31.008629000 Z
updated_at: 2015-03-01 23:30:48.373240000 Z
', '2015-03-02 19:21:00.042412');
INSERT INTO versions VALUES (593, 'Person', 89, 'update', NULL, '---
id: 89
salutation: 
name: ''Aurelina ''
lastnames: ''Roldán ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:17:55.397238000 Z
updated_at: 2015-03-01 23:30:48.379256000 Z
', '2015-03-02 19:21:00.049599');
INSERT INTO versions VALUES (594, 'Person', 86, 'update', NULL, '---
id: 86
salutation: 
name: ''Aurelio ''
lastnames: ''Ríos ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:16:38.054947000 Z
updated_at: 2015-03-01 23:30:50.021550000 Z
', '2015-03-02 19:21:03.18249');
INSERT INTO versions VALUES (595, 'Person', 78, 'update', NULL, '---
id: 78
salutation: 1
name: ''César ''
lastnames: ''Maurás ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:12:58.693612000 Z
updated_at: 2015-03-01 23:30:50.075838000 Z
', '2015-03-02 19:21:03.397761');
INSERT INTO versions VALUES (596, 'Person', 87, 'update', NULL, '---
id: 87
salutation: 
name: ''Edgardo ''
lastnames: ''Miranda ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:17:00.753889000 Z
updated_at: 2015-03-01 23:30:50.082357000 Z
', '2015-03-02 19:21:03.41706');
INSERT INTO versions VALUES (597, 'Person', 91, 'update', NULL, '---
id: 91
salutation: 1
name: ''Edwin ''
lastnames: ''Rivera ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 14
created_at: 2015-02-24 02:22:48.675203000 Z
updated_at: 2015-03-01 23:30:50.091834000 Z
', '2015-03-02 19:21:03.425223');
INSERT INTO versions VALUES (598, 'Person', 90, 'update', NULL, '---
id: 90
salutation: 1
name: ''Félix ''
lastnames: ''Rivera ''
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:18:41.545225000 Z
updated_at: 2015-03-01 23:30:50.098767000 Z
', '2015-03-02 19:21:03.432187');
INSERT INTO versions VALUES (599, 'Person', 81, 'update', NULL, '---
id: 81
salutation: 1
name: ''Héctor A. ''
lastnames: ''Rivera ''
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:14:22.852503000 Z
updated_at: 2015-03-01 23:30:50.105392000 Z
', '2015-03-02 19:21:03.438554');
INSERT INTO versions VALUES (600, 'Person', 92, 'update', NULL, '---
id: 92
salutation: 
name: Juan R.
lastnames: ''Flusa ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 14
created_at: 2015-02-24 02:23:11.719046000 Z
updated_at: 2015-03-01 23:30:51.717428000 Z
', '2015-03-02 19:21:06.797246');
INSERT INTO versions VALUES (601, 'Person', 83, 'update', NULL, '---
id: 83
salutation: 
name: ''Noemí ''
lastnames: ''Ortiz ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:15:12.645890000 Z
updated_at: 2015-03-01 23:30:51.809932000 Z
', '2015-03-02 19:21:07.043932');
INSERT INTO versions VALUES (602, 'Person', 93, 'update', NULL, '---
id: 93
salutation: 
name: ''Oscar ''
lastnames: ''Lausell ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 14
created_at: 2015-02-24 02:23:34.710960000 Z
updated_at: 2015-03-01 23:30:51.826779000 Z
', '2015-03-02 19:21:07.056798');
INSERT INTO versions VALUES (603, 'Person', 84, 'update', NULL, '---
id: 84
salutation: 
name: ''Reinaldo ''
lastnames: ''Robles ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:15:41.375244000 Z
updated_at: 2015-03-01 23:30:51.843118000 Z
', '2015-03-02 19:21:07.065614');
INSERT INTO versions VALUES (604, 'Person', 80, 'update', NULL, '---
id: 80
salutation: 1
name: ''Yamina ''
lastnames: ''Apolinaris ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 13
created_at: 2015-02-24 02:13:57.475449000 Z
updated_at: 2015-03-01 23:30:51.857240000 Z
', '2015-03-02 19:21:07.075293');
INSERT INTO versions VALUES (605, 'Person', 180, 'update', NULL, '---
id: 180
salutation: 
name: ''Aida I. ''
lastnames: Torres
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 14:08:52.759995000 Z
updated_at: 2015-03-01 23:30:51.871336000 Z
', '2015-03-02 19:21:07.08354');
INSERT INTO versions VALUES (606, 'Person', 179, 'update', NULL, '---
id: 179
salutation: 1
name: ''Angel ''
lastnames: Mundo
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 14:07:06.346536000 Z
updated_at: 2015-03-01 23:30:53.501401000 Z
', '2015-03-02 19:21:10.233761');
INSERT INTO versions VALUES (607, 'Person', 184, 'update', NULL, '---
id: 184
salutation: 
name: ''Carlos ''
lastnames: ''Febo ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 14:10:25.178415000 Z
updated_at: 2015-03-01 23:30:53.984037000 Z
', '2015-03-02 19:21:10.280774');
INSERT INTO versions VALUES (608, 'Person', 224, 'update', NULL, '---
id: 224
salutation: 1
name: ''Efrain ''
lastnames: Figueroa
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 15:01:02.222804000 Z
updated_at: 2015-03-01 23:30:54.379887000 Z
', '2015-03-02 19:21:10.295371');
INSERT INTO versions VALUES (609, 'Person', 225, 'update', NULL, '---
id: 225
salutation: 0
name: Francisco
lastnames: Pinto
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 15:01:44.624629000 Z
updated_at: 2015-03-01 23:30:54.397546000 Z
', '2015-03-02 19:21:10.301647');
INSERT INTO versions VALUES (610, 'Person', 177, 'update', NULL, '---
id: 177
salutation: 1
name: ''Irma ''
lastnames: ''Pastrana ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 14:06:06.140412000 Z
updated_at: 2015-03-01 23:30:54.413215000 Z
', '2015-03-02 19:21:10.30888');
INSERT INTO versions VALUES (611, 'Person', 182, 'update', NULL, '---
id: 182
salutation: 
name: ''Luis ''
lastnames: Osorio
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 14:09:37.573035000 Z
updated_at: 2015-03-01 23:30:54.428622000 Z
', '2015-03-02 19:21:10.315042');
INSERT INTO versions VALUES (612, 'Person', 181, 'update', NULL, '---
id: 181
salutation: 
name: ''Luis ''
lastnames: ''Rosario ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 14:09:15.743096000 Z
updated_at: 2015-03-01 23:30:56.134680000 Z
', '2015-03-02 19:21:13.796177');
INSERT INTO versions VALUES (613, 'Person', 223, 'update', NULL, '---
id: 223
salutation: 1
name: ''Myrna I. ''
lastnames: Ramos
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 15:00:38.844886000 Z
updated_at: 2015-03-01 23:30:56.243244000 Z
', '2015-03-02 19:21:13.936204');
INSERT INTO versions VALUES (614, 'Person', 178, 'update', NULL, '---
id: 178
salutation: 0
name: ''Pedro ''
lastnames: Castro
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 14:06:33.867690000 Z
updated_at: 2015-03-01 23:30:56.259961000 Z
', '2015-03-02 19:21:13.952374');
INSERT INTO versions VALUES (615, 'Person', 183, 'update', NULL, '---
id: 183
salutation: 
name: ''Saúl ''
lastnames: Castillo
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 14:10:04.471921000 Z
updated_at: 2015-03-01 23:30:56.270864000 Z
', '2015-03-02 19:21:13.961307');
INSERT INTO versions VALUES (616, 'Person', 259, 'update', NULL, '---
id: 259
salutation: 
name: ''Benjamín ''
lastnames: ''Ortiz ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 18
created_at: 2015-02-24 15:32:15.704090000 Z
updated_at: 2015-03-01 23:30:56.281489000 Z
', '2015-03-02 19:21:13.966844');
INSERT INTO versions VALUES (617, 'Person', 255, 'update', NULL, '---
id: 255
salutation: 0
name: ''Edgardo ''
lastnames: Caraballo
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 18
created_at: 2015-02-24 15:30:51.289108000 Z
updated_at: 2015-03-01 23:30:56.290883000 Z
', '2015-03-02 19:21:13.973421');
INSERT INTO versions VALUES (618, 'Person', 260, 'update', NULL, '---
id: 260
salutation: 
name: ''Libertad ''
lastnames: ''Carrión ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 18
created_at: 2015-02-24 15:32:33.980877000 Z
updated_at: 2015-03-01 23:30:58.353299000 Z
', '2015-03-02 19:21:17.111771');
INSERT INTO versions VALUES (619, 'Person', 257, 'update', NULL, '---
id: 257
salutation: 
name: ''Matilde ''
lastnames: ''Dávila ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 18
created_at: 2015-02-24 15:31:36.906140000 Z
updated_at: 2015-03-01 23:30:58.439678000 Z
', '2015-03-02 19:21:17.572641');
INSERT INTO versions VALUES (620, 'Person', 258, 'update', NULL, '---
id: 258
salutation: 
name: ''Miguel ''
lastnames: ''Carrasquillo ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 18
created_at: 2015-02-24 15:31:57.720168000 Z
updated_at: 2015-03-01 23:30:58.447248000 Z
', '2015-03-02 19:21:17.588312');
INSERT INTO versions VALUES (621, 'Person', 256, 'update', NULL, '---
id: 256
salutation: 
name: ''Miguel ''
lastnames: ''Vázquez ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 18
created_at: 2015-02-24 15:31:15.047610000 Z
updated_at: 2015-03-01 23:30:58.463301000 Z
', '2015-03-02 19:21:17.593825');
INSERT INTO versions VALUES (622, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-03-01 23:30:58.477898000 Z
', '2015-03-02 19:21:17.60062');
INSERT INTO versions VALUES (623, 'Person', 155, 'update', NULL, '---
id: 155
salutation: 
name: ''Angela ''
lastnames: Arroyo Santiago
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:31:13.682457000 Z
updated_at: 2015-03-01 23:30:58.490083000 Z
', '2015-03-02 19:21:17.608189');
INSERT INTO versions VALUES (624, 'Person', 160, 'update', NULL, '---
id: 160
salutation: 
name: ''Carlos ''
lastnames: Dominguez Cristobal
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:33:40.851015000 Z
updated_at: 2015-03-01 23:31:00.151387000 Z
', '2015-03-02 19:21:20.736483');
INSERT INTO versions VALUES (625, 'Person', 159, 'update', NULL, '---
id: 159
salutation: 
name: ''Carlos ''
lastnames: Rodriguez Delannoy
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:33:17.399365000 Z
updated_at: 2015-03-01 23:31:00.194306000 Z
', '2015-03-02 19:21:20.929247');
INSERT INTO versions VALUES (626, 'Person', 148, 'update', NULL, '---
id: 148
salutation: 
name: ''Carmen ''
lastnames: ''Morales ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:39:28.230070000 Z
updated_at: 2015-03-01 23:31:00.200808000 Z
', '2015-03-02 19:21:20.944904');
INSERT INTO versions VALUES (627, 'Person', 138, 'update', NULL, '---
id: 138
salutation: 1
name: ''Carmen C. ''
lastnames: ''Adames ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:30:24.198051000 Z
updated_at: 2015-03-01 23:31:00.206097000 Z
', '2015-03-02 19:21:20.953895');
INSERT INTO versions VALUES (628, 'Person', 142, 'update', NULL, '---
id: 142
salutation: 1
name: ''Carmen M. ''
lastnames: ''Arroyo ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:34:25.075862000 Z
updated_at: 2015-03-01 23:31:00.211218000 Z
', '2015-03-02 19:21:20.960938');
INSERT INTO versions VALUES (629, 'Person', 158, 'update', NULL, '---
id: 158
salutation: 
name: ''Fernando ''
lastnames: ''Barreto Cardona ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:32:55.491074000 Z
updated_at: 2015-03-01 23:31:00.216771000 Z
', '2015-03-02 19:21:20.967438');
INSERT INTO versions VALUES (630, 'Person', 161, 'update', NULL, '---
id: 161
salutation: 
name: ''Gladys ''
lastnames: Linares Estrada
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:34:03.070512000 Z
updated_at: 2015-03-01 23:31:01.941664000 Z
', '2015-03-02 19:21:24.096907');
INSERT INTO versions VALUES (631, 'Person', 149, 'update', NULL, '---
id: 149
salutation: 
name: ''José A. ''
lastnames: ''Fernández ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:40:17.711563000 Z
updated_at: 2015-03-01 23:31:02.306625000 Z
', '2015-03-02 19:21:24.193865');
INSERT INTO versions VALUES (632, 'Person', 139, 'update', NULL, '---
id: 139
salutation: 1
name: ''Juan E. ''
lastnames: ''Matias ''
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:31:25.127264000 Z
updated_at: 2015-03-01 23:31:02.337095000 Z
', '2015-03-02 19:21:24.209602');
INSERT INTO versions VALUES (633, 'Person', 153, 'update', NULL, '---
id: 153
salutation: 
name: Lillian
lastnames: Rivera Morales
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:26:47.056805000 Z
updated_at: 2015-03-01 23:31:02.355362000 Z
', '2015-03-02 19:21:24.245975');
INSERT INTO versions VALUES (634, 'Person', 143, 'update', NULL, '---
id: 143
salutation: 1
name: ''Luis R. ''
lastnames: ''Quiñones ''
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:35:16.499350000 Z
updated_at: 2015-03-01 23:31:02.374384000 Z
', '2015-03-02 19:21:24.688929');
INSERT INTO versions VALUES (635, 'Person', 154, 'update', NULL, '---
id: 154
salutation: 1
name: ''Madelyn ''
lastnames: Figueroa Alamo
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:30:40.268446000 Z
updated_at: 2015-03-01 23:31:02.387736000 Z
', '2015-03-02 19:21:24.705561');
INSERT INTO versions VALUES (636, 'Person', 145, 'update', NULL, '---
id: 145
salutation: 0
name: ''Margot ''
lastnames: ''Camacho ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:06.046467000 Z
updated_at: 2015-03-01 23:31:04.026931000 Z
', '2015-03-02 19:21:28.546491');
INSERT INTO versions VALUES (637, 'Person', 151, 'update', NULL, '---
id: 151
salutation: 
name: Maria E.
lastnames: ''Rivera Melendez ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:25:34.789697000 Z
updated_at: 2015-03-01 23:31:04.115888000 Z
', '2015-03-02 19:21:28.731942');
INSERT INTO versions VALUES (638, 'Person', 141, 'update', NULL, '---
id: 141
salutation: 1
name: ''María E. ''
lastnames: ''Calderón ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:33:33.087962000 Z
updated_at: 2015-03-01 23:31:04.140794000 Z
', '2015-03-02 19:21:28.751597');
INSERT INTO versions VALUES (639, 'Person', 140, 'update', NULL, '---
id: 140
salutation: 1
name: ''Marilyn ''
lastnames: ''Ortiz ''
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:32:32.978955000 Z
updated_at: 2015-03-01 23:31:04.154222000 Z
', '2015-03-02 19:21:28.762252');
INSERT INTO versions VALUES (640, 'Person', 147, 'update', NULL, '---
id: 147
salutation: 
name: ''Mario ''
lastnames: ''Moya ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:38:43.989795000 Z
updated_at: 2015-03-01 23:31:04.181524000 Z
', '2015-03-02 19:21:28.766804');
INSERT INTO versions VALUES (641, 'Person', 150, 'update', NULL, '---
id: 150
salutation: 
name: ''Milagros ''
lastnames: Pizarrro
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:22:38.515628000 Z
updated_at: 2015-03-01 23:31:04.961351000 Z
', '2015-03-02 19:21:28.773597');
INSERT INTO versions VALUES (642, 'Person', 156, 'update', NULL, '---
id: 156
salutation: 
name: ''Norma ''
lastnames: Valentin Guerrero
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:31:44.768649000 Z
updated_at: 2015-03-01 23:31:06.601788000 Z
', '2015-03-02 19:21:32.178264');
INSERT INTO versions VALUES (643, 'Person', 144, 'update', NULL, '---
id: 144
salutation: 0
name: ''Omar A. ''
lastnames: ''Santiago ''
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:36:11.543037000 Z
updated_at: 2015-03-01 23:31:06.609124000 Z
', '2015-03-02 19:21:32.705858');
INSERT INTO versions VALUES (644, 'Person', 157, 'update', NULL, '---
id: 157
salutation: 
name: ''Sonia ''
lastnames: ''García Hernández ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:32:21.484489000 Z
updated_at: 2015-03-01 23:31:06.614929000 Z
', '2015-03-02 19:21:32.718762');
INSERT INTO versions VALUES (645, 'Person', 152, 'update', NULL, '---
id: 152
salutation: 
name: ''Victor ''
lastnames: Rivera Santiago
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:26:17.801431000 Z
updated_at: 2015-03-01 23:31:06.620337000 Z
', '2015-03-02 19:21:32.726566');
INSERT INTO versions VALUES (646, 'Person', 293, 'update', NULL, '---
id: 293
salutation: 
name: ''Diana ''
lastnames: ''Medina ''
sex: false
role: 4
description: ''''
attended: false
printed: false
materials: false
church_id: 98
created_at: 2015-02-27 02:37:49.971019000 Z
updated_at: 2015-03-01 23:31:06.625804000 Z
', '2015-03-02 19:21:32.733313');
INSERT INTO versions VALUES (647, 'Person', 292, 'update', NULL, '---
id: 292
salutation: 0
name: ''Karilyn ''
lastnames: ''Galarza ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 98
created_at: 2015-02-27 02:37:13.680893000 Z
updated_at: 2015-03-01 23:31:06.632395000 Z
', '2015-03-02 19:21:32.74175');
INSERT INTO versions VALUES (648, 'Person', 60, 'update', NULL, '---
id: 60
salutation: 
name: ''Angel ''
lastnames: ''De Jesús ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 33
created_at: 2015-02-24 02:00:59.145070000 Z
updated_at: 2015-03-01 23:31:08.240985000 Z
', '2015-03-02 19:21:35.877374');
INSERT INTO versions VALUES (649, 'Person', 59, 'update', NULL, '---
id: 59
salutation: 
name: ''Antonio ''
lastnames: ''Cabrera ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 33
created_at: 2015-02-24 02:00:30.777975000 Z
updated_at: 2015-03-01 23:31:08.317234000 Z
', '2015-03-02 19:21:35.973259');
INSERT INTO versions VALUES (650, 'Person', 65, 'update', NULL, '---
id: 65
salutation: 1
name: ''Benigno ''
lastnames: ''Torres ''
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 33
created_at: 2015-02-24 02:03:03.022471000 Z
updated_at: 2015-03-01 23:31:08.334097000 Z
', '2015-03-02 19:21:35.98753');
INSERT INTO versions VALUES (651, 'Person', 64, 'update', NULL, '---
id: 64
salutation: 
name: ''Emérito ''
lastnames: ''Sánchez ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 33
created_at: 2015-02-24 02:02:38.334079000 Z
updated_at: 2015-03-01 23:31:08.346176000 Z
', '2015-03-02 19:21:35.99475');
INSERT INTO versions VALUES (652, 'Person', 58, 'update', NULL, '---
id: 58
salutation: 0
name: ''Jorge L. ''
lastnames: ''Cintrón ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 33
created_at: 2015-02-24 02:00:09.302735000 Z
updated_at: 2015-03-01 23:31:08.351382000 Z
', '2015-03-02 19:21:36.001386');
INSERT INTO versions VALUES (653, 'Person', 62, 'update', NULL, '---
id: 62
salutation: 
name: ''Jorge L. ''
lastnames: ''Oquendo ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 33
created_at: 2015-02-24 02:01:45.246570000 Z
updated_at: 2015-03-01 23:31:08.356881000 Z
', '2015-03-02 19:21:36.008296');
INSERT INTO versions VALUES (654, 'Person', 61, 'update', NULL, '---
id: 61
salutation: 
name: ''José A. ''
lastnames: ''Cotto ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 33
created_at: 2015-02-24 02:01:25.367756000 Z
updated_at: 2015-03-01 23:31:09.971160000 Z
', '2015-03-02 19:21:39.245139');
INSERT INTO versions VALUES (655, 'Person', 63, 'update', NULL, '---
id: 63
salutation: 
name: ''María del C. ''
lastnames: ''Meléndez ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 33
created_at: 2015-02-24 02:02:14.536270000 Z
updated_at: 2015-03-01 23:31:10.094468000 Z
', '2015-03-02 19:21:39.28645');
INSERT INTO versions VALUES (656, 'Person', 165, 'update', NULL, '---
id: 165
salutation: 
name: ''Margarita ''
lastnames: Rodríguez
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 26
created_at: 2015-02-24 13:51:43.982194000 Z
updated_at: 2015-03-01 23:31:10.111974000 Z
', '2015-03-02 19:21:39.291275');
INSERT INTO versions VALUES (657, 'Person', 163, 'update', NULL, '---
id: 163
salutation: 
name: ''Neris ''
lastnames: ''Carrasquillo ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 26
created_at: 2015-02-24 13:50:59.036800000 Z
updated_at: 2015-03-01 23:31:10.121533000 Z
', '2015-03-02 19:21:39.296444');
INSERT INTO versions VALUES (658, 'Person', 162, 'update', NULL, '---
id: 162
salutation: 0
name: ''Nilsa ''
lastnames: Rodríguez Casillas
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 26
created_at: 2015-02-24 13:50:27.216163000 Z
updated_at: 2015-03-01 23:31:10.130660000 Z
', '2015-03-02 19:21:39.300724');
INSERT INTO versions VALUES (659, 'Person', 164, 'update', NULL, '---
id: 164
salutation: 
name: ''Sonia ''
lastnames: ''Casillas ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 26
created_at: 2015-02-24 13:51:15.708854000 Z
updated_at: 2015-03-01 23:31:10.138926000 Z
', '2015-03-02 19:21:39.304595');
INSERT INTO versions VALUES (660, 'Person', 97, 'update', NULL, '---
id: 97
salutation: 0
name: ''Carmen P. ''
lastnames: ''Pérez ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 50
created_at: 2015-02-24 02:26:09.989510000 Z
updated_at: 2015-03-01 23:31:11.757997000 Z
', '2015-03-02 19:21:42.462503');
INSERT INTO versions VALUES (661, 'Person', 98, 'update', NULL, '---
id: 98
salutation: 0
name: ''Emma ''
lastnames: ''Méndez ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 50
created_at: 2015-02-24 02:26:31.869154000 Z
updated_at: 2015-03-01 23:31:11.878021000 Z
', '2015-03-02 19:21:42.468642');
INSERT INTO versions VALUES (662, 'Person', 99, 'update', NULL, '---
id: 99
salutation: 
name: ''Idalia ''
lastnames: ''García ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 50
created_at: 2015-02-24 02:26:53.654669000 Z
updated_at: 2015-03-01 23:31:11.893353000 Z
', '2015-03-02 19:21:42.473426');
INSERT INTO versions VALUES (663, 'Person', 100, 'update', NULL, '---
id: 100
salutation: 
name: ''José A. ''
lastnames: ''Boria ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 50
created_at: 2015-02-24 02:27:18.420492000 Z
updated_at: 2015-03-01 23:31:11.906779000 Z
', '2015-03-02 19:21:42.478424');
INSERT INTO versions VALUES (664, 'Person', 50, 'update', NULL, '---
id: 50
salutation: 
name: ''Ahmed ''
lastnames: ''Díaz ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 113
created_at: 2015-02-24 01:53:49.390545000 Z
updated_at: 2015-03-01 23:31:11.917387000 Z
', '2015-03-02 19:21:42.483221');
INSERT INTO versions VALUES (665, 'Person', 48, 'update', NULL, '---
id: 48
salutation: 1
name: ''Jimmy ''
lastnames: ''Vargas ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 113
created_at: 2015-02-24 01:53:09.270001000 Z
updated_at: 2015-03-01 23:31:11.924963000 Z
', '2015-03-02 19:21:42.488494');
INSERT INTO versions VALUES (666, 'Person', 49, 'update', NULL, '---
id: 49
salutation: 
name: ''Víctor ''
lastnames: ''Rivera ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 113
created_at: 2015-02-24 01:53:29.170580000 Z
updated_at: 2015-03-01 23:31:13.597693000 Z
', '2015-03-02 19:21:45.732029');
INSERT INTO versions VALUES (667, 'Person', 270, 'update', NULL, '---
id: 270
salutation: 4
name: ''Arturo J. ''
lastnames: Siaca
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 36
created_at: 2015-02-24 17:41:40.122104000 Z
updated_at: 2015-03-01 23:31:13.684384000 Z
', '2015-03-02 19:21:46.326002');
INSERT INTO versions VALUES (668, 'Person', 67, 'update', NULL, '---
id: 67
salutation: 
name: ''Cristina ''
lastnames: ''Báez ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 36
created_at: 2015-02-24 02:05:28.776187000 Z
updated_at: 2015-03-01 23:31:13.702535000 Z
', '2015-03-02 19:21:46.341981');
INSERT INTO versions VALUES (669, 'Person', 68, 'update', NULL, '---
id: 68
salutation: 
name: ''Daniel ''
lastnames: ''Santos ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 36
created_at: 2015-02-24 02:05:58.200172000 Z
updated_at: 2015-03-01 23:31:13.717096000 Z
', '2015-03-02 19:21:46.349298');
INSERT INTO versions VALUES (670, 'Person', 71, 'update', NULL, '---
id: 71
salutation: 
name: ''Dora ''
lastnames: ''Cruz ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 37
created_at: 2015-02-24 02:07:36.947044000 Z
updated_at: 2015-03-01 23:31:13.725178000 Z
', '2015-03-02 19:21:46.355083');
INSERT INTO versions VALUES (671, 'Person', 72, 'update', NULL, '---
id: 72
salutation: 
name: ''Fredeswilda ''
lastnames: ''Vargas ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 37
created_at: 2015-02-24 02:08:16.277270000 Z
updated_at: 2015-03-01 23:31:13.733748000 Z
', '2015-03-02 19:21:46.36086');
INSERT INTO versions VALUES (672, 'Person', 66, 'update', NULL, '---
id: 66
salutation: 1
name: ''Jaime ''
lastnames: ''Rodríguez ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 36
created_at: 2015-02-24 02:05:02.059083000 Z
updated_at: 2015-03-01 23:31:15.355774000 Z
', '2015-03-02 19:21:49.500852');
INSERT INTO versions VALUES (673, 'Person', 69, 'update', NULL, '---
id: 69
salutation: 0
name: ''Juan C. ''
lastnames: ''Navarro ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 37
created_at: 2015-02-24 02:06:47.609568000 Z
updated_at: 2015-03-01 23:31:15.429546000 Z
', '2015-03-02 19:21:49.640537');
INSERT INTO versions VALUES (674, 'Person', 73, 'update', NULL, '---
id: 73
salutation: 
name: ''Yolaris ''
lastnames: ''Negrón ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 37
created_at: 2015-02-24 02:08:54.002502000 Z
updated_at: 2015-03-01 23:31:15.447410000 Z
', '2015-03-02 19:21:49.656262');
INSERT INTO versions VALUES (675, 'Person', 70, 'update', NULL, '---
id: 70
salutation: 
name: ''Zoraida I. ''
lastnames: Serrano
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 37
created_at: 2015-02-24 02:07:15.106485000 Z
updated_at: 2015-03-01 23:31:15.459895000 Z
', '2015-03-02 19:21:49.672468');
INSERT INTO versions VALUES (676, 'Person', 229, 'update', NULL, '---
id: 229
salutation: 
name: ''Lucy ''
lastnames: Muñoz
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 39
created_at: 2015-02-24 15:04:56.866984000 Z
updated_at: 2015-03-01 23:31:15.472433000 Z
', '2015-03-02 19:21:49.689594');
INSERT INTO versions VALUES (677, 'Person', 230, 'update', NULL, '---
id: 230
salutation: 
name: Norma I.
lastnames: Pérez
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 39
created_at: 2015-02-24 15:05:16.436013000 Z
updated_at: 2015-03-01 23:31:15.483828000 Z
', '2015-03-02 19:21:49.704317');
INSERT INTO versions VALUES (678, 'Person', 282, 'update', NULL, '---
id: 282
salutation: 1
name: ''Dr. Anibal ''
lastnames: ''Cruz ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 121
created_at: 2015-02-25 14:47:11.251809000 Z
updated_at: 2015-03-01 23:31:17.107910000 Z
', '2015-03-02 19:21:52.812291');
INSERT INTO versions VALUES (679, 'Person', 75, 'update', NULL, '---
id: 75
salutation: 
name: ''David ''
lastnames: ''Calderón ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 40
created_at: 2015-02-24 02:10:31.344285000 Z
updated_at: 2015-03-01 23:31:17.755463000 Z
', '2015-03-02 19:21:52.89839');
INSERT INTO versions VALUES (680, 'Person', 74, 'update', NULL, '---
id: 74
salutation: 
name: ''Luis ''
lastnames: ''López ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 40
created_at: 2015-02-24 02:09:58.047775000 Z
updated_at: 2015-03-01 23:31:17.776312000 Z
', '2015-03-02 19:21:52.90551');
INSERT INTO versions VALUES (681, 'Person', 269, 'update', NULL, '---
id: 269
salutation: 0
name: ''Ramon ''
lastnames: Arroyo
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 40
created_at: 2015-02-24 17:40:29.026992000 Z
updated_at: 2015-03-01 23:31:17.793173000 Z
', '2015-03-02 19:21:52.912123');
INSERT INTO versions VALUES (682, 'Person', 268, 'update', NULL, '---
id: 268
salutation: 1
name: Carmen J.
lastnames: ''Pagan ''
sex: false
role: 3
description: Sustituto
attended: false
printed: false
materials: false
church_id: 103
created_at: 2015-02-24 17:33:42.659320000 Z
updated_at: 2015-03-01 23:31:17.803771000 Z
', '2015-03-02 19:21:52.918117');
INSERT INTO versions VALUES (683, 'Person', 11, 'update', NULL, '---
id: 11
salutation: 
name: ''Jessica ''
lastnames: ''Lugo ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 103
created_at: 2015-02-24 01:17:56.120307000 Z
updated_at: 2015-03-01 23:31:17.813087000 Z
', '2015-03-02 19:21:52.922048');
INSERT INTO versions VALUES (684, 'Person', 12, 'update', NULL, '---
id: 12
salutation: 
name: ''Mary Leen ''
lastnames: Marrero
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 103
created_at: 2015-02-24 01:18:51.363156000 Z
updated_at: 2015-03-01 23:31:19.449473000 Z
', '2015-03-02 19:21:56.041413');
INSERT INTO versions VALUES (685, 'Person', 10, 'update', NULL, '---
id: 10
salutation: 1
name: ''Miriam ''
lastnames: Rodríguez de Gutiérrez
sex: false
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 103
created_at: 2015-02-24 01:17:20.485002000 Z
updated_at: 2015-03-01 23:31:19.495367000 Z
', '2015-03-02 19:21:56.765379');
INSERT INTO versions VALUES (686, 'Person', 13, 'update', NULL, '---
id: 13
salutation: 
name: ''Noel ''
lastnames: ''Ortiz ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 103
created_at: 2015-02-24 01:19:13.409094000 Z
updated_at: 2015-03-01 23:31:19.501361000 Z
', '2015-03-02 19:21:56.77171');
INSERT INTO versions VALUES (687, 'Person', 14, 'update', NULL, '---
id: 14
salutation: 
name: ''Pedro ''
lastnames: ''Gely ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 103
created_at: 2015-02-24 01:19:45.854266000 Z
updated_at: 2015-03-01 23:31:19.515673000 Z
', '2015-03-02 19:21:56.777153');
INSERT INTO versions VALUES (688, 'Person', 16, 'update', NULL, '---
id: 16
salutation: 
name: ''Zoraida ''
lastnames: ''Rivera ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 103
created_at: 2015-02-24 01:20:55.459826000 Z
updated_at: 2015-03-01 23:31:19.533705000 Z
', '2015-03-02 19:21:56.782012');
INSERT INTO versions VALUES (689, 'Person', 17, 'update', NULL, '---
id: 17
salutation: 1
name: ''David ''
lastnames: ''Valentín ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 3
created_at: 2015-02-24 01:24:22.065414000 Z
updated_at: 2015-03-01 23:31:19.542955000 Z
', '2015-03-02 19:21:56.787173');
INSERT INTO versions VALUES (690, 'Person', 272, 'update', NULL, '---
id: 272
salutation: 
name: ''Debora ''
lastnames: Varona Guerrero
sex: false
role: 4
description: ''''
attended: false
printed: false
materials: false
church_id: 3
created_at: 2015-02-24 18:10:46.124550000 Z
updated_at: 2015-03-01 23:31:21.150669000 Z
', '2015-03-02 19:22:00.362639');
INSERT INTO versions VALUES (691, 'Person', 18, 'update', NULL, '---
id: 18
salutation: 
name: ''Jennie ''
lastnames: ''Cintrón ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 3
created_at: 2015-02-24 01:25:06.338216000 Z
updated_at: 2015-03-01 23:31:21.207742000 Z
', '2015-03-02 19:22:00.389736');
INSERT INTO versions VALUES (692, 'Person', 19, 'update', NULL, '---
id: 19
salutation: 
name: ''José A. ''
lastnames: ''Flores ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 3
created_at: 2015-02-24 01:25:39.803808000 Z
updated_at: 2015-03-01 23:31:21.224544000 Z
', '2015-03-02 19:22:00.394671');
INSERT INTO versions VALUES (693, 'Person', 21, 'update', NULL, '---
id: 21
salutation: 
name: ''Miguel A. ''
lastnames: ''Rivera ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 3
created_at: 2015-02-24 01:26:30.752850000 Z
updated_at: 2015-03-01 23:31:21.239128000 Z
', '2015-03-02 19:22:00.402489');
INSERT INTO versions VALUES (694, 'Person', 20, 'update', NULL, '---
id: 20
salutation: 
name: ''Samuel ''
lastnames: Encarnación
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 3
created_at: 2015-02-24 01:26:07.105439000 Z
updated_at: 2015-03-01 23:31:21.249755000 Z
', '2015-03-02 19:22:00.407848');
INSERT INTO versions VALUES (695, 'Person', 101, 'update', NULL, '---
id: 101
salutation: 1
name: ''Juan ''
lastnames: ''Vergara ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 52
created_at: 2015-02-24 02:28:47.997609000 Z
updated_at: 2015-03-01 23:31:21.258901000 Z
', '2015-03-02 19:22:00.413357');
INSERT INTO versions VALUES (696, 'Person', 102, 'update', NULL, '---
id: 102
salutation: 
name: ''Marisol ''
lastnames: ''Rosa ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 52
created_at: 2015-02-24 02:29:10.040047000 Z
updated_at: 2015-03-01 23:31:23.260155000 Z
', '2015-03-02 19:22:03.579467');
INSERT INTO versions VALUES (697, 'Person', 106, 'update', NULL, '---
id: 106
salutation: 0
name: ''Miguel A. ''
lastnames: ''Sánchez ''
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 52
created_at: 2015-02-24 02:31:01.728234000 Z
updated_at: 2015-03-01 23:31:23.294973000 Z
', '2015-03-02 19:22:03.973892');
INSERT INTO versions VALUES (698, 'Person', 105, 'update', NULL, '---
id: 105
salutation: 4
name: ''Nayda ''
lastnames: Márquez
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 52
created_at: 2015-02-24 02:30:38.332964000 Z
updated_at: 2015-03-01 23:31:23.301713000 Z
', '2015-03-02 19:22:04.372714');
INSERT INTO versions VALUES (699, 'Person', 104, 'update', NULL, '---
id: 104
salutation: 
name: ''Roberto ''
lastnames: ''Rodríguez ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 52
created_at: 2015-02-24 02:30:03.651506000 Z
updated_at: 2015-03-01 23:31:23.307410000 Z
', '2015-03-02 19:22:04.397413');
INSERT INTO versions VALUES (700, 'Person', 103, 'update', NULL, '---
id: 103
salutation: 
name: ''Samuel ''
lastnames: ''Acevedo ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 52
created_at: 2015-02-24 02:29:30.896712000 Z
updated_at: 2015-03-01 23:31:23.313719000 Z
', '2015-03-02 19:22:04.406483');
INSERT INTO versions VALUES (701, 'Person', 33, 'update', NULL, '---
id: 33
salutation: 
name: ''Awilda ''
lastnames: ''Hernández ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 123
created_at: 2015-02-24 01:42:32.458934000 Z
updated_at: 2015-03-01 23:31:23.319646000 Z
', '2015-03-02 19:22:04.412443');
INSERT INTO versions VALUES (702, 'Person', 31, 'update', NULL, '---
id: 31
salutation: 0
name: ''Hipólito ''
lastnames: ''Félix ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 123
created_at: 2015-02-24 01:41:36.181148000 Z
updated_at: 2015-03-01 23:31:25.044959000 Z
', '2015-03-02 19:22:07.559851');
INSERT INTO versions VALUES (703, 'Person', 32, 'update', NULL, '---
id: 32
salutation: 
name: ''Lydia ''
lastnames: ''Camacho ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 123
created_at: 2015-02-24 01:42:07.441078000 Z
updated_at: 2015-03-01 23:31:25.263853000 Z
', '2015-03-02 19:22:07.714311');
INSERT INTO versions VALUES (704, 'Person', 305, 'update', NULL, '---
id: 305
salutation: 1
name: Luz C.
lastnames: Abreu
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 90
created_at: 2015-03-02 19:20:31.776100000 Z
updated_at: 2015-03-02 19:20:31.776100000 Z
', '2015-03-02 19:22:07.731322');
INSERT INTO versions VALUES (705, 'Person', 29, 'update', NULL, '---
id: 29
salutation: 
name: ''Carmen N. ''
lastnames: ''Negrón ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 12
created_at: 2015-02-24 01:39:08.318674000 Z
updated_at: 2015-03-01 23:31:25.287516000 Z
', '2015-03-02 19:22:07.744586');
INSERT INTO versions VALUES (706, 'Person', 30, 'update', NULL, '---
id: 30
salutation: 
name: ''Raquel ''
lastnames: ''Oquendo ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 12
created_at: 2015-02-24 01:39:31.364703000 Z
updated_at: 2015-03-01 23:31:25.305064000 Z
', '2015-03-02 19:22:07.75111');
INSERT INTO versions VALUES (707, 'Person', 121, 'update', NULL, '---
id: 121
salutation: 
name: ''Audrey ''
lastnames: ''Viera ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 15
created_at: 2015-02-24 02:40:13.362635000 Z
updated_at: 2015-03-01 23:31:25.321619000 Z
', '2015-03-02 19:22:07.758025');
INSERT INTO versions VALUES (708, 'Person', 119, 'update', NULL, '---
id: 119
salutation: 0
name: ''Blanca ''
lastnames: ''Velázquez ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 15
created_at: 2015-02-24 02:39:10.397961000 Z
updated_at: 2015-03-01 23:31:25.354702000 Z
', '2015-03-02 19:22:11.16335');
INSERT INTO versions VALUES (709, 'Person', 120, 'update', NULL, '---
id: 120
salutation: 
name: ''Providencia ''
lastnames: ''Hernández ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 15
created_at: 2015-02-24 02:39:44.622382000 Z
updated_at: 2015-03-01 23:31:27.066920000 Z
', '2015-03-02 19:22:12.421088');
INSERT INTO versions VALUES (710, 'Person', 187, 'update', NULL, '---
id: 187
salutation: 
name: Ada N.
lastnames: Quiñones
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 42
created_at: 2015-02-24 14:19:01.547741000 Z
updated_at: 2015-03-01 23:31:27.106688000 Z
', '2015-03-02 19:22:12.432172');
INSERT INTO versions VALUES (711, 'Person', 188, 'update', NULL, '---
id: 188
salutation: 
name: ''Anidalia ''
lastnames: Rivera
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 42
created_at: 2015-02-24 14:19:32.496052000 Z
updated_at: 2015-03-01 23:31:27.114254000 Z
', '2015-03-02 19:22:12.442362');
INSERT INTO versions VALUES (712, 'Person', 186, 'update', NULL, '---
id: 186
salutation: 
name: ''Carmen ''
lastnames: ''Johnson ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 42
created_at: 2015-02-24 14:18:37.601020000 Z
updated_at: 2015-03-01 23:31:27.120737000 Z
', '2015-03-02 19:22:12.452575');
INSERT INTO versions VALUES (713, 'Person', 185, 'update', NULL, '---
id: 185
salutation: 0
name: ''Javier E. ''
lastnames: Sosa Rodríguez
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 42
created_at: 2015-02-24 14:18:03.475814000 Z
updated_at: 2015-03-01 23:31:27.126703000 Z
', '2015-03-02 19:22:12.458571');
INSERT INTO versions VALUES (714, 'Person', 6, 'update', NULL, '---
id: 6
salutation: 1
name: ''Eneida ''
lastnames: Angleró
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 105
created_at: 2015-02-23 22:25:35.265226000 Z
updated_at: 2015-03-01 23:31:27.132618000 Z
', '2015-03-02 19:22:15.617905');
INSERT INTO versions VALUES (715, 'Person', 8, 'update', NULL, '---
id: 8
salutation: 
name: ''Rómulo ''
lastnames: ''Ortiz ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 105
created_at: 2015-02-23 22:26:41.588490000 Z
updated_at: 2015-03-01 23:31:28.743095000 Z
', '2015-03-02 19:22:15.723554');
INSERT INTO versions VALUES (716, 'Person', 9, 'update', NULL, '---
id: 9
salutation: 
name: ''Wilfredo ''
lastnames: ''Torres ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 105
created_at: 2015-02-23 22:27:06.708956000 Z
updated_at: 2015-03-01 23:31:28.863740000 Z
', '2015-03-02 19:22:15.740765');
INSERT INTO versions VALUES (717, 'Person', 7, 'update', NULL, '---
id: 7
salutation: 
name: ''Yamalis ''
lastnames: ''González ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 105
created_at: 2015-02-23 22:26:10.392410000 Z
updated_at: 2015-03-01 23:31:28.881146000 Z
', '2015-03-02 19:22:15.756524');
INSERT INTO versions VALUES (718, 'Person', 231, 'update', NULL, '---
id: 231
salutation: 0
name: ''Celis ''
lastnames: Zambrana Batista
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 45
created_at: 2015-02-24 15:06:14.599552000 Z
updated_at: 2015-03-01 23:31:28.896336000 Z
', '2015-03-02 19:22:15.772849');
INSERT INTO versions VALUES (719, 'Person', 233, 'update', NULL, '---
id: 233
salutation: 
name: ''David ''
lastnames: ''Soto Cardona ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 45
created_at: 2015-02-24 15:07:18.502531000 Z
updated_at: 2015-03-01 23:31:28.907103000 Z
', '2015-03-02 19:22:15.789414');
INSERT INTO versions VALUES (720, 'Person', 234, 'update', NULL, '---
id: 234
salutation: 
name: ''Digna ''
lastnames: Valdés Laboy
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 45
created_at: 2015-02-24 15:07:44.276170000 Z
updated_at: 2015-03-01 23:31:28.917840000 Z
', '2015-03-02 19:22:19.2392');
INSERT INTO versions VALUES (721, 'Person', 235, 'update', NULL, '---
id: 235
salutation: 
name: ''Luis ''
lastnames: ''Berrios Bones ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 45
created_at: 2015-02-24 15:08:07.300651000 Z
updated_at: 2015-03-01 23:31:30.545808000 Z
', '2015-03-02 19:22:19.244413');
INSERT INTO versions VALUES (722, 'Person', 236, 'update', NULL, '---
id: 236
salutation: 
name: ''Maria C. ''
lastnames: Gómez García
sex: false
role: 3
description: Sustituto
attended: false
printed: false
materials: false
church_id: 45
created_at: 2015-02-24 15:08:43.896090000 Z
updated_at: 2015-03-01 23:31:30.611839000 Z
', '2015-03-02 19:22:19.24959');
INSERT INTO versions VALUES (723, 'Person', 232, 'update', NULL, '---
id: 232
salutation: 
name: ''Nilma Y. ''
lastnames: Agosto García
sex: false
role: 5
description: ''''
attended: false
printed: false
materials: false
church_id: 45
created_at: 2015-02-24 15:06:56.720207000 Z
updated_at: 2015-03-01 23:31:30.628631000 Z
', '2015-03-02 19:22:19.255075');
INSERT INTO versions VALUES (724, 'Person', 237, 'update', NULL, '---
id: 237
salutation: 
name: ''Santos ''
lastnames: ''Torres Padilla ''
sex: true
role: 3
description: Sustituto
attended: false
printed: false
materials: false
church_id: 45
created_at: 2015-02-24 15:09:04.911706000 Z
updated_at: 2015-03-01 23:31:30.642377000 Z
', '2015-03-02 19:22:19.259573');
INSERT INTO versions VALUES (725, 'Person', 238, 'update', NULL, '---
id: 238
salutation: 0
name: ''Carlos A. ''
lastnames: ''Padilla Rivera ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 47
created_at: 2015-02-24 15:09:45.918708000 Z
updated_at: 2015-03-01 23:31:30.655685000 Z
', '2015-03-02 19:22:19.263861');
INSERT INTO versions VALUES (726, 'Person', 296, 'update', NULL, '---
id: 296
salutation: 1
name: ''Félix ''
lastnames: ''López ''
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 53
created_at: 2015-02-27 02:44:42.000719000 Z
updated_at: 2015-03-01 23:31:30.666412000 Z
', '2015-03-02 19:22:22.364287');
INSERT INTO versions VALUES (727, 'Person', 299, 'update', NULL, '---
id: 299
salutation: 
name: ''Isabel ''
lastnames: ''Calderón ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 53
created_at: 2015-02-27 02:46:30.932917000 Z
updated_at: 2015-03-01 23:31:32.297386000 Z
', '2015-03-02 19:22:22.579417');
INSERT INTO versions VALUES (728, 'Person', 295, 'update', NULL, '---
id: 295
salutation: 1
name: ''José A. ''
lastnames: López
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 53
created_at: 2015-02-27 02:44:15.396685000 Z
updated_at: 2015-03-01 23:31:32.305374000 Z
', '2015-03-02 19:22:22.597211');
INSERT INTO versions VALUES (729, 'Person', 297, 'update', NULL, '---
id: 297
salutation: 
name: ''María ''
lastnames: ''Castillo ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 53
created_at: 2015-02-27 02:45:46.184223000 Z
updated_at: 2015-03-01 23:31:32.322060000 Z
', '2015-03-02 19:22:22.60475');
INSERT INTO versions VALUES (730, 'Person', 298, 'update', NULL, '---
id: 298
salutation: 
name: ''Rebeca ''
lastnames: ''Rivera ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 53
created_at: 2015-02-27 02:46:06.542945000 Z
updated_at: 2015-03-01 23:31:32.333809000 Z
', '2015-03-02 19:22:22.61048');
INSERT INTO versions VALUES (731, 'Person', 190, 'update', NULL, '---
id: 190
salutation: 
name: ''Joel ''
lastnames: ''Roldán Oquendo ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 83
created_at: 2015-02-24 14:26:26.019892000 Z
updated_at: 2015-03-01 23:31:33.001398000 Z
', '2015-03-02 19:22:22.616447');
INSERT INTO versions VALUES (732, 'Person', 294, 'update', NULL, '---
id: 294
salutation: 4
name: ''Nilda E. ''
lastnames: ''García ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 83
created_at: 2015-02-27 02:39:11.936961000 Z
updated_at: 2015-03-01 23:31:33.031646000 Z
', '2015-03-02 19:22:25.738539');
INSERT INTO versions VALUES (733, 'Person', 191, 'update', NULL, '---
id: 191
salutation: 
name: ''Raúl ''
lastnames: Matos Castilo
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 83
created_at: 2015-02-24 14:26:50.425779000 Z
updated_at: 2015-03-01 23:31:34.685088000 Z
', '2015-03-02 19:22:26.13143');
INSERT INTO versions VALUES (734, 'Person', 192, 'update', NULL, '---
id: 192
salutation: 0
name: ''Abigail ''
lastnames: Castro
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 19
created_at: 2015-02-24 14:28:11.784210000 Z
updated_at: 2015-03-01 23:31:34.775975000 Z
', '2015-03-02 19:22:26.678497');
INSERT INTO versions VALUES (735, 'Person', 306, 'create', NULL, NULL, '2015-03-02 19:22:26.875225');
INSERT INTO versions VALUES (736, 'Person', 277, 'update', NULL, '---
id: 277
salutation: 
name: ''Daniel ''
lastnames: ''Pérez Medina ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 19
created_at: 2015-02-25 13:25:23.919180000 Z
updated_at: 2015-03-01 23:31:34.793018000 Z
', '2015-03-02 19:22:27.138582');
INSERT INTO versions VALUES (737, 'Person', 194, 'update', NULL, '---
id: 194
salutation: 
name: ''Maria ''
lastnames: ''Charles ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 19
created_at: 2015-02-24 14:32:01.785633000 Z
updated_at: 2015-03-01 23:31:34.807168000 Z
', '2015-03-02 19:22:27.154679');
INSERT INTO versions VALUES (738, 'Person', 193, 'update', NULL, '---
id: 193
salutation: 
name: ''Nilda ''
lastnames: García
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 19
created_at: 2015-02-24 14:28:49.381875000 Z
updated_at: 2015-03-01 23:31:34.816822000 Z
', '2015-03-02 19:22:27.171047');
INSERT INTO versions VALUES (739, 'Person', 107, 'update', NULL, '---
id: 107
salutation: 0
name: Catalino
lastnames: ''Colón ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 87
created_at: 2015-02-24 02:32:59.759045000 Z
updated_at: 2015-03-01 23:31:34.826393000 Z
', '2015-03-02 19:22:30.81075');
INSERT INTO versions VALUES (740, 'Person', 108, 'update', NULL, '---
id: 108
salutation: 
name: ''Heriberto ''
lastnames: ''Del Valle ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 87
created_at: 2015-02-24 02:33:19.629444000 Z
updated_at: 2015-03-01 23:31:36.434781000 Z
', '2015-03-02 19:22:30.919349');
INSERT INTO versions VALUES (741, 'Person', 109, 'update', NULL, '---
id: 109
salutation: 
name: ''Vacilio ''
lastnames: ''Del Valle ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 87
created_at: 2015-02-24 02:33:49.139829000 Z
updated_at: 2015-03-01 23:31:36.520586000 Z
', '2015-03-02 19:22:32.316945');
INSERT INTO versions VALUES (742, 'Person', 110, 'update', NULL, '---
id: 110
salutation: 
name: ''Wanda ''
lastnames: ''Acevedo ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 87
created_at: 2015-02-24 02:34:06.462161000 Z
updated_at: 2015-03-01 23:31:36.540427000 Z
', '2015-03-02 19:22:32.328951');
INSERT INTO versions VALUES (743, 'Person', 265, 'update', NULL, '---
id: 265
salutation: 
name: ''Angel M. ''
lastnames: García
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 15:40:47.634235000 Z
updated_at: 2015-03-01 23:31:36.550681000 Z
', '2015-03-02 19:22:32.339292');
INSERT INTO versions VALUES (744, 'Person', 198, 'update', NULL, '---
id: 198
salutation: 
name: ''Antonio ''
lastnames: Freire
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 14:36:33.922822000 Z
updated_at: 2015-03-01 23:31:36.559092000 Z
', '2015-03-02 19:22:32.348138');
INSERT INTO versions VALUES (745, 'Person', 195, 'update', NULL, '---
id: 195
salutation: 
name: ''Arelys ''
lastnames: Ortiz
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 14:34:57.882413000 Z
updated_at: 2015-03-01 23:31:36.567587000 Z
', '2015-03-02 19:22:35.546131');
INSERT INTO versions VALUES (746, 'Person', 197, 'update', NULL, '---
id: 197
salutation: 
name: ''Daisy ''
lastnames: García
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 14:36:01.266279000 Z
updated_at: 2015-03-01 23:31:38.170901000 Z
', '2015-03-02 19:22:35.656386');
INSERT INTO versions VALUES (747, 'Person', 199, 'update', NULL, '---
id: 199
salutation: 
name: ''David ''
lastnames: ''Morales ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 14:36:58.831092000 Z
updated_at: 2015-03-01 23:31:38.253949000 Z
', '2015-03-02 19:22:35.66099');
INSERT INTO versions VALUES (748, 'Person', 266, 'update', NULL, '---
id: 266
salutation: 
name: ''Deliris ''
lastnames: ''Carrión ''
sex: false
role: 5
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 15:41:10.184324000 Z
updated_at: 2015-03-01 23:31:38.271805000 Z
', '2015-03-02 19:22:35.665967');
INSERT INTO versions VALUES (749, 'Person', 196, 'update', NULL, '---
id: 196
salutation: 
name: ''Jossie ''
lastnames: Sostre
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 14:35:32.238243000 Z
updated_at: 2015-03-01 23:31:38.286096000 Z
', '2015-03-02 19:22:35.67094');
INSERT INTO versions VALUES (750, 'Person', 200, 'update', NULL, '---
id: 200
salutation: 
name: ''Minerva ''
lastnames: Rivera
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 14:37:42.741944000 Z
updated_at: 2015-03-01 23:31:38.296951000 Z
', '2015-03-02 19:22:35.676917');
INSERT INTO versions VALUES (751, 'Person', 114, 'update', NULL, '---
id: 114
salutation: 
name: ''Carmen ''
lastnames: ''Leduc ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 60
created_at: 2015-02-24 02:35:59.457418000 Z
updated_at: 2015-03-01 23:31:38.306911000 Z
', '2015-03-02 19:22:38.926155');
INSERT INTO versions VALUES (752, 'Person', 117, 'update', NULL, '---
id: 117
salutation: 
name: ''Carmen L. ''
lastnames: ''Santos ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 60
created_at: 2015-02-24 02:37:12.731568000 Z
updated_at: 2015-03-01 23:31:39.926027000 Z
', '2015-03-02 19:22:39.116753');
INSERT INTO versions VALUES (753, 'Person', 116, 'update', NULL, '---
id: 116
salutation: 
name: ''Daniel ''
lastnames: ''Cardona ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 60
created_at: 2015-02-24 02:36:47.171359000 Z
updated_at: 2015-03-01 23:31:40.601611000 Z
', '2015-03-02 19:22:39.13336');
INSERT INTO versions VALUES (754, 'Person', 111, 'update', NULL, '---
id: 111
salutation: 1
name: ''Edwin ''
lastnames: ''Mojica ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 60
created_at: 2015-02-24 02:34:40.419461000 Z
updated_at: 2015-03-01 23:31:40.619007000 Z
', '2015-03-02 19:22:39.141822');
INSERT INTO versions VALUES (755, 'Person', 115, 'update', NULL, '---
id: 115
salutation: 
name: ''Jossie ''
lastnames: ''Cardona ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 60
created_at: 2015-02-24 02:36:19.732517000 Z
updated_at: 2015-03-01 23:31:40.633323000 Z
', '2015-03-02 19:22:39.148261');
INSERT INTO versions VALUES (756, 'Person', 113, 'update', NULL, '---
id: 113
salutation: 
name: ''Maria de los A. ''
lastnames: Rolón
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 60
created_at: 2015-02-24 02:35:37.036285000 Z
updated_at: 2015-03-01 23:31:40.648437000 Z
', '2015-03-02 19:22:39.155205');
INSERT INTO versions VALUES (757, 'Person', 112, 'update', NULL, '---
id: 112
salutation: 1
name: ''Norma I. ''
lastnames: ''Torres ''
sex: false
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 60
created_at: 2015-02-24 02:35:11.391098000 Z
updated_at: 2015-03-01 23:31:40.662666000 Z
', '2015-03-02 19:22:42.560551');
INSERT INTO versions VALUES (758, 'Person', 118, 'update', NULL, '---
id: 118
salutation: 
name: ''Wilda ''
lastnames: ''Lugo ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 60
created_at: 2015-02-24 02:37:32.520058000 Z
updated_at: 2015-02-24 02:37:32.520058000 Z
', '2015-03-02 19:22:42.625909');
INSERT INTO versions VALUES (759, 'Person', 283, 'update', NULL, '---
id: 283
salutation: 
name: ''Danirys ''
lastnames: ''Sánchez ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 118
created_at: 2015-02-25 14:48:04.168582000 Z
updated_at: 2015-02-25 14:48:04.168582000 Z
', '2015-03-02 19:22:42.631269');
INSERT INTO versions VALUES (760, 'Person', 96, 'update', NULL, '---
id: 96
salutation: 
name: Joanne
lastnames: ''Carrillo ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 59
created_at: 2015-02-24 02:25:30.268758000 Z
updated_at: 2015-02-24 02:25:30.268758000 Z
', '2015-03-02 19:22:42.635765');
INSERT INTO versions VALUES (761, 'Person', 95, 'update', NULL, '---
id: 95
salutation: 
name: ''Maribel ''
lastnames: ''González ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 59
created_at: 2015-02-24 02:25:06.878867000 Z
updated_at: 2015-02-24 02:25:06.878867000 Z
', '2015-03-02 19:22:42.640584');
INSERT INTO versions VALUES (762, 'Person', 94, 'update', NULL, '---
id: 94
salutation: 0
name: ''Mario ''
lastnames: ''Rodas ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 59
created_at: 2015-02-24 02:24:44.088983000 Z
updated_at: 2015-02-24 02:24:44.088983000 Z
', '2015-03-02 19:22:42.645962');
INSERT INTO versions VALUES (763, 'Person', 76, 'update', NULL, '---
id: 76
salutation: 3
name: ''Alfredo ''
lastnames: ''Méndez ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 64
created_at: 2015-02-24 02:11:21.043451000 Z
updated_at: 2015-02-24 02:11:21.043451000 Z
', '2015-03-02 19:22:45.787871');
INSERT INTO versions VALUES (764, 'Person', 77, 'update', NULL, '---
id: 77
salutation: 
name: ''Lorenzo A. ''
lastnames: ''Fuentes ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 64
created_at: 2015-02-24 02:11:56.858646000 Z
updated_at: 2015-02-24 02:11:56.858646000 Z
', '2015-03-02 19:22:45.994114');
INSERT INTO versions VALUES (765, 'Person', 201, 'update', NULL, '---
id: 201
salutation: 0
name: ''Susana ''
lastnames: ''Rivera ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 67
created_at: 2015-02-24 14:39:41.628178000 Z
updated_at: 2015-02-24 14:39:41.628178000 Z
', '2015-03-02 19:22:47.467271');
INSERT INTO versions VALUES (766, 'Person', 172, 'update', NULL, '---
id: 172
salutation: 
name: Cecilio
lastnames: Rivera
sex: true
role: 3
description: Sustituto
attended: false
printed: false
materials: false
church_id: 20
created_at: 2015-02-24 13:58:26.021753000 Z
updated_at: 2015-02-24 13:58:26.021753000 Z
', '2015-03-02 19:22:47.483223');
INSERT INTO versions VALUES (767, 'Person', 167, 'update', NULL, '---
id: 167
salutation: 
name: ''Francisco ''
lastnames: ''Medina ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 20
created_at: 2015-02-24 13:54:46.987425000 Z
updated_at: 2015-02-24 13:54:46.987425000 Z
', '2015-03-02 19:22:47.493751');
INSERT INTO versions VALUES (768, 'Person', 168, 'update', NULL, '---
id: 168
salutation: 
name: ''Lilliana ''
lastnames: Landrón
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 20
created_at: 2015-02-24 13:55:10.762190000 Z
updated_at: 2015-02-24 13:55:10.762190000 Z
', '2015-03-02 19:22:47.503465');
INSERT INTO versions VALUES (769, 'Person', 170, 'update', NULL, '---
id: 170
salutation: 
name: ''Nilsa ''
lastnames: Muñoz
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 20
created_at: 2015-02-24 13:55:46.930581000 Z
updated_at: 2015-02-24 13:55:46.930581000 Z
', '2015-03-02 19:22:50.792314');
INSERT INTO versions VALUES (770, 'Person', 166, 'update', NULL, '---
id: 166
salutation: 0
name: Pedro
lastnames: González
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 20
created_at: 2015-02-24 13:52:46.225562000 Z
updated_at: 2015-02-24 13:52:46.225562000 Z
', '2015-03-02 19:22:51.212917');
INSERT INTO versions VALUES (771, 'Person', 171, 'update', NULL, '---
id: 171
salutation: 
name: Rebeca
lastnames: Castro
sex: false
role: 3
description: Sustituto
attended: false
printed: false
materials: false
church_id: 20
created_at: 2015-02-24 13:56:21.984322000 Z
updated_at: 2015-02-24 13:56:21.984322000 Z
', '2015-03-02 19:22:52.364662');
INSERT INTO versions VALUES (772, 'Person', 169, 'update', NULL, '---
id: 169
salutation: 
name: ''Sonia ''
lastnames: Lugo
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 20
created_at: 2015-02-24 13:55:28.176248000 Z
updated_at: 2015-02-24 13:55:28.176248000 Z
', '2015-03-02 19:22:52.377409');
INSERT INTO versions VALUES (773, 'Person', 287, 'update', NULL, '---
id: 287
salutation: 1
name: ''Efraín ''
lastnames: ''Rosario ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 27
created_at: 2015-02-27 02:29:25.417229000 Z
updated_at: 2015-02-27 02:29:25.417229000 Z
', '2015-03-02 19:22:52.38642');
INSERT INTO versions VALUES (774, 'Person', 288, 'update', NULL, '---
id: 288
salutation: 
name: ''Rosa ''
lastnames: ''Capellán ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 27
created_at: 2015-02-27 02:30:14.499799000 Z
updated_at: 2015-02-27 02:30:14.499799000 Z
', '2015-03-02 19:22:52.395303');
INSERT INTO versions VALUES (775, 'Person', 126, 'update', NULL, '---
id: 126
salutation: 
name: ''Abner E. ''
lastnames: ''Cotto ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 56
created_at: 2015-02-24 02:42:55.836961000 Z
updated_at: 2015-02-24 02:42:55.836961000 Z
', '2015-03-02 19:22:55.512603');
INSERT INTO versions VALUES (776, 'Person', 122, 'update', NULL, '---
id: 122
salutation: 0
name: ''Alberto J. ''
lastnames: ''Díaz ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 56
created_at: 2015-02-24 02:40:50.078129000 Z
updated_at: 2015-02-24 02:40:50.078129000 Z
', '2015-03-02 19:22:55.683268');
INSERT INTO versions VALUES (777, 'Person', 125, 'update', NULL, '---
id: 125
salutation: 
name: ''Félix J. ''
lastnames: ''Colón ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 56
created_at: 2015-02-24 02:42:20.495190000 Z
updated_at: 2015-02-24 02:42:20.495190000 Z
', '2015-03-02 19:22:56.082244');
INSERT INTO versions VALUES (778, 'Person', 124, 'update', NULL, '---
id: 124
salutation: 
name: ''Lilybeth ''
lastnames: Bosch
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 56
created_at: 2015-02-24 02:41:48.368594000 Z
updated_at: 2015-02-24 02:41:48.368594000 Z
', '2015-03-02 19:22:56.097335');
INSERT INTO versions VALUES (779, 'Person', 123, 'update', NULL, '---
id: 123
salutation: 4
name: ''Sonia ''
lastnames: Villodas
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 56
created_at: 2015-02-24 02:41:19.738212000 Z
updated_at: 2015-02-24 02:41:19.738212000 Z
', '2015-03-02 19:22:56.105333');
INSERT INTO versions VALUES (780, 'Person', 240, 'update', NULL, '---
id: 240
salutation: 
name: ''Priscilla ''
lastnames: Esteves Ponde de León
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 71
created_at: 2015-02-24 15:11:09.635891000 Z
updated_at: 2015-02-24 15:11:09.635891000 Z
', '2015-03-02 19:22:56.111788');
INSERT INTO versions VALUES (781, 'Person', 239, 'update', NULL, '---
id: 239
salutation: 
name: ''Robert ''
lastnames: Quintero Negrón
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 71
created_at: 2015-02-24 15:10:43.116616000 Z
updated_at: 2015-02-24 15:10:43.116616000 Z
', '2015-03-02 19:22:59.238003');
INSERT INTO versions VALUES (782, 'Person', 202, 'update', NULL, '---
id: 202
salutation: 1
name: Aniceto
lastnames: Sustache
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 66
created_at: 2015-02-24 14:41:07.887430000 Z
updated_at: 2015-02-24 14:41:07.887430000 Z
', '2015-03-02 19:22:59.323733');
INSERT INTO versions VALUES (783, 'Person', 204, 'update', NULL, '---
id: 204
salutation: 
name: ''Iris ''
lastnames: ''Colon Padilla ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 66
created_at: 2015-02-24 14:42:04.139904000 Z
updated_at: 2015-02-24 14:42:04.139904000 Z
', '2015-03-02 19:22:59.338185');
INSERT INTO versions VALUES (784, 'Person', 203, 'update', NULL, '---
id: 203
salutation: 
name: ''Maria ''
lastnames: ''Quiñones ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 66
created_at: 2015-02-24 14:41:40.761442000 Z
updated_at: 2015-02-24 14:41:40.761442000 Z
', '2015-03-02 19:22:59.345661');
INSERT INTO versions VALUES (785, 'Person', 284, 'update', NULL, '---
id: 284
salutation: 6
name: ''Daniel ''
lastnames: Santos
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 120
created_at: 2015-02-25 14:49:00.280008000 Z
updated_at: 2015-02-25 14:49:00.280008000 Z
', '2015-03-02 19:22:59.351852');
INSERT INTO versions VALUES (786, 'Person', 285, 'update', NULL, '---
id: 285
salutation: 
name: ''Awilda ''
lastnames: Bonilla
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 122
created_at: 2015-02-25 14:49:25.742138000 Z
updated_at: 2015-02-25 14:49:25.742138000 Z
', '2015-03-02 19:22:59.359356');
INSERT INTO versions VALUES (787, 'Person', 286, 'update', NULL, '---
id: 286
salutation: 2
name: ''Alejandrina ''
lastnames: ''Ortiz ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 119
created_at: 2015-02-25 14:50:38.256213000 Z
updated_at: 2015-02-25 14:50:38.256213000 Z
', '2015-03-02 19:23:03.246883');
INSERT INTO versions VALUES (788, 'Person', 129, 'update', NULL, '---
id: 129
salutation: 
name: ''Carmen D. ''
lastnames: ''Hernández ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 124
created_at: 2015-02-24 02:46:39.451325000 Z
updated_at: 2015-02-24 02:46:39.451325000 Z
', '2015-03-02 19:23:03.352737');
INSERT INTO versions VALUES (789, 'Person', 127, 'update', NULL, '---
id: 127
salutation: 0
name: ''Gladys ''
lastnames: ''Morales ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 124
created_at: 2015-02-24 02:45:36.537569000 Z
updated_at: 2015-02-24 02:45:36.537569000 Z
', '2015-03-02 19:23:03.36229');
INSERT INTO versions VALUES (790, 'Person', 128, 'update', NULL, '---
id: 128
salutation: 
name: ''Margarita ''
lastnames: ''Chico ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 124
created_at: 2015-02-24 02:46:03.776806000 Z
updated_at: 2015-02-24 02:46:03.776806000 Z
', '2015-03-02 19:23:03.367921');
INSERT INTO versions VALUES (791, 'Person', 289, 'update', NULL, '---
id: 289
salutation: 1
name: ''Angel L. ''
lastnames: Pabellón
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 75
created_at: 2015-02-27 02:34:55.182295000 Z
updated_at: 2015-02-27 02:34:55.182295000 Z
', '2015-03-02 19:23:03.372879');
INSERT INTO versions VALUES (792, 'Person', 291, 'update', NULL, '---
id: 291
salutation: 
name: ''Julio ''
lastnames: Cintrón
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 75
created_at: 2015-02-27 02:36:13.132308000 Z
updated_at: 2015-02-27 02:36:13.132308000 Z
', '2015-03-02 19:23:03.377649');
INSERT INTO versions VALUES (793, 'Person', 290, 'update', NULL, '---
id: 290
salutation: 
name: María D.
lastnames: ''Nuñez ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 75
created_at: 2015-02-27 02:35:45.393998000 Z
updated_at: 2015-02-27 02:35:45.393998000 Z
', '2015-03-02 19:23:06.747826');
INSERT INTO versions VALUES (794, 'Person', 208, 'update', NULL, '---
id: 208
salutation: 
name: ''Anita ''
lastnames: González
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 84
created_at: 2015-02-24 14:43:53.101388000 Z
updated_at: 2015-02-24 14:43:53.101388000 Z
', '2015-03-02 19:23:07.134255');
INSERT INTO versions VALUES (795, 'Person', 214, 'update', NULL, '---
id: 214
salutation: 
name: ''Antonia ''
lastnames: ''Urbina ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 84
created_at: 2015-02-24 14:46:22.778430000 Z
updated_at: 2015-02-24 14:46:22.778430000 Z
', '2015-03-02 19:23:07.139169');
INSERT INTO versions VALUES (796, 'Person', 213, 'update', NULL, '---
id: 213
salutation: 
name: ''Emma ''
lastnames: Figueroa Agosto
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 84
created_at: 2015-02-24 14:46:01.725059000 Z
updated_at: 2015-02-24 14:46:01.725059000 Z
', '2015-03-02 19:23:07.143518');
INSERT INTO versions VALUES (797, 'Person', 211, 'update', NULL, '---
id: 211
salutation: 
name: Glorielis
lastnames: ''Flores Rodriguez ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 84
created_at: 2015-02-24 14:45:14.699725000 Z
updated_at: 2015-02-24 14:45:14.699725000 Z
', '2015-03-02 19:23:07.147961');
INSERT INTO versions VALUES (798, 'Person', 210, 'update', NULL, '---
id: 210
salutation: 
name: ''Ismael ''
lastnames: González
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 84
created_at: 2015-02-24 14:44:40.125466000 Z
updated_at: 2015-02-24 14:44:40.125466000 Z
', '2015-03-02 19:23:07.152382');
INSERT INTO versions VALUES (799, 'Person', 216, 'update', NULL, '---
id: 216
salutation: 1
name: ''Jose ''
lastnames: Calo Castro
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 84
created_at: 2015-02-24 14:46:58.269313000 Z
updated_at: 2015-02-24 14:46:58.269313000 Z
', '2015-03-02 19:23:10.293042');
INSERT INTO versions VALUES (800, 'Person', 205, 'update', NULL, '---
id: 205
salutation: 1
name: Luz E.
lastnames: Rodríguez
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 84
created_at: 2015-02-24 14:42:43.920366000 Z
updated_at: 2015-02-24 14:47:16.099342000 Z
', '2015-03-02 19:23:10.29887');
INSERT INTO versions VALUES (801, 'Person', 212, 'update', NULL, '---
id: 212
salutation: 
name: María del C.
lastnames: Lanzo
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 84
created_at: 2015-02-24 14:45:35.727958000 Z
updated_at: 2015-02-24 14:45:35.727958000 Z
', '2015-03-02 19:23:10.303754');
INSERT INTO versions VALUES (802, 'Person', 207, 'update', NULL, '---
id: 207
salutation: 
name: ''Migdalia ''
lastnames: Quiñones Pizarro
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 84
created_at: 2015-02-24 14:43:36.159235000 Z
updated_at: 2015-02-24 14:43:36.159235000 Z
', '2015-03-02 19:23:10.308111');
INSERT INTO versions VALUES (803, 'Person', 206, 'update', NULL, '---
id: 206
salutation: 
name: ''Nilsa L. ''
lastnames: Torres Correa
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 84
created_at: 2015-02-24 14:43:11.479270000 Z
updated_at: 2015-02-24 14:43:11.479270000 Z
', '2015-03-02 19:23:10.312726');
INSERT INTO versions VALUES (804, 'Person', 215, 'update', NULL, '---
id: 215
salutation: 
name: ''Pedro ''
lastnames: ''Carrasquillo ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 84
created_at: 2015-02-24 14:46:39.863971000 Z
updated_at: 2015-02-24 14:46:39.863971000 Z
', '2015-03-02 19:23:10.316642');
INSERT INTO versions VALUES (805, 'Person', 209, 'update', NULL, '---
id: 209
salutation: 
name: ''Víctor ''
lastnames: Valentín
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 84
created_at: 2015-02-24 14:44:22.637707000 Z
updated_at: 2015-02-24 14:44:22.637707000 Z
', '2015-03-02 19:23:13.655033');
INSERT INTO versions VALUES (806, 'Person', 217, 'update', NULL, '---
id: 217
salutation: 0
name: Abraham
lastnames: ''Morales ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 21
created_at: 2015-02-24 14:51:21.886829000 Z
updated_at: 2015-02-24 14:51:21.886829000 Z
', '2015-03-02 19:23:13.836624');
INSERT INTO versions VALUES (807, 'Person', 218, 'update', NULL, '---
id: 218
salutation: 
name: ''Johnny ''
lastnames: Rivera
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 21
created_at: 2015-02-24 14:51:45.799248000 Z
updated_at: 2015-02-24 14:51:45.799248000 Z
', '2015-03-02 19:23:13.853995');
INSERT INTO versions VALUES (808, 'Person', 219, 'update', NULL, '---
id: 219
salutation: 
name: ''Oscar ''
lastnames: Santiago
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 21
created_at: 2015-02-24 14:51:58.885631000 Z
updated_at: 2015-02-24 14:51:58.885631000 Z
', '2015-03-02 19:23:13.867164');
INSERT INTO versions VALUES (809, 'Person', 244, 'update', NULL, '---
id: 244
salutation: 
name: ''Delma ''
lastnames: Lananze
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 76
created_at: 2015-02-24 15:13:38.480586000 Z
updated_at: 2015-02-24 15:13:38.480586000 Z
', '2015-03-02 19:23:13.873407');
INSERT INTO versions VALUES (810, 'Person', 241, 'update', NULL, '---
id: 241
salutation: 1
name: ''Magda ''
lastnames: Aguirre
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 76
created_at: 2015-02-24 15:12:09.346928000 Z
updated_at: 2015-02-24 15:12:09.346928000 Z
', '2015-03-02 19:23:13.87982');
INSERT INTO versions VALUES (811, 'Person', 242, 'update', NULL, '---
id: 242
salutation: 
name: ''Maribel ''
lastnames: Colón
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 76
created_at: 2015-02-24 15:12:49.333038000 Z
updated_at: 2015-02-24 15:12:49.333038000 Z
', '2015-03-02 19:23:17.038048');
INSERT INTO versions VALUES (812, 'Person', 243, 'update', NULL, '---
id: 243
salutation: 
name: ''Minerva ''
lastnames: ''Costa ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 76
created_at: 2015-02-24 15:13:14.962885000 Z
updated_at: 2015-02-24 15:13:14.962885000 Z
', '2015-03-02 19:23:18.43669');
INSERT INTO versions VALUES (813, 'Person', 35, 'update', NULL, '---
id: 35
salutation: 
name: ''Carlos ''
lastnames: ''Maldonado ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 107
created_at: 2015-02-24 01:44:21.294952000 Z
updated_at: 2015-02-24 01:44:21.294952000 Z
', '2015-03-02 19:23:18.456197');
INSERT INTO versions VALUES (814, 'Person', 37, 'update', NULL, '---
id: 37
salutation: 
name: ''Fernando ''
lastnames: ''Toro ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 107
created_at: 2015-02-24 01:45:18.350020000 Z
updated_at: 2015-02-24 01:45:18.350020000 Z
', '2015-03-02 19:23:18.462932');
INSERT INTO versions VALUES (815, 'Person', 34, 'update', NULL, '---
id: 34
salutation: 1
name: ''Heriberto ''
lastnames: ''Muñoz ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 107
created_at: 2015-02-24 01:43:56.325452000 Z
updated_at: 2015-02-24 01:43:56.325452000 Z
', '2015-03-02 19:23:18.471039');
INSERT INTO versions VALUES (816, 'Person', 39, 'update', NULL, '---
id: 39
salutation: 
name: ''José ''
lastnames: ''Armenteros ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 107
created_at: 2015-02-24 01:46:09.753433000 Z
updated_at: 2015-02-24 01:46:09.753433000 Z
', '2015-03-02 19:23:18.477879');
INSERT INTO versions VALUES (817, 'Person', 40, 'update', NULL, '---
id: 40
salutation: 
name: ''Margarita ''
lastnames: Fígaro
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 107
created_at: 2015-02-24 01:46:45.493396000 Z
updated_at: 2015-02-24 01:46:45.493396000 Z
', '2015-03-02 19:23:21.653762');
INSERT INTO versions VALUES (818, 'Person', 38, 'update', NULL, '---
id: 38
salutation: 
name: ''María de los A. ''
lastnames: ''Torres ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 107
created_at: 2015-02-24 01:45:45.277971000 Z
updated_at: 2015-02-24 01:45:45.277971000 Z
', '2015-03-02 19:23:22.454697');
INSERT INTO versions VALUES (819, 'Person', 36, 'update', NULL, '---
id: 36
salutation: 
name: ''Vivian ''
lastnames: Pagán
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 107
created_at: 2015-02-24 01:44:56.280726000 Z
updated_at: 2015-02-24 01:44:56.280726000 Z
', '2015-03-02 19:23:22.475209');
INSERT INTO versions VALUES (820, 'Person', 271, 'update', NULL, '---
id: 271
salutation: 
name: ''Eddie ''
lastnames: Diaz
sex: true
role: 4
description: ''''
attended: false
printed: false
materials: false
church_id: 108
created_at: 2015-02-24 17:43:15.014054000 Z
updated_at: 2015-02-24 17:43:15.014054000 Z
', '2015-03-02 19:23:22.4846');
INSERT INTO versions VALUES (821, 'Person', 3, 'update', NULL, '---
id: 3
salutation: 
name: José
lastnames: ''Tejeda ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 108
created_at: 2015-02-23 22:23:11.598545000 Z
updated_at: 2015-02-23 22:23:11.598545000 Z
', '2015-03-02 19:23:22.491311');
INSERT INTO versions VALUES (822, 'Person', 4, 'update', NULL, '---
id: 4
salutation: 
name: ''Luis ''
lastnames: ''Vázquez ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 108
created_at: 2015-02-23 22:23:49.805825000 Z
updated_at: 2015-02-23 22:23:49.805825000 Z
', '2015-03-02 19:23:22.49915');
INSERT INTO versions VALUES (823, 'Person', 5, 'update', NULL, '---
id: 5
salutation: 
name: ''Mary ''
lastnames: ''Vázquez ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 108
created_at: 2015-02-23 22:24:15.398515000 Z
updated_at: 2015-02-23 22:24:15.398515000 Z
', '2015-03-02 19:23:25.631939');
INSERT INTO versions VALUES (824, 'Person', 1, 'update', NULL, '---
id: 1
salutation: 1
name: ''Roy ''
lastnames: ''Acosta ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 108
created_at: 2015-02-23 22:21:49.889093000 Z
updated_at: 2015-02-23 22:21:49.889093000 Z
', '2015-03-02 19:23:25.707362');
INSERT INTO versions VALUES (825, 'Person', 2, 'update', NULL, '---
id: 2
salutation: 
name: ''Susano ''
lastnames: ''Luzunaris ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 108
created_at: 2015-02-23 22:22:37.697968000 Z
updated_at: 2015-02-24 17:44:05.226801000 Z
', '2015-03-02 19:23:25.722655');
INSERT INTO versions VALUES (826, 'Person', 131, 'update', NULL, '---
id: 131
salutation: 0
name: ''Glenda L. ''
lastnames: ''De León ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 65
created_at: 2015-02-24 02:48:14.616949000 Z
updated_at: 2015-02-24 02:48:14.616949000 Z
', '2015-03-02 19:23:25.731664');
INSERT INTO versions VALUES (827, 'Person', 133, 'update', NULL, '---
id: 133
salutation: 
name: ''Lizvette ''
lastnames: ''Rodríguez ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 65
created_at: 2015-02-24 02:49:09.238478000 Z
updated_at: 2015-02-24 02:49:09.238478000 Z
', '2015-03-02 19:23:25.738174');
INSERT INTO versions VALUES (828, 'Person', 132, 'update', NULL, '---
id: 132
salutation: 
name: ''Marisabel ''
lastnames: ''Beltrán ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 65
created_at: 2015-02-24 02:48:45.523712000 Z
updated_at: 2015-02-24 02:48:45.523712000 Z
', '2015-03-02 19:23:25.745261');
INSERT INTO versions VALUES (829, 'Person', 130, 'update', NULL, '---
id: 130
salutation: 0
name: ''Ulbencio ''
lastnames: ''Rivera ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 65
created_at: 2015-02-24 02:47:50.485002000 Z
updated_at: 2015-02-24 02:47:50.485002000 Z
', '2015-03-02 19:23:28.882032');
INSERT INTO versions VALUES (830, 'Person', 302, 'update', NULL, '---
id: 302
salutation: 
name: ''Ana ''
lastnames: ''Diaz ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 85
created_at: 2015-03-02 19:18:55.910737000 Z
updated_at: 2015-03-02 19:18:55.910737000 Z
', '2015-03-02 19:23:29.035479');
INSERT INTO versions VALUES (831, 'Person', 304, 'update', NULL, '---
id: 304
salutation: 
name: ''Judith ''
lastnames: Castro
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 85
created_at: 2015-03-02 19:19:39.726530000 Z
updated_at: 2015-03-02 19:19:39.726530000 Z
', '2015-03-02 19:23:29.476126');
INSERT INTO versions VALUES (832, 'Person', 303, 'update', NULL, '---
id: 303
salutation: 
name: ''Mayra ''
lastnames: ''Rivera ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 85
created_at: 2015-03-02 19:19:17.181209000 Z
updated_at: 2015-03-02 19:19:17.181209000 Z
', '2015-03-02 19:23:29.493018');
INSERT INTO versions VALUES (833, 'Person', 300, 'update', NULL, '---
id: 300
salutation: 1
name: ''Miguel ''
lastnames: ''Acosta ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 85
created_at: 2015-03-02 19:17:29.658572000 Z
updated_at: 2015-03-02 19:17:29.658572000 Z
', '2015-03-02 19:23:29.504552');
INSERT INTO versions VALUES (834, 'Person', 301, 'update', NULL, '---
id: 301
salutation: 
name: ''Sonia ''
lastnames: ''Nieves ''
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 85
created_at: 2015-03-02 19:18:34.403674000 Z
updated_at: 2015-03-02 19:18:34.403674000 Z
', '2015-03-02 19:23:29.511954');
INSERT INTO versions VALUES (835, 'Person', 26, 'update', NULL, '---
id: 26
salutation: 
name: ''José D. ''
lastnames: Colón
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 109
created_at: 2015-02-24 01:29:09.930154000 Z
updated_at: 2015-02-24 01:29:09.930154000 Z
', '2015-03-02 19:23:32.67016');
INSERT INTO versions VALUES (836, 'Person', 23, 'update', NULL, '---
id: 23
salutation: 
name: Juan C.
lastnames: ''Rivera ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 109
created_at: 2015-02-24 01:27:43.735306000 Z
updated_at: 2015-02-24 01:30:11.045020000 Z
', '2015-03-02 19:23:33.197993');
INSERT INTO versions VALUES (837, 'Person', 22, 'update', NULL, '---
id: 22
salutation: 0
name: ''Laura ''
lastnames: ''Ayala ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 109
created_at: 2015-02-24 01:27:13.149274000 Z
updated_at: 2015-02-24 01:27:13.149274000 Z
', '2015-03-02 19:23:33.21463');
INSERT INTO versions VALUES (838, 'Person', 24, 'update', NULL, '---
id: 24
salutation: 
name: Nubia G.
lastnames: ''Santos ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 109
created_at: 2015-02-24 01:28:09.897945000 Z
updated_at: 2015-02-24 01:28:09.897945000 Z
', '2015-03-02 19:23:33.226675');
INSERT INTO versions VALUES (839, 'Person', 25, 'update', NULL, '---
id: 25
salutation: 
name: ''Zoraida ''
lastnames: ''Derieux ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 109
created_at: 2015-02-24 01:28:40.668004000 Z
updated_at: 2015-02-24 01:28:40.668004000 Z
', '2015-03-02 19:23:33.233339');
INSERT INTO versions VALUES (840, 'Person', 42, 'update', NULL, '---
id: 42
salutation: 
name: ''Angel ''
lastnames: ''Torres ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 110
created_at: 2015-02-24 01:49:43.059036000 Z
updated_at: 2015-02-24 01:49:43.059036000 Z
', '2015-03-02 19:23:33.240064');
INSERT INTO versions VALUES (841, 'Person', 41, 'update', NULL, '---
id: 41
salutation: 1
name: ''Joel ''
lastnames: ''Velázquez ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 110
created_at: 2015-02-24 01:49:18.955261000 Z
updated_at: 2015-02-24 01:49:18.955261000 Z
', '2015-03-02 19:23:36.787114');
INSERT INTO versions VALUES (842, 'Person', 43, 'update', NULL, '---
id: 43
salutation: 
name: ''Luciano ''
lastnames: ''Ortiz ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 110
created_at: 2015-02-24 01:50:05.172259000 Z
updated_at: 2015-02-24 01:50:05.172259000 Z
', '2015-03-02 19:23:38.06639');
INSERT INTO versions VALUES (843, 'Person', 275, 'update', NULL, '---
id: 275
salutation: 
name: ''Diana ''
lastnames: Alomar
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 32
created_at: 2015-02-25 13:23:22.911890000 Z
updated_at: 2015-02-25 13:23:22.911890000 Z
', '2015-03-02 19:23:38.084612');
INSERT INTO versions VALUES (844, 'Person', 276, 'update', NULL, '---
id: 276
salutation: 
name: Efraín
lastnames: ''Dávila ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 32
created_at: 2015-02-25 13:23:47.195972000 Z
updated_at: 2015-02-25 13:23:47.195972000 Z
', '2015-03-02 19:23:38.092506');
INSERT INTO versions VALUES (845, 'Person', 274, 'update', NULL, '---
id: 274
salutation: 
name: ''María ''
lastnames: Benitez
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 32
created_at: 2015-02-25 13:22:58.907116000 Z
updated_at: 2015-02-25 13:22:58.907116000 Z
', '2015-03-02 19:23:38.098602');
INSERT INTO versions VALUES (846, 'Person', 273, 'update', NULL, '---
id: 273
salutation: 0
name: ''Rolando ''
lastnames: ''Pabellón ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 32
created_at: 2015-02-25 13:22:35.132459000 Z
updated_at: 2015-02-25 13:22:35.132459000 Z
', '2015-03-02 19:23:38.105199');
INSERT INTO versions VALUES (847, 'Person', 46, 'update', NULL, '---
id: 46
salutation: 
name: ''Amelia ''
lastnames: Colón
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 112
created_at: 2015-02-24 01:51:58.622180000 Z
updated_at: 2015-02-24 01:51:58.622180000 Z
', '2015-03-02 19:23:41.240917');
INSERT INTO versions VALUES (848, 'Person', 47, 'update', NULL, '---
id: 47
salutation: 
name: ''Ana Petra ''
lastnames: ''Félix ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 112
created_at: 2015-02-24 01:52:30.066319000 Z
updated_at: 2015-02-24 01:52:30.066319000 Z
', '2015-03-02 19:23:41.361503');
INSERT INTO versions VALUES (849, 'Person', 44, 'update', NULL, '---
id: 44
salutation: 0
name: ''Carlos J. ''
lastnames: ''Montalvo ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 112
created_at: 2015-02-24 01:51:09.641324000 Z
updated_at: 2015-02-24 01:51:09.641324000 Z
', '2015-03-02 19:23:41.366701');
INSERT INTO versions VALUES (850, 'Person', 45, 'update', NULL, '---
id: 45
salutation: 
name: ''Leticia ''
lastnames: ''Santaella ''
sex: false
role: 4
description: ''''
attended: false
printed: false
materials: false
church_id: 112
created_at: 2015-02-24 01:51:34.052136000 Z
updated_at: 2015-02-24 01:51:34.052136000 Z
', '2015-03-02 19:23:41.371032');
INSERT INTO versions VALUES (851, 'Person', 220, 'update', NULL, '---
id: 220
salutation: 0
name: ''Elsa ''
lastnames: ''Rivera Martínez ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 68
created_at: 2015-02-24 14:54:01.686913000 Z
updated_at: 2015-02-24 14:54:01.686913000 Z
', '2015-03-02 19:23:41.376739');
INSERT INTO versions VALUES (852, 'Person', 221, 'update', NULL, '---
id: 221
salutation: 
name: ''Lained ''
lastnames: ''Bonano ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 68
created_at: 2015-02-24 14:55:06.388086000 Z
updated_at: 2015-02-24 14:55:06.388086000 Z
', '2015-03-02 19:23:41.381726');
INSERT INTO versions VALUES (853, 'Person', 222, 'update', NULL, '---
id: 222
salutation: 
name: ''Marcelina ''
lastnames: ''Escalera ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 68
created_at: 2015-02-24 14:56:17.092857000 Z
updated_at: 2015-02-24 14:56:17.092857000 Z
', '2015-03-02 19:23:44.551658');
INSERT INTO versions VALUES (854, 'Person', 261, 'update', NULL, '---
id: 261
salutation: 
name: Carmen I.
lastnames: ''Fontanez ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 96
created_at: 2015-02-24 15:36:45.081695000 Z
updated_at: 2015-02-24 15:36:45.081695000 Z
', '2015-03-02 19:23:44.671583');
INSERT INTO versions VALUES (855, 'Person', 263, 'update', NULL, '---
id: 263
salutation: 
name: ''Evelyn ''
lastnames: ''Cruz ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 96
created_at: 2015-02-24 15:37:12.574595000 Z
updated_at: 2015-02-24 15:37:12.574595000 Z
', '2015-03-02 19:23:44.678968');
INSERT INTO versions VALUES (856, 'Person', 262, 'update', NULL, '---
id: 262
salutation: 
name: ''Luis ''
lastnames: ''Beltran ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 96
created_at: 2015-02-24 15:36:59.766195000 Z
updated_at: 2015-02-24 15:36:59.766195000 Z
', '2015-03-02 19:23:44.683735');
INSERT INTO versions VALUES (857, 'Person', 264, 'update', NULL, '---
id: 264
salutation: 
name: ''Luis A. ''
lastnames: Poggi
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 96
created_at: 2015-02-24 15:37:27.835344000 Z
updated_at: 2015-02-24 15:37:27.835344000 Z
', '2015-03-02 19:23:44.689279');
INSERT INTO versions VALUES (858, 'Person', 245, 'update', NULL, '---
id: 245
salutation: 0
name: ''Luis ''
lastnames: Serrano
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 6
created_at: 2015-02-24 15:14:15.607845000 Z
updated_at: 2015-02-24 15:14:15.607845000 Z
', '2015-03-02 19:23:44.694154');
INSERT INTO versions VALUES (859, 'Person', 246, 'update', NULL, '---
id: 246
salutation: 
name: ''Raquel ''
lastnames: ''López Rodríguez ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 6
created_at: 2015-02-24 15:14:41.256116000 Z
updated_at: 2015-02-24 15:14:41.256116000 Z
', '2015-03-02 19:23:47.868671');
INSERT INTO versions VALUES (860, 'Person', 247, 'update', NULL, '---
id: 247
salutation: 
name: ''Roberto ''
lastnames: Vera Monroig
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 6
created_at: 2015-02-24 15:15:22.012673000 Z
updated_at: 2015-02-24 15:15:22.012673000 Z
', '2015-03-02 19:23:48.363357');
INSERT INTO versions VALUES (861, 'Person', 251, 'update', NULL, '---
id: 251
salutation: 
name: Clarissa
lastnames: Rodríguez
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 99
created_at: 2015-02-24 15:17:40.919683000 Z
updated_at: 2015-02-24 15:27:46.077982000 Z
', '2015-03-02 19:23:48.381169');
INSERT INTO versions VALUES (862, 'Person', 250, 'update', NULL, '---
id: 250
salutation: 
name: ''Elsa I. ''
lastnames: Mercado Torres
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 99
created_at: 2015-02-24 15:17:04.962409000 Z
updated_at: 2015-02-24 15:17:04.962409000 Z
', '2015-03-02 19:23:48.388945');
INSERT INTO versions VALUES (863, 'Person', 248, 'update', NULL, '---
id: 248
salutation: 1
name: ''Juan N. ''
lastnames: Medina Argueta
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 99
created_at: 2015-02-24 15:16:16.155526000 Z
updated_at: 2015-02-24 15:16:16.155526000 Z
', '2015-03-02 19:23:48.394907');
INSERT INTO versions VALUES (864, 'Person', 253, 'update', NULL, '---
id: 253
salutation: 
name: ''Marta ''
lastnames: ''Ayala Vega ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 99
created_at: 2015-02-24 15:18:59.956187000 Z
updated_at: 2015-02-24 15:18:59.956187000 Z
', '2015-03-02 19:23:48.399679');
INSERT INTO versions VALUES (865, 'Person', 307, 'create', NULL, NULL, '2015-03-02 19:25:50.29984');
INSERT INTO versions VALUES (866, 'Person', 308, 'create', NULL, NULL, '2015-03-02 19:26:14.730561');
INSERT INTO versions VALUES (867, 'Person', 309, 'create', NULL, NULL, '2015-03-02 19:26:35.222113');
INSERT INTO versions VALUES (868, 'Person', 310, 'create', NULL, NULL, '2015-03-02 19:26:55.394899');
INSERT INTO versions VALUES (869, 'Person', 308, 'update', NULL, '---
id: 308
salutation: 
name: Aida B.
lastnames: ''Cruz ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 51
created_at: 2015-03-02 19:26:14.724721000 Z
updated_at: 2015-03-02 19:26:14.724721000 Z
', '2015-03-02 19:26:56.658167');
INSERT INTO versions VALUES (870, 'Person', 307, 'update', NULL, '---
id: 307
salutation: 
name: ''Lizette ''
lastnames: ''Vázquez ''
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 51
created_at: 2015-03-02 19:25:50.298034000 Z
updated_at: 2015-03-02 19:25:50.298034000 Z
', '2015-03-02 19:26:56.907147');
INSERT INTO versions VALUES (871, 'Person', 309, 'update', NULL, '---
id: 309
salutation: 
name: ''Nilza ''
lastnames: ''Rivera ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 51
created_at: 2015-03-02 19:26:35.216231000 Z
updated_at: 2015-03-02 19:26:35.216231000 Z
', '2015-03-02 19:26:56.924183');
INSERT INTO versions VALUES (872, 'Person', 306, 'update', NULL, '---
id: 306
salutation: 
name: ''Leynaris ''
lastnames: Diaz
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 90
created_at: 2015-03-02 19:22:26.869249000 Z
updated_at: 2015-03-02 19:22:26.869249000 Z
', '2015-03-02 19:26:56.936613');
INSERT INTO versions VALUES (873, 'Person', 254, 'update', NULL, '---
id: 254
salutation: 
name: ''Noel Y. ''
lastnames: ''Pachecho Alvarez ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 99
created_at: 2015-02-24 15:26:06.338909000 Z
updated_at: 2015-02-24 15:26:06.338909000 Z
', '2015-03-02 19:26:56.942728');
INSERT INTO versions VALUES (874, 'Person', 249, 'update', NULL, '---
id: 249
salutation: 
name: ''Yolanda ''
lastnames: Orendo Montes
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 99
created_at: 2015-02-24 15:16:47.614559000 Z
updated_at: 2015-02-24 15:16:47.614559000 Z
', '2015-03-02 19:26:56.951113');
INSERT INTO versions VALUES (882, 'Person', 312, 'update', NULL, '---
id: 312
salutation: 0
name: Carlos I.
lastnames: ''López ''
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 2
created_at: 2015-03-02 19:30:21.919239000 Z
updated_at: 2015-03-02 19:30:21.919239000 Z
', '2015-03-02 19:33:00.283081');
INSERT INTO versions VALUES (883, 'Person', 313, 'update', NULL, '---
id: 313
salutation: 
name: Ramón
lastnames: Negrón
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 2
created_at: 2015-03-02 19:30:39.762878000 Z
updated_at: 2015-03-02 19:30:39.762878000 Z
', '2015-03-02 19:33:00.430964');
INSERT INTO versions VALUES (884, 'Person', 310, 'update', NULL, '---
id: 310
salutation: 
name: Adalberto
lastnames: Barbosa
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 51
created_at: 2015-03-02 19:26:55.393258000 Z
updated_at: 2015-03-02 19:26:55.393258000 Z
', '2015-03-02 19:33:00.996158');
INSERT INTO versions VALUES (885, 'Person', 311, 'update', NULL, '---
id: 311
salutation: 
name: José M.
lastnames: Colón
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 51
created_at: 2015-03-02 19:27:20.512037000 Z
updated_at: 2015-03-02 19:27:20.512037000 Z
', '2015-03-02 19:33:01.408468');
INSERT INTO versions VALUES (886, 'Person', 315, 'update', NULL, '---
id: 315
salutation: 
name: Carlos W.
lastnames: Filippetti
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 80
created_at: 2015-03-02 19:32:08.017509000 Z
updated_at: 2015-03-02 19:32:08.017509000 Z
', '2015-03-02 19:33:01.425592');
INSERT INTO versions VALUES (887, 'Person', 316, 'update', NULL, '---
id: 316
salutation: 
name: ''Daisy ''
lastnames: Cruz Torres
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 80
created_at: 2015-03-02 19:32:29.777240000 Z
updated_at: 2015-03-02 19:32:29.777240000 Z
', '2015-03-02 19:33:01.437183');
INSERT INTO versions VALUES (893, 'Person', 321, 'update', NULL, '---
id: 321
salutation: 1
name: Carmen Z.
lastnames: Díaz
sex: false
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 77
created_at: 2015-03-02 19:41:17.833786000 Z
updated_at: 2015-03-02 19:41:17.833786000 Z
', '2015-03-02 19:42:04.748059');
INSERT INTO versions VALUES (894, 'Person', 314, 'update', NULL, '---
id: 314
salutation: 1
name: ''Jaime ''
lastnames: Galarza Sierra
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 80
created_at: 2015-03-02 19:31:39.242967000 Z
updated_at: 2015-03-02 19:31:39.242967000 Z
', '2015-03-02 19:42:04.778875');
INSERT INTO versions VALUES (895, 'Person', 320, 'update', NULL, '---
id: 320
salutation: 
name: ''Ivonne ''
lastnames: Díaz Lombardo
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 49
created_at: 2015-03-02 19:36:14.365341000 Z
updated_at: 2015-03-02 19:36:14.365341000 Z
', '2015-03-02 19:42:04.789946');
INSERT INTO versions VALUES (896, 'Person', 318, 'update', NULL, '---
id: 318
salutation: 
name: ''José M. ''
lastnames: Birriel
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 49
created_at: 2015-03-02 19:33:54.654529000 Z
updated_at: 2015-03-02 19:33:54.654529000 Z
', '2015-03-02 19:42:04.80226');
INSERT INTO versions VALUES (897, 'Person', 319, 'update', NULL, '---
id: 319
salutation: 
name: Lilliam
lastnames: Mas Birriel
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 49
created_at: 2015-03-02 19:34:27.418925000 Z
updated_at: 2015-03-02 19:34:27.418925000 Z
', '2015-03-02 19:42:04.810742');
INSERT INTO versions VALUES (898, 'Person', 317, 'update', NULL, '---
id: 317
salutation: 1
name: ''Miladys ''
lastnames: Oliveras
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 49
created_at: 2015-03-02 19:33:26.920211000 Z
updated_at: 2015-03-02 19:33:26.920211000 Z
', '2015-03-02 19:42:04.822643');
INSERT INTO versions VALUES (906, 'Person', 323, 'update', NULL, '---
id: 323
salutation: 
name: Anamaría
lastnames: Gallardo
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 102
created_at: 2015-03-02 19:43:37.463487000 Z
updated_at: 2015-03-02 19:45:40.777539000 Z
', '2015-03-02 19:47:08.035982');
INSERT INTO versions VALUES (907, 'Person', 322, 'update', NULL, '---
id: 322
salutation: 0
name: ''Eva ''
lastnames: Agosto
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 102
created_at: 2015-03-02 19:42:38.811020000 Z
updated_at: 2015-03-02 19:42:38.811020000 Z
', '2015-03-02 19:47:08.25928');
INSERT INTO versions VALUES (908, 'Person', 324, 'update', NULL, '---
id: 324
salutation: 
name: ''Milagros ''
lastnames: Ortíz
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 102
created_at: 2015-03-02 19:44:00.215750000 Z
updated_at: 2015-03-02 19:44:00.215750000 Z
', '2015-03-02 19:47:08.674517');
INSERT INTO versions VALUES (909, 'Person', 327, 'update', NULL, '---
id: 327
salutation: 
name: ''Carmelo ''
lastnames: ''Rivera ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 41
created_at: 2015-03-02 19:46:51.495269000 Z
updated_at: 2015-03-02 19:46:51.495269000 Z
', '2015-03-02 19:47:09.120476');
INSERT INTO versions VALUES (910, 'Person', 326, 'update', NULL, '---
id: 326
salutation: 0
name: Luis O.
lastnames: Arizmendi
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 41
created_at: 2015-03-02 19:46:33.155905000 Z
updated_at: 2015-03-02 19:46:33.155905000 Z
', '2015-03-02 19:47:09.13654');
INSERT INTO versions VALUES (911, 'Person', 325, 'update', NULL, '---
id: 325
salutation: 0
name: ''Zoraida ''
lastnames: Rivera Morales
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 41
created_at: 2015-03-02 19:46:12.671406000 Z
updated_at: 2015-03-02 19:46:12.671406000 Z
', '2015-03-02 19:47:09.142773');
INSERT INTO versions VALUES (919, 'Person', 329, 'update', NULL, '---
id: 329
salutation: 
name: ''Elena ''
lastnames: Rivera
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 41
created_at: 2015-03-02 19:47:39.758229000 Z
updated_at: 2015-03-02 19:47:39.758229000 Z
', '2015-03-02 19:53:12.397624');
INSERT INTO versions VALUES (920, 'Person', 328, 'update', NULL, '---
id: 328
salutation: 
name: ''Ruth ''
lastnames: Rosa
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 41
created_at: 2015-03-02 19:47:10.836208000 Z
updated_at: 2015-03-02 19:47:10.836208000 Z
', '2015-03-02 19:53:12.487019');
INSERT INTO versions VALUES (921, 'Person', 332, 'update', NULL, '---
id: 332
salutation: 0
name: ''Julio ''
lastnames: Graciani
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 91
created_at: 2015-03-02 19:52:12.063683000 Z
updated_at: 2015-03-02 19:52:12.063683000 Z
', '2015-03-02 19:53:12.498404');
INSERT INTO versions VALUES (922, 'Person', 333, 'update', NULL, '---
id: 333
salutation: 
name: ''Lourdes ''
lastnames: Santana
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 91
created_at: 2015-03-02 19:52:28.083547000 Z
updated_at: 2015-03-02 19:52:28.083547000 Z
', '2015-03-02 19:53:12.522489');
INSERT INTO versions VALUES (923, 'Person', 334, 'update', NULL, '---
id: 334
salutation: 
name: Luz D.
lastnames: Lamboy
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 91
created_at: 2015-03-02 19:52:43.963990000 Z
updated_at: 2015-03-02 19:52:43.963990000 Z
', '2015-03-02 19:53:12.534192');
INSERT INTO versions VALUES (924, 'Person', 331, 'update', NULL, '---
id: 331
salutation: 0
name: ''Marcela ''
lastnames: Ortíz
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 91
created_at: 2015-03-02 19:51:47.102612000 Z
updated_at: 2015-03-02 19:51:47.102612000 Z
', '2015-03-02 19:53:12.542345');
INSERT INTO versions VALUES (931, 'Person', 336, 'update', NULL, '---
id: 336
salutation: 
name: ''Alexander ''
lastnames: ''Cruz ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 29
created_at: 2015-03-02 19:54:54.858849000 Z
updated_at: 2015-03-02 19:54:54.858849000 Z
', '2015-03-02 20:00:15.871086');
INSERT INTO versions VALUES (932, 'Person', 335, 'update', NULL, '---
id: 335
salutation: 0
name: ''Jesús E. ''
lastnames: García
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 29
created_at: 2015-03-02 19:54:39.652549000 Z
updated_at: 2015-03-02 19:54:39.652549000 Z
', '2015-03-02 20:00:15.982082');
INSERT INTO versions VALUES (902, 'Person', 323, 'update', NULL, '---
id: 323
salutation: 
name: Anamaría
lastnames: Gallardo
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 102
created_at: 2015-03-02 19:43:37.463487000 Z
updated_at: 2015-03-02 19:43:37.463487000 Z
', '2015-03-02 19:45:40.794255');
INSERT INTO versions VALUES (903, 'Person', 325, 'create', NULL, NULL, '2015-03-02 19:46:12.677154');
INSERT INTO versions VALUES (904, 'Person', 326, 'create', NULL, NULL, '2015-03-02 19:46:33.162604');
INSERT INTO versions VALUES (905, 'Person', 327, 'create', NULL, NULL, '2015-03-02 19:46:51.500594');
INSERT INTO versions VALUES (912, 'Person', 328, 'create', NULL, NULL, '2015-03-02 19:47:10.849145');
INSERT INTO versions VALUES (913, 'Person', 329, 'create', NULL, NULL, '2015-03-02 19:47:39.760018');
INSERT INTO versions VALUES (914, 'Person', 330, 'create', NULL, NULL, '2015-03-02 19:48:26.903847');
INSERT INTO versions VALUES (915, 'Person', 331, 'create', NULL, NULL, '2015-03-02 19:51:47.108568');
INSERT INTO versions VALUES (916, 'Person', 332, 'create', NULL, NULL, '2015-03-02 19:52:12.069235');
INSERT INTO versions VALUES (917, 'Person', 333, 'create', NULL, NULL, '2015-03-02 19:52:28.089385');
INSERT INTO versions VALUES (918, 'Person', 334, 'create', NULL, NULL, '2015-03-02 19:52:43.96542');
INSERT INTO versions VALUES (925, 'Check', 21, 'create', NULL, NULL, '2015-03-02 19:53:55.356776');
INSERT INTO versions VALUES (926, 'Person', 335, 'create', NULL, NULL, '2015-03-02 19:54:39.658285');
INSERT INTO versions VALUES (927, 'Person', 336, 'create', NULL, NULL, '2015-03-02 19:54:54.864899');
INSERT INTO versions VALUES (928, 'Person', 337, 'create', NULL, NULL, '2015-03-02 19:55:18.708103');
INSERT INTO versions VALUES (929, 'Person', 338, 'create', NULL, NULL, '2015-03-02 19:55:39.355943');
INSERT INTO versions VALUES (930, 'Person', 339, 'create', NULL, NULL, '2015-03-02 20:00:08.951455');
INSERT INTO versions VALUES (937, 'Person', 222, 'update', NULL, '---
id: 222
salutation: 
name: ''Marcelina ''
lastnames: ''Escalera ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 68
created_at: 2015-02-24 14:56:17.092857000 Z
updated_at: 2015-03-02 19:23:44.548125000 Z
', '2015-03-02 20:01:51.753785');
INSERT INTO versions VALUES (938, 'Check', 22, 'create', NULL, NULL, '2015-03-02 20:08:12.072248');
INSERT INTO versions VALUES (939, 'Check', 23, 'create', NULL, NULL, '2015-03-02 20:08:49.31908');
INSERT INTO versions VALUES (940, 'Check', 24, 'create', NULL, NULL, '2015-03-02 20:09:01.976744');
INSERT INTO versions VALUES (941, 'Check', 25, 'create', NULL, NULL, '2015-03-02 20:09:33.592211');
INSERT INTO versions VALUES (942, 'Check', 26, 'create', NULL, NULL, '2015-03-02 20:12:45.818215');
INSERT INTO versions VALUES (943, 'Check', 27, 'create', NULL, NULL, '2015-03-02 20:14:35.878301');
INSERT INTO versions VALUES (944, 'Check', 28, 'create', NULL, NULL, '2015-03-02 20:15:53.190178');
INSERT INTO versions VALUES (945, 'Person', 340, 'create', NULL, NULL, '2015-03-02 20:20:35.250202');
INSERT INTO versions VALUES (946, 'Person', 341, 'create', NULL, NULL, '2015-03-02 20:20:58.477723');
INSERT INTO versions VALUES (947, 'Person', 342, 'create', NULL, NULL, '2015-03-02 20:21:12.422342');
INSERT INTO versions VALUES (948, 'Check', 29, 'create', NULL, NULL, '2015-03-02 20:21:41.788061');
INSERT INTO versions VALUES (933, 'Person', 338, 'update', NULL, '---
id: 338
salutation: 
name: Pedro J.
lastnames: Morales
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 29
created_at: 2015-03-02 19:55:39.350618000 Z
updated_at: 2015-03-02 19:55:39.350618000 Z
', '2015-03-02 20:00:15.999491');
INSERT INTO versions VALUES (934, 'Person', 337, 'update', NULL, '---
id: 337
salutation: 
name: ''Ricartel ''
lastnames: Rivera
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 29
created_at: 2015-03-02 19:55:18.703264000 Z
updated_at: 2015-03-02 19:55:18.703264000 Z
', '2015-03-02 20:00:16.008091');
INSERT INTO versions VALUES (935, 'Person', 339, 'update', NULL, '---
id: 339
salutation: 
name: Rubén
lastnames: ''Jiménez ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 75
created_at: 2015-03-02 20:00:08.946664000 Z
updated_at: 2015-03-02 20:00:08.946664000 Z
', '2015-03-02 20:00:16.014288');
INSERT INTO versions VALUES (936, 'Person', 330, 'update', NULL, '---
id: 330
salutation: 1
name: ''David ''
lastnames: Casillas
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 108
created_at: 2015-03-02 19:48:26.897330000 Z
updated_at: 2015-03-02 19:48:26.897330000 Z
', '2015-03-02 20:00:16.02076');
INSERT INTO versions VALUES (949, 'Person', 341, 'update', NULL, '---
id: 341
salutation: 
name: ''Bonifacio ''
lastnames: Del Valle
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 86
created_at: 2015-03-02 20:20:58.471397000 Z
updated_at: 2015-03-02 20:20:58.471397000 Z
', '2015-03-02 20:50:19.012954');
INSERT INTO versions VALUES (950, 'Person', 340, 'update', NULL, '---
id: 340
salutation: 0
name: ''Luis R. ''
lastnames: Figueroa
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 86
created_at: 2015-03-02 20:20:35.244301000 Z
updated_at: 2015-03-02 20:20:35.244301000 Z
', '2015-03-02 20:50:19.241416');
INSERT INTO versions VALUES (951, 'Person', 342, 'update', NULL, '---
id: 342
salutation: 
name: ''Luz ''
lastnames: Maldonado
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 86
created_at: 2015-03-02 20:21:12.416348000 Z
updated_at: 2015-03-02 20:21:12.416348000 Z
', '2015-03-02 20:50:19.646521');
INSERT INTO versions VALUES (952, 'Person', 343, 'create', NULL, NULL, '2015-03-04 10:57:00.601226');
INSERT INTO versions VALUES (953, 'Person', 344, 'create', NULL, NULL, '2015-03-04 10:57:43.867836');
INSERT INTO versions VALUES (954, 'Person', 345, 'create', NULL, NULL, '2015-03-04 10:59:22.647352');
INSERT INTO versions VALUES (955, 'Person', 346, 'create', NULL, NULL, '2015-03-04 11:00:06.933044');
INSERT INTO versions VALUES (956, 'Person', 345, 'update', NULL, '---
id: 345
salutation: 0
name: Margarita
lastnames: Rodríguez
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 10:59:22.645046000 Z
updated_at: 2015-03-04 10:59:22.645046000 Z
', '2015-03-04 11:00:48.489855');
INSERT INTO versions VALUES (957, 'Person', 347, 'create', NULL, NULL, '2015-03-04 11:02:09.14483');
INSERT INTO versions VALUES (958, 'Person', 348, 'create', NULL, NULL, '2015-03-04 11:02:42.318939');
INSERT INTO versions VALUES (959, 'Person', 349, 'create', NULL, NULL, '2015-03-04 11:03:01.359754');
INSERT INTO versions VALUES (960, 'Person', 346, 'update', NULL, '---
id: 346
salutation: 0
name: Carmen W.
lastnames: Lebrón
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 11:00:06.930223000 Z
updated_at: 2015-03-04 11:00:06.930223000 Z
', '2015-03-04 11:03:13.062272');
INSERT INTO versions VALUES (961, 'Person', 344, 'update', NULL, '---
id: 344
salutation: 1
name: Clemente
lastnames: Flores
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 10:57:43.865004000 Z
updated_at: 2015-03-04 10:57:43.865004000 Z
', '2015-03-04 11:03:13.074611');
INSERT INTO versions VALUES (962, 'Person', 349, 'update', NULL, '---
id: 349
salutation: 
name: Francisca
lastnames: Rodríguez
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 11:03:01.357140000 Z
updated_at: 2015-03-04 11:03:01.357140000 Z
', '2015-03-04 11:03:13.080996');
INSERT INTO versions VALUES (963, 'Person', 348, 'update', NULL, '---
id: 348
salutation: 
name: Juan
lastnames: Figueroa
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 11:02:42.315908000 Z
updated_at: 2015-03-04 11:02:42.315908000 Z
', '2015-03-04 11:03:13.09134');
INSERT INTO versions VALUES (964, 'Person', 345, 'update', NULL, '---
id: 345
salutation: 0
name: Margarita
lastnames: Rodríguez
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 10:59:22.645046000 Z
updated_at: 2015-03-04 11:00:48.431200000 Z
', '2015-03-04 11:03:13.102404');
INSERT INTO versions VALUES (965, 'Person', 347, 'update', NULL, '---
id: 347
salutation: 4
name: Moisés
lastnames: Martínez
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 11:02:09.141491000 Z
updated_at: 2015-03-04 11:02:09.141491000 Z
', '2015-03-04 11:03:13.114293');
INSERT INTO versions VALUES (966, 'Person', 350, 'create', NULL, NULL, '2015-03-04 11:03:24.916618');
INSERT INTO versions VALUES (967, 'Person', 351, 'create', NULL, NULL, '2015-03-04 11:03:46.629945');
INSERT INTO versions VALUES (968, 'Person', 352, 'create', NULL, NULL, '2015-03-04 11:04:46.846849');
INSERT INTO versions VALUES (969, 'Person', 353, 'create', NULL, NULL, '2015-03-04 11:05:18.262919');
INSERT INTO versions VALUES (970, 'Person', 354, 'create', NULL, NULL, '2015-03-04 11:05:35.222045');
INSERT INTO versions VALUES (971, 'Person', 355, 'create', NULL, NULL, '2015-03-04 11:05:56.400328');
INSERT INTO versions VALUES (972, 'Person', 355, 'update', NULL, '---
id: 355
salutation: 
name: Julio
lastnames: Fuentes
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 55
created_at: 2015-03-04 11:05:56.397368000 Z
updated_at: 2015-03-04 11:05:56.397368000 Z
', '2015-03-04 11:06:06.970929');
INSERT INTO versions VALUES (973, 'Person', 352, 'update', NULL, '---
id: 352
salutation: 1
name: Luis Francisco
lastnames: Alicea Caraballo
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 55
created_at: 2015-03-04 11:04:46.844147000 Z
updated_at: 2015-03-04 11:04:46.844147000 Z
', '2015-03-04 11:06:07.125857');
INSERT INTO versions VALUES (974, 'Person', 353, 'update', NULL, '---
id: 353
salutation: 0
name: Pedro
lastnames: Boria Ortiz
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 55
created_at: 2015-03-04 11:05:18.260131000 Z
updated_at: 2015-03-04 11:05:18.260131000 Z
', '2015-03-04 11:06:07.538383');
INSERT INTO versions VALUES (975, 'Person', 354, 'update', NULL, '---
id: 354
salutation: 
name: Ramón
lastnames: García
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 55
created_at: 2015-03-04 11:05:35.219957000 Z
updated_at: 2015-03-04 11:05:35.219957000 Z
', '2015-03-04 11:06:07.547943');
INSERT INTO versions VALUES (976, 'Person', 351, 'update', NULL, '---
id: 351
salutation: 
name: Francisca
lastnames: Alicea
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 11:03:46.627915000 Z
updated_at: 2015-03-04 11:03:46.627915000 Z
', '2015-03-04 11:06:07.55514');
INSERT INTO versions VALUES (977, 'Person', 350, 'update', NULL, '---
id: 350
salutation: 
name: Myrna
lastnames: Villafranca
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 11:03:24.913737000 Z
updated_at: 2015-03-04 11:03:24.913737000 Z
', '2015-03-04 11:06:07.563005');
INSERT INTO versions VALUES (978, 'Person', 356, 'create', NULL, NULL, '2015-03-04 11:06:18.371185');
INSERT INTO versions VALUES (979, 'Person', 357, 'create', NULL, NULL, '2015-03-04 11:06:38.053507');
INSERT INTO versions VALUES (980, 'Person', 358, 'create', NULL, NULL, '2015-03-04 11:13:02.83029');
INSERT INTO versions VALUES (981, 'Person', 359, 'create', NULL, NULL, '2015-03-04 11:13:47.824543');
INSERT INTO versions VALUES (982, 'Person', 360, 'create', NULL, NULL, '2015-03-04 11:14:22.505683');
INSERT INTO versions VALUES (983, 'Person', 357, 'update', NULL, '---
id: 357
salutation: 
name: Edgardo
lastnames: López
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 55
created_at: 2015-03-04 11:06:38.050754000 Z
updated_at: 2015-03-04 11:06:38.050754000 Z
', '2015-03-04 11:15:11.60239');
INSERT INTO versions VALUES (984, 'Person', 356, 'update', NULL, '---
id: 356
salutation: 
name: Maribel
lastnames: Boria
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 55
created_at: 2015-03-04 11:06:18.367635000 Z
updated_at: 2015-03-04 11:06:18.367635000 Z
', '2015-03-04 11:15:11.742325');
INSERT INTO versions VALUES (989, 'Person', 361, 'create', NULL, NULL, '2015-03-04 11:15:12.302253');
INSERT INTO versions VALUES (990, 'Person', 362, 'create', NULL, NULL, '2015-03-04 11:17:12.163315');
INSERT INTO versions VALUES (991, 'Person', 363, 'create', NULL, NULL, '2015-03-04 11:17:44.884032');
INSERT INTO versions VALUES (985, 'Person', 343, 'update', NULL, '---
id: 343
salutation: 1
name: Ruth A.
lastnames: Martínez
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 10:57:00.490612000 Z
updated_at: 2015-03-04 10:57:00.490612000 Z
', '2015-03-04 11:15:11.755446');
INSERT INTO versions VALUES (986, 'Person', 358, 'update', NULL, '---
id: 358
salutation: 0
name: David A.
lastnames: González Meléndez
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 16
created_at: 2015-03-04 11:13:02.826787000 Z
updated_at: 2015-03-04 11:13:02.826787000 Z
', '2015-03-04 11:15:11.801506');
INSERT INTO versions VALUES (987, 'Person', 360, 'update', NULL, '---
id: 360
salutation: 
name: José A.
lastnames: Ortiz Rivera
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 16
created_at: 2015-03-04 11:14:22.501926000 Z
updated_at: 2015-03-04 11:14:22.501926000 Z
', '2015-03-04 11:15:11.810011');
INSERT INTO versions VALUES (988, 'Person', 359, 'update', NULL, '---
id: 359
salutation: 
name: María V.
lastnames: Colón Alvarado
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 16
created_at: 2015-03-04 11:13:47.821593000 Z
updated_at: 2015-03-04 11:13:47.821593000 Z
', '2015-03-04 11:15:11.815992');
INSERT INTO versions VALUES (995, 'Person', 365, 'update', NULL, '---
id: 365
salutation: 
name: Ada
lastnames: Serrano
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 48
created_at: 2015-03-04 11:19:51.909843000 Z
updated_at: 2015-03-04 11:19:51.909843000 Z
', '2015-03-04 11:21:15.810546');
INSERT INTO versions VALUES (996, 'Person', 364, 'update', NULL, '---
id: 364
salutation: 0
name: Héctor
lastnames: Soto
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 48
created_at: 2015-03-04 11:19:31.038158000 Z
updated_at: 2015-03-04 11:19:31.038158000 Z
', '2015-03-04 11:21:15.866525');
INSERT INTO versions VALUES (997, 'Person', 366, 'update', NULL, '---
id: 366
salutation: 
name: Nelson
lastnames: Ortiz
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 48
created_at: 2015-03-04 11:20:18.775498000 Z
updated_at: 2015-03-04 11:20:18.775498000 Z
', '2015-03-04 11:21:15.879278');
INSERT INTO versions VALUES (998, 'Person', 361, 'update', NULL, '---
id: 361
salutation: 
name: Ana R.
lastnames: Torres Montañez
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 16
created_at: 2015-03-04 11:15:12.300300000 Z
updated_at: 2015-03-04 11:15:12.300300000 Z
', '2015-03-04 11:21:15.884828');
INSERT INTO versions VALUES (999, 'Person', 363, 'update', NULL, '---
id: 363
salutation: 
name: Gloria
lastnames: Ríos Rolón
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 16
created_at: 2015-03-04 11:17:44.881599000 Z
updated_at: 2015-03-04 11:17:44.881599000 Z
', '2015-03-04 11:21:15.895873');
INSERT INTO versions VALUES (1000, 'Person', 362, 'update', NULL, '---
id: 362
salutation: 
name: Pedro P.
lastnames: Santiago Romero
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 16
created_at: 2015-03-04 11:17:12.159850000 Z
updated_at: 2015-03-04 11:17:12.159850000 Z
', '2015-03-04 11:21:15.902265');
INSERT INTO versions VALUES (1001, 'Person', 365, 'update', NULL, '---
id: 365
salutation: 
name: Ada
lastnames: Serrano
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 11:19:51.909843000 Z
updated_at: 2015-03-04 11:21:15.802599000 Z
', '2015-03-04 11:26:15.293767');
INSERT INTO versions VALUES (1002, 'Person', 364, 'update', NULL, '---
id: 364
salutation: 0
name: Héctor
lastnames: Soto
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 11:19:31.038158000 Z
updated_at: 2015-03-04 11:21:15.861874000 Z
', '2015-03-04 11:26:16.663412');
INSERT INTO versions VALUES (1003, 'Person', 366, 'update', NULL, '---
id: 366
salutation: 
name: Nelson
lastnames: Ortiz
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 11:20:18.775498000 Z
updated_at: 2015-03-04 11:21:15.869487000 Z
', '2015-03-04 11:26:17.505491');
INSERT INTO versions VALUES (1004, 'Person', 361, 'update', NULL, '---
id: 361
salutation: 
name: Ana R.
lastnames: Torres Montañez
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:15:12.300300000 Z
updated_at: 2015-03-04 11:21:15.882024000 Z
', '2015-03-04 11:26:18.077485');
INSERT INTO versions VALUES (1005, 'Person', 363, 'update', NULL, '---
id: 363
salutation: 
name: Gloria
lastnames: Ríos Rolón
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:17:44.881599000 Z
updated_at: 2015-03-04 11:21:15.888273000 Z
', '2015-03-04 11:26:18.592532');
INSERT INTO versions VALUES (1006, 'Person', 362, 'update', NULL, '---
id: 362
salutation: 
name: Pedro P.
lastnames: Santiago Romero
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:17:12.159850000 Z
updated_at: 2015-03-04 11:21:15.897987000 Z
', '2015-03-04 11:26:19.444545');
INSERT INTO versions VALUES (1007, 'Person', 365, 'update', NULL, '---
id: 365
salutation: 
name: Ada
lastnames: Serrano
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 48
created_at: 2015-03-04 11:19:51.909843000 Z
updated_at: 2015-03-04 11:26:15.289284000 Z
', '2015-03-04 11:27:19.793287');
INSERT INTO versions VALUES (1008, 'Person', 364, 'update', NULL, '---
id: 364
salutation: 0
name: Héctor
lastnames: Soto
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 48
created_at: 2015-03-04 11:19:31.038158000 Z
updated_at: 2015-03-04 11:26:16.656220000 Z
', '2015-03-04 11:27:20.284106');
INSERT INTO versions VALUES (1009, 'Person', 366, 'update', NULL, '---
id: 366
salutation: 
name: Nelson
lastnames: Ortiz
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 48
created_at: 2015-03-04 11:20:18.775498000 Z
updated_at: 2015-03-04 11:26:17.498982000 Z
', '2015-03-04 11:27:20.729347');
INSERT INTO versions VALUES (1010, 'Person', 361, 'update', NULL, '---
id: 361
salutation: 
name: Ana R.
lastnames: Torres Montañez
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 16
created_at: 2015-03-04 11:15:12.300300000 Z
updated_at: 2015-03-04 11:26:18.072817000 Z
', '2015-03-04 11:27:20.743844');
INSERT INTO versions VALUES (1011, 'Person', 363, 'update', NULL, '---
id: 363
salutation: 
name: Gloria
lastnames: Ríos Rolón
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 16
created_at: 2015-03-04 11:17:44.881599000 Z
updated_at: 2015-03-04 11:26:18.586402000 Z
', '2015-03-04 11:27:20.750214');
INSERT INTO versions VALUES (1012, 'Person', 362, 'update', NULL, '---
id: 362
salutation: 
name: Pedro P.
lastnames: Santiago Romero
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 16
created_at: 2015-03-04 11:17:12.159850000 Z
updated_at: 2015-03-04 11:26:19.435550000 Z
', '2015-03-04 11:27:20.755608');
INSERT INTO versions VALUES (1013, 'Person', 346, 'update', NULL, '---
id: 346
salutation: 0
name: Carmen W.
lastnames: Lebrón
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:00:06.930223000 Z
updated_at: 2015-03-04 11:03:13.051429000 Z
', '2015-03-04 11:27:28.630672');
INSERT INTO versions VALUES (1014, 'Person', 344, 'update', NULL, '---
id: 344
salutation: 1
name: Clemente
lastnames: Flores
sex: true
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 10:57:43.865004000 Z
updated_at: 2015-03-04 11:03:13.066074000 Z
', '2015-03-04 11:27:29.273571');
INSERT INTO versions VALUES (1015, 'Person', 351, 'update', NULL, '---
id: 351
salutation: 
name: Francisca
lastnames: Alicea
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:03:46.627915000 Z
updated_at: 2015-03-04 11:06:07.550961000 Z
', '2015-03-04 11:27:30.321251');
INSERT INTO versions VALUES (1016, 'Person', 349, 'update', NULL, '---
id: 349
salutation: 
name: Francisca
lastnames: Rodríguez
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:03:01.357140000 Z
updated_at: 2015-03-04 11:03:13.077141000 Z
', '2015-03-04 11:27:30.343637');
INSERT INTO versions VALUES (1017, 'Person', 348, 'update', NULL, '---
id: 348
salutation: 
name: Juan
lastnames: Figueroa
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:02:42.315908000 Z
updated_at: 2015-03-04 11:03:13.087591000 Z
', '2015-03-04 11:27:30.957506');
INSERT INTO versions VALUES (1018, 'Person', 345, 'update', NULL, '---
id: 345
salutation: 0
name: Margarita
lastnames: Rodríguez
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 10:59:22.645046000 Z
updated_at: 2015-03-04 11:03:13.095212000 Z
', '2015-03-04 11:27:31.54976');
INSERT INTO versions VALUES (1019, 'Person', 347, 'update', NULL, '---
id: 347
salutation: 4
name: Moisés
lastnames: Martínez
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:02:09.141491000 Z
updated_at: 2015-03-04 11:03:13.104874000 Z
', '2015-03-04 11:27:32.010583');
INSERT INTO versions VALUES (1020, 'Person', 350, 'update', NULL, '---
id: 350
salutation: 
name: Myrna
lastnames: Villafranca
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:03:24.913737000 Z
updated_at: 2015-03-04 11:06:07.558960000 Z
', '2015-03-04 11:27:32.494964');
INSERT INTO versions VALUES (1021, 'Person', 343, 'update', NULL, '---
id: 343
salutation: 1
name: Ruth A.
lastnames: Martínez
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 10:57:00.490612000 Z
updated_at: 2015-03-04 11:15:11.745510000 Z
', '2015-03-04 11:27:33.004298');
INSERT INTO versions VALUES (1022, 'Person', 346, 'update', NULL, '---
id: 346
salutation: 0
name: Carmen W.
lastnames: Lebrón
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 11:00:06.930223000 Z
updated_at: 2015-03-04 11:27:28.623181000 Z
', '2015-03-04 11:28:24.558915');
INSERT INTO versions VALUES (1023, 'Person', 344, 'update', NULL, '---
id: 344
salutation: 1
name: Clemente
lastnames: Flores
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 10:57:43.865004000 Z
updated_at: 2015-03-04 11:27:29.267137000 Z
', '2015-03-04 11:28:24.876754');
INSERT INTO versions VALUES (1024, 'Person', 351, 'update', NULL, '---
id: 351
salutation: 
name: Francisca
lastnames: Alicea
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 11:03:46.627915000 Z
updated_at: 2015-03-04 11:27:30.315041000 Z
', '2015-03-04 11:28:25.20907');
INSERT INTO versions VALUES (1025, 'Person', 349, 'update', NULL, '---
id: 349
salutation: 
name: Francisca
lastnames: Rodríguez
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 11:03:01.357140000 Z
updated_at: 2015-03-04 11:27:30.340511000 Z
', '2015-03-04 11:28:25.217349');
INSERT INTO versions VALUES (1026, 'Person', 348, 'update', NULL, '---
id: 348
salutation: 
name: Juan
lastnames: Figueroa
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 11:02:42.315908000 Z
updated_at: 2015-03-04 11:27:30.952185000 Z
', '2015-03-04 11:28:25.224729');
INSERT INTO versions VALUES (1027, 'Person', 345, 'update', NULL, '---
id: 345
salutation: 0
name: Margarita
lastnames: Rodríguez
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 10:59:22.645046000 Z
updated_at: 2015-03-04 11:27:31.541575000 Z
', '2015-03-04 11:28:25.232056');
INSERT INTO versions VALUES (1028, 'Person', 347, 'update', NULL, '---
id: 347
salutation: 4
name: Moisés
lastnames: Martínez
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 11:02:09.141491000 Z
updated_at: 2015-03-04 11:27:32.005307000 Z
', '2015-03-04 19:05:53.370918');
INSERT INTO versions VALUES (1029, 'Person', 350, 'update', NULL, '---
id: 350
salutation: 
name: Myrna
lastnames: Villafranca
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 11:03:24.913737000 Z
updated_at: 2015-03-04 11:27:32.490223000 Z
', '2015-03-04 19:05:53.673403');
INSERT INTO versions VALUES (1030, 'Person', 343, 'update', NULL, '---
id: 343
salutation: 1
name: Ruth A.
lastnames: Martínez
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 10:57:00.490612000 Z
updated_at: 2015-03-04 11:27:32.995925000 Z
', '2015-03-04 19:05:53.944359');
INSERT INTO versions VALUES (1031, 'Person', 367, 'create', NULL, NULL, '2015-03-04 19:08:30.896765');
INSERT INTO versions VALUES (1032, 'Person', 368, 'create', NULL, NULL, '2015-03-04 19:27:33.724385');
INSERT INTO versions VALUES (1033, 'Person', 369, 'create', NULL, NULL, '2015-03-04 19:31:21.980398');
INSERT INTO versions VALUES (1034, 'Person', 122, 'update', NULL, '---
id: 122
salutation: 0
name: ''Alberto J. ''
lastnames: ''Díaz ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 56
created_at: 2015-02-24 02:40:50.078129000 Z
updated_at: 2015-03-02 19:22:55.672100000 Z
', '2015-03-04 19:31:48.089707');
INSERT INTO versions VALUES (1035, 'Person', 370, 'create', NULL, NULL, '2015-03-04 19:34:30.912651');
INSERT INTO versions VALUES (1036, 'Person', 371, 'create', NULL, NULL, '2015-03-04 19:35:02.991715');
INSERT INTO versions VALUES (1037, 'Person', 372, 'create', NULL, NULL, '2015-03-04 19:35:09.74532');
INSERT INTO versions VALUES (1038, 'Person', 373, 'create', NULL, NULL, '2015-03-04 19:35:40.286101');
INSERT INTO versions VALUES (1039, 'Person', 374, 'create', NULL, NULL, '2015-03-04 19:36:12.143663');
INSERT INTO versions VALUES (1040, 'Person', 375, 'create', NULL, NULL, '2015-03-04 19:36:12.735635');
INSERT INTO versions VALUES (1041, 'Person', 367, 'update', NULL, '---
id: 367
salutation: 
name: Margarita
lastnames: Ramírez
sex: false
role: 4
description: Presidenta IBPR
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:08:30.862204000 Z
updated_at: 2015-03-04 19:08:30.862204000 Z
', '2015-03-04 19:36:17.876082');
INSERT INTO versions VALUES (1042, 'Person', 368, 'update', NULL, '---
id: 368
salutation: 1
name: ''Francisco ''
lastnames: Ortiz
sex: true
role: 5
description: Presidente, Universidad Teológica del Caribe
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:27:33.555304000 Z
updated_at: 2015-03-04 19:27:33.555304000 Z
', '2015-03-04 19:36:17.924318');
INSERT INTO versions VALUES (1043, 'Person', 369, 'update', NULL, '---
id: 369
salutation: 1
name: Heriberto
lastnames: Martínez
sex: true
role: 5
description: Secretario, Sociedades Biblícas de Puerto Rico
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:31:21.974401000 Z
updated_at: 2015-03-04 19:31:21.974401000 Z
', '2015-03-04 19:36:17.966831');
INSERT INTO versions VALUES (1044, 'Person', 370, 'update', NULL, '---
id: 370
salutation: 1
name: Dra. Doris
lastnames: García
sex: true
role: 5
description: Presidenta, Seminario Evangélico de Puerto Rico
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:34:30.906062000 Z
updated_at: 2015-03-04 19:34:30.906062000 Z
', '2015-03-04 19:36:18.001329');
INSERT INTO versions VALUES (1045, 'Person', 371, 'update', NULL, '---
id: 371
salutation: 1
name: Ingrid
lastnames: Roldán
sex: false
role: 5
description: Misionera
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:35:02.987980000 Z
updated_at: 2015-03-04 19:35:02.987980000 Z
', '2015-03-04 19:36:18.033402');
INSERT INTO versions VALUES (1046, 'Person', 372, 'update', NULL, '---
id: 372
salutation: 
name: José
lastnames: Candelaria
sex: true
role: 4
description: Tesorero
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:35:09.740009000 Z
updated_at: 2015-03-04 19:35:09.740009000 Z
', '2015-03-04 19:36:18.062809');
INSERT INTO versions VALUES (1047, 'Person', 376, 'create', NULL, NULL, '2015-03-04 19:36:34.464375');
INSERT INTO versions VALUES (1048, 'Person', 377, 'create', NULL, NULL, '2015-03-04 19:37:09.326105');
INSERT INTO versions VALUES (1049, 'Person', 378, 'create', NULL, NULL, '2015-03-04 19:39:38.443994');
INSERT INTO versions VALUES (1050, 'Person', 373, 'update', NULL, '---
id: 373
salutation: 1
name: Deliris
lastnames: Carrión
sex: false
role: 5
description: Misionera
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:35:40.279900000 Z
updated_at: 2015-03-04 19:35:40.279900000 Z
', '2015-03-04 19:40:11.42489');
INSERT INTO versions VALUES (1051, 'Person', 374, 'update', NULL, '---
id: 374
salutation: 1
name: Madeline
lastnames: Flores
sex: false
role: 5
description: Misionera
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:36:12.138507000 Z
updated_at: 2015-03-04 19:36:12.138507000 Z
', '2015-03-04 19:40:11.932911');
INSERT INTO versions VALUES (1052, 'Person', 375, 'update', NULL, '---
id: 375
salutation: 1
name: Héctor F.
lastnames: Soto
sex: true
role: 5
description: Secretario Interino,Concilio de las Iglesias de PR
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:36:12.730086000 Z
updated_at: 2015-03-04 19:36:12.730086000 Z
', '2015-03-04 19:40:12.389907');
INSERT INTO versions VALUES (1053, 'Person', 376, 'update', NULL, '---
id: 376
salutation: 
name: Brunilda
lastnames: Gónzalez
sex: false
role: 4
description: Secretaria
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:36:34.458007000 Z
updated_at: 2015-03-04 19:36:34.458007000 Z
', '2015-03-04 19:40:12.403317');
INSERT INTO versions VALUES (1054, 'Person', 377, 'update', NULL, '---
id: 377
salutation: 0
name: Walleska
lastnames: Febres
sex: false
role: 5
description: Misionera
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:37:09.323060000 Z
updated_at: 2015-03-04 19:37:09.323060000 Z
', '2015-03-04 19:40:12.415416');
INSERT INTO versions VALUES (1055, 'Person', 378, 'update', NULL, '---
id: 378
salutation: 1
name: Julio
lastnames: Gónzalez
sex: true
role: 4
description: Vocal
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:39:38.442108000 Z
updated_at: 2015-03-04 19:39:38.442108000 Z
', '2015-03-04 19:40:12.422273');
INSERT INTO versions VALUES (1056, 'Person', 379, 'create', NULL, NULL, '2015-03-04 19:40:24.858564');
INSERT INTO versions VALUES (1057, 'Person', 111, 'update', NULL, '---
id: 111
salutation: 1
name: ''Edwin ''
lastnames: ''Mojica ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 60
created_at: 2015-02-24 02:34:40.419461000 Z
updated_at: 2015-03-02 19:22:39.138066000 Z
', '2015-03-04 19:40:27.37456');
INSERT INTO versions VALUES (1058, 'Person', 371, 'update', NULL, '---
id: 371
salutation: 1
name: Ingrid
lastnames: Roldán
sex: false
role: 5
description: Misionera
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:35:02.987980000 Z
updated_at: 2015-03-04 19:36:18.028346000 Z
', '2015-03-04 19:41:00.142146');
INSERT INTO versions VALUES (1059, 'Person', 369, 'update', NULL, '---
id: 369
salutation: 1
name: Heriberto
lastnames: Martínez
sex: true
role: 5
description: Secretario, Sociedades Biblícas de Puerto Rico
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:31:21.974401000 Z
updated_at: 2015-03-04 19:36:17.957770000 Z
', '2015-03-04 19:41:45.036893');
INSERT INTO versions VALUES (1060, 'Person', 369, 'update', NULL, '---
id: 369
salutation: 1
name: Heriberto
lastnames: Martínez
sex: true
role: 5
description: Secretario, SBPR
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:31:21.974401000 Z
updated_at: 2015-03-04 19:41:45.027830000 Z
', '2015-03-04 19:41:52.054372');
INSERT INTO versions VALUES (1061, 'Person', 373, 'update', NULL, '---
id: 373
salutation: 1
name: Deliris
lastnames: Carrión
sex: false
role: 5
description: Misionera
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:35:40.279900000 Z
updated_at: 2015-03-04 19:40:11.420874000 Z
', '2015-03-04 19:42:02.51693');
INSERT INTO versions VALUES (1062, 'Person', 245, 'update', NULL, '---
id: 245
salutation: 0
name: ''Luis ''
lastnames: Serrano
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 6
created_at: 2015-02-24 15:14:15.607845000 Z
updated_at: 2015-03-02 19:23:44.691243000 Z
', '2015-03-04 19:42:16.179895');
INSERT INTO versions VALUES (1063, 'Person', 380, 'create', NULL, NULL, '2015-03-04 19:42:34.063452');
INSERT INTO versions VALUES (1064, 'Person', 374, 'update', NULL, '---
id: 374
salutation: 1
name: Madeline
lastnames: Flores
sex: false
role: 5
description: Misionera
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:36:12.138507000 Z
updated_at: 2015-03-04 19:40:11.923648000 Z
', '2015-03-04 19:42:41.50041');
INSERT INTO versions VALUES (1065, 'Person', 370, 'update', NULL, '---
id: 370
salutation: 1
name: Dra. Doris
lastnames: García
sex: true
role: 5
description: Presidenta, Seminario Evangélico de Puerto Rico
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:34:30.906062000 Z
updated_at: 2015-03-04 19:36:17.982754000 Z
', '2015-03-04 19:43:01.514638');
INSERT INTO versions VALUES (1066, 'Person', 377, 'update', NULL, '---
id: 377
salutation: 0
name: Walleska
lastnames: Febres
sex: false
role: 5
description: Misionera
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:37:09.323060000 Z
updated_at: 2015-03-04 19:40:12.408591000 Z
', '2015-03-04 19:43:04.75128');
INSERT INTO versions VALUES (1067, 'Person', 370, 'update', NULL, '---
id: 370
salutation: 1
name: Dra. Doris
lastnames: García
sex: true
role: 5
description: Presidenta, SEPR
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:34:30.906062000 Z
updated_at: 2015-03-04 19:43:01.505138000 Z
', '2015-03-04 19:43:10.62202');
INSERT INTO versions VALUES (1068, 'Person', 381, 'create', NULL, NULL, '2015-03-04 19:43:36.651594');
INSERT INTO versions VALUES (1069, 'Person', 382, 'create', NULL, NULL, '2015-03-04 19:43:50.927915');
INSERT INTO versions VALUES (1070, 'Person', 383, 'create', NULL, NULL, '2015-03-04 19:43:54.525289');
INSERT INTO versions VALUES (1077, 'Person', 343, 'update', NULL, '---
id: 343
salutation: 1
name: Ruth A.
lastnames: Martínez
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 10:57:00.490612000 Z
updated_at: 2015-03-04 19:05:53.941670000 Z
', '2015-03-04 19:44:56.443287');
INSERT INTO versions VALUES (1078, 'Person', 384, 'create', NULL, NULL, '2015-03-04 19:45:01.245028');
INSERT INTO versions VALUES (1079, 'Person', 385, 'create', NULL, NULL, '2015-03-04 19:46:07.867232');
INSERT INTO versions VALUES (1080, 'Person', 386, 'create', NULL, NULL, '2015-03-04 19:46:11.219503');
INSERT INTO versions VALUES (1081, 'Person', 387, 'create', NULL, NULL, '2015-03-04 19:46:11.565493');
INSERT INTO versions VALUES (1082, 'Person', 388, 'create', NULL, NULL, '2015-03-04 19:46:44.162888');
INSERT INTO versions VALUES (1089, 'Person', 317, 'update', NULL, '---
id: 317
salutation: 1
name: ''Miladys ''
lastnames: Oliveras
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 49
created_at: 2015-03-02 19:33:26.920211000 Z
updated_at: 2015-03-02 19:42:04.814164000 Z
', '2015-03-04 19:47:28.69414');
INSERT INTO versions VALUES (1090, 'Person', 389, 'create', NULL, NULL, '2015-03-04 19:47:45.75927');
INSERT INTO versions VALUES (1091, 'Person', 271, 'update', NULL, '---
id: 271
salutation: 
name: ''Eddie ''
lastnames: Diaz
sex: true
role: 4
description: ''''
attended: false
printed: true
materials: false
church_id: 108
created_at: 2015-02-24 17:43:15.014054000 Z
updated_at: 2015-03-02 19:23:22.481090000 Z
', '2015-03-04 19:48:17.753109');
INSERT INTO versions VALUES (1092, 'Person', 389, 'update', NULL, '---
id: 389
salutation: 1
name: Irma Violeta
lastnames: Cruz
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:47:45.753261000 Z
updated_at: 2015-03-04 19:47:45.753261000 Z
', '2015-03-04 19:48:33.875981');
INSERT INTO versions VALUES (1093, 'Person', 390, 'create', NULL, NULL, '2015-03-04 19:48:37.391763');
INSERT INTO versions VALUES (1094, 'Person', 391, 'create', NULL, NULL, '2015-03-04 19:48:58.448583');
INSERT INTO versions VALUES (1095, 'Person', 392, 'create', NULL, NULL, '2015-03-04 19:49:24.956503');
INSERT INTO versions VALUES (1096, 'Person', 393, 'create', NULL, NULL, '2015-03-04 19:49:31.954189');
INSERT INTO versions VALUES (1097, 'Person', 385, 'update', NULL, '---
id: 385
salutation: 1
name: Paulita
lastnames: Matos Garcia
sex: true
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:46:07.861347000 Z
updated_at: 2015-03-04 19:47:19.094537000 Z
', '2015-03-04 19:49:48.531584');
INSERT INTO versions VALUES (1098, 'Person', 394, 'create', NULL, NULL, '2015-03-04 19:49:48.681138');
INSERT INTO versions VALUES (1099, 'Person', 395, 'create', NULL, NULL, '2015-03-04 19:50:20.386985');
INSERT INTO versions VALUES (1106, 'Person', 396, 'create', NULL, NULL, '2015-03-04 19:50:37.742264');
INSERT INTO versions VALUES (1107, 'Person', 397, 'create', NULL, NULL, '2015-03-04 19:50:48.036831');
INSERT INTO versions VALUES (1108, 'Person', 364, 'update', NULL, '---
id: 364
salutation: 0
name: Héctor
lastnames: Soto
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 11:19:31.038158000 Z
updated_at: 2015-03-04 11:27:20.279757000 Z
', '2015-03-04 19:50:48.579164');
INSERT INTO versions VALUES (1109, 'Person', 364, 'update', NULL, '---
id: 364
salutation: 0
name: Héctor
lastnames: Soto
sex: true
role: 5
description: Secretario Interino CIPR
attended: false
printed: false
materials: false
church_id: 48
created_at: 2015-03-04 11:19:31.038158000 Z
updated_at: 2015-03-04 19:50:48.574053000 Z
', '2015-03-04 19:51:15.662716');
INSERT INTO versions VALUES (1110, 'Person', 364, 'update', NULL, '---
id: 364
salutation: 0
name: Héctor
lastnames: Soto
sex: true
role: 5
description: Secretario Interino CIPR
attended: false
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 11:19:31.038158000 Z
updated_at: 2015-03-04 19:51:15.653286000 Z
', '2015-03-04 19:51:17.467591');
INSERT INTO versions VALUES (1111, 'Person', 398, 'create', NULL, NULL, '2015-03-04 19:51:28.535115');
INSERT INTO versions VALUES (1112, 'Person', 69, 'update', NULL, '---
id: 69
salutation: 0
name: ''Juan C. ''
lastnames: ''Navarro ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 37
created_at: 2015-02-24 02:06:47.609568000 Z
updated_at: 2015-03-02 19:21:49.629720000 Z
', '2015-03-04 19:51:34.535594');
INSERT INTO versions VALUES (1113, 'Person', 399, 'create', NULL, NULL, '2015-03-04 19:51:53.747542');
INSERT INTO versions VALUES (1114, 'Person', 364, 'update', NULL, '---
id: 364
salutation: 0
name: Héctor
lastnames: Soto
sex: true
role: 5
description: Secretario Interino CIPR
attended: false
printed: false
materials: false
church_id: 48
created_at: 2015-03-04 11:19:31.038158000 Z
updated_at: 2015-03-04 19:51:17.458794000 Z
', '2015-03-04 19:52:08.042232');
INSERT INTO versions VALUES (1115, 'Person', 400, 'create', NULL, NULL, '2015-03-04 19:52:22.29451');
INSERT INTO versions VALUES (1122, 'Person', 401, 'create', NULL, NULL, '2015-03-04 19:52:32.055911');
INSERT INTO versions VALUES (1123, 'Person', 402, 'create', NULL, NULL, '2015-03-04 19:52:46.475556');
INSERT INTO versions VALUES (1124, 'Person', 403, 'create', NULL, NULL, '2015-03-04 19:53:15.72358');
INSERT INTO versions VALUES (1125, 'Person', 404, 'create', NULL, NULL, '2015-03-04 19:53:21.134527');
INSERT INTO versions VALUES (1126, 'Person', 405, 'create', NULL, NULL, '2015-03-04 19:53:29.175814');
INSERT INTO versions VALUES (1127, 'Person', 406, 'create', NULL, NULL, '2015-03-04 19:53:39.967402');
INSERT INTO versions VALUES (1134, 'Person', 407, 'create', NULL, NULL, '2015-03-04 19:54:36.715685');
INSERT INTO versions VALUES (1135, 'Person', 408, 'create', NULL, NULL, '2015-03-04 19:54:57.366892');
INSERT INTO versions VALUES (1136, 'Person', 409, 'create', NULL, NULL, '2015-03-04 19:55:04.166655');
INSERT INTO versions VALUES (1137, 'Person', 410, 'create', NULL, NULL, '2015-03-04 19:55:26.106432');
INSERT INTO versions VALUES (1138, 'Person', 411, 'create', NULL, NULL, '2015-03-04 19:55:52.848676');
INSERT INTO versions VALUES (1139, 'Person', 412, 'create', NULL, NULL, '2015-03-04 19:55:55.488265');
INSERT INTO versions VALUES (1146, 'Person', 413, 'create', NULL, NULL, '2015-03-04 19:56:46.634749');
INSERT INTO versions VALUES (1147, 'Person', 414, 'create', NULL, NULL, '2015-03-04 19:57:00.715567');
INSERT INTO versions VALUES (1148, 'Person', 415, 'create', NULL, NULL, '2015-03-04 19:57:11.334633');
INSERT INTO versions VALUES (1149, 'Person', 416, 'create', NULL, NULL, '2015-03-04 19:57:16.007335');
INSERT INTO versions VALUES (1150, 'Person', 417, 'create', NULL, NULL, '2015-03-04 19:57:32.718329');
INSERT INTO versions VALUES (1157, 'Person', 418, 'create', NULL, NULL, '2015-03-04 19:57:59.794995');
INSERT INTO versions VALUES (1158, 'Person', 419, 'create', NULL, NULL, '2015-03-04 19:58:00.165399');
INSERT INTO versions VALUES (1159, 'Person', 420, 'create', NULL, NULL, '2015-03-04 19:58:28.339462');
INSERT INTO versions VALUES (1160, 'Person', 421, 'create', NULL, NULL, '2015-03-04 19:58:52.631841');
INSERT INTO versions VALUES (1161, 'Person', 422, 'create', NULL, NULL, '2015-03-04 19:58:55.203842');
INSERT INTO versions VALUES (1071, 'Person', 379, 'update', NULL, '---
id: 379
salutation: 1
name: Esteban
lastnames: González Doble
sex: true
role: 5
description: Pastor General IDCPR
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:40:24.852969000 Z
updated_at: 2015-03-04 19:40:24.852969000 Z
', '2015-03-04 19:44:15.648795');
INSERT INTO versions VALUES (1072, 'Person', 369, 'update', NULL, '---
id: 369
salutation: 1
name: Heriberto
lastnames: Martínez
sex: true
role: 5
description: Secretario, SBPR
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:31:21.974401000 Z
updated_at: 2015-03-04 19:41:52.045874000 Z
', '2015-03-04 19:44:15.776911');
INSERT INTO versions VALUES (1073, 'Person', 380, 'update', NULL, '---
id: 380
salutation: 1
name: ''Dr. Daniel Luis ''
lastnames: Flores
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:42:34.058117000 Z
updated_at: 2015-03-04 19:42:34.058117000 Z
', '2015-03-04 19:44:15.784689');
INSERT INTO versions VALUES (1074, 'Person', 370, 'update', NULL, '---
id: 370
salutation: 1
name: Dra. Doris
lastnames: García
sex: true
role: 5
description: Presidenta, SEPR
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:34:30.906062000 Z
updated_at: 2015-03-04 19:43:10.614285000 Z
', '2015-03-04 19:44:15.790032');
INSERT INTO versions VALUES (1075, 'Person', 381, 'update', NULL, '---
id: 381
salutation: 
name: Alexandra
lastnames: Zavala
sex: true
role: 4
description: Representante General
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:43:36.645025000 Z
updated_at: 2015-03-04 19:43:36.645025000 Z
', '2015-03-04 19:44:15.79495');
INSERT INTO versions VALUES (1076, 'Person', 382, 'update', NULL, '---
id: 382
salutation: 1
name: ''Carlos ''
lastnames: Gomez
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:43:50.921234000 Z
updated_at: 2015-03-04 19:43:50.921234000 Z
', '2015-03-04 19:44:15.820148');
INSERT INTO versions VALUES (1083, 'Person', 383, 'update', NULL, '---
id: 383
salutation: 1
name: Ketley
lastnames: Pierre
sex: false
role: 5
description: Misionera en Nicaragua
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:43:54.519804000 Z
updated_at: 2015-03-04 19:43:54.519804000 Z
', '2015-03-04 19:47:19.044865');
INSERT INTO versions VALUES (1084, 'Person', 384, 'update', NULL, '---
id: 384
salutation: 1
name: Clodomiro
lastnames: Crespo
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:45:01.239306000 Z
updated_at: 2015-03-04 19:45:01.239306000 Z
', '2015-03-04 19:47:19.092607');
INSERT INTO versions VALUES (1085, 'Person', 385, 'update', NULL, '---
id: 385
salutation: 1
name: Paulita
lastnames: Matos Garcia
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:46:07.861347000 Z
updated_at: 2015-03-04 19:46:07.861347000 Z
', '2015-03-04 19:47:19.100902');
INSERT INTO versions VALUES (1086, 'Person', 386, 'update', NULL, '---
id: 386
salutation: 1
name: José
lastnames: Norat Rodríguez
sex: true
role: 5
description: Dir. Area Iberoamérica-Caribe Minist. Inter.
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:46:11.213459000 Z
updated_at: 2015-03-04 19:46:11.213459000 Z
', '2015-03-04 19:47:19.105809');
INSERT INTO versions VALUES (1087, 'Person', 387, 'update', NULL, '---
id: 387
salutation: 
name: Julio
lastnames: Quiros
sex: true
role: 4
description: Representante General
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:46:11.562372000 Z
updated_at: 2015-03-04 19:46:11.562372000 Z
', '2015-03-04 19:47:19.11191');
INSERT INTO versions VALUES (1088, 'Person', 388, 'update', NULL, '---
id: 388
salutation: 1
name: Mayra
lastnames: Giovannetti
sex: false
role: 5
description: Misionera en Nicaragua
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:46:44.155826000 Z
updated_at: 2015-03-04 19:46:44.155826000 Z
', '2015-03-04 19:47:19.121228');
INSERT INTO versions VALUES (1100, 'Person', 389, 'update', NULL, '---
id: 389
salutation: 1
name: Irma Violeta
lastnames: Cruz
sex: false
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:47:45.753261000 Z
updated_at: 2015-03-04 19:48:33.869375000 Z
', '2015-03-04 19:50:22.403739');
INSERT INTO versions VALUES (1101, 'Person', 390, 'update', NULL, '---
id: 390
salutation: 1
name: Salvador
lastnames: Orellana
sex: true
role: 5
description: Coord. Nac. Minist. Inter.ABHMS
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:48:37.386472000 Z
updated_at: 2015-03-04 19:48:37.386472000 Z
', '2015-03-04 19:50:22.439597');
INSERT INTO versions VALUES (1102, 'Person', 391, 'update', NULL, '---
id: 391
salutation: 1
name: Tomás
lastnames: Rojas
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:48:58.443066000 Z
updated_at: 2015-03-04 19:48:58.443066000 Z
', '2015-03-04 19:50:22.464839');
INSERT INTO versions VALUES (1103, 'Person', 392, 'update', NULL, '---
id: 392
salutation: 1
name: Petra A.
lastnames: Urbina
sex: false
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:49:24.950424000 Z
updated_at: 2015-03-04 19:49:24.950424000 Z
', '2015-03-04 19:50:22.473351');
INSERT INTO versions VALUES (1104, 'Person', 393, 'update', NULL, '---
id: 393
salutation: 
name: Gonzalo
lastnames: Alers
sex: true
role: 4
description: Representante Distrito
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:49:31.948319000 Z
updated_at: 2015-03-04 19:49:31.948319000 Z
', '2015-03-04 19:50:22.480778');
INSERT INTO versions VALUES (1105, 'Person', 394, 'update', NULL, '---
id: 394
salutation: 1
name: Miguel
lastnames: Alvarado
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:49:48.674176000 Z
updated_at: 2015-03-04 19:49:48.674176000 Z
', '2015-03-04 19:50:22.4854');
INSERT INTO versions VALUES (1116, 'Person', 364, 'update', NULL, '---
id: 364
salutation: 1
name: Héctor
lastnames: Soto
sex: true
role: 5
description: Secretario Interino CIPR
attended: false
printed: false
materials: false
church_id: 48
created_at: 2015-03-04 11:19:31.038158000 Z
updated_at: 2015-03-04 19:52:08.033949000 Z
', '2015-03-04 19:52:25.911908');
INSERT INTO versions VALUES (1117, 'Person', 395, 'update', NULL, '---
id: 395
salutation: 1
name: José F.
lastnames: López
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:50:20.385193000 Z
updated_at: 2015-03-04 19:50:20.385193000 Z
', '2015-03-04 19:52:25.969272');
INSERT INTO versions VALUES (1118, 'Person', 396, 'update', NULL, '---
id: 396
salutation: 1
name: rafael
lastnames: davila
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:50:37.735660000 Z
updated_at: 2015-03-04 19:50:37.735660000 Z
', '2015-03-04 19:52:25.975834');
INSERT INTO versions VALUES (1119, 'Person', 397, 'update', NULL, '---
id: 397
salutation: 1
name: Félix
lastnames: Rivera
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:50:48.030418000 Z
updated_at: 2015-03-04 19:50:48.030418000 Z
', '2015-03-04 19:52:25.985678');
INSERT INTO versions VALUES (1120, 'Person', 398, 'update', NULL, '---
id: 398
salutation: 1
name: arcadio
lastnames: gonzalez
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:51:28.532266000 Z
updated_at: 2015-03-04 19:51:28.532266000 Z
', '2015-03-04 19:52:25.998602');
INSERT INTO versions VALUES (1121, 'Person', 399, 'update', NULL, '---
id: 399
salutation: 1
name: Dr. Evaldo C.
lastnames: Roura Ortiz
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:51:53.742181000 Z
updated_at: 2015-03-04 19:51:53.742181000 Z
', '2015-03-04 19:52:26.005675');
INSERT INTO versions VALUES (1128, 'Person', 400, 'update', NULL, '---
id: 400
salutation: 0
name: Pedro
lastnames: Parrilla
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:52:22.289306000 Z
updated_at: 2015-03-04 19:52:22.289306000 Z
', '2015-03-04 19:54:29.308743');
INSERT INTO versions VALUES (1129, 'Person', 401, 'update', NULL, '---
id: 401
salutation: 
name: ''Alfredo ''
lastnames: Laboy
sex: true
role: 4
description: Representante Distrito
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:52:32.052594000 Z
updated_at: 2015-03-04 19:52:32.052594000 Z
', '2015-03-04 19:54:29.34686');
INSERT INTO versions VALUES (1130, 'Person', 402, 'update', NULL, '---
id: 402
salutation: 1
name: Dr. Héctor Manuel
lastnames: Rivera
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:52:46.470247000 Z
updated_at: 2015-03-04 19:52:46.470247000 Z
', '2015-03-04 19:54:29.368512');
INSERT INTO versions VALUES (1131, 'Person', 403, 'update', NULL, '---
id: 403
salutation: 1
name: Daniel
lastnames: Flores
sex: true
role: 4
description: Representante Distrito
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:53:15.717243000 Z
updated_at: 2015-03-04 19:53:15.717243000 Z
', '2015-03-04 19:54:29.377781');
INSERT INTO versions VALUES (1132, 'Person', 404, 'update', NULL, '---
id: 404
salutation: 1
name: José
lastnames: Flores
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:53:21.128695000 Z
updated_at: 2015-03-04 19:53:21.128695000 Z
', '2015-03-04 19:54:29.38216');
INSERT INTO versions VALUES (1133, 'Person', 405, 'update', NULL, '---
id: 405
salutation: 1
name: Dr. Cristino
lastnames: diaz montañez
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:53:29.169968000 Z
updated_at: 2015-03-04 19:53:29.169968000 Z
', '2015-03-04 19:54:29.389733');
INSERT INTO versions VALUES (1140, 'Person', 406, 'update', NULL, '---
id: 406
salutation: 1
name: Eva
lastnames: Barreto
sex: false
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:53:39.961680000 Z
updated_at: 2015-03-04 19:53:39.961680000 Z
', '2015-03-04 19:56:32.555152');
INSERT INTO versions VALUES (1141, 'Person', 407, 'update', NULL, '---
id: 407
salutation: 1
name: roberto
lastnames: pabellon
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:54:36.710823000 Z
updated_at: 2015-03-04 19:54:36.710823000 Z
', '2015-03-04 19:56:32.877775');
INSERT INTO versions VALUES (1142, 'Person', 408, 'update', NULL, '---
id: 408
salutation: 1
name: Luis A.
lastnames: Navarro
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:54:57.360982000 Z
updated_at: 2015-03-04 19:54:57.360982000 Z
', '2015-03-04 19:56:32.888678');
INSERT INTO versions VALUES (1143, 'Person', 409, 'update', NULL, '---
id: 409
salutation: 1
name: Fela
lastnames: Barruento
sex: true
role: 5
description: National Coodinator PRAM
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:55:04.161644000 Z
updated_at: 2015-03-04 19:55:04.161644000 Z
', '2015-03-04 19:56:32.89741');
INSERT INTO versions VALUES (1144, 'Person', 410, 'update', NULL, '---
id: 410
salutation: 0
name: Rafael
lastnames: Dávila
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:55:26.102035000 Z
updated_at: 2015-03-04 19:55:26.102035000 Z
', '2015-03-04 19:56:32.901513');
INSERT INTO versions VALUES (1145, 'Person', 411, 'update', NULL, '---
id: 411
salutation: 
name: José
lastnames: Pérez
sex: true
role: 4
description: Representante Distrito
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:55:52.843474000 Z
updated_at: 2015-03-04 19:55:52.843474000 Z
', '2015-03-04 19:56:32.908747');
INSERT INTO versions VALUES (1151, 'Person', 412, 'update', NULL, '---
id: 412
salutation: 0
name: Victor
lastnames: Vázquez
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:55:55.483161000 Z
updated_at: 2015-03-04 19:55:55.483161000 Z
', '2015-03-04 19:57:36.087446');
INSERT INTO versions VALUES (1152, 'Person', 413, 'update', NULL, '---
id: 413
salutation: 0
name: Migdalia
lastnames: Núñez
sex: false
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:56:46.628594000 Z
updated_at: 2015-03-04 19:56:46.628594000 Z
', '2015-03-04 19:57:36.164645');
INSERT INTO versions VALUES (1153, 'Person', 414, 'update', NULL, '---
id: 414
salutation: 6
name: ''Héctor ''
lastnames: Gonzáalez
sex: true
role: 5
description: Consejero Hispano, ABCCU/WMS
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:57:00.711374000 Z
updated_at: 2015-03-04 19:57:00.711374000 Z
', '2015-03-04 19:57:36.171482');
INSERT INTO versions VALUES (1154, 'Person', 415, 'update', NULL, '---
id: 415
salutation: 1
name: Dra. Julia
lastnames: Batista
sex: false
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:57:11.327825000 Z
updated_at: 2015-03-04 19:57:11.327825000 Z
', '2015-03-04 19:57:36.176841');
INSERT INTO versions VALUES (1155, 'Person', 416, 'update', NULL, '---
id: 416
salutation: 0
name: jose a.
lastnames: velasquez
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:57:16.001068000 Z
updated_at: 2015-03-04 19:57:16.001068000 Z
', '2015-03-04 19:57:36.184661');
INSERT INTO versions VALUES (1156, 'Person', 417, 'update', NULL, '---
id: 417
salutation: 
name: José L.
lastnames: Alicea
sex: true
role: 4
description: Representante Distrito
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:57:32.710282000 Z
updated_at: 2015-03-04 19:57:32.710282000 Z
', '2015-03-04 19:57:36.193033');
INSERT INTO versions VALUES (1162, 'Person', 423, 'create', NULL, NULL, '2015-03-04 19:59:14.092383');
INSERT INTO versions VALUES (1163, 'Person', 418, 'update', NULL, '---
id: 418
salutation: 1
name: Miriam
lastnames: Chacón Peralta
sex: true
role: 5
description: Representante Regional MMBB
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:57:59.789934000 Z
updated_at: 2015-03-04 19:57:59.789934000 Z
', '2015-03-04 19:59:39.402299');
INSERT INTO versions VALUES (1164, 'Person', 419, 'update', NULL, '---
id: 419
salutation: 0
name: Santiago
lastnames: Sánchez
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:58:00.163474000 Z
updated_at: 2015-03-04 19:58:00.163474000 Z
', '2015-03-04 19:59:39.482287');
INSERT INTO versions VALUES (1165, 'Person', 420, 'update', NULL, '---
id: 420
salutation: 0
name: rafael
lastnames: rodriguez
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:58:28.334312000 Z
updated_at: 2015-03-04 19:58:28.334312000 Z
', '2015-03-04 19:59:39.491964');
INSERT INTO versions VALUES (1166, 'Person', 421, 'update', NULL, '---
id: 421
salutation: 0
name: Plácido
lastnames: Reyes
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:58:52.625850000 Z
updated_at: 2015-03-04 19:58:52.625850000 Z
', '2015-03-04 19:59:39.502189');
INSERT INTO versions VALUES (1167, 'Person', 422, 'update', NULL, '---
id: 422
salutation: 1
name: Don
lastnames: Ng
sex: true
role: 5
description: Presidente IBA
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:58:55.198491000 Z
updated_at: 2015-03-04 19:58:55.198491000 Z
', '2015-03-04 19:59:39.506453');
INSERT INTO versions VALUES (1168, 'Person', 423, 'update', NULL, '---
id: 423
salutation: 1
name: Luis
lastnames: Ortiz
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:59:14.085644000 Z
updated_at: 2015-03-04 19:59:14.085644000 Z
', '2015-03-04 19:59:39.512812');
INSERT INTO versions VALUES (1169, 'Person', 424, 'create', NULL, NULL, '2015-03-04 19:59:57.449565');
INSERT INTO versions VALUES (1170, 'Person', 425, 'create', NULL, NULL, '2015-03-04 20:00:24.977516');
INSERT INTO versions VALUES (1171, 'Person', 255, 'update', NULL, '---
id: 255
salutation: 0
name: ''Edgardo ''
lastnames: Caraballo
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 18
created_at: 2015-02-24 15:30:51.289108000 Z
updated_at: 2015-03-02 19:21:13.970112000 Z
', '2015-03-04 20:00:54.766585');
INSERT INTO versions VALUES (1172, 'Person', 426, 'create', NULL, NULL, '2015-03-04 20:01:00.334168');
INSERT INTO versions VALUES (1173, 'Person', 427, 'create', NULL, NULL, '2015-03-04 20:01:05.91375');
INSERT INTO versions VALUES (1174, 'Person', 428, 'create', NULL, NULL, '2015-03-04 20:01:27.478964');
INSERT INTO versions VALUES (1175, 'Person', 429, 'create', NULL, NULL, '2015-03-04 20:01:53.797899');
INSERT INTO versions VALUES (1176, 'Person', 430, 'create', NULL, NULL, '2015-03-04 20:01:55.726395');
INSERT INTO versions VALUES (1177, 'Person', 431, 'create', NULL, NULL, '2015-03-04 20:02:22.968543');
INSERT INTO versions VALUES (1179, 'Person', 424, 'update', NULL, '---
id: 424
salutation: 1
name: Dr. Efraín
lastnames: Figueroa
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:59:57.444176000 Z
updated_at: 2015-03-04 19:59:57.444176000 Z
', '2015-03-04 20:02:42.801224');
INSERT INTO versions VALUES (1180, 'Person', 425, 'update', NULL, '---
id: 425
salutation: 1
name: Rubén
lastnames: Figueroa
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:00:24.971762000 Z
updated_at: 2015-03-04 20:00:24.971762000 Z
', '2015-03-04 20:02:42.831332');
INSERT INTO versions VALUES (1181, 'Person', 426, 'update', NULL, '---
id: 426
salutation: 1
name: Elpidio
lastnames: Jiménez
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:01:00.327583000 Z
updated_at: 2015-03-04 20:01:00.327583000 Z
', '2015-03-04 20:02:42.83885');
INSERT INTO versions VALUES (1182, 'Person', 427, 'update', NULL, '---
id: 427
salutation: 2
name: Laura
lastnames: Miraz
sex: true
role: 5
description: Director Ejec. Asociado, Board Staff Services
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:01:05.908035000 Z
updated_at: 2015-03-04 20:01:05.908035000 Z
', '2015-03-04 20:02:42.846196');
INSERT INTO versions VALUES (1183, 'Person', 428, 'update', NULL, '---
id: 428
salutation: 1
name: Dr. David
lastnames: Casillas
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:01:27.472776000 Z
updated_at: 2015-03-04 20:01:27.472776000 Z
', '2015-03-04 20:02:42.854364');
INSERT INTO versions VALUES (1184, 'Person', 429, 'update', NULL, '---
id: 429
salutation: 1
name: Jorge L.
lastnames: Aledo
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:01:53.792872000 Z
updated_at: 2015-03-04 20:01:53.792872000 Z
', '2015-03-04 20:02:42.883271');
INSERT INTO versions VALUES (1189, 'Person', 430, 'update', NULL, '---
id: 430
salutation: 
name: Angelique
lastnames: Acevedo
sex: false
role: 4
description: Representante Distrito
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:01:55.722466000 Z
updated_at: 2015-03-04 20:01:55.722466000 Z
', '2015-03-04 20:03:46.194986');
INSERT INTO versions VALUES (1190, 'Person', 431, 'update', NULL, '---
id: 431
salutation: 
name: Stan
lastnames: Slade
sex: true
role: 5
description: Consultor Mundial, Ministerios Internacionales
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:02:22.961000000 Z
updated_at: 2015-03-04 20:02:22.961000000 Z
', '2015-03-04 20:03:46.292802');
INSERT INTO versions VALUES (1191, 'Person', 432, 'update', NULL, '---
id: 432
salutation: 0
name: Georgina
lastnames: Rodríguez
sex: false
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:02:23.240620000 Z
updated_at: 2015-03-04 20:02:23.240620000 Z
', '2015-03-04 20:03:46.301765');
INSERT INTO versions VALUES (1192, 'Person', 433, 'update', NULL, '---
id: 433
salutation: 1
name: José A.
lastnames: Alicea
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:02:54.856394000 Z
updated_at: 2015-03-04 20:02:54.856394000 Z
', '2015-03-04 20:03:46.305608');
INSERT INTO versions VALUES (1193, 'Person', 434, 'update', NULL, '---
id: 434
salutation: 
name: José
lastnames: Cirio
sex: true
role: 4
description: Representante Distrito
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:03:00.229594000 Z
updated_at: 2015-03-04 20:03:00.229594000 Z
', '2015-03-04 20:03:46.314723');
INSERT INTO versions VALUES (1194, 'Person', 435, 'update', NULL, '---
id: 435
salutation: 1
name: Aida
lastnames: Castillo
sex: false
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:03:16.083663000 Z
updated_at: 2015-03-04 20:03:16.083663000 Z
', '2015-03-04 20:03:46.31895');
INSERT INTO versions VALUES (1202, 'Person', 436, 'update', NULL, '---
id: 436
salutation: 0
name: Mercedes
lastnames: Ortiz
sex: false
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:03:38.673185000 Z
updated_at: 2015-03-04 20:03:38.673185000 Z
', '2015-03-04 20:09:49.611419');
INSERT INTO versions VALUES (1203, 'Person', 437, 'update', NULL, '---
id: 437
salutation: 
name: Stan
lastnames: Slade
sex: true
role: 5
description: Consultor Mundial, Ministerios Internacionales
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:03:46.887122000 Z
updated_at: 2015-03-04 20:03:46.887122000 Z
', '2015-03-04 20:09:49.732074');
INSERT INTO versions VALUES (1204, 'Person', 438, 'update', NULL, '---
id: 438
salutation: 
name: Stan
lastnames: Slade
sex: true
role: 5
description: Consultor Mundial, Ministerios Internacionales
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:06:08.087245000 Z
updated_at: 2015-03-04 20:06:08.087245000 Z
', '2015-03-04 20:09:49.740002');
INSERT INTO versions VALUES (1205, 'Person', 439, 'update', NULL, '---
id: 439
salutation: 
name: Xiomara A.
lastnames: Medina Ramos
sex: false
role: 4
description: Unión de Jóvenes Bautista de P.R.
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:06:10.236140000 Z
updated_at: 2015-03-04 20:06:10.236140000 Z
', '2015-03-04 20:09:49.747581');
INSERT INTO versions VALUES (1206, 'Person', 440, 'update', NULL, '---
id: 440
salutation: 
name: Luis
lastnames: Coreano
sex: true
role: 4
description: Comisión de Evangelismo
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:08:19.010844000 Z
updated_at: 2015-03-04 20:08:19.010844000 Z
', '2015-03-04 20:09:49.752627');
INSERT INTO versions VALUES (1207, 'Person', 441, 'update', NULL, '---
id: 441
salutation: 
name: ''Gloria ''
lastnames: Vázquez
sex: false
role: 4
description: Comisión de Eduación Cristiana
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:09:32.032224000 Z
updated_at: 2015-03-04 20:09:32.032224000 Z
', '2015-03-04 20:09:49.760744');
INSERT INTO versions VALUES (1217, 'Person', 442, 'update', NULL, '---
id: 442
salutation: 3
name: Raymond
lastnames: Martínez
sex: true
role: 4
description: Comisión de Planificación
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:11:17.805466000 Z
updated_at: 2015-03-04 20:11:17.805466000 Z
', '2015-03-04 20:15:53.013904');
INSERT INTO versions VALUES (1218, 'Person', 443, 'update', NULL, '---
id: 443
salutation: 1
name: Dr. Roberto
lastnames: Dieppa Baéz
sex: true
role: 4
description: Ex-Oficio Ministro Ejecutivo y Asociados
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:11:24.743812000 Z
updated_at: 2015-03-04 20:11:24.743812000 Z
', '2015-03-04 20:15:53.144024');
INSERT INTO versions VALUES (1219, 'Person', 444, 'update', NULL, '---
id: 444
salutation: 1
name: Lydia
lastnames: Reyes
sex: false
role: 4
description: Ex-Oficio Ministro Ejecutivo y Asociados
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:12:18.772563000 Z
updated_at: 2015-03-04 20:12:18.772563000 Z
', '2015-03-04 20:15:53.151897');
INSERT INTO versions VALUES (1220, 'Person', 445, 'update', NULL, '---
id: 445
salutation: 1
name: Noelia
lastnames: Rodriguez
sex: false
role: 4
description: Ex-Oficio Ministro Ejecutivo y Asociados
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:12:43.119888000 Z
updated_at: 2015-03-04 20:12:43.119888000 Z
', '2015-03-04 20:15:53.156717');
INSERT INTO versions VALUES (1221, 'Person', 446, 'update', NULL, '---
id: 446
salutation: 0
name: Felipe
lastnames: Candelaria
sex: true
role: 4
description: Representante en ABC
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:12:48.643667000 Z
updated_at: 2015-03-04 20:12:48.643667000 Z
', '2015-03-04 20:15:53.165105');
INSERT INTO versions VALUES (1222, 'Person', 447, 'update', NULL, '---
id: 447
salutation: 
name: Mary
lastnames: Weaver
sex: false
role: 5
description: Asisente Admin. M.I.
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:14:55.937201000 Z
updated_at: 2015-03-04 20:15:31.722186000 Z
', '2015-03-04 20:15:53.170733');
INSERT INTO versions VALUES (1196, 'Person', 314, 'update', NULL, '---
id: 314
salutation: 1
name: ''Jaime ''
lastnames: Galarza Sierra
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 80
created_at: 2015-03-02 19:31:39.242967000 Z
updated_at: 2015-03-02 19:42:04.776225000 Z
', '2015-03-04 20:04:15.416364');
INSERT INTO versions VALUES (1197, 'Person', 426, 'update', NULL, '---
id: 426
salutation: 1
name: Elpidio
lastnames: Jiménez
sex: true
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:01:00.327583000 Z
updated_at: 2015-03-04 20:02:42.833306000 Z
', '2015-03-04 20:04:17.276902');
INSERT INTO versions VALUES (1198, 'Person', 438, 'create', NULL, NULL, '2015-03-04 20:06:08.091109');
INSERT INTO versions VALUES (1199, 'Person', 439, 'create', NULL, NULL, '2015-03-04 20:06:10.23943');
INSERT INTO versions VALUES (1200, 'Person', 440, 'create', NULL, NULL, '2015-03-04 20:08:19.016088');
INSERT INTO versions VALUES (1201, 'Person', 441, 'create', NULL, NULL, '2015-03-04 20:09:32.038535');
INSERT INTO versions VALUES (1208, 'Person', 442, 'create', NULL, NULL, '2015-03-04 20:11:17.812038');
INSERT INTO versions VALUES (1209, 'Person', 443, 'create', NULL, NULL, '2015-03-04 20:11:24.749031');
INSERT INTO versions VALUES (1210, 'Person', 431, 'update', NULL, '---
id: 431
salutation: 
name: Stan
lastnames: Slade
sex: true
role: 5
description: Consultor Mundial, Ministerios Internacionales
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:02:22.961000000 Z
updated_at: 2015-03-04 20:03:46.288782000 Z
', '2015-03-04 20:12:05.091049');
INSERT INTO versions VALUES (1211, 'Person', 444, 'create', NULL, NULL, '2015-03-04 20:12:18.777259');
INSERT INTO versions VALUES (1212, 'Person', 445, 'create', NULL, NULL, '2015-03-04 20:12:43.126046');
INSERT INTO versions VALUES (1213, 'Person', 446, 'create', NULL, NULL, '2015-03-04 20:12:48.649097');
INSERT INTO versions VALUES (1214, 'Person', 447, 'create', NULL, NULL, '2015-03-04 20:14:55.942823');
INSERT INTO versions VALUES (1215, 'Person', 447, 'update', NULL, '---
id: 447
salutation: 
name: Mary
lastnames: Weaver
sex: false
role: 5
description: Asisente Adm. M.I.
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:14:55.937201000 Z
updated_at: 2015-03-04 20:14:55.937201000 Z
', '2015-03-04 20:15:31.731579');
INSERT INTO versions VALUES (1216, 'Person', 448, 'create', NULL, NULL, '2015-03-04 20:15:42.06128');
INSERT INTO versions VALUES (1223, 'Person', 449, 'create', NULL, NULL, '2015-03-04 20:16:29.024698');
INSERT INTO versions VALUES (1224, 'Person', 450, 'create', NULL, NULL, '2015-03-04 20:16:37.988988');
INSERT INTO versions VALUES (1225, 'Person', 451, 'create', NULL, NULL, '2015-03-04 20:17:52.99106');
INSERT INTO versions VALUES (1226, 'Person', 452, 'create', NULL, NULL, '2015-03-04 20:18:41.623611');
INSERT INTO versions VALUES (1227, 'Person', 371, 'update', NULL, '---
id: 371
salutation: 1
name: Ingrid
lastnames: Roldán
sex: false
role: 5
description: Misionera en Panamá
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:35:02.987980000 Z
updated_at: 2015-03-04 19:41:00.136272000 Z
', '2015-03-04 20:19:25.558043');
INSERT INTO versions VALUES (1228, 'Person', 111, 'update', NULL, '---
id: 111
salutation: 1
name: ''Edwin ''
lastnames: ''Mojica ''
sex: true
role: 4
description: Vocal
attended: false
printed: true
materials: false
church_id: 60
created_at: 2015-02-24 02:34:40.419461000 Z
updated_at: 2015-03-04 19:40:27.371496000 Z
', '2015-03-04 20:19:34.412554');
INSERT INTO versions VALUES (1229, 'Person', 373, 'update', NULL, '---
id: 373
salutation: 1
name: Deliris
lastnames: Carrión
sex: false
role: 5
description: Misionera en Haíti
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:35:40.279900000 Z
updated_at: 2015-03-04 19:42:02.508003000 Z
', '2015-03-04 20:19:53.669713');
INSERT INTO versions VALUES (1230, 'Person', 453, 'create', NULL, NULL, '2015-03-04 20:19:56.102358');
INSERT INTO versions VALUES (1237, 'Person', 374, 'update', NULL, '---
id: 374
salutation: 1
name: Madeline
lastnames: Flores
sex: false
role: 5
description: Misionera en República Dominicana
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:36:12.138507000 Z
updated_at: 2015-03-04 19:42:41.492901000 Z
', '2015-03-04 20:20:05.241081');
INSERT INTO versions VALUES (1238, 'Person', 454, 'create', NULL, NULL, '2015-03-04 20:20:06.7099');
INSERT INTO versions VALUES (1239, 'Person', 377, 'update', NULL, '---
id: 377
salutation: 0
name: Walleska
lastnames: Febres
sex: false
role: 5
description: Misionera en Colombia
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:37:09.323060000 Z
updated_at: 2015-03-04 19:43:04.748546000 Z
', '2015-03-04 20:20:16.50193');
INSERT INTO versions VALUES (1240, 'Person', 245, 'update', NULL, '---
id: 245
salutation: 0
name: ''Luis ''
lastnames: Serrano
sex: true
role: 4
description: Representante General
attended: false
printed: true
materials: false
church_id: 6
created_at: 2015-02-24 15:14:15.607845000 Z
updated_at: 2015-03-04 19:42:16.171407000 Z
', '2015-03-04 20:20:21.946104');
INSERT INTO versions VALUES (1241, 'Person', 383, 'update', NULL, '---
id: 383
salutation: 1
name: Ketley
lastnames: Pierre
sex: false
role: 5
description: Misionera en Nicaragua
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:43:54.519804000 Z
updated_at: 2015-03-04 19:47:19.041526000 Z
', '2015-03-04 20:20:38.339252');
INSERT INTO versions VALUES (1242, 'Person', 454, 'update', NULL, '---
id: 454
salutation: 
name: Dr. Reid
lastnames: Trulson
sex: true
role: 5
description: Dirctor Ejecutivo M.I.
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:20:06.703008000 Z
updated_at: 2015-03-04 20:20:06.703008000 Z
', '2015-03-04 20:20:38.414858');
INSERT INTO versions VALUES (1243, 'Person', 343, 'update', NULL, '---
id: 343
salutation: 1
name: Ruth A.
lastnames: Martínez
sex: false
role: 4
description: Representante General
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 10:57:00.490612000 Z
updated_at: 2015-03-04 19:44:56.433892000 Z
', '2015-03-04 20:20:41.468398');
INSERT INTO versions VALUES (1244, 'Person', 388, 'update', NULL, '---
id: 388
salutation: 1
name: Mayra
lastnames: Giovannetti
sex: false
role: 5
description: Misionera en Nicaragua
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:46:44.155826000 Z
updated_at: 2015-03-04 19:47:19.114098000 Z
', '2015-03-04 20:20:46.35371');
INSERT INTO versions VALUES (1245, 'Person', 438, 'destroy', NULL, '---
id: 438
salutation: 
name: Stan
lastnames: Slade
sex: true
role: 5
description: Consultor Mundial, Ministerios Internacionales
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:06:08.087245000 Z
updated_at: 2015-03-04 20:09:49.734517000 Z
', '2015-03-04 20:20:56.075094');
INSERT INTO versions VALUES (1252, 'Person', 437, 'destroy', NULL, '---
id: 437
salutation: 
name: Stan
lastnames: Slade
sex: true
role: 5
description: Consultor Mundial, Ministerios Internacionales
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:03:46.887122000 Z
updated_at: 2015-03-04 20:09:49.729345000 Z
', '2015-03-04 20:21:05.483526');
INSERT INTO versions VALUES (1253, 'Person', 317, 'update', NULL, '---
id: 317
salutation: 1
name: ''Miladys ''
lastnames: Oliveras
sex: false
role: 4
description: Representante Distrito
attended: false
printed: true
materials: false
church_id: 49
created_at: 2015-03-02 19:33:26.920211000 Z
updated_at: 2015-03-04 19:47:28.684600000 Z
', '2015-03-04 20:21:10.288781');
INSERT INTO versions VALUES (1254, 'Person', 271, 'update', NULL, '---
id: 271
salutation: 
name: ''Eddie ''
lastnames: Diaz
sex: true
role: 4
description: Representante Distrito
attended: false
printed: true
materials: false
church_id: 108
created_at: 2015-02-24 17:43:15.014054000 Z
updated_at: 2015-03-04 19:48:17.744261000 Z
', '2015-03-04 20:21:33.974184');
INSERT INTO versions VALUES (1255, 'Person', 431, 'update', NULL, '---
id: 431
salutation: 
name: Stan
lastnames: Slade
sex: true
role: 5
description: Consultor Mundial MI
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:02:22.961000000 Z
updated_at: 2015-03-04 20:12:05.083394000 Z
', '2015-03-04 20:21:42.811328');
INSERT INTO versions VALUES (1256, 'Person', 69, 'update', NULL, '---
id: 69
salutation: 0
name: ''Juan C. ''
lastnames: ''Navarro ''
sex: true
role: 4
description: Comisión de Mayordomía y Misiones
attended: false
printed: true
materials: false
church_id: 37
created_at: 2015-02-24 02:06:47.609568000 Z
updated_at: 2015-03-04 19:51:34.527145000 Z
', '2015-03-04 20:21:55.997675');
INSERT INTO versions VALUES (1263, 'Person', 266, 'destroy', NULL, '---
id: 266
salutation: 
name: ''Deliris ''
lastnames: ''Carrión ''
sex: false
role: 5
description: ''''
attended: false
printed: true
materials: false
church_id: 69
created_at: 2015-02-24 15:41:10.184324000 Z
updated_at: 2015-03-02 19:22:35.663569000 Z
', '2015-03-04 20:22:15.519405');
INSERT INTO versions VALUES (1231, 'Person', 111, 'update', NULL, '---
id: 111
salutation: 1
name: ''Edwin ''
lastnames: ''Mojica ''
sex: true
role: 4
description: Vocal
attended: false
printed: false
materials: false
church_id: 60
created_at: 2015-02-24 02:34:40.419461000 Z
updated_at: 2015-03-04 20:19:34.407213000 Z
', '2015-03-04 20:19:56.514929');
INSERT INTO versions VALUES (1232, 'Person', 448, 'update', NULL, '---
id: 448
salutation: 2
name: Manuel
lastnames: Sarrias
sex: true
role: 5
description: Ministro Ejecutivo España
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:15:42.059218000 Z
updated_at: 2015-03-04 20:15:42.059218000 Z
', '2015-03-04 20:19:56.652901');
INSERT INTO versions VALUES (1233, 'Person', 449, 'update', NULL, '---
id: 449
salutation: 
name: José
lastnames: Martínez
sex: true
role: 5
description: Logos
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:16:29.018027000 Z
updated_at: 2015-03-04 20:16:29.018027000 Z
', '2015-03-04 20:19:56.660091');
INSERT INTO versions VALUES (1234, 'Person', 450, 'update', NULL, '---
id: 450
salutation: 
name: Danny
lastnames: Martinez
sex: true
role: 5
description: Seguros Danny Martinez
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:16:37.986405000 Z
updated_at: 2015-03-04 20:16:37.986405000 Z
', '2015-03-04 20:19:56.66785');
INSERT INTO versions VALUES (1235, 'Person', 451, 'update', NULL, '---
id: 451
salutation: 
name: ''Jim ''
lastnames: Weigner
sex: true
role: 5
description: Ministerios Internacionales
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:17:52.985921000 Z
updated_at: 2015-03-04 20:17:52.985921000 Z
', '2015-03-04 20:19:56.673191');
INSERT INTO versions VALUES (1236, 'Person', 452, 'update', NULL, '---
id: 452
salutation: 
name: Leo S.
lastnames: Thorn
sex: true
role: 5
description: Associate General Sec. ABC
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:18:41.617982000 Z
updated_at: 2015-03-04 20:18:41.617982000 Z
', '2015-03-04 20:19:56.678233');
INSERT INTO versions VALUES (1246, 'Person', 343, 'update', NULL, '---
id: 343
salutation: 1
name: Ruth A.
lastnames: Martínez
sex: false
role: 4
description: Representante General
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 10:57:00.490612000 Z
updated_at: 2015-03-04 20:20:41.458648000 Z
', '2015-03-04 20:21:00.181485');
INSERT INTO versions VALUES (1247, 'Person', 245, 'update', NULL, '---
id: 245
salutation: 0
name: ''Luis ''
lastnames: Serrano
sex: true
role: 4
description: Representante General
attended: false
printed: false
materials: false
church_id: 6
created_at: 2015-02-24 15:14:15.607845000 Z
updated_at: 2015-03-04 20:20:21.936777000 Z
', '2015-03-04 20:21:00.221678');
INSERT INTO versions VALUES (1248, 'Person', 371, 'update', NULL, '---
id: 371
salutation: 1
name: Ingrid
lastnames: Roldán
sex: false
role: 5
description: Misionera en Panamá
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:35:02.987980000 Z
updated_at: 2015-03-04 20:19:25.548474000 Z
', '2015-03-04 20:21:00.229527');
INSERT INTO versions VALUES (1249, 'Person', 373, 'update', NULL, '---
id: 373
salutation: 1
name: Deliris
lastnames: Carrión
sex: false
role: 5
description: Misionera en Haíti
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:35:40.279900000 Z
updated_at: 2015-03-04 20:19:53.660399000 Z
', '2015-03-04 20:21:00.236557');
INSERT INTO versions VALUES (1250, 'Person', 453, 'update', NULL, '---
id: 453
salutation: 1
name: Roy
lastnames: Medley
sex: true
role: 5
description: Secretario General ABC
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:19:56.100619000 Z
updated_at: 2015-03-04 20:19:56.100619000 Z
', '2015-03-04 20:21:00.24594');
INSERT INTO versions VALUES (1251, 'Person', 374, 'update', NULL, '---
id: 374
salutation: 1
name: Madeline
lastnames: Flores
sex: false
role: 5
description: Misionera en República Dominicana
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:36:12.138507000 Z
updated_at: 2015-03-04 20:20:05.233576000 Z
', '2015-03-04 20:21:00.252519');
INSERT INTO versions VALUES (1257, 'Person', 69, 'update', NULL, '---
id: 69
salutation: 0
name: ''Juan C. ''
lastnames: ''Navarro ''
sex: true
role: 4
description: Comisión de Mayordomía y Misiones
attended: false
printed: false
materials: false
church_id: 37
created_at: 2015-02-24 02:06:47.609568000 Z
updated_at: 2015-03-04 20:21:55.988312000 Z
', '2015-03-04 20:22:03.607209');
INSERT INTO versions VALUES (1258, 'Person', 271, 'update', NULL, '---
id: 271
salutation: 
name: ''Eddie ''
lastnames: Diaz
sex: true
role: 4
description: Representante Distrito
attended: false
printed: false
materials: false
church_id: 108
created_at: 2015-02-24 17:43:15.014054000 Z
updated_at: 2015-03-04 20:21:33.966142000 Z
', '2015-03-04 20:22:03.696713');
INSERT INTO versions VALUES (1259, 'Person', 317, 'update', NULL, '---
id: 317
salutation: 1
name: ''Miladys ''
lastnames: Oliveras
sex: false
role: 4
description: Representante Distrito
attended: false
printed: false
materials: false
church_id: 49
created_at: 2015-03-02 19:33:26.920211000 Z
updated_at: 2015-03-04 20:21:10.278374000 Z
', '2015-03-04 20:22:03.717874');
INSERT INTO versions VALUES (1260, 'Person', 377, 'update', NULL, '---
id: 377
salutation: 0
name: Walleska
lastnames: Febres
sex: false
role: 5
description: Misionera en Colombia
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:37:09.323060000 Z
updated_at: 2015-03-04 20:20:16.493622000 Z
', '2015-03-04 20:22:03.734431');
INSERT INTO versions VALUES (1261, 'Person', 383, 'update', NULL, '---
id: 383
salutation: 1
name: Ketley
lastnames: Pierre
sex: false
role: 5
description: Misionera en Nicaragua
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:43:54.519804000 Z
updated_at: 2015-03-04 20:20:38.330222000 Z
', '2015-03-04 20:22:03.807105');
INSERT INTO versions VALUES (1262, 'Person', 454, 'update', NULL, '---
id: 454
salutation: 
name: Dr. Reid
lastnames: Trulson
sex: true
role: 5
description: Director Ejecutivo M.I.
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:20:06.703008000 Z
updated_at: 2015-03-04 20:20:38.409576000 Z
', '2015-03-04 20:22:03.815375');
INSERT INTO versions VALUES (1270, 'Person', 255, 'update', NULL, '---
id: 255
salutation: 0
name: ''Edgardo ''
lastnames: Caraballo
sex: true
role: 4
description: Representante Distrito
attended: false
printed: false
materials: false
church_id: 18
created_at: 2015-02-24 15:30:51.289108000 Z
updated_at: 2015-03-04 20:22:25.257709000 Z
', '2015-03-04 20:24:07.516992');
INSERT INTO versions VALUES (1271, 'Person', 195, 'update', NULL, '---
id: 195
salutation: 
name: ''Arelys ''
lastnames: Ortiz
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 14:34:57.882413000 Z
updated_at: 2015-03-04 20:22:59.939458000 Z
', '2015-03-04 20:24:07.600623');
INSERT INTO versions VALUES (1272, 'Person', 197, 'update', NULL, '---
id: 197
salutation: 
name: ''Daisy ''
lastnames: García
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 14:36:01.266279000 Z
updated_at: 2015-03-04 20:23:20.519668000 Z
', '2015-03-04 20:24:07.607258');
INSERT INTO versions VALUES (1273, 'Person', 199, 'update', NULL, '---
id: 199
salutation: 
name: ''David ''
lastnames: ''Morales ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 14:36:58.831092000 Z
updated_at: 2015-03-04 20:24:01.384736000 Z
', '2015-03-04 20:24:07.613495');
INSERT INTO versions VALUES (1274, 'Person', 388, 'update', NULL, '---
id: 388
salutation: 1
name: Mayra
lastnames: Giovannetti
sex: false
role: 5
description: Misionera en Nicaragua
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:46:44.155826000 Z
updated_at: 2015-03-04 20:20:46.344258000 Z
', '2015-03-04 20:24:07.620983');
INSERT INTO versions VALUES (1275, 'Person', 431, 'update', NULL, '---
id: 431
salutation: 
name: Stan
lastnames: Slade
sex: true
role: 5
description: Consultor Mundial MI
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:02:22.961000000 Z
updated_at: 2015-03-04 20:21:42.803393000 Z
', '2015-03-04 20:24:07.628115');
INSERT INTO versions VALUES (1283, 'Person', 6, 'update', NULL, '---
id: 6
salutation: 1
name: ''Eneida ''
lastnames: Angleró
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 105
created_at: 2015-02-23 22:25:35.265226000 Z
updated_at: 2015-03-04 20:26:35.643763000 Z
', '2015-03-04 20:27:11.004867');
INSERT INTO versions VALUES (1264, 'Person', 255, 'update', NULL, '---
id: 255
salutation: 0
name: ''Edgardo ''
lastnames: Caraballo
sex: true
role: 4
description: Representante Distrito
attended: false
printed: true
materials: false
church_id: 18
created_at: 2015-02-24 15:30:51.289108000 Z
updated_at: 2015-03-04 20:00:54.758917000 Z
', '2015-03-04 20:22:25.266761');
INSERT INTO versions VALUES (1265, 'Person', 195, 'update', NULL, '---
id: 195
salutation: 
name: ''Arelys ''
lastnames: Ortiz
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 69
created_at: 2015-02-24 14:34:57.882413000 Z
updated_at: 2015-03-02 19:22:35.542706000 Z
', '2015-03-04 20:22:57.104602');
INSERT INTO versions VALUES (1266, 'Person', 195, 'update', NULL, '---
id: 195
salutation: 
name: ''Arelys ''
lastnames: Ortiz
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 69
created_at: 2015-02-24 14:34:57.882413000 Z
updated_at: 2015-03-04 20:22:57.099873000 Z
', '2015-03-04 20:22:59.948419');
INSERT INTO versions VALUES (1267, 'Person', 197, 'update', NULL, '---
id: 197
salutation: 
name: ''Daisy ''
lastnames: García
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 69
created_at: 2015-02-24 14:36:01.266279000 Z
updated_at: 2015-03-02 19:22:35.646900000 Z
', '2015-03-04 20:23:20.527245');
INSERT INTO versions VALUES (1268, 'Person', 455, 'create', NULL, NULL, '2015-03-04 20:23:33.062166');
INSERT INTO versions VALUES (1269, 'Person', 199, 'update', NULL, '---
id: 199
salutation: 
name: ''David ''
lastnames: ''Morales ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 69
created_at: 2015-02-24 14:36:58.831092000 Z
updated_at: 2015-03-02 19:22:35.658529000 Z
', '2015-03-04 20:24:01.39003');
INSERT INTO versions VALUES (1276, 'Person', 456, 'create', NULL, NULL, '2015-03-04 20:24:09.810793');
INSERT INTO versions VALUES (1277, 'Person', 455, 'update', NULL, '---
id: 455
salutation: 
name: ''Dr. Reg ''
lastnames: Mills
sex: true
role: 5
description: Presidente Ministerios Internationales
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:23:33.059731000 Z
updated_at: 2015-03-04 20:23:33.059731000 Z
', '2015-03-04 20:24:10.517419');
INSERT INTO versions VALUES (1278, 'Person', 196, 'update', NULL, '---
id: 196
salutation: 
name: ''Jossie ''
lastnames: Sostre
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 69
created_at: 2015-02-24 14:35:32.238243000 Z
updated_at: 2015-03-02 19:22:35.667925000 Z
', '2015-03-04 20:25:34.267772');
INSERT INTO versions VALUES (1279, 'Person', 447, 'update', NULL, '---
id: 447
salutation: 
name: Mary
lastnames: Weaver
sex: false
role: 5
description: Asisente Admin. M.I.
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:14:55.937201000 Z
updated_at: 2015-03-04 20:15:53.167006000 Z
', '2015-03-04 20:25:49.307434');
INSERT INTO versions VALUES (1280, 'Person', 200, 'update', NULL, '---
id: 200
salutation: 
name: ''Minerva ''
lastnames: Rivera
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 69
created_at: 2015-02-24 14:37:42.741944000 Z
updated_at: 2015-03-02 19:22:35.674469000 Z
', '2015-03-04 20:25:59.496134');
INSERT INTO versions VALUES (1281, 'Person', 6, 'update', NULL, '---
id: 6
salutation: 1
name: ''Eneida ''
lastnames: Angleró
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 105
created_at: 2015-02-23 22:25:35.265226000 Z
updated_at: 2015-03-02 19:22:15.614445000 Z
', '2015-03-04 20:26:35.649571');
INSERT INTO versions VALUES (1282, 'Person', 8, 'update', NULL, '---
id: 8
salutation: 
name: ''Rómulo ''
lastnames: ''Ortiz ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 105
created_at: 2015-02-23 22:26:41.588490000 Z
updated_at: 2015-03-02 19:22:15.712505000 Z
', '2015-03-04 20:26:51.427513');
INSERT INTO versions VALUES (1289, 'Person', 414, 'update', NULL, '---
id: 414
salutation: 6
name: ''Héctor ''
lastnames: Gonzáalez
sex: true
role: 5
description: Consejero Hispano, ABCCU/WMS
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:57:00.711374000 Z
updated_at: 2015-03-04 19:57:36.166797000 Z
', '2015-03-04 20:27:30.9035');
INSERT INTO versions VALUES (1290, 'Person', 414, 'update', NULL, '---
id: 414
salutation: 6
name: ''Héctor ''
lastnames: González
sex: true
role: 5
description: Consejero Hispano, ABCCU/WMS
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:57:00.711374000 Z
updated_at: 2015-03-04 20:27:30.898604000 Z
', '2015-03-04 20:27:36.03426');
INSERT INTO versions VALUES (1291, 'Person', 9, 'update', NULL, '---
id: 9
salutation: 
name: ''Wilfredo ''
lastnames: ''Torres ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 105
created_at: 2015-02-23 22:27:06.708956000 Z
updated_at: 2015-03-02 19:22:15.730617000 Z
', '2015-03-04 20:28:30.192572');
INSERT INTO versions VALUES (1292, 'Person', 7, 'update', NULL, '---
id: 7
salutation: 
name: ''Yamalis ''
lastnames: ''González ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 105
created_at: 2015-02-23 22:26:10.392410000 Z
updated_at: 2015-03-02 19:22:15.747353000 Z
', '2015-03-04 20:28:49.213906');
INSERT INTO versions VALUES (1293, 'Person', 364, 'update', NULL, '---
id: 364
salutation: 1
name: Héctor
lastnames: Soto
sex: true
role: 5
description: Secretario Interino CIPR
attended: false
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 11:19:31.038158000 Z
updated_at: 2015-03-04 19:52:25.907722000 Z
', '2015-03-04 20:29:58.347492');
INSERT INTO versions VALUES (1294, 'Person', 231, 'update', NULL, '---
id: 231
salutation: 0
name: ''Celis ''
lastnames: Zambrana Batista
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 45
created_at: 2015-02-24 15:06:14.599552000 Z
updated_at: 2015-03-02 19:22:15.763245000 Z
', '2015-03-04 20:29:58.407698');
INSERT INTO versions VALUES (1295, 'Person', 364, 'update', NULL, '---
id: 364
salutation: 1
name: Héctor F
lastnames: Soto
sex: true
role: 5
description: Secretario Interino CIPR
attended: false
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 11:19:31.038158000 Z
updated_at: 2015-03-04 20:29:58.336960000 Z
', '2015-03-04 20:30:00.041199');
INSERT INTO versions VALUES (1302, 'Person', 231, 'update', NULL, '---
id: 231
salutation: 0
name: ''Celis ''
lastnames: Zambrana Batista
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 45
created_at: 2015-02-24 15:06:14.599552000 Z
updated_at: 2015-03-04 20:30:15.009431000 Z
', '2015-03-04 20:30:19.613408');
INSERT INTO versions VALUES (1303, 'Person', 233, 'update', NULL, '---
id: 233
salutation: 
name: ''David ''
lastnames: ''Soto Cardona ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 45
created_at: 2015-02-24 15:07:18.502531000 Z
updated_at: 2015-03-02 19:22:15.779875000 Z
', '2015-03-04 20:31:05.62316');
INSERT INTO versions VALUES (1304, 'Person', 347, 'destroy', NULL, '---
id: 347
salutation: 4
name: Moisés
lastnames: Martínez
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:02:09.141491000 Z
updated_at: 2015-03-04 19:05:53.303409000 Z
', '2015-03-04 20:32:17.609161');
INSERT INTO versions VALUES (1305, 'Person', 409, 'update', NULL, '---
id: 409
salutation: 1
name: Fela
lastnames: Barruento
sex: true
role: 5
description: National Coodinator PRAM
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:55:04.161644000 Z
updated_at: 2015-03-04 19:56:32.890344000 Z
', '2015-03-04 20:32:50.407613');
INSERT INTO versions VALUES (1306, 'Person', 409, 'update', NULL, '---
id: 409
salutation: 1
name: Fela
lastnames: Barrueto
sex: false
role: 5
description: National Coodinator PRAM
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:55:04.161644000 Z
updated_at: 2015-03-04 20:32:50.396802000 Z
', '2015-03-04 20:32:53.238112');
INSERT INTO versions VALUES (1307, 'Person', 350, 'update', NULL, '---
id: 350
salutation: 
name: Myrna
lastnames: Villafranca
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:03:24.913737000 Z
updated_at: 2015-03-04 19:05:53.606681000 Z
', '2015-03-04 20:33:05.168601');
INSERT INTO versions VALUES (1346, 'Person', 352, 'update', NULL, '---
id: 352
salutation: 1
name: Luis Francisco
lastnames: Alicea Caraballo
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 55
created_at: 2015-03-04 11:04:46.844147000 Z
updated_at: 2015-03-04 11:06:07.118519000 Z
', '2015-03-04 20:49:12.87558');
INSERT INTO versions VALUES (1284, 'Person', 8, 'update', NULL, '---
id: 8
salutation: 
name: ''Rómulo ''
lastnames: ''Ortiz ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 105
created_at: 2015-02-23 22:26:41.588490000 Z
updated_at: 2015-03-04 20:26:51.418628000 Z
', '2015-03-04 20:27:11.078552');
INSERT INTO versions VALUES (1285, 'Person', 196, 'update', NULL, '---
id: 196
salutation: 
name: ''Jossie ''
lastnames: Sostre
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 14:35:32.238243000 Z
updated_at: 2015-03-04 20:25:34.259033000 Z
', '2015-03-04 20:27:11.084781');
INSERT INTO versions VALUES (1286, 'Person', 200, 'update', NULL, '---
id: 200
salutation: 
name: ''Minerva ''
lastnames: Rivera
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 14:37:42.741944000 Z
updated_at: 2015-03-04 20:25:59.487823000 Z
', '2015-03-04 20:27:11.092969');
INSERT INTO versions VALUES (1287, 'Person', 456, 'update', NULL, '---
id: 456
salutation: 0
name: Dr. Aidsan
lastnames: Wright Riggins III
sex: true
role: 5
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:24:09.805368000 Z
updated_at: 2015-03-04 20:24:09.805368000 Z
', '2015-03-04 20:27:11.097249');
INSERT INTO versions VALUES (1288, 'Person', 455, 'update', NULL, '---
id: 455
salutation: 
name: ''Dr. Reg ''
lastnames: Mills
sex: true
role: 5
description: Presidente Ministerios Internacionales
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:23:33.059731000 Z
updated_at: 2015-03-04 20:24:10.511583000 Z
', '2015-03-04 20:27:11.104023');
INSERT INTO versions VALUES (1296, 'Person', 9, 'update', NULL, '---
id: 9
salutation: 
name: ''Wilfredo ''
lastnames: ''Torres ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 105
created_at: 2015-02-23 22:27:06.708956000 Z
updated_at: 2015-03-04 20:28:30.187822000 Z
', '2015-03-04 20:30:14.823382');
INSERT INTO versions VALUES (1297, 'Person', 7, 'update', NULL, '---
id: 7
salutation: 
name: ''Yamalis ''
lastnames: ''González ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 105
created_at: 2015-02-23 22:26:10.392410000 Z
updated_at: 2015-03-04 20:28:49.207923000 Z
', '2015-03-04 20:30:15.0049');
INSERT INTO versions VALUES (1298, 'Person', 231, 'update', NULL, '---
id: 231
salutation: 0
name: ''Celis ''
lastnames: Zambrana Batista
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 45
created_at: 2015-02-24 15:06:14.599552000 Z
updated_at: 2015-03-04 20:29:58.402556000 Z
', '2015-03-04 20:30:15.011977');
INSERT INTO versions VALUES (1299, 'Person', 364, 'update', NULL, '---
id: 364
salutation: 1
name: Héctor F
lastnames: Soto
sex: true
role: 5
description: Secretario Interino CIPR
attended: false
printed: false
materials: false
church_id: 48
created_at: 2015-03-04 11:19:31.038158000 Z
updated_at: 2015-03-04 20:30:00.032400000 Z
', '2015-03-04 20:30:15.021577');
INSERT INTO versions VALUES (1300, 'Person', 447, 'update', NULL, '---
id: 447
salutation: 
name: Mary
lastnames: Weaver
sex: false
role: 5
description: Asistente Admin. M.I.
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:14:55.937201000 Z
updated_at: 2015-03-04 20:25:49.302038000 Z
', '2015-03-04 20:30:15.031304');
INSERT INTO versions VALUES (1301, 'Person', 414, 'update', NULL, '---
id: 414
salutation: 6
name: ''Héctor ''
lastnames: González
sex: true
role: 5
description: Consejero Hispano, ABCCU/WMS
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:57:00.711374000 Z
updated_at: 2015-03-04 20:27:36.025459000 Z
', '2015-03-04 20:30:15.036618');
INSERT INTO versions VALUES (1312, 'Person', 231, 'update', NULL, '---
id: 231
salutation: 0
name: ''Celis ''
lastnames: Zambrana Batista
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 45
created_at: 2015-02-24 15:06:14.599552000 Z
updated_at: 2015-03-04 20:30:19.606778000 Z
', '2015-03-04 20:34:18.391603');
INSERT INTO versions VALUES (1313, 'Person', 233, 'update', NULL, '---
id: 233
salutation: 
name: ''David ''
lastnames: ''Soto Cardona ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 45
created_at: 2015-02-24 15:07:18.502531000 Z
updated_at: 2015-03-04 20:31:05.619327000 Z
', '2015-03-04 20:34:19.623115');
INSERT INTO versions VALUES (1314, 'Person', 350, 'update', NULL, '---
id: 350
salutation: 
name: Myrna
lastnames: Villafranca
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 11:03:24.913737000 Z
updated_at: 2015-03-04 20:33:05.160980000 Z
', '2015-03-04 20:34:19.725554');
INSERT INTO versions VALUES (1315, 'Person', 409, 'update', NULL, '---
id: 409
salutation: 1
name: Fela
lastnames: Barrueto
sex: false
role: 5
description: National Coodinator PRAM
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:55:04.161644000 Z
updated_at: 2015-03-04 20:32:53.226853000 Z
', '2015-03-04 20:34:19.738289');
INSERT INTO versions VALUES (1316, 'Person', 427, 'update', NULL, '---
id: 427
salutation: 2
name: Laura
lastnames: Miraz
sex: false
role: 5
description: Directora Ejec. Asociada, Board Staff Services
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:01:05.908035000 Z
updated_at: 2015-03-04 20:33:42.260642000 Z
', '2015-03-04 20:34:19.748645');
INSERT INTO versions VALUES (1317, 'Person', 418, 'update', NULL, '---
id: 418
salutation: 1
name: Miriam
lastnames: Chacón Peralta
sex: false
role: 5
description: Representante Regional MMBB
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 19:57:59.789934000 Z
updated_at: 2015-03-04 20:33:56.525915000 Z
', '2015-03-04 20:34:19.754259');
INSERT INTO versions VALUES (1325, 'Person', 357, 'update', NULL, '---
id: 357
salutation: 
name: Edgardo
lastnames: López
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 55
created_at: 2015-03-04 11:06:38.050754000 Z
updated_at: 2015-03-04 20:37:35.074383000 Z
', '2015-03-04 20:41:23.36717');
INSERT INTO versions VALUES (1326, 'Person', 356, 'update', NULL, '---
id: 356
salutation: 
name: Maribel
lastnames: Boria
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 55
created_at: 2015-03-04 11:06:18.367635000 Z
updated_at: 2015-03-04 20:37:49.358559000 Z
', '2015-03-04 20:41:23.401336');
INSERT INTO versions VALUES (1327, 'Person', 358, 'update', NULL, '---
id: 358
salutation: 0
name: David A.
lastnames: González
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 16
created_at: 2015-03-04 11:13:02.826787000 Z
updated_at: 2015-03-04 20:39:39.111796000 Z
', '2015-03-04 20:41:23.410098');
INSERT INTO versions VALUES (1328, 'Person', 360, 'update', NULL, '---
id: 360
salutation: 
name: José A.
lastnames: Ortiz Rivera
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 16
created_at: 2015-03-04 11:14:22.501926000 Z
updated_at: 2015-03-04 20:40:11.774595000 Z
', '2015-03-04 20:41:23.422348');
INSERT INTO versions VALUES (1329, 'Person', 359, 'update', NULL, '---
id: 359
salutation: 
name: María V.
lastnames: Colón Alvarado
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 16
created_at: 2015-03-04 11:13:47.821593000 Z
updated_at: 2015-03-04 20:40:38.813754000 Z
', '2015-03-04 20:41:23.42697');
INSERT INTO versions VALUES (1330, 'Person', 431, 'update', NULL, '---
id: 431
salutation: 
name: Stan
lastnames: Slade
sex: true
role: 5
description: Consultor Mundial MI
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:02:22.961000000 Z
updated_at: 2015-03-04 20:34:43.998836000 Z
', '2015-03-04 20:41:23.437345');
INSERT INTO versions VALUES (1308, 'Person', 427, 'update', NULL, '---
id: 427
salutation: 2
name: Laura
lastnames: Miraz
sex: true
role: 5
description: Director Ejec. Asociado, Board Staff Services
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:01:05.908035000 Z
updated_at: 2015-03-04 20:02:42.840781000 Z
', '2015-03-04 20:33:30.11504');
INSERT INTO versions VALUES (1309, 'Person', 427, 'update', NULL, '---
id: 427
salutation: 2
name: Laura
lastnames: Miraz
sex: false
role: 5
description: Directora Ejec. Asociada, Board Staff Services
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:01:05.908035000 Z
updated_at: 2015-03-04 20:33:30.104852000 Z
', '2015-03-04 20:33:42.269273');
INSERT INTO versions VALUES (1310, 'Person', 418, 'update', NULL, '---
id: 418
salutation: 1
name: Miriam
lastnames: Chacón Peralta
sex: true
role: 5
description: Representante Regional MMBB
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:57:59.789934000 Z
updated_at: 2015-03-04 19:59:39.397953000 Z
', '2015-03-04 20:33:54.190089');
INSERT INTO versions VALUES (1311, 'Person', 418, 'update', NULL, '---
id: 418
salutation: 1
name: Miriam
lastnames: Chacón Peralta
sex: false
role: 5
description: Representante Regional MMBB
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:57:59.789934000 Z
updated_at: 2015-03-04 20:33:54.184469000 Z
', '2015-03-04 20:33:56.535518');
INSERT INTO versions VALUES (1318, 'Person', 431, 'update', NULL, '---
id: 431
salutation: 
name: Stan
lastnames: Slade
sex: true
role: 5
description: Consultor Mundial MI
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:02:22.961000000 Z
updated_at: 2015-03-04 20:24:07.625806000 Z
', '2015-03-04 20:34:44.00734');
INSERT INTO versions VALUES (1319, 'Person', 357, 'update', NULL, '---
id: 357
salutation: 
name: Edgardo
lastnames: López
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 55
created_at: 2015-03-04 11:06:38.050754000 Z
updated_at: 2015-03-04 11:15:11.597005000 Z
', '2015-03-04 20:37:35.0803');
INSERT INTO versions VALUES (1320, 'Person', 356, 'update', NULL, '---
id: 356
salutation: 
name: Maribel
lastnames: Boria
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 55
created_at: 2015-03-04 11:06:18.367635000 Z
updated_at: 2015-03-04 11:15:11.737650000 Z
', '2015-03-04 20:37:49.363769');
INSERT INTO versions VALUES (1321, 'Person', 358, 'update', NULL, '---
id: 358
salutation: 0
name: David A.
lastnames: González Meléndez
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:13:02.826787000 Z
updated_at: 2015-03-04 11:15:11.797791000 Z
', '2015-03-04 20:38:48.466721');
INSERT INTO versions VALUES (1322, 'Person', 358, 'update', NULL, '---
id: 358
salutation: 0
name: David A.
lastnames: González Meléndez
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 16
created_at: 2015-03-04 11:13:02.826787000 Z
updated_at: 2015-03-04 20:38:48.461447000 Z
', '2015-03-04 20:39:39.114938');
INSERT INTO versions VALUES (1323, 'Person', 360, 'update', NULL, '---
id: 360
salutation: 
name: José A.
lastnames: Ortiz Rivera
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:14:22.501926000 Z
updated_at: 2015-03-04 11:15:11.803443000 Z
', '2015-03-04 20:40:11.779211');
INSERT INTO versions VALUES (1324, 'Person', 359, 'update', NULL, '---
id: 359
salutation: 
name: María V.
lastnames: Colón Alvarado
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:13:47.821593000 Z
updated_at: 2015-03-04 11:15:11.812701000 Z
', '2015-03-04 20:40:38.818029');
INSERT INTO versions VALUES (1331, 'Person', 365, 'update', NULL, '---
id: 365
salutation: 
name: Ada
lastnames: Serrano
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 11:19:51.909843000 Z
updated_at: 2015-03-04 11:27:19.787991000 Z
', '2015-03-04 20:41:49.211549');
INSERT INTO versions VALUES (1332, 'Person', 375, 'destroy', NULL, '---
id: 375
salutation: 1
name: Héctor F.
lastnames: Soto
sex: true
role: 5
description: Secretario Interino,Concilio de las Iglesias de PR
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:36:12.730086000 Z
updated_at: 2015-03-04 19:40:12.380581000 Z
', '2015-03-04 20:42:34.905448');
INSERT INTO versions VALUES (1333, 'Person', 364, 'update', NULL, '---
id: 364
salutation: 1
name: Héctor F
lastnames: Soto
sex: true
role: 5
description: Secretario Interino CIPR
attended: false
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 11:19:31.038158000 Z
updated_at: 2015-03-04 20:30:15.014851000 Z
', '2015-03-04 20:45:40.473475');
INSERT INTO versions VALUES (1334, 'Person', 457, 'create', NULL, NULL, '2015-03-04 20:46:17.068964');
INSERT INTO versions VALUES (1335, 'Person', 366, 'update', NULL, '---
id: 366
salutation: 
name: Nelson
lastnames: Ortiz
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 11:20:18.775498000 Z
updated_at: 2015-03-04 11:27:20.720984000 Z
', '2015-03-04 20:47:06.097194');
INSERT INTO versions VALUES (1336, 'Person', 361, 'update', NULL, '---
id: 361
salutation: 
name: Ana R.
lastnames: Torres Montañez
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:15:12.300300000 Z
updated_at: 2015-03-04 11:27:20.735408000 Z
', '2015-03-04 20:47:22.703564');
INSERT INTO versions VALUES (1337, 'Person', 363, 'update', NULL, '---
id: 363
salutation: 
name: Gloria
lastnames: Ríos Rolón
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:17:44.881599000 Z
updated_at: 2015-03-04 11:27:20.747005000 Z
', '2015-03-04 20:47:48.20186');
INSERT INTO versions VALUES (1338, 'Person', 362, 'update', NULL, '---
id: 362
salutation: 
name: Pedro P.
lastnames: Santiago Romero
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:17:12.159850000 Z
updated_at: 2015-03-04 11:27:20.752758000 Z
', '2015-03-04 20:48:05.711288');
INSERT INTO versions VALUES (1339, 'Person', 365, 'update', NULL, '---
id: 365
salutation: 
name: Ada
lastnames: Serrano
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 48
created_at: 2015-03-04 11:19:51.909843000 Z
updated_at: 2015-03-04 20:41:49.208365000 Z
', '2015-03-04 20:48:26.939641');
INSERT INTO versions VALUES (1340, 'Person', 457, 'update', NULL, '---
id: 457
salutation: 
name: Héctor
lastnames: Soto
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 48
created_at: 2015-03-04 20:46:17.064976000 Z
updated_at: 2015-03-04 20:46:17.064976000 Z
', '2015-03-04 20:48:26.988826');
INSERT INTO versions VALUES (1341, 'Person', 366, 'update', NULL, '---
id: 366
salutation: 
name: Nelson
lastnames: Ortiz
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 48
created_at: 2015-03-04 11:20:18.775498000 Z
updated_at: 2015-03-04 20:47:06.087286000 Z
', '2015-03-04 20:48:26.994261');
INSERT INTO versions VALUES (1342, 'Person', 361, 'update', NULL, '---
id: 361
salutation: 
name: Ana R.
lastnames: Torres Montañez
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 16
created_at: 2015-03-04 11:15:12.300300000 Z
updated_at: 2015-03-04 20:47:22.695714000 Z
', '2015-03-04 20:48:27.014251');
INSERT INTO versions VALUES (1343, 'Person', 363, 'update', NULL, '---
id: 363
salutation: 
name: Gloria
lastnames: Ríos Rolón
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 16
created_at: 2015-03-04 11:17:44.881599000 Z
updated_at: 2015-03-04 20:47:48.195682000 Z
', '2015-03-04 20:48:27.018197');
INSERT INTO versions VALUES (1344, 'Person', 362, 'update', NULL, '---
id: 362
salutation: 
name: Pedro P.
lastnames: Santiago Romero
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 16
created_at: 2015-03-04 11:17:12.159850000 Z
updated_at: 2015-03-04 20:48:05.706135000 Z
', '2015-03-04 20:48:27.026252');
INSERT INTO versions VALUES (1345, 'Person', 355, 'update', NULL, '---
id: 355
salutation: 
name: Julio
lastnames: Fuentes
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 55
created_at: 2015-03-04 11:05:56.397368000 Z
updated_at: 2015-03-04 11:06:06.965355000 Z
', '2015-03-04 20:49:07.545607');
INSERT INTO versions VALUES (2023, 'Person', 501, 'create', NULL, NULL, '2015-03-05 13:05:38.230928');
INSERT INTO versions VALUES (1347, 'Person', 353, 'update', NULL, '---
id: 353
salutation: 0
name: Pedro
lastnames: Boria Ortiz
sex: true
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 55
created_at: 2015-03-04 11:05:18.260131000 Z
updated_at: 2015-03-04 11:06:07.528750000 Z
', '2015-03-04 20:49:21.958697');
INSERT INTO versions VALUES (1348, 'Person', 354, 'update', NULL, '---
id: 354
salutation: 
name: Ramón
lastnames: García
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 55
created_at: 2015-03-04 11:05:35.219957000 Z
updated_at: 2015-03-04 11:06:07.543917000 Z
', '2015-03-04 20:49:29.833222');
INSERT INTO versions VALUES (1349, 'Person', 351, 'update', NULL, '---
id: 351
salutation: 
name: Francisca
lastnames: Alicea
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:03:46.627915000 Z
updated_at: 2015-03-04 11:28:25.204485000 Z
', '2015-03-04 20:50:31.823151');
INSERT INTO versions VALUES (1350, 'Person', 346, 'update', NULL, '---
id: 346
salutation: 0
name: Carmen W.
lastnames: Lebrón
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:00:06.930223000 Z
updated_at: 2015-03-04 11:28:24.554047000 Z
', '2015-03-04 20:51:46.906341');
INSERT INTO versions VALUES (1351, 'Person', 344, 'update', NULL, '---
id: 344
salutation: 1
name: Clemente
lastnames: Flores
sex: true
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 10:57:43.865004000 Z
updated_at: 2015-03-04 11:28:24.867494000 Z
', '2015-03-04 20:52:07.629464');
INSERT INTO versions VALUES (1352, 'Person', 349, 'update', NULL, '---
id: 349
salutation: 
name: Francisca
lastnames: Rodríguez
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:03:01.357140000 Z
updated_at: 2015-03-04 11:28:25.212151000 Z
', '2015-03-04 20:52:13.899094');
INSERT INTO versions VALUES (1353, 'Person', 348, 'update', NULL, '---
id: 348
salutation: 
name: Juan
lastnames: Figueroa
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:02:42.315908000 Z
updated_at: 2015-03-04 11:28:25.220479000 Z
', '2015-03-04 20:52:19.875544');
INSERT INTO versions VALUES (1354, 'Person', 345, 'update', NULL, '---
id: 345
salutation: 0
name: Margarita
lastnames: Rodríguez
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 10:59:22.645046000 Z
updated_at: 2015-03-04 11:28:25.227862000 Z
', '2015-03-04 20:52:26.70793');
INSERT INTO versions VALUES (1361, 'Person', 352, 'update', NULL, '---
id: 352
salutation: 1
name: Luis Francisco
lastnames: Alicea Caraballo
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 55
created_at: 2015-03-04 11:04:46.844147000 Z
updated_at: 2015-03-04 20:52:30.289789000 Z
', '2015-03-04 20:53:49.800218');
INSERT INTO versions VALUES (1362, 'Person', 352, 'update', NULL, '---
id: 352
salutation: 1
name: Luis F.
lastnames: Alicea Caraballo
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 55
created_at: 2015-03-04 11:04:46.844147000 Z
updated_at: 2015-03-04 20:53:49.795490000 Z
', '2015-03-04 20:53:52.149236');
INSERT INTO versions VALUES (1363, 'Person', 367, 'update', NULL, '---
id: 367
salutation: 
name: Margarita
lastnames: Ramírez
sex: false
role: 4
description: Presidenta IBPR
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:08:30.862204000 Z
updated_at: 2015-03-04 19:36:17.867266000 Z
', '2015-03-04 21:00:21.463555');
INSERT INTO versions VALUES (1364, 'Person', 122, 'update', NULL, '---
id: 122
salutation: 0
name: ''Alberto J. ''
lastnames: ''Díaz ''
sex: true
role: 4
description: Vice Presidente
attended: false
printed: true
materials: false
church_id: 56
created_at: 2015-02-24 02:40:50.078129000 Z
updated_at: 2015-03-04 19:31:48.030148000 Z
', '2015-03-04 21:00:54.398753');
INSERT INTO versions VALUES (1365, 'Person', 372, 'update', NULL, '---
id: 372
salutation: 
name: José
lastnames: Candelaria
sex: true
role: 4
description: Tesorero
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:35:09.740009000 Z
updated_at: 2015-03-04 19:36:18.058719000 Z
', '2015-03-04 21:03:03.818909');
INSERT INTO versions VALUES (1366, 'Person', 376, 'update', NULL, '---
id: 376
salutation: 
name: Brunilda
lastnames: Gónzalez
sex: false
role: 4
description: Secretaria
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:36:34.458007000 Z
updated_at: 2015-03-04 19:40:12.395052000 Z
', '2015-03-04 21:03:30.112989');
INSERT INTO versions VALUES (1367, 'Person', 378, 'update', NULL, '---
id: 378
salutation: 1
name: Julio
lastnames: Gónzalez
sex: true
role: 4
description: Vocal
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:39:38.442108000 Z
updated_at: 2015-03-04 19:40:12.417715000 Z
', '2015-03-04 21:09:06.683043');
INSERT INTO versions VALUES (1368, 'Person', 405, 'update', NULL, '---
id: 405
salutation: 1
name: Dr. Cristino
lastnames: diaz montañez
sex: true
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:53:29.169968000 Z
updated_at: 2015-03-04 19:54:29.383849000 Z
', '2015-03-04 21:17:41.760634');
INSERT INTO versions VALUES (1369, 'Person', 420, 'update', NULL, '---
id: 420
salutation: 0
name: rafael
lastnames: rodriguez
sex: true
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:58:28.334312000 Z
updated_at: 2015-03-04 19:59:39.489339000 Z
', '2015-03-04 21:20:59.586094');
INSERT INTO versions VALUES (1370, 'Person', 416, 'update', NULL, '---
id: 416
salutation: 0
name: jose a.
lastnames: velasquez
sex: true
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:57:16.001068000 Z
updated_at: 2015-03-04 19:57:36.182421000 Z
', '2015-03-04 21:22:12.491475');
INSERT INTO versions VALUES (1376, 'Person', 367, 'update', NULL, '---
id: 367
salutation: 
name: Margarita
lastnames: Ramírez
sex: false
role: 4
description: Presidenta IBPR
attended: false
printed: true
materials: false
church_id: 118
created_at: 2015-03-04 19:08:30.862204000 Z
updated_at: 2015-03-04 21:00:21.460621000 Z
', '2015-03-04 21:23:01.461708');
INSERT INTO versions VALUES (1377, 'Person', 122, 'update', NULL, '---
id: 122
salutation: 0
name: ''Alberto J. ''
lastnames: ''Díaz ''
sex: true
role: 4
description: Vice Presidente
attended: false
printed: true
materials: false
church_id: 118
created_at: 2015-02-24 02:40:50.078129000 Z
updated_at: 2015-03-04 21:00:54.394873000 Z
', '2015-03-04 21:29:18.14358');
INSERT INTO versions VALUES (1378, 'Person', 372, 'update', NULL, '---
id: 372
salutation: 
name: José
lastnames: Candelaria
sex: true
role: 4
description: Tesorero
attended: false
printed: true
materials: false
church_id: 118
created_at: 2015-03-04 19:35:09.740009000 Z
updated_at: 2015-03-04 21:03:03.813544000 Z
', '2015-03-04 21:29:41.515016');
INSERT INTO versions VALUES (1379, 'Person', 376, 'update', NULL, '---
id: 376
salutation: 
name: Brunilda
lastnames: Gónzalez
sex: false
role: 4
description: Secretaria
attended: false
printed: true
materials: false
church_id: 118
created_at: 2015-03-04 19:36:34.458007000 Z
updated_at: 2015-03-04 21:03:30.106488000 Z
', '2015-03-04 21:30:27.76385');
INSERT INTO versions VALUES (1380, 'Person', 458, 'create', NULL, NULL, '2015-03-04 21:30:50.357801');
INSERT INTO versions VALUES (1381, 'Person', 378, 'update', NULL, '---
id: 378
salutation: 1
name: Julio
lastnames: Gónzalez
sex: true
role: 4
description: Vocal
attended: false
printed: true
materials: false
church_id: 118
created_at: 2015-03-04 19:39:38.442108000 Z
updated_at: 2015-03-04 21:09:06.678471000 Z
', '2015-03-04 21:30:59.794146');
INSERT INTO versions VALUES (1382, 'Person', 459, 'create', NULL, NULL, '2015-03-04 21:31:38.653986');
INSERT INTO versions VALUES (1383, 'Person', 460, 'create', NULL, NULL, '2015-03-04 21:32:21.363532');
INSERT INTO versions VALUES (1384, 'Person', 283, 'update', NULL, '---
id: 283
salutation: 
name: ''Danirys ''
lastnames: ''Sánchez ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 118
created_at: 2015-02-25 14:48:04.168582000 Z
updated_at: 2015-03-02 19:22:42.628694000 Z
', '2015-03-04 21:33:44.476067');
INSERT INTO versions VALUES (1385, 'Person', 283, 'update', NULL, '---
id: 283
salutation: 
name: ''Daniris ''
lastnames: ''Sánchez ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 118
created_at: 2015-02-25 14:48:04.168582000 Z
updated_at: 2015-03-04 21:33:44.470890000 Z
', '2015-03-04 21:34:11.508222');
INSERT INTO versions VALUES (1355, 'Person', 355, 'update', NULL, '---
id: 355
salutation: 
name: Julio
lastnames: Fuentes
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 55
created_at: 2015-03-04 11:05:56.397368000 Z
updated_at: 2015-03-04 20:49:07.540668000 Z
', '2015-03-04 20:52:30.217258');
INSERT INTO versions VALUES (1356, 'Person', 352, 'update', NULL, '---
id: 352
salutation: 1
name: Luis Francisco
lastnames: Alicea Caraballo
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 55
created_at: 2015-03-04 11:04:46.844147000 Z
updated_at: 2015-03-04 20:49:12.866062000 Z
', '2015-03-04 20:52:30.292346');
INSERT INTO versions VALUES (1357, 'Person', 353, 'update', NULL, '---
id: 353
salutation: 0
name: Pedro
lastnames: Boria Ortiz
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 55
created_at: 2015-03-04 11:05:18.260131000 Z
updated_at: 2015-03-04 20:49:21.948890000 Z
', '2015-03-04 20:52:30.301798');
INSERT INTO versions VALUES (1358, 'Person', 354, 'update', NULL, '---
id: 354
salutation: 
name: Ramón
lastnames: García
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 55
created_at: 2015-03-04 11:05:35.219957000 Z
updated_at: 2015-03-04 20:49:29.829141000 Z
', '2015-03-04 20:52:30.305888');
INSERT INTO versions VALUES (1359, 'Person', 346, 'update', NULL, '---
id: 346
salutation: 0
name: Carmen W.
lastnames: Lebrón
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 11:00:06.930223000 Z
updated_at: 2015-03-04 20:51:46.900896000 Z
', '2015-03-04 20:52:30.312462');
INSERT INTO versions VALUES (1360, 'Person', 344, 'update', NULL, '---
id: 344
salutation: 1
name: Clemente
lastnames: Flores
sex: true
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 10:57:43.865004000 Z
updated_at: 2015-03-04 20:52:07.622642000 Z
', '2015-03-04 20:52:30.322744');
INSERT INTO versions VALUES (1371, 'Person', 352, 'update', NULL, '---
id: 352
salutation: 1
name: Luis F.
lastnames: Alicea Caraballo
sex: true
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 55
created_at: 2015-03-04 11:04:46.844147000 Z
updated_at: 2015-03-04 20:53:52.141396000 Z
', '2015-03-04 21:22:33.664564');
INSERT INTO versions VALUES (1372, 'Person', 351, 'update', NULL, '---
id: 351
salutation: 
name: Francisca
lastnames: Alicea
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 11:03:46.627915000 Z
updated_at: 2015-03-04 20:50:31.819471000 Z
', '2015-03-04 21:22:33.719733');
INSERT INTO versions VALUES (1373, 'Person', 349, 'update', NULL, '---
id: 349
salutation: 
name: Francisca
lastnames: Rodríguez
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 11:03:01.357140000 Z
updated_at: 2015-03-04 20:52:13.891154000 Z
', '2015-03-04 21:22:33.740915');
INSERT INTO versions VALUES (1374, 'Person', 348, 'update', NULL, '---
id: 348
salutation: 
name: Juan
lastnames: Figueroa
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 11:02:42.315908000 Z
updated_at: 2015-03-04 20:52:19.870385000 Z
', '2015-03-04 21:22:33.749572');
INSERT INTO versions VALUES (1375, 'Person', 345, 'update', NULL, '---
id: 345
salutation: 0
name: Margarita
lastnames: Rodríguez
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 58
created_at: 2015-03-04 10:59:22.645046000 Z
updated_at: 2015-03-04 20:52:26.699314000 Z
', '2015-03-04 21:22:34.268722');
INSERT INTO versions VALUES (1386, 'Person', 459, 'update', NULL, '---
id: 459
salutation: 
name: Alma
lastnames: Morales
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 48
created_at: 2015-03-04 21:31:38.650802000 Z
updated_at: 2015-03-04 21:31:38.650802000 Z
', '2015-03-04 21:34:57.033969');
INSERT INTO versions VALUES (1387, 'Person', 460, 'update', NULL, '---
id: 460
salutation: 
name: Damaris
lastnames: Pizarro
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 48
created_at: 2015-03-04 21:32:21.357256000 Z
updated_at: 2015-03-04 21:32:21.357256000 Z
', '2015-03-04 21:34:57.076868');
INSERT INTO versions VALUES (1388, 'Person', 458, 'update', NULL, '---
id: 458
salutation: 0
name: Rodolfo
lastnames: Castillo
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 48
created_at: 2015-03-04 21:30:50.350742000 Z
updated_at: 2015-03-04 21:30:50.350742000 Z
', '2015-03-04 21:34:57.088454');
INSERT INTO versions VALUES (1389, 'Person', 283, 'update', NULL, '---
id: 283
salutation: 
name: ''Daniris ''
lastnames: ''Sánchez ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 118
created_at: 2015-02-25 14:48:04.168582000 Z
updated_at: 2015-03-04 21:34:11.503409000 Z
', '2015-03-04 21:34:57.092575');
INSERT INTO versions VALUES (1390, 'Person', 443, 'update', NULL, '---
id: 443
salutation: 1
name: Dr. Roberto
lastnames: Dieppa Baéz
sex: true
role: 4
description: Ex-Oficio Ministro Ejecutivo y Asociados
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:11:24.743812000 Z
updated_at: 2015-03-04 20:15:53.139226000 Z
', '2015-03-04 22:17:10.134674');
INSERT INTO versions VALUES (1391, 'Person', 444, 'update', NULL, '---
id: 444
salutation: 1
name: Lydia
lastnames: Reyes
sex: false
role: 4
description: Ex-Oficio Ministro Ejecutivo y Asociados
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:12:18.772563000 Z
updated_at: 2015-03-04 20:15:53.145812000 Z
', '2015-03-04 22:18:04.873603');
INSERT INTO versions VALUES (1392, 'Person', 444, 'update', NULL, '---
id: 444
salutation: 1
name: Lydia
lastnames: Reyes
sex: false
role: 4
description: Ministra Ejecutiva Asociada
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:12:18.772563000 Z
updated_at: 2015-03-04 22:18:04.867598000 Z
', '2015-03-04 22:18:13.997522');
INSERT INTO versions VALUES (1393, 'Person', 445, 'update', NULL, '---
id: 445
salutation: 1
name: Noelia
lastnames: Rodriguez
sex: false
role: 4
description: Ex-Oficio Ministro Ejecutivo y Asociados
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:12:43.119888000 Z
updated_at: 2015-03-04 20:15:53.153893000 Z
', '2015-03-04 22:18:44.775078');
INSERT INTO versions VALUES (1394, 'Person', 443, 'update', NULL, '---
id: 443
salutation: 1
name: Dr. Roberto
lastnames: Dieppa Baéz
sex: true
role: 4
description: Ministro Ejecutivo
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:11:24.743812000 Z
updated_at: 2015-03-04 22:17:10.120920000 Z
', '2015-03-04 22:18:55.881054');
INSERT INTO versions VALUES (1395, 'Person', 444, 'update', NULL, '---
id: 444
salutation: 1
name: Lydia
lastnames: Reyes
sex: false
role: 4
description: Ministra Ejecutiva Asociada
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:12:18.772563000 Z
updated_at: 2015-03-04 22:18:13.991943000 Z
', '2015-03-04 22:18:55.92534');
INSERT INTO versions VALUES (1396, 'Person', 445, 'update', NULL, '---
id: 445
salutation: 1
name: Noelia
lastnames: Rodriguez
sex: false
role: 4
description: Ministra Ejecutiva Asociada
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:12:43.119888000 Z
updated_at: 2015-03-04 22:18:44.772229000 Z
', '2015-03-04 22:18:55.932004');
INSERT INTO versions VALUES (1397, 'Person', 443, 'update', NULL, '---
id: 443
salutation: 1
name: Dr. Roberto
lastnames: Dieppa Baéz
sex: true
role: 4
description: Ministro Ejecutivo
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:11:24.743812000 Z
updated_at: 2015-03-04 22:18:55.874078000 Z
', '2015-03-04 22:22:45.462629');
INSERT INTO versions VALUES (1398, 'Person', 444, 'update', NULL, '---
id: 444
salutation: 1
name: Lydia
lastnames: Reyes
sex: false
role: 4
description: Ministra Ejecutiva Asociada
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:12:18.772563000 Z
updated_at: 2015-03-04 22:18:55.922524000 Z
', '2015-03-04 22:22:53.375797');
INSERT INTO versions VALUES (1399, 'Person', 444, 'update', NULL, '---
id: 444
salutation: 1
name: Lydia
lastnames: Reyes
sex: false
role: 4
description: Ministra Ejecutiva Asociada
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:12:18.772563000 Z
updated_at: 2015-03-04 22:22:53.371445000 Z
', '2015-03-04 22:23:29.165893');
INSERT INTO versions VALUES (1400, 'Person', 445, 'update', NULL, '---
id: 445
salutation: 1
name: Noelia
lastnames: Rodriguez
sex: false
role: 4
description: Ministra Ejecutiva Asociada
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:12:43.119888000 Z
updated_at: 2015-03-04 22:18:55.929665000 Z
', '2015-03-04 22:23:51.252837');
INSERT INTO versions VALUES (1401, 'Person', 259, 'update', NULL, '---
id: 259
salutation: 
name: ''Benjamín ''
lastnames: ''Ortiz ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 18
created_at: 2015-02-24 15:32:15.704090000 Z
updated_at: 2015-03-02 19:21:13.963381000 Z
', '2015-03-05 10:48:25.200621');
INSERT INTO versions VALUES (1402, 'Check', 30, 'create', NULL, NULL, '2015-03-05 10:53:03.349641');
INSERT INTO versions VALUES (1403, 'Check', 31, 'create', NULL, NULL, '2015-03-05 10:54:39.866332');
INSERT INTO versions VALUES (1404, 'Person', 333, 'update', NULL, '---
id: 333
salutation: 
name: ''Lourdes ''
lastnames: Santana
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 91
created_at: 2015-03-02 19:52:28.083547000 Z
updated_at: 2015-03-02 19:53:12.519959000 Z
', '2015-03-05 10:56:26.535357');
INSERT INTO versions VALUES (1405, 'Person', 333, 'update', NULL, '---
id: 333
salutation: 
name: ''Lourdes ''
lastnames: Santana
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 91
created_at: 2015-03-02 19:52:28.083547000 Z
updated_at: 2015-03-05 10:56:26.525833000 Z
', '2015-03-05 10:56:29.936519');
INSERT INTO versions VALUES (1406, 'Person', 117, 'update', NULL, '---
id: 117
salutation: 
name: ''Carmen L. ''
lastnames: ''Santos ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 60
created_at: 2015-02-24 02:37:12.731568000 Z
updated_at: 2015-03-02 19:22:39.104799000 Z
', '2015-03-05 10:57:27.056069');
INSERT INTO versions VALUES (1407, 'Person', 117, 'update', NULL, '---
id: 117
salutation: 
name: ''Carmen L. ''
lastnames: ''Santos ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 60
created_at: 2015-02-24 02:37:12.731568000 Z
updated_at: 2015-03-05 10:57:27.046450000 Z
', '2015-03-05 10:57:29.990041');
INSERT INTO versions VALUES (1408, 'Person', 443, 'update', NULL, '---
id: 443
salutation: 1
name: Dr. Roberto
lastnames: Dieppa Baéz
sex: true
role: 4
description: Ministro Ejecutivo
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:11:24.743812000 Z
updated_at: 2015-03-04 22:22:45.396217000 Z
', '2015-03-05 10:58:44.25211');
INSERT INTO versions VALUES (1409, 'Person', 444, 'update', NULL, '---
id: 444
salutation: 1
name: Lydia
lastnames: Rivas
sex: false
role: 4
description: Ministra Ejecutiva Asociada
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:12:18.772563000 Z
updated_at: 2015-03-04 22:23:29.161290000 Z
', '2015-03-05 10:58:44.302792');
INSERT INTO versions VALUES (1410, 'Person', 445, 'update', NULL, '---
id: 445
salutation: 1
name: Noelia
lastnames: Rodríguez
sex: false
role: 4
description: Ministra Ejecutiva Asociada
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:12:43.119888000 Z
updated_at: 2015-03-04 22:23:51.247996000 Z
', '2015-03-05 10:58:44.338322');
INSERT INTO versions VALUES (1411, 'Person', 259, 'update', NULL, '---
id: 259
salutation: 
name: Irma
lastnames: González
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 18
created_at: 2015-02-24 15:32:15.704090000 Z
updated_at: 2015-03-05 10:48:25.109768000 Z
', '2015-03-05 10:58:44.360607');
INSERT INTO versions VALUES (1412, 'Person', 190, 'update', NULL, '---
id: 190
salutation: 
name: ''Joel ''
lastnames: ''Roldán Oquendo ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 83
created_at: 2015-02-24 14:26:26.019892000 Z
updated_at: 2015-03-02 19:22:22.612860000 Z
', '2015-03-05 10:59:38.629894');
INSERT INTO versions VALUES (1413, 'Person', 190, 'update', NULL, '---
id: 190
salutation: 
name: ''Joel ''
lastnames: ''Roldán Oquendo ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 83
created_at: 2015-02-24 14:26:26.019892000 Z
updated_at: 2015-03-05 10:59:38.620740000 Z
', '2015-03-05 10:59:39.916191');
INSERT INTO versions VALUES (1414, 'Person', 137, 'update', NULL, '---
id: 137
salutation: 
name: ''Grisel ''
lastnames: ''Díaz ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 23
created_at: 2015-02-24 02:53:15.800547000 Z
updated_at: 2015-03-02 19:20:52.857133000 Z
', '2015-03-05 11:01:52.625899');
INSERT INTO versions VALUES (1415, 'Person', 137, 'update', NULL, '---
id: 137
salutation: 
name: ''Grisel ''
lastnames: ''Díaz ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 23
created_at: 2015-02-24 02:53:15.800547000 Z
updated_at: 2015-03-05 11:01:52.616555000 Z
', '2015-03-05 11:01:54.47814');
INSERT INTO versions VALUES (1416, 'Person', 104, 'update', NULL, '---
id: 104
salutation: 
name: ''Roberto ''
lastnames: ''Rodríguez ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 52
created_at: 2015-02-24 02:30:03.651506000 Z
updated_at: 2015-03-02 19:22:04.379272000 Z
', '2015-03-05 11:05:52.232246');
INSERT INTO versions VALUES (1417, 'Person', 104, 'update', NULL, '---
id: 104
salutation: 
name: ''Roberto ''
lastnames: ''Rodríguez ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 52
created_at: 2015-02-24 02:30:03.651506000 Z
updated_at: 2015-03-05 11:05:52.226295000 Z
', '2015-03-05 11:05:55.130695');
INSERT INTO versions VALUES (1418, 'Person', 92, 'update', NULL, '---
id: 92
salutation: 
name: Juan R.
lastnames: ''Flusa ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 14
created_at: 2015-02-24 02:23:11.719046000 Z
updated_at: 2015-03-02 19:21:06.793916000 Z
', '2015-03-05 11:05:58.381781');
INSERT INTO versions VALUES (1419, 'Person', 92, 'update', NULL, '---
id: 92
salutation: 
name: Juan R.
lastnames: ''Flusa ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 14
created_at: 2015-02-24 02:23:11.719046000 Z
updated_at: 2015-03-05 11:05:58.374386000 Z
', '2015-03-05 11:06:00.006234');
INSERT INTO versions VALUES (1420, 'Person', 70, 'update', NULL, '---
id: 70
salutation: 
name: ''Zoraida I. ''
lastnames: Serrano
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 37
created_at: 2015-02-24 02:07:15.106485000 Z
updated_at: 2015-03-02 19:21:49.663134000 Z
', '2015-03-05 11:06:45.924625');
INSERT INTO versions VALUES (1421, 'Person', 70, 'update', NULL, '---
id: 70
salutation: 
name: ''Zoraida I. ''
lastnames: Serrano
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 37
created_at: 2015-02-24 02:07:15.106485000 Z
updated_at: 2015-03-05 11:06:45.916824000 Z
', '2015-03-05 11:06:47.779502');
INSERT INTO versions VALUES (1422, 'Person', 71, 'update', NULL, '---
id: 71
salutation: 
name: ''Dora ''
lastnames: ''Cruz ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 37
created_at: 2015-02-24 02:07:36.947044000 Z
updated_at: 2015-03-02 19:21:46.351712000 Z
', '2015-03-05 11:06:52.092215');
INSERT INTO versions VALUES (1423, 'Person', 71, 'update', NULL, '---
id: 71
salutation: 
name: ''Dora ''
lastnames: ''Cruz ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 37
created_at: 2015-02-24 02:07:36.947044000 Z
updated_at: 2015-03-05 11:06:52.082859000 Z
', '2015-03-05 11:06:54.092222');
INSERT INTO versions VALUES (1424, 'Person', 69, 'update', NULL, '---
id: 69
salutation: 0
name: ''Juan C. ''
lastnames: ''Navarro ''
sex: true
role: 4
description: Comisión de Mayordomía y Misiones
attended: false
printed: true
materials: false
church_id: 37
created_at: 2015-02-24 02:06:47.609568000 Z
updated_at: 2015-03-04 20:22:03.602473000 Z
', '2015-03-05 11:06:58.664713');
INSERT INTO versions VALUES (1425, 'Person', 69, 'update', NULL, '---
id: 69
salutation: 0
name: ''Juan C. ''
lastnames: ''Navarro ''
sex: true
role: 4
description: Comisión de Mayordomía y Misiones
attended: true
printed: true
materials: false
church_id: 37
created_at: 2015-02-24 02:06:47.609568000 Z
updated_at: 2015-03-05 11:06:58.655921000 Z
', '2015-03-05 11:07:00.487247');
INSERT INTO versions VALUES (1426, 'Person', 443, 'update', NULL, '---
id: 443
salutation: 1
name: Dr. Roberto
lastnames: Dieppa Baéz
sex: true
role: 4
description: Ministro Ejecutivo
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:11:24.743812000 Z
updated_at: 2015-03-05 10:58:44.247845000 Z
', '2015-03-05 11:09:24.889948');
INSERT INTO versions VALUES (1427, 'Person', 444, 'update', NULL, '---
id: 444
salutation: 1
name: Lydia
lastnames: Rivas
sex: false
role: 4
description: Ministra Ejecutiva Asociada
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:12:18.772563000 Z
updated_at: 2015-03-05 10:58:44.299737000 Z
', '2015-03-05 11:09:34.056407');
INSERT INTO versions VALUES (1428, 'Person', 461, 'create', NULL, NULL, '2015-03-05 11:10:56.973683');
INSERT INTO versions VALUES (1429, 'Person', 166, 'update', NULL, '---
id: 166
salutation: 0
name: Pedro
lastnames: González
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 20
created_at: 2015-02-24 13:52:46.225562000 Z
updated_at: 2015-03-02 19:22:51.200986000 Z
', '2015-03-05 11:11:24.280746');
INSERT INTO versions VALUES (1430, 'Person', 166, 'update', NULL, '---
id: 166
salutation: 0
name: Pedro
lastnames: González
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 20
created_at: 2015-02-24 13:52:46.225562000 Z
updated_at: 2015-03-05 11:11:24.272605000 Z
', '2015-03-05 11:11:26.355578');
INSERT INTO versions VALUES (1431, 'Person', 462, 'create', NULL, NULL, '2015-03-05 11:11:28.826522');
INSERT INTO versions VALUES (1432, 'Person', 463, 'create', NULL, NULL, '2015-03-05 11:12:16.892288');
INSERT INTO versions VALUES (1433, 'Person', 286, 'update', NULL, '---
id: 286
salutation: 2
name: ''Alejandrina ''
lastnames: ''Ortiz ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 119
created_at: 2015-02-25 14:50:38.256213000 Z
updated_at: 2015-03-02 19:23:03.243692000 Z
', '2015-03-05 11:12:40.507881');
INSERT INTO versions VALUES (1434, 'Person', 383, 'update', NULL, '---
id: 383
salutation: 1
name: Ketley
lastnames: Pierre
sex: false
role: 5
description: Misionera en Nicaragua
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:43:54.519804000 Z
updated_at: 2015-03-04 20:22:03.803648000 Z
', '2015-03-05 11:13:31.72414');
INSERT INTO versions VALUES (1435, 'Person', 383, 'update', NULL, '---
id: 383
salutation: 1
name: Ketley
lastnames: Pierre
sex: false
role: 5
description: Misionera en Nicaragua
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:43:54.519804000 Z
updated_at: 2015-03-05 11:13:31.717067000 Z
', '2015-03-05 11:13:32.523101');
INSERT INTO versions VALUES (1436, 'Person', 371, 'update', NULL, '---
id: 371
salutation: 1
name: Ingrid
lastnames: Roldán
sex: false
role: 5
description: Misionera en Panamá
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:35:02.987980000 Z
updated_at: 2015-03-04 20:21:00.224285000 Z
', '2015-03-05 11:13:52.717249');
INSERT INTO versions VALUES (1437, 'Person', 371, 'update', NULL, '---
id: 371
salutation: 1
name: Ingrid
lastnames: Roldán
sex: false
role: 5
description: Misionera en Panamá
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:35:02.987980000 Z
updated_at: 2015-03-05 11:13:52.707499000 Z
', '2015-03-05 11:13:53.8928');
INSERT INTO versions VALUES (1438, 'Person', 256, 'update', NULL, '---
id: 256
salutation: 
name: ''Miguel ''
lastnames: ''Vázquez ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 18
created_at: 2015-02-24 15:31:15.047610000 Z
updated_at: 2015-03-02 19:21:17.590678000 Z
', '2015-03-05 11:13:57.474517');
INSERT INTO versions VALUES (1439, 'Person', 256, 'update', NULL, '---
id: 256
salutation: 
name: ''Miguel ''
lastnames: ''Vázquez ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 18
created_at: 2015-02-24 15:31:15.047610000 Z
updated_at: 2015-03-05 11:13:57.468356000 Z
', '2015-03-05 11:13:59.243305');
INSERT INTO versions VALUES (1440, 'Person', 249, 'update', NULL, '---
id: 249
salutation: 
name: ''Yolanda ''
lastnames: Orendo Montes
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 99
created_at: 2015-02-24 15:16:47.614559000 Z
updated_at: 2015-03-02 19:26:56.946448000 Z
', '2015-03-05 11:14:44.749203');
INSERT INTO versions VALUES (1441, 'Person', 249, 'update', NULL, '---
id: 249
salutation: 
name: ''Yolanda ''
lastnames: Orendo Montes
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 99
created_at: 2015-02-24 15:16:47.614559000 Z
updated_at: 2015-03-05 11:14:44.740080000 Z
', '2015-03-05 11:14:49.866277');
INSERT INTO versions VALUES (1442, 'Person', 57, 'update', NULL, '---
id: 57
salutation: 
name: Lillian
lastnames: ''Rivera ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 10
created_at: 2015-02-24 01:59:18.740724000 Z
updated_at: 2015-03-02 19:20:49.660249000 Z
', '2015-03-05 11:15:05.60576');
INSERT INTO versions VALUES (1443, 'Person', 57, 'update', NULL, '---
id: 57
salutation: 
name: Lillian
lastnames: ''Rivera ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 10
created_at: 2015-02-24 01:59:18.740724000 Z
updated_at: 2015-03-05 11:15:05.597337000 Z
', '2015-03-05 11:15:07.49026');
INSERT INTO versions VALUES (1444, 'Person', 250, 'update', NULL, '---
id: 250
salutation: 
name: ''Elsa I. ''
lastnames: Mercado Torres
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 99
created_at: 2015-02-24 15:17:04.962409000 Z
updated_at: 2015-03-02 19:23:48.385949000 Z
', '2015-03-05 11:15:08.821429');
INSERT INTO versions VALUES (1445, 'Person', 250, 'update', NULL, '---
id: 250
salutation: 
name: ''Elsa I. ''
lastnames: Mercado Torres
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 99
created_at: 2015-02-24 15:17:04.962409000 Z
updated_at: 2015-03-05 11:15:08.813079000 Z
', '2015-03-05 11:15:13.233385');
INSERT INTO versions VALUES (1446, 'Person', 290, 'update', NULL, '---
id: 290
salutation: 
name: María D.
lastnames: ''Nuñez ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 75
created_at: 2015-02-27 02:35:45.393998000 Z
updated_at: 2015-03-02 19:23:06.744687000 Z
', '2015-03-05 11:16:06.885975');
INSERT INTO versions VALUES (1447, 'Person', 290, 'update', NULL, '---
id: 290
salutation: 
name: María D.
lastnames: ''Nuñez ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 75
created_at: 2015-02-27 02:35:45.393998000 Z
updated_at: 2015-03-05 11:16:06.882899000 Z
', '2015-03-05 11:16:09.029823');
INSERT INTO versions VALUES (1448, 'Person', 376, 'update', NULL, '---
id: 376
salutation: 
name: Brunilda
lastnames: Gónzalez
sex: false
role: 4
description: Secretaria
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 19:36:34.458007000 Z
updated_at: 2015-03-04 21:30:27.760953000 Z
', '2015-03-05 11:19:56.540674');
INSERT INTO versions VALUES (1449, 'Person', 376, 'update', NULL, '---
id: 376
salutation: 
name: Brunilda
lastnames: Gónzalez
sex: false
role: 4
description: Secretaria
attended: true
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 19:36:34.458007000 Z
updated_at: 2015-03-05 11:19:56.531641000 Z
', '2015-03-05 11:19:58.156508');
INSERT INTO versions VALUES (1450, 'Person', 226, 'update', NULL, '---
id: 226
salutation: 0
name: Hilda G.
lastnames: Acosta Rivera
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 97
created_at: 2015-02-24 15:02:58.244599000 Z
updated_at: 2015-03-02 19:20:45.401045000 Z
', '2015-03-05 11:21:23.736641');
INSERT INTO versions VALUES (1451, 'Person', 226, 'update', NULL, '---
id: 226
salutation: 0
name: Hilda G.
lastnames: Acosta Rivera
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 97
created_at: 2015-02-24 15:02:58.244599000 Z
updated_at: 2015-03-05 11:21:23.728675000 Z
', '2015-03-05 11:21:25.436659');
INSERT INTO versions VALUES (1452, 'Person', 9, 'update', NULL, '---
id: 9
salutation: 
name: ''Wilfredo ''
lastnames: ''Torres ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 105
created_at: 2015-02-23 22:27:06.708956000 Z
updated_at: 2015-03-04 20:30:14.817566000 Z
', '2015-03-05 11:22:04.336998');
INSERT INTO versions VALUES (1453, 'Person', 9, 'update', NULL, '---
id: 9
salutation: 
name: ''Wilfredo ''
lastnames: ''Torres ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 105
created_at: 2015-02-23 22:27:06.708956000 Z
updated_at: 2015-03-05 11:22:04.328276000 Z
', '2015-03-05 11:22:06.185296');
INSERT INTO versions VALUES (1454, 'Person', 118, 'update', NULL, '---
id: 118
salutation: 
name: ''Wilda ''
lastnames: ''Lugo ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 60
created_at: 2015-02-24 02:37:32.520058000 Z
updated_at: 2015-03-02 19:22:42.623339000 Z
', '2015-03-05 11:22:45.275601');
INSERT INTO versions VALUES (1455, 'Person', 118, 'update', NULL, '---
id: 118
salutation: 
name: ''Wilda ''
lastnames: ''Lugo ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 60
created_at: 2015-02-24 02:37:32.520058000 Z
updated_at: 2015-03-05 11:22:45.271990000 Z
', '2015-03-05 11:22:47.017288');
INSERT INTO versions VALUES (1456, 'Person', 377, 'update', NULL, '---
id: 377
salutation: 0
name: Walleska
lastnames: Febres
sex: false
role: 5
description: Misionera en Colombia
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:37:09.323060000 Z
updated_at: 2015-03-04 20:22:03.725254000 Z
', '2015-03-05 11:23:47.161628');
INSERT INTO versions VALUES (1457, 'Person', 377, 'update', NULL, '---
id: 377
salutation: 0
name: Walleska
lastnames: Febres
sex: false
role: 5
description: Misionera en Colombia
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:37:09.323060000 Z
updated_at: 2015-03-05 11:23:47.152139000 Z
', '2015-03-05 11:23:53.698802');
INSERT INTO versions VALUES (1458, 'Person', 251, 'update', NULL, '---
id: 251
salutation: 
name: Clarissa
lastnames: Rodríguez
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 99
created_at: 2015-02-24 15:17:40.919683000 Z
updated_at: 2015-03-02 19:23:48.370365000 Z
', '2015-03-05 11:26:38.397414');
INSERT INTO versions VALUES (1459, 'Person', 251, 'update', NULL, '---
id: 251
salutation: 
name: Clarissa
lastnames: Rodríguez
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 99
created_at: 2015-02-24 15:17:40.919683000 Z
updated_at: 2015-03-05 11:26:38.386466000 Z
', '2015-03-05 11:26:41.545646');
INSERT INTO versions VALUES (1460, 'Person', 113, 'update', NULL, '---
id: 113
salutation: 
name: ''Maria de los A. ''
lastnames: Rolón
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 60
created_at: 2015-02-24 02:35:37.036285000 Z
updated_at: 2015-03-02 19:22:39.151544000 Z
', '2015-03-05 11:27:02.603631');
INSERT INTO versions VALUES (1461, 'Person', 113, 'update', NULL, '---
id: 113
salutation: 
name: ''Maria de los A. ''
lastnames: Rolón
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 60
created_at: 2015-02-24 02:35:37.036285000 Z
updated_at: 2015-03-05 11:27:02.596955000 Z
', '2015-03-05 11:27:05.124377');
INSERT INTO versions VALUES (1462, 'Check', 32, 'create', NULL, NULL, '2015-03-05 11:27:40.948104');
INSERT INTO versions VALUES (1463, 'Check', 32, 'update', NULL, '---
id: 32
number: 9698
amount: 125.0
description: ''''
church_id: 23
created_at: 2015-03-05 11:27:40.942055000 Z
updated_at: 2015-03-05 11:27:40.942055000 Z
', '2015-03-05 11:28:22.111787');
INSERT INTO versions VALUES (1464, 'Person', 357, 'update', NULL, '---
id: 357
salutation: 
name: Edgardo
lastnames: López
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 55
created_at: 2015-03-04 11:06:38.050754000 Z
updated_at: 2015-03-04 20:41:23.362499000 Z
', '2015-03-05 11:30:22.392242');
INSERT INTO versions VALUES (1465, 'Person', 357, 'update', NULL, '---
id: 357
salutation: 
name: Edgardo
lastnames: López
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 55
created_at: 2015-03-04 11:06:38.050754000 Z
updated_at: 2015-03-05 11:30:22.382955000 Z
', '2015-03-05 11:30:23.203117');
INSERT INTO versions VALUES (1466, 'Person', 173, 'update', NULL, '---
id: 173
salutation: 0
name: ''Margarita ''
lastnames: ''Santana ''
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 24
created_at: 2015-02-24 14:00:34.174153000 Z
updated_at: 2015-03-02 19:20:56.282147000 Z
', '2015-03-05 11:31:19.262142');
INSERT INTO versions VALUES (1467, 'Person', 173, 'update', NULL, '---
id: 173
salutation: 0
name: ''Margarita ''
lastnames: ''Santana ''
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 24
created_at: 2015-02-24 14:00:34.174153000 Z
updated_at: 2015-03-05 11:31:19.255509000 Z
', '2015-03-05 11:31:21.558253');
INSERT INTO versions VALUES (1468, 'Person', 125, 'update', NULL, '---
id: 125
salutation: 
name: ''Félix J. ''
lastnames: ''Colón ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 56
created_at: 2015-02-24 02:42:20.495190000 Z
updated_at: 2015-03-02 19:22:56.070897000 Z
', '2015-03-05 11:31:30.353868');
INSERT INTO versions VALUES (1469, 'Person', 125, 'update', NULL, '---
id: 125
salutation: 
name: ''Félix J. ''
lastnames: ''Colón ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 56
created_at: 2015-02-24 02:42:20.495190000 Z
updated_at: 2015-03-05 11:31:30.344170000 Z
', '2015-03-05 11:31:32.462096');
INSERT INTO versions VALUES (1470, 'Person', 123, 'update', NULL, '---
id: 123
salutation: 4
name: ''Sonia ''
lastnames: Villodas
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 56
created_at: 2015-02-24 02:41:19.738212000 Z
updated_at: 2015-03-02 19:22:56.100306000 Z
', '2015-03-05 11:32:12.865584');
INSERT INTO versions VALUES (1471, 'Person', 123, 'update', NULL, '---
id: 123
salutation: 4
name: ''Sonia ''
lastnames: Villodas
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 56
created_at: 2015-02-24 02:41:19.738212000 Z
updated_at: 2015-03-05 11:32:12.856348000 Z
', '2015-03-05 11:32:14.50877');
INSERT INTO versions VALUES (1472, 'Person', 176, 'update', NULL, '---
id: 176
salutation: 
name: ''Juan ''
lastnames: ''Morales ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 24
created_at: 2015-02-24 14:03:23.992370000 Z
updated_at: 2015-03-02 19:20:56.271756000 Z
', '2015-03-05 11:32:25.918681');
INSERT INTO versions VALUES (1473, 'Person', 176, 'update', NULL, '---
id: 176
salutation: 
name: ''Juan ''
lastnames: ''Morales ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 24
created_at: 2015-02-24 14:03:23.992370000 Z
updated_at: 2015-03-05 11:32:25.915035000 Z
', '2015-03-05 11:32:27.21777');
INSERT INTO versions VALUES (1474, 'Person', 280, 'update', NULL, '---
id: 280
salutation: 
name: ''Lydia ''
lastnames: Del Valle
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 11
created_at: 2015-02-25 14:46:00.734214000 Z
updated_at: 2015-03-02 19:20:56.255274000 Z
', '2015-03-05 11:33:26.451212');
INSERT INTO versions VALUES (1475, 'Person', 280, 'update', NULL, '---
id: 280
salutation: 
name: ''Lydia ''
lastnames: Del Valle
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 11
created_at: 2015-02-25 14:46:00.734214000 Z
updated_at: 2015-03-05 11:33:26.440710000 Z
', '2015-03-05 11:33:28.408758');
INSERT INTO versions VALUES (1476, 'Person', 12, 'update', NULL, '---
id: 12
salutation: 
name: ''Mary Leen ''
lastnames: Marrero
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 103
created_at: 2015-02-24 01:18:51.363156000 Z
updated_at: 2015-03-02 19:21:56.038092000 Z
', '2015-03-05 11:33:32.32308');
INSERT INTO versions VALUES (1477, 'Person', 12, 'update', NULL, '---
id: 12
salutation: 
name: ''Mary Leen ''
lastnames: Marrero
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 103
created_at: 2015-02-24 01:18:51.363156000 Z
updated_at: 2015-03-05 11:33:32.314664000 Z
', '2015-03-05 11:33:33.966507');
INSERT INTO versions VALUES (1478, 'Person', 13, 'update', NULL, '---
id: 13
salutation: 
name: ''Noel ''
lastnames: ''Ortiz ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 103
created_at: 2015-02-24 01:19:13.409094000 Z
updated_at: 2015-03-02 19:21:56.767915000 Z
', '2015-03-05 11:33:52.592951');
INSERT INTO versions VALUES (1479, 'Person', 13, 'update', NULL, '---
id: 13
salutation: 
name: ''Noel ''
lastnames: ''Ortiz ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 103
created_at: 2015-02-24 01:19:13.409094000 Z
updated_at: 2015-03-05 11:33:52.584417000 Z
', '2015-03-05 11:33:54.760065');
INSERT INTO versions VALUES (1480, 'Check', 33, 'create', NULL, NULL, '2015-03-05 11:34:04.40817');
INSERT INTO versions VALUES (1481, 'Person', 175, 'update', NULL, '---
id: 175
salutation: 
name: ''Marisol ''
lastnames: ''Sanchez ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 24
created_at: 2015-02-24 14:03:07.962388000 Z
updated_at: 2015-03-02 19:20:56.287988000 Z
', '2015-03-05 11:34:13.753382');
INSERT INTO versions VALUES (2024, 'Check', 49, 'update', NULL, '---
id: 49
number: 0
amount: 50.0
description: ''''
church_id: 43
created_at: 2015-03-05 13:05:12.620638000 Z
updated_at: 2015-03-05 13:05:12.620638000 Z
', '2015-03-05 13:05:44.143978');
INSERT INTO versions VALUES (1482, 'Person', 175, 'update', NULL, '---
id: 175
salutation: 
name: ''Marisol ''
lastnames: ''Sanchez ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 24
created_at: 2015-02-24 14:03:07.962388000 Z
updated_at: 2015-03-05 11:34:13.750912000 Z
', '2015-03-05 11:34:15.678633');
INSERT INTO versions VALUES (1483, 'Check', 34, 'create', NULL, NULL, '2015-03-05 11:34:47.701852');
INSERT INTO versions VALUES (1484, 'Person', 191, 'update', NULL, '---
id: 191
salutation: 
name: ''Raúl ''
lastnames: Matos Castilo
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 83
created_at: 2015-02-24 14:26:50.425779000 Z
updated_at: 2015-03-02 19:22:26.119160000 Z
', '2015-03-05 11:38:48.260888');
INSERT INTO versions VALUES (1485, 'Person', 191, 'update', NULL, '---
id: 191
salutation: 
name: ''Raúl ''
lastnames: Matos Castilo
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 83
created_at: 2015-02-24 14:26:50.425779000 Z
updated_at: 2015-03-05 11:38:48.251495000 Z
', '2015-03-05 11:38:49.44984');
INSERT INTO versions VALUES (1486, 'Person', 264, 'update', NULL, '---
id: 264
salutation: 
name: ''Luis A. ''
lastnames: Poggi
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 96
created_at: 2015-02-24 15:37:27.835344000 Z
updated_at: 2015-03-02 19:23:44.686680000 Z
', '2015-03-05 11:38:57.510687');
INSERT INTO versions VALUES (1487, 'Person', 264, 'update', NULL, '---
id: 264
salutation: 
name: ''Luis A. ''
lastnames: Poggi
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 96
created_at: 2015-02-24 15:37:27.835344000 Z
updated_at: 2015-03-05 11:38:57.501782000 Z
', '2015-03-05 11:38:58.837599');
INSERT INTO versions VALUES (1488, 'Person', 361, 'update', NULL, '---
id: 361
salutation: 
name: Ana R.
lastnames: Torres Montañez
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:15:12.300300000 Z
updated_at: 2015-03-04 20:48:27.006572000 Z
', '2015-03-05 11:40:11.073769');
INSERT INTO versions VALUES (1489, 'Person', 361, 'update', NULL, '---
id: 361
salutation: 
name: Ana R.
lastnames: Torres Montañez
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:15:12.300300000 Z
updated_at: 2015-03-05 11:40:11.063750000 Z
', '2015-03-05 11:40:12.559148');
INSERT INTO versions VALUES (1490, 'Person', 100, 'update', NULL, '---
id: 100
salutation: 
name: ''José A. ''
lastnames: ''Boria ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 50
created_at: 2015-02-24 02:27:18.420492000 Z
updated_at: 2015-03-02 19:21:42.475626000 Z
', '2015-03-05 11:40:36.545154');
INSERT INTO versions VALUES (1491, 'Person', 100, 'update', NULL, '---
id: 100
salutation: 
name: ''José A. ''
lastnames: ''Boria ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 50
created_at: 2015-02-24 02:27:18.420492000 Z
updated_at: 2015-03-05 11:40:36.542561000 Z
', '2015-03-05 11:40:38.671493');
INSERT INTO versions VALUES (1496, 'Person', 159, 'update', NULL, '---
id: 159
salutation: 
name: ''Carlos ''
lastnames: Rodriguez Delannoy
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:33:17.399365000 Z
updated_at: 2015-03-02 19:21:20.918843000 Z
', '2015-03-05 11:40:58.898786');
INSERT INTO versions VALUES (1497, 'Person', 159, 'update', NULL, '---
id: 159
salutation: 
name: ''Carlos ''
lastnames: Rodriguez Delannoy
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:33:17.399365000 Z
updated_at: 2015-03-05 11:40:58.896174000 Z
', '2015-03-05 11:40:59.781665');
INSERT INTO versions VALUES (1498, 'Person', 115, 'update', NULL, '---
id: 115
salutation: 
name: ''Jossie ''
lastnames: ''Cardona ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 60
created_at: 2015-02-24 02:36:19.732517000 Z
updated_at: 2015-03-02 19:22:39.144495000 Z
', '2015-03-05 11:41:02.164272');
INSERT INTO versions VALUES (1499, 'Person', 115, 'update', NULL, '---
id: 115
salutation: 
name: ''Jossie ''
lastnames: ''Cardona ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 60
created_at: 2015-02-24 02:36:19.732517000 Z
updated_at: 2015-03-05 11:41:02.155968000 Z
', '2015-03-05 11:41:03.486125');
INSERT INTO versions VALUES (1500, 'Person', 159, 'update', NULL, '---
id: 159
salutation: 
name: ''Carlos ''
lastnames: Rodriguez Delannoy
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:33:17.399365000 Z
updated_at: 2015-03-05 11:40:59.775217000 Z
', '2015-03-05 11:41:03.512317');
INSERT INTO versions VALUES (1501, 'Person', 159, 'update', NULL, '---
id: 159
salutation: 
name: ''Carlos ''
lastnames: Rodriguez Delannoy
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:33:17.399365000 Z
updated_at: 2015-03-05 11:41:03.507248000 Z
', '2015-03-05 11:41:05.607405');
INSERT INTO versions VALUES (1502, 'Person', 425, 'update', NULL, '---
id: 425
salutation: 1
name: Rubén
lastnames: Figueroa
sex: true
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:00:24.971762000 Z
updated_at: 2015-03-04 20:02:42.827159000 Z
', '2015-03-05 11:41:49.031351');
INSERT INTO versions VALUES (1503, 'Person', 425, 'update', NULL, '---
id: 425
salutation: 1
name: Rubén
lastnames: Figueroa
sex: true
role: 2
description: ''''
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:00:24.971762000 Z
updated_at: 2015-03-05 11:41:49.022734000 Z
', '2015-03-05 11:41:50.040453');
INSERT INTO versions VALUES (1504, 'Person', 253, 'update', NULL, '---
id: 253
salutation: 
name: ''Marta ''
lastnames: ''Ayala Vega ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 99
created_at: 2015-02-24 15:18:59.956187000 Z
updated_at: 2015-03-02 19:23:48.396920000 Z
', '2015-03-05 11:42:48.943029');
INSERT INTO versions VALUES (1505, 'Person', 253, 'update', NULL, '---
id: 253
salutation: 
name: ''Marta ''
lastnames: ''Ayala Vega ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 99
created_at: 2015-02-24 15:18:59.956187000 Z
updated_at: 2015-03-05 11:42:48.934144000 Z
', '2015-03-05 11:42:50.245382');
INSERT INTO versions VALUES (1506, 'Person', 73, 'update', NULL, '---
id: 73
salutation: 
name: ''Yolaris ''
lastnames: ''Negrón ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 37
created_at: 2015-02-24 02:08:54.002502000 Z
updated_at: 2015-03-02 19:21:49.646904000 Z
', '2015-03-05 11:42:50.693102');
INSERT INTO versions VALUES (1507, 'Person', 73, 'update', NULL, '---
id: 73
salutation: 
name: ''Yolaris ''
lastnames: ''Negrón ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 37
created_at: 2015-02-24 02:08:54.002502000 Z
updated_at: 2015-03-05 11:42:50.683941000 Z
', '2015-03-05 11:42:53.665849');
INSERT INTO versions VALUES (1508, 'Person', 248, 'update', NULL, '---
id: 248
salutation: 1
name: ''Juan N. ''
lastnames: Medina Argueta
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 99
created_at: 2015-02-24 15:16:16.155526000 Z
updated_at: 2015-03-02 19:23:48.391175000 Z
', '2015-03-05 11:43:31.564656');
INSERT INTO versions VALUES (1509, 'Person', 248, 'update', NULL, '---
id: 248
salutation: 1
name: ''Juan N. ''
lastnames: Medina Argueta
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 99
created_at: 2015-02-24 15:16:16.155526000 Z
updated_at: 2015-03-05 11:43:31.555782000 Z
', '2015-03-05 11:43:32.538162');
INSERT INTO versions VALUES (1510, 'Person', 363, 'update', NULL, '---
id: 363
salutation: 
name: Gloria
lastnames: Ríos Rolón
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:17:44.881599000 Z
updated_at: 2015-03-04 20:48:27.016219000 Z
', '2015-03-05 11:43:53.432647');
INSERT INTO versions VALUES (1511, 'Person', 363, 'update', NULL, '---
id: 363
salutation: 
name: Gloria
lastnames: Ríos Rolón
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:17:44.881599000 Z
updated_at: 2015-03-05 11:43:53.422851000 Z
', '2015-03-05 11:43:55.127014');
INSERT INTO versions VALUES (1492, 'Person', 461, 'update', NULL, '---
id: 461
salutation: 
name: Virgina
lastnames: Laporte
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 72
created_at: 2015-03-05 11:10:56.890901000 Z
updated_at: 2015-03-05 11:10:56.890901000 Z
', '2015-03-05 11:40:43.258471');
INSERT INTO versions VALUES (1493, 'Person', 462, 'update', NULL, '---
id: 462
salutation: 
name: Maria
lastnames: Estela
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 72
created_at: 2015-03-05 11:11:28.821418000 Z
updated_at: 2015-03-05 11:11:28.821418000 Z
', '2015-03-05 11:40:43.36273');
INSERT INTO versions VALUES (1494, 'Person', 463, 'update', NULL, '---
id: 463
salutation: 0
name: Luz D.
lastnames: Rivera
sex: false
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 72
created_at: 2015-03-05 11:12:16.885277000 Z
updated_at: 2015-03-05 11:12:16.885277000 Z
', '2015-03-05 11:40:43.368345');
INSERT INTO versions VALUES (1495, 'Person', 286, 'update', NULL, '---
id: 286
salutation: 2
name: ''Alejandrina ''
lastnames: ''Ortiz ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 119
created_at: 2015-02-25 14:50:38.256213000 Z
updated_at: 2015-03-05 11:12:40.502647000 Z
', '2015-03-05 11:40:43.374913');
INSERT INTO versions VALUES (1512, 'Person', 130, 'update', NULL, '---
id: 130
salutation: 0
name: ''Ulbencio ''
lastnames: ''Rivera ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 65
created_at: 2015-02-24 02:47:50.485002000 Z
updated_at: 2015-03-02 19:23:28.878260000 Z
', '2015-03-05 11:44:05.514231');
INSERT INTO versions VALUES (1513, 'Person', 130, 'update', NULL, '---
id: 130
salutation: 0
name: ''Ulbencio ''
lastnames: ''Rivera ''
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 65
created_at: 2015-02-24 02:47:50.485002000 Z
updated_at: 2015-03-05 11:44:05.503862000 Z
', '2015-03-05 11:44:06.184841');
INSERT INTO versions VALUES (1514, 'Person', 359, 'update', NULL, '---
id: 359
salutation: 
name: María V.
lastnames: Colón Alvarado
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:13:47.821593000 Z
updated_at: 2015-03-04 20:41:23.424335000 Z
', '2015-03-05 11:44:27.690643');
INSERT INTO versions VALUES (1515, 'Person', 359, 'update', NULL, '---
id: 359
salutation: 
name: María V.
lastnames: Colón Alvarado
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:13:47.821593000 Z
updated_at: 2015-03-05 11:44:27.687153000 Z
', '2015-03-05 11:44:29.361492');
INSERT INTO versions VALUES (1516, 'Person', 278, 'update', NULL, '---
id: 278
salutation: 0
name: ''Germán ''
lastnames: Malavé
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 11
created_at: 2015-02-25 14:45:14.416172000 Z
updated_at: 2015-03-02 19:20:56.167911000 Z
', '2015-03-05 11:44:41.942859');
INSERT INTO versions VALUES (1517, 'Person', 278, 'update', NULL, '---
id: 278
salutation: 0
name: ''Germán ''
lastnames: Malavé
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 11
created_at: 2015-02-25 14:45:14.416172000 Z
updated_at: 2015-03-05 11:44:41.934212000 Z
', '2015-03-05 11:44:50.274956');
INSERT INTO versions VALUES (1518, 'Person', 248, 'update', NULL, '---
id: 248
salutation: 1
name: ''Juan N. ''
lastnames: Medina Argueta
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: true
church_id: 99
created_at: 2015-02-24 15:16:16.155526000 Z
updated_at: 2015-03-05 11:43:32.528473000 Z
', '2015-03-05 11:45:23.194962');
INSERT INTO versions VALUES (1519, 'Person', 116, 'update', NULL, '---
id: 116
salutation: 
name: ''Daniel ''
lastnames: ''Cardona ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 60
created_at: 2015-02-24 02:36:47.171359000 Z
updated_at: 2015-03-02 19:22:39.123170000 Z
', '2015-03-05 11:45:30.524318');
INSERT INTO versions VALUES (1520, 'Person', 116, 'update', NULL, '---
id: 116
salutation: 
name: ''Daniel ''
lastnames: ''Cardona ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 60
created_at: 2015-02-24 02:36:47.171359000 Z
updated_at: 2015-03-05 11:45:30.516322000 Z
', '2015-03-05 11:45:32.093198');
INSERT INTO versions VALUES (1521, 'Person', 355, 'update', NULL, '---
id: 355
salutation: 
name: Julio
lastnames: Fuentes
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 55
created_at: 2015-03-04 11:05:56.397368000 Z
updated_at: 2015-03-04 20:52:30.214684000 Z
', '2015-03-05 11:46:35.028149');
INSERT INTO versions VALUES (1522, 'Person', 355, 'update', NULL, '---
id: 355
salutation: 
name: Julio
lastnames: Fuentes
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 55
created_at: 2015-03-04 11:05:56.397368000 Z
updated_at: 2015-03-05 11:46:35.019848000 Z
', '2015-03-05 11:46:36.348014');
INSERT INTO versions VALUES (1523, 'Person', 255, 'update', NULL, '---
id: 255
salutation: 0
name: ''Edgardo ''
lastnames: Caraballo
sex: true
role: 4
description: Representante Distrito
attended: false
printed: true
materials: false
church_id: 18
created_at: 2015-02-24 15:30:51.289108000 Z
updated_at: 2015-03-04 20:24:07.512602000 Z
', '2015-03-05 11:47:05.848238');
INSERT INTO versions VALUES (1524, 'Person', 255, 'update', NULL, '---
id: 255
salutation: 0
name: ''Edgardo ''
lastnames: Caraballo
sex: true
role: 4
description: Representante Distrito
attended: true
printed: true
materials: false
church_id: 18
created_at: 2015-02-24 15:30:51.289108000 Z
updated_at: 2015-03-05 11:47:05.839151000 Z
', '2015-03-05 11:47:07.177209');
INSERT INTO versions VALUES (1525, 'Person', 136, 'update', NULL, '---
id: 136
salutation: 
name: ''Luz D. ''
lastnames: ''Lozada ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 23
created_at: 2015-02-24 02:52:52.625027000 Z
updated_at: 2015-03-02 19:20:52.895938000 Z
', '2015-03-05 11:47:14.145533');
INSERT INTO versions VALUES (1526, 'Person', 136, 'update', NULL, '---
id: 136
salutation: 
name: ''Luz D. ''
lastnames: ''Lozada ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 23
created_at: 2015-02-24 02:52:52.625027000 Z
updated_at: 2015-03-05 11:47:14.139380000 Z
', '2015-03-05 11:47:15.704515');
INSERT INTO versions VALUES (1527, 'Person', 342, 'update', NULL, '---
id: 342
salutation: 
name: ''Luz ''
lastnames: Maldonado
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 86
created_at: 2015-03-02 20:21:12.416348000 Z
updated_at: 2015-03-02 20:50:19.638706000 Z
', '2015-03-05 11:47:55.818323');
INSERT INTO versions VALUES (1528, 'Person', 342, 'update', NULL, '---
id: 342
salutation: 
name: ''Luz ''
lastnames: Maldonado
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 86
created_at: 2015-03-02 20:21:12.416348000 Z
updated_at: 2015-03-05 11:47:55.809195000 Z
', '2015-03-05 11:47:57.352168');
INSERT INTO versions VALUES (1529, 'Person', 288, 'update', NULL, '---
id: 288
salutation: 
name: ''Rosa ''
lastnames: ''Capellán ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 27
created_at: 2015-02-27 02:30:14.499799000 Z
updated_at: 2015-03-02 19:22:52.389416000 Z
', '2015-03-05 11:49:07.605739');
INSERT INTO versions VALUES (1530, 'Person', 288, 'update', NULL, '---
id: 288
salutation: 
name: ''Rosa ''
lastnames: ''Capellán ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 27
created_at: 2015-02-27 02:30:14.499799000 Z
updated_at: 2015-03-05 11:49:07.597050000 Z
', '2015-03-05 11:49:10.252194');
INSERT INTO versions VALUES (1531, 'Person', 88, 'update', NULL, '---
id: 88
salutation: 
name: ''Angel ''
lastnames: ''Sierra ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:17:31.008629000 Z
updated_at: 2015-03-02 19:21:00.038696000 Z
', '2015-03-05 11:50:00.719045');
INSERT INTO versions VALUES (1532, 'Person', 88, 'update', NULL, '---
id: 88
salutation: 
name: ''Angel ''
lastnames: ''Sierra ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:17:31.008629000 Z
updated_at: 2015-03-05 11:50:00.710414000 Z
', '2015-03-05 11:50:01.569445');
INSERT INTO versions VALUES (1533, 'Person', 356, 'update', NULL, '---
id: 356
salutation: 
name: Maribel
lastnames: Boria
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 55
created_at: 2015-03-04 11:06:18.367635000 Z
updated_at: 2015-03-04 20:41:23.398032000 Z
', '2015-03-05 11:50:04.065742');
INSERT INTO versions VALUES (1534, 'Person', 356, 'update', NULL, '---
id: 356
salutation: 
name: Maribel
lastnames: Boria
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 55
created_at: 2015-03-04 11:06:18.367635000 Z
updated_at: 2015-03-05 11:50:04.057229000 Z
', '2015-03-05 11:50:06.03176');
INSERT INTO versions VALUES (1535, 'Person', 464, 'create', NULL, NULL, '2015-03-05 11:50:43.339704');
INSERT INTO versions VALUES (1536, 'Person', 342, 'update', NULL, '---
id: 342
salutation: 
name: ''Luz ''
lastnames: Maldonado
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 86
created_at: 2015-03-02 20:21:12.416348000 Z
updated_at: 2015-03-05 11:47:57.342499000 Z
', '2015-03-05 11:53:52.720944');
INSERT INTO versions VALUES (1537, 'Person', 257, 'update', NULL, '---
id: 257
salutation: 
name: ''Matilde ''
lastnames: ''Dávila ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 18
created_at: 2015-02-24 15:31:36.906140000 Z
updated_at: 2015-03-02 19:21:17.562284000 Z
', '2015-03-05 11:53:57.429003');
INSERT INTO versions VALUES (1538, 'Person', 257, 'update', NULL, '---
id: 257
salutation: 
name: ''Matilde ''
lastnames: ''Dávila ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 18
created_at: 2015-02-24 15:31:36.906140000 Z
updated_at: 2015-03-05 11:53:57.420229000 Z
', '2015-03-05 11:53:58.736531');
INSERT INTO versions VALUES (1539, 'Person', 259, 'update', NULL, '---
id: 259
salutation: 
name: Irma
lastnames: González
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 18
created_at: 2015-02-24 15:32:15.704090000 Z
updated_at: 2015-03-05 10:58:44.354061000 Z
', '2015-03-05 11:54:00.729191');
INSERT INTO versions VALUES (1540, 'Person', 259, 'update', NULL, '---
id: 259
salutation: 
name: Irma
lastnames: González
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 18
created_at: 2015-02-24 15:32:15.704090000 Z
updated_at: 2015-03-05 11:54:00.719143000 Z
', '2015-03-05 11:54:02.352966');
INSERT INTO versions VALUES (1541, 'Person', 259, 'update', NULL, '---
id: 259
salutation: 
name: Irma
lastnames: González
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 18
created_at: 2015-02-24 15:32:15.704090000 Z
updated_at: 2015-03-05 11:54:02.344409000 Z
', '2015-03-05 11:54:05.028134');
INSERT INTO versions VALUES (1542, 'Person', 259, 'update', NULL, '---
id: 259
salutation: 
name: Irma
lastnames: González
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 18
created_at: 2015-02-24 15:32:15.704090000 Z
updated_at: 2015-03-05 11:54:05.019128000 Z
', '2015-03-05 11:54:07.369649');
INSERT INTO versions VALUES (1543, 'Person', 259, 'update', NULL, '---
id: 259
salutation: 
name: Irma
lastnames: González
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 18
created_at: 2015-02-24 15:32:15.704090000 Z
updated_at: 2015-03-05 11:54:07.361432000 Z
', '2015-03-05 11:54:08.94125');
INSERT INTO versions VALUES (1544, 'Person', 259, 'update', NULL, '---
id: 259
salutation: 
name: Irma
lastnames: González
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 18
created_at: 2015-02-24 15:32:15.704090000 Z
updated_at: 2015-03-05 11:54:08.932015000 Z
', '2015-03-05 11:54:09.737646');
INSERT INTO versions VALUES (1545, 'Person', 260, 'update', NULL, '---
id: 260
salutation: 
name: ''Libertad ''
lastnames: ''Carrión ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 18
created_at: 2015-02-24 15:32:33.980877000 Z
updated_at: 2015-03-02 19:21:17.108770000 Z
', '2015-03-05 11:54:19.299082');
INSERT INTO versions VALUES (1546, 'Person', 289, 'update', NULL, '---
id: 289
salutation: 1
name: ''Angel L. ''
lastnames: Pabellón
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 75
created_at: 2015-02-27 02:34:55.182295000 Z
updated_at: 2015-03-02 19:23:03.369996000 Z
', '2015-03-05 11:54:19.960079');
INSERT INTO versions VALUES (1547, 'Person', 289, 'update', NULL, '---
id: 289
salutation: 1
name: ''Angel L. ''
lastnames: Pabellón
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 75
created_at: 2015-02-27 02:34:55.182295000 Z
updated_at: 2015-03-05 11:54:19.952096000 Z
', '2015-03-05 11:54:20.975214');
INSERT INTO versions VALUES (1548, 'Person', 260, 'update', NULL, '---
id: 260
salutation: 
name: ''Libertad ''
lastnames: ''Carrión ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 18
created_at: 2015-02-24 15:32:33.980877000 Z
updated_at: 2015-03-05 11:54:19.290259000 Z
', '2015-03-05 11:54:21.432609');
INSERT INTO versions VALUES (1549, 'Person', 263, 'update', NULL, '---
id: 263
salutation: 
name: ''Evelyn ''
lastnames: ''Cruz ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 96
created_at: 2015-02-24 15:37:12.574595000 Z
updated_at: 2015-03-02 19:23:44.675764000 Z
', '2015-03-05 11:54:36.223336');
INSERT INTO versions VALUES (1550, 'Person', 263, 'update', NULL, '---
id: 263
salutation: 
name: ''Evelyn ''
lastnames: ''Cruz ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 96
created_at: 2015-02-24 15:37:12.574595000 Z
updated_at: 2015-03-05 11:54:36.212528000 Z
', '2015-03-05 11:54:38.068054');
INSERT INTO versions VALUES (1551, 'Person', 135, 'update', NULL, '---
id: 135
salutation: 
name: ''Irving ''
lastnames: ''Rivera ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 23
created_at: 2015-02-24 02:52:29.814474000 Z
updated_at: 2015-03-02 19:20:52.876170000 Z
', '2015-03-05 11:55:05.280624');
INSERT INTO versions VALUES (1552, 'Person', 135, 'update', NULL, '---
id: 135
salutation: 
name: ''Irving ''
lastnames: ''Rivera ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 23
created_at: 2015-02-24 02:52:29.814474000 Z
updated_at: 2015-03-05 11:55:05.271062000 Z
', '2015-03-05 11:55:07.169831');
INSERT INTO versions VALUES (1553, 'Person', 184, 'update', NULL, '---
id: 184
salutation: 
name: ''Carlos ''
lastnames: ''Febo ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 1
created_at: 2015-02-24 14:10:25.178415000 Z
updated_at: 2015-03-02 19:21:10.268390000 Z
', '2015-03-05 11:55:29.640361');
INSERT INTO versions VALUES (1554, 'Person', 184, 'update', NULL, '---
id: 184
salutation: 
name: ''Carlos ''
lastnames: ''Febo ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 1
created_at: 2015-02-24 14:10:25.178415000 Z
updated_at: 2015-03-05 11:55:29.631270000 Z
', '2015-03-05 11:55:30.650121');
INSERT INTO versions VALUES (1555, 'Person', 56, 'update', NULL, '---
id: 56
salutation: 
name: ''Héctor N. ''
lastnames: ''López ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 10
created_at: 2015-02-24 01:58:53.431612000 Z
updated_at: 2015-03-02 19:20:49.653676000 Z
', '2015-03-05 11:55:39.869836');
INSERT INTO versions VALUES (1556, 'Person', 56, 'update', NULL, '---
id: 56
salutation: 
name: ''Héctor N. ''
lastnames: ''López ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 10
created_at: 2015-02-24 01:58:53.431612000 Z
updated_at: 2015-03-05 11:55:39.861039000 Z
', '2015-03-05 11:55:41.416211');
INSERT INTO versions VALUES (1557, 'Person', 181, 'update', NULL, '---
id: 181
salutation: 
name: ''Luis ''
lastnames: ''Rosario ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 1
created_at: 2015-02-24 14:09:15.743096000 Z
updated_at: 2015-03-02 19:21:13.793173000 Z
', '2015-03-05 11:55:56.010181');
INSERT INTO versions VALUES (1558, 'Person', 181, 'update', NULL, '---
id: 181
salutation: 
name: ''Luis ''
lastnames: ''Rosario ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 1
created_at: 2015-02-24 14:09:15.743096000 Z
updated_at: 2015-03-05 11:55:56.001771000 Z
', '2015-03-05 11:55:57.348226');
INSERT INTO versions VALUES (1559, 'Person', 307, 'update', NULL, '---
id: 307
salutation: 
name: ''Lizette ''
lastnames: ''Vázquez ''
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 51
created_at: 2015-03-02 19:25:50.298034000 Z
updated_at: 2015-03-02 19:26:56.895956000 Z
', '2015-03-05 11:55:57.818521');
INSERT INTO versions VALUES (1560, 'Person', 307, 'update', NULL, '---
id: 307
salutation: 
name: ''Lizette ''
lastnames: ''Vázquez ''
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 51
created_at: 2015-03-02 19:25:50.298034000 Z
updated_at: 2015-03-05 11:55:57.810789000 Z
', '2015-03-05 11:55:58.846156');
INSERT INTO versions VALUES (1561, 'Person', 362, 'update', NULL, '---
id: 362
salutation: 
name: Pedro P.
lastnames: Santiago Romero
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:17:12.159850000 Z
updated_at: 2015-03-04 20:48:27.019884000 Z
', '2015-03-05 11:56:14.501632');
INSERT INTO versions VALUES (1562, 'Person', 362, 'update', NULL, '---
id: 362
salutation: 
name: Pedro P.
lastnames: Santiago Romero
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:17:12.159850000 Z
updated_at: 2015-03-05 11:56:14.492671000 Z
', '2015-03-05 11:56:16.022595');
INSERT INTO versions VALUES (1563, 'Check', 35, 'create', NULL, NULL, '2015-03-05 11:56:29.042821');
INSERT INTO versions VALUES (1564, 'Person', 360, 'update', NULL, '---
id: 360
salutation: 
name: José A.
lastnames: Ortiz Rivera
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:14:22.501926000 Z
updated_at: 2015-03-04 20:41:23.412115000 Z
', '2015-03-05 11:58:27.321531');
INSERT INTO versions VALUES (1565, 'Person', 360, 'update', NULL, '---
id: 360
salutation: 
name: José A.
lastnames: Ortiz Rivera
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:14:22.501926000 Z
updated_at: 2015-03-05 11:58:27.310899000 Z
', '2015-03-05 11:58:28.743039');
INSERT INTO versions VALUES (1566, 'Person', 311, 'update', NULL, '---
id: 311
salutation: 
name: José M.
lastnames: Colón
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 51
created_at: 2015-03-02 19:27:20.512037000 Z
updated_at: 2015-03-02 19:33:01.396753000 Z
', '2015-03-05 11:58:32.570624');
INSERT INTO versions VALUES (1567, 'Person', 401, 'update', NULL, '---
id: 401
salutation: 
name: ''Alfredo ''
lastnames: Laboy
sex: true
role: 4
description: Representante Distrito
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:52:32.052594000 Z
updated_at: 2015-03-04 19:54:29.343721000 Z
', '2015-03-05 11:58:32.976937');
INSERT INTO versions VALUES (1568, 'Person', 311, 'update', NULL, '---
id: 311
salutation: 
name: José M.
lastnames: Colón
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 51
created_at: 2015-03-02 19:27:20.512037000 Z
updated_at: 2015-03-05 11:58:32.560944000 Z
', '2015-03-05 11:58:33.383865');
INSERT INTO versions VALUES (1569, 'Person', 401, 'update', NULL, '---
id: 401
salutation: 
name: ''Alfredo ''
lastnames: Laboy
sex: true
role: 4
description: Representante Distrito
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:52:32.052594000 Z
updated_at: 2015-03-05 11:58:32.967857000 Z
', '2015-03-05 11:58:34.015606');
INSERT INTO versions VALUES (1570, 'Person', 310, 'update', NULL, '---
id: 310
salutation: 
name: Adalberto
lastnames: Barbosa
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 51
created_at: 2015-03-02 19:26:55.393258000 Z
updated_at: 2015-03-02 19:33:00.985731000 Z
', '2015-03-05 11:58:58.219857');
INSERT INTO versions VALUES (1571, 'Person', 310, 'update', NULL, '---
id: 310
salutation: 
name: Adalberto
lastnames: Barbosa
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 51
created_at: 2015-03-02 19:26:55.393258000 Z
updated_at: 2015-03-05 11:58:58.209591000 Z
', '2015-03-05 11:58:59.695885');
INSERT INTO versions VALUES (1572, 'Person', 50, 'update', NULL, '---
id: 50
salutation: 
name: ''Ahmed ''
lastnames: ''Díaz ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 113
created_at: 2015-02-24 01:53:49.390545000 Z
updated_at: 2015-03-02 19:21:42.480561000 Z
', '2015-03-05 11:59:13.626023');
INSERT INTO versions VALUES (1573, 'Person', 50, 'update', NULL, '---
id: 50
salutation: 
name: ''Ahmed ''
lastnames: ''Díaz ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 113
created_at: 2015-02-24 01:53:49.390545000 Z
updated_at: 2015-03-05 11:59:13.616695000 Z
', '2015-03-05 11:59:15.675824');
INSERT INTO versions VALUES (1574, 'Person', 49, 'update', NULL, '---
id: 49
salutation: 
name: ''Víctor ''
lastnames: ''Rivera ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 113
created_at: 2015-02-24 01:53:29.170580000 Z
updated_at: 2015-03-02 19:21:45.728334000 Z
', '2015-03-05 11:59:42.415205');
INSERT INTO versions VALUES (1575, 'Person', 49, 'update', NULL, '---
id: 49
salutation: 
name: ''Víctor ''
lastnames: ''Rivera ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 113
created_at: 2015-02-24 01:53:29.170580000 Z
updated_at: 2015-03-05 11:59:42.405933000 Z
', '2015-03-05 11:59:46.488422');
INSERT INTO versions VALUES (1576, 'Person', 61, 'update', NULL, '---
id: 61
salutation: 
name: ''José A. ''
lastnames: ''Cotto ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 33
created_at: 2015-02-24 02:01:25.367756000 Z
updated_at: 2015-03-02 19:21:39.241725000 Z
', '2015-03-05 11:59:47.046579');
INSERT INTO versions VALUES (1577, 'Person', 61, 'update', NULL, '---
id: 61
salutation: 
name: ''José A. ''
lastnames: ''Cotto ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 33
created_at: 2015-02-24 02:01:25.367756000 Z
updated_at: 2015-03-05 11:59:47.037046000 Z
', '2015-03-05 11:59:47.858225');
INSERT INTO versions VALUES (1578, 'Person', 63, 'update', NULL, '---
id: 63
salutation: 
name: ''María del C. ''
lastnames: ''Meléndez ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 33
created_at: 2015-02-24 02:02:14.536270000 Z
updated_at: 2015-03-02 19:21:39.283821000 Z
', '2015-03-05 11:59:58.120815');
INSERT INTO versions VALUES (1579, 'Person', 63, 'update', NULL, '---
id: 63
salutation: 
name: ''María del C. ''
lastnames: ''Meléndez ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 33
created_at: 2015-02-24 02:02:14.536270000 Z
updated_at: 2015-03-05 11:59:58.111201000 Z
', '2015-03-05 11:59:59.583057');
INSERT INTO versions VALUES (1580, 'Person', 465, 'create', NULL, NULL, '2015-03-05 12:00:01.204315');
INSERT INTO versions VALUES (1581, 'Person', 442, 'update', NULL, '---
id: 442
salutation: 3
name: Raymond
lastnames: Martínez
sex: true
role: 4
description: Comisión de Planificación
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:11:17.805466000 Z
updated_at: 2015-03-04 20:15:53.009401000 Z
', '2015-03-05 12:00:28.539806');
INSERT INTO versions VALUES (1582, 'Person', 442, 'update', NULL, '---
id: 442
salutation: 3
name: Raymond
lastnames: Martínez
sex: true
role: 4
description: Comisión de Planificación
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:11:17.805466000 Z
updated_at: 2015-03-05 12:00:28.531326000 Z
', '2015-03-05 12:00:33.787355');
INSERT INTO versions VALUES (1583, 'Person', 466, 'create', NULL, NULL, '2015-03-05 12:00:35.190621');
INSERT INTO versions VALUES (1584, 'Person', 64, 'update', NULL, '---
id: 64
salutation: 
name: ''Emérito ''
lastnames: ''Sánchez ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 33
created_at: 2015-02-24 02:02:38.334079000 Z
updated_at: 2015-03-02 19:21:35.990376000 Z
', '2015-03-05 12:00:50.794114');
INSERT INTO versions VALUES (1585, 'Person', 338, 'update', NULL, '---
id: 338
salutation: 
name: Pedro J.
lastnames: Morales
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 29
created_at: 2015-03-02 19:55:39.350618000 Z
updated_at: 2015-03-02 20:00:15.988221000 Z
', '2015-03-05 12:00:51.953474');
INSERT INTO versions VALUES (1586, 'Person', 64, 'update', NULL, '---
id: 64
salutation: 
name: ''Emérito ''
lastnames: ''Sánchez ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 33
created_at: 2015-02-24 02:02:38.334079000 Z
updated_at: 2015-03-05 12:00:50.784250000 Z
', '2015-03-05 12:00:52.698239');
INSERT INTO versions VALUES (1587, 'Person', 338, 'update', NULL, '---
id: 338
salutation: 
name: Pedro J.
lastnames: Morales
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 29
created_at: 2015-03-02 19:55:39.350618000 Z
updated_at: 2015-03-05 12:00:51.944176000 Z
', '2015-03-05 12:00:53.486557');
INSERT INTO versions VALUES (1588, 'Person', 349, 'update', NULL, '---
id: 349
salutation: 
name: Francisca
lastnames: Rodríguez
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:03:01.357140000 Z
updated_at: 2015-03-04 21:22:33.738326000 Z
', '2015-03-05 12:02:01.822659');
INSERT INTO versions VALUES (1589, 'Person', 349, 'update', NULL, '---
id: 349
salutation: 
name: Francisca
lastnames: Rodríguez
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:03:01.357140000 Z
updated_at: 2015-03-05 12:02:01.813157000 Z
', '2015-03-05 12:02:02.950526');
INSERT INTO versions VALUES (1590, 'Person', 351, 'update', NULL, '---
id: 351
salutation: 
name: Francisca
lastnames: Alicea
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:03:46.627915000 Z
updated_at: 2015-03-04 21:22:33.716848000 Z
', '2015-03-05 12:02:04.672399');
INSERT INTO versions VALUES (1591, 'Person', 351, 'update', NULL, '---
id: 351
salutation: 
name: Francisca
lastnames: Alicea
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:03:46.627915000 Z
updated_at: 2015-03-05 12:02:04.663311000 Z
', '2015-03-05 12:02:05.997551');
INSERT INTO versions VALUES (1592, 'Person', 348, 'update', NULL, '---
id: 348
salutation: 
name: Juan
lastnames: Figueroa
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:02:42.315908000 Z
updated_at: 2015-03-04 21:22:33.746883000 Z
', '2015-03-05 12:02:35.532403');
INSERT INTO versions VALUES (1593, 'Person', 348, 'update', NULL, '---
id: 348
salutation: 
name: Juan
lastnames: Figueroa
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:02:42.315908000 Z
updated_at: 2015-03-05 12:02:35.523687000 Z
', '2015-03-05 12:02:36.709128');
INSERT INTO versions VALUES (1594, 'Person', 350, 'update', NULL, '---
id: 350
salutation: 
name: Myrna
lastnames: Villafranca
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:03:24.913737000 Z
updated_at: 2015-03-04 20:34:19.716132000 Z
', '2015-03-05 12:02:38.554284');
INSERT INTO versions VALUES (1595, 'Person', 350, 'update', NULL, '---
id: 350
salutation: 
name: Myrna
lastnames: Villafranca
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:03:24.913737000 Z
updated_at: 2015-03-05 12:02:38.545045000 Z
', '2015-03-05 12:02:40.697644');
INSERT INTO versions VALUES (1596, 'Person', 343, 'update', NULL, '---
id: 343
salutation: 1
name: Ruth A.
lastnames: Martínez
sex: false
role: 4
description: Representante General
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 10:57:00.490612000 Z
updated_at: 2015-03-04 20:21:00.176542000 Z
', '2015-03-05 12:02:44.658195');
INSERT INTO versions VALUES (1597, 'Person', 343, 'update', NULL, '---
id: 343
salutation: 1
name: Ruth A.
lastnames: Martínez
sex: false
role: 4
description: Representante General
attended: true
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 10:57:00.490612000 Z
updated_at: 2015-03-05 12:02:44.649965000 Z
', '2015-03-05 12:02:47.667942');
INSERT INTO versions VALUES (1598, 'Person', 340, 'update', NULL, '---
id: 340
salutation: 0
name: ''Luis R. ''
lastnames: Figueroa
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 86
created_at: 2015-03-02 20:20:35.244301000 Z
updated_at: 2015-03-02 20:50:19.229328000 Z
', '2015-03-05 12:03:05.786907');
INSERT INTO versions VALUES (1599, 'Person', 340, 'update', NULL, '---
id: 340
salutation: 0
name: ''Luis R. ''
lastnames: Figueroa
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 86
created_at: 2015-03-02 20:20:35.244301000 Z
updated_at: 2015-03-05 12:03:05.783453000 Z
', '2015-03-05 12:03:06.736182');
INSERT INTO versions VALUES (1600, 'Person', 346, 'update', NULL, '---
id: 346
salutation: 0
name: Carmen W.
lastnames: Lebrón
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:00:06.930223000 Z
updated_at: 2015-03-04 20:52:30.307622000 Z
', '2015-03-05 12:03:22.112597');
INSERT INTO versions VALUES (1601, 'Person', 346, 'update', NULL, '---
id: 346
salutation: 0
name: Carmen W.
lastnames: Lebrón
sex: false
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 11:00:06.930223000 Z
updated_at: 2015-03-05 12:03:22.103178000 Z
', '2015-03-05 12:03:23.299211');
INSERT INTO versions VALUES (1602, 'Person', 8, 'update', NULL, '---
id: 8
salutation: 
name: ''Rómulo ''
lastnames: ''Ortiz ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 105
created_at: 2015-02-23 22:26:41.588490000 Z
updated_at: 2015-03-04 20:27:11.073227000 Z
', '2015-03-05 12:04:10.654751');
INSERT INTO versions VALUES (1603, 'Person', 8, 'update', NULL, '---
id: 8
salutation: 
name: ''Rómulo ''
lastnames: ''Ortiz ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 105
created_at: 2015-02-23 22:26:41.588490000 Z
updated_at: 2015-03-05 12:04:10.646371000 Z
', '2015-03-05 12:04:12.063724');
INSERT INTO versions VALUES (1604, 'Person', 417, 'update', NULL, '---
id: 417
salutation: 
name: José L.
lastnames: Alicea
sex: true
role: 4
description: Representante Distrito
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:57:32.710282000 Z
updated_at: 2015-03-04 19:57:36.186841000 Z
', '2015-03-05 12:04:14.534476');
INSERT INTO versions VALUES (1605, 'Person', 417, 'update', NULL, '---
id: 417
salutation: 
name: José L.
lastnames: Alicea
sex: true
role: 4
description: Representante Distrito
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:57:32.710282000 Z
updated_at: 2015-03-05 12:04:14.523080000 Z
', '2015-03-05 12:04:15.162102');
INSERT INTO versions VALUES (1606, 'Person', 58, 'destroy', NULL, '---
id: 58
salutation: 0
name: ''Jorge L. ''
lastnames: ''Cintrón ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 33
created_at: 2015-02-24 02:00:09.302735000 Z
updated_at: 2015-03-02 19:21:35.997652000 Z
', '2015-03-05 12:04:29.329117');
INSERT INTO versions VALUES (1607, 'Person', 340, 'update', NULL, '---
id: 340
salutation: 0
name: ''Luis R. ''
lastnames: Figueroa
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: true
church_id: 86
created_at: 2015-03-02 20:20:35.244301000 Z
updated_at: 2015-03-05 12:03:06.726903000 Z
', '2015-03-05 12:04:55.21114');
INSERT INTO versions VALUES (1608, 'Person', 309, 'update', NULL, '---
id: 309
salutation: 
name: ''Nilza ''
lastnames: ''Rivera ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 51
created_at: 2015-03-02 19:26:35.216231000 Z
updated_at: 2015-03-02 19:26:56.914007000 Z
', '2015-03-05 12:04:56.08381');
INSERT INTO versions VALUES (1609, 'Person', 309, 'update', NULL, '---
id: 309
salutation: 
name: ''Nilza ''
lastnames: ''Rivera ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 51
created_at: 2015-03-02 19:26:35.216231000 Z
updated_at: 2015-03-05 12:04:56.072685000 Z
', '2015-03-05 12:04:58.355802');
INSERT INTO versions VALUES (1610, 'Person', 248, 'update', NULL, '---
id: 248
salutation: 1
name: Juan Nelson
lastnames: Medina
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 99
created_at: 2015-02-24 15:16:16.155526000 Z
updated_at: 2015-03-05 11:45:23.189271000 Z
', '2015-03-05 12:05:47.076373');
INSERT INTO versions VALUES (1611, 'Person', 464, 'update', NULL, '---
id: 464
salutation: 
name: Marylin D.
lastnames: Soto Quintana
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 27
created_at: 2015-03-05 11:50:43.333068000 Z
updated_at: 2015-03-05 11:50:43.333068000 Z
', '2015-03-05 12:05:47.199565');
INSERT INTO versions VALUES (1612, 'Person', 342, 'update', NULL, '---
id: 342
salutation: 
name: ''Luz ''
lastnames: Maldonado
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 86
created_at: 2015-03-02 20:21:12.416348000 Z
updated_at: 2015-03-05 11:53:52.716112000 Z
', '2015-03-05 12:05:48.329106');
INSERT INTO versions VALUES (1613, 'Person', 465, 'update', NULL, '---
id: 465
salutation: 1
name: Guillermo
lastnames: Diaz
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 30
created_at: 2015-03-05 12:00:01.198987000 Z
updated_at: 2015-03-05 12:00:01.198987000 Z
', '2015-03-05 12:05:48.33423');
INSERT INTO versions VALUES (1614, 'Person', 466, 'update', NULL, '---
id: 466
salutation: 
name: Frank
lastnames: Perez
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 30
created_at: 2015-03-05 12:00:35.185212000 Z
updated_at: 2015-03-05 12:00:35.185212000 Z
', '2015-03-05 12:05:48.338673');
INSERT INTO versions VALUES (1615, 'Person', 340, 'update', NULL, '---
id: 340
salutation: 0
name: ''Luis R. ''
lastnames: Figueroa
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 86
created_at: 2015-03-02 20:20:35.244301000 Z
updated_at: 2015-03-05 12:04:55.207211000 Z
', '2015-03-05 12:05:48.34268');
INSERT INTO versions VALUES (1616, 'Person', 188, 'update', NULL, '---
id: 188
salutation: 
name: ''Anidalia ''
lastnames: Rivera
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 42
created_at: 2015-02-24 14:19:32.496052000 Z
updated_at: 2015-03-02 19:22:12.436047000 Z
', '2015-03-05 12:05:50.62679');
INSERT INTO versions VALUES (1617, 'Person', 188, 'update', NULL, '---
id: 188
salutation: 
name: ''Anidalia ''
lastnames: Rivera
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 42
created_at: 2015-02-24 14:19:32.496052000 Z
updated_at: 2015-03-05 12:05:50.618061000 Z
', '2015-03-05 12:05:52.084725');
INSERT INTO versions VALUES (1618, 'Person', 466, 'update', NULL, '---
id: 466
salutation: 
name: Frank
lastnames: Perez
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 30
created_at: 2015-03-05 12:00:35.185212000 Z
updated_at: 2015-03-05 12:05:48.336188000 Z
', '2015-03-05 12:06:01.933242');
INSERT INTO versions VALUES (1619, 'Person', 465, 'update', NULL, '---
id: 465
salutation: 1
name: Guillermo
lastnames: Diaz
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: true
church_id: 30
created_at: 2015-03-05 12:00:01.198987000 Z
updated_at: 2015-03-05 12:05:48.331176000 Z
', '2015-03-05 12:06:03.12706');
INSERT INTO versions VALUES (1620, 'Person', 467, 'create', NULL, NULL, '2015-03-05 12:06:15.593144');
INSERT INTO versions VALUES (1621, 'Person', 365, 'update', NULL, '---
id: 365
salutation: 
name: Ada
lastnames: Serrano
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 11:19:51.909843000 Z
updated_at: 2015-03-04 20:48:26.935385000 Z
', '2015-03-05 12:06:35.348416');
INSERT INTO versions VALUES (1622, 'Person', 365, 'update', NULL, '---
id: 365
salutation: 
name: Ada
lastnames: Serrano
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 11:19:51.909843000 Z
updated_at: 2015-03-05 12:06:35.338760000 Z
', '2015-03-05 12:06:36.958234');
INSERT INTO versions VALUES (1623, 'Person', 133, 'update', NULL, '---
id: 133
salutation: 
name: ''Lizvette ''
lastnames: ''Rodríguez ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 65
created_at: 2015-02-24 02:49:09.238478000 Z
updated_at: 2015-03-02 19:23:25.734382000 Z
', '2015-03-05 12:07:31.363074');
INSERT INTO versions VALUES (1624, 'Person', 133, 'update', NULL, '---
id: 133
salutation: 
name: ''Lizvette ''
lastnames: ''Rodríguez ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 65
created_at: 2015-02-24 02:49:09.238478000 Z
updated_at: 2015-03-05 12:07:31.353933000 Z
', '2015-03-05 12:07:32.837127');
INSERT INTO versions VALUES (1625, 'Person', 468, 'create', NULL, NULL, '2015-03-05 12:07:59.312223');
INSERT INTO versions VALUES (1626, 'Person', 187, 'update', NULL, '---
id: 187
salutation: 
name: Ada N.
lastnames: Quiñones
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 42
created_at: 2015-02-24 14:19:01.547741000 Z
updated_at: 2015-03-02 19:22:12.426215000 Z
', '2015-03-05 12:08:27.253439');
INSERT INTO versions VALUES (1627, 'Person', 187, 'update', NULL, '---
id: 187
salutation: 
name: Ada N.
lastnames: Quiñones
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 42
created_at: 2015-02-24 14:19:01.547741000 Z
updated_at: 2015-03-05 12:08:27.245029000 Z
', '2015-03-05 12:08:28.48392');
INSERT INTO versions VALUES (1628, 'Person', 205, 'update', NULL, '---
id: 205
salutation: 1
name: Luz E.
lastnames: Rodríguez
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 84
created_at: 2015-02-24 14:42:43.920366000 Z
updated_at: 2015-03-02 19:23:10.295882000 Z
', '2015-03-05 12:08:28.912105');
INSERT INTO versions VALUES (1629, 'Person', 205, 'update', NULL, '---
id: 205
salutation: 1
name: Luz E.
lastnames: Rodríguez
sex: false
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 84
created_at: 2015-02-24 14:42:43.920366000 Z
updated_at: 2015-03-05 12:08:28.902771000 Z
', '2015-03-05 12:08:30.517643');
INSERT INTO versions VALUES (1630, 'Person', 366, 'update', NULL, '---
id: 366
salutation: 
name: Nelson
lastnames: Ortiz
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 11:20:18.775498000 Z
updated_at: 2015-03-04 20:48:26.991481000 Z
', '2015-03-05 12:08:49.077025');
INSERT INTO versions VALUES (1631, 'Person', 366, 'update', NULL, '---
id: 366
salutation: 
name: Nelson
lastnames: Ortiz
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 11:20:18.775498000 Z
updated_at: 2015-03-05 12:08:49.066263000 Z
', '2015-03-05 12:08:49.966919');
INSERT INTO versions VALUES (1632, 'Person', 398, 'update', NULL, '---
id: 398
salutation: 1
name: arcadio
lastnames: gonzalez
sex: true
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:51:28.532266000 Z
updated_at: 2015-03-04 19:52:25.996274000 Z
', '2015-03-05 12:09:32.131557');
INSERT INTO versions VALUES (1633, 'Person', 398, 'update', NULL, '---
id: 398
salutation: 1
name: arcadio
lastnames: gonzalez
sex: true
role: 2
description: ''''
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:51:28.532266000 Z
updated_at: 2015-03-05 12:09:32.122104000 Z
', '2015-03-05 12:09:33.777521');
INSERT INTO versions VALUES (1634, 'Person', 469, 'create', NULL, NULL, '2015-03-05 12:09:50.848196');
INSERT INTO versions VALUES (1635, 'Person', 470, 'create', NULL, NULL, '2015-03-05 12:10:48.621178');
INSERT INTO versions VALUES (1642, 'Person', 341, 'update', NULL, '---
id: 341
salutation: 
name: ''Bonifacio ''
lastnames: Del Valle
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 86
created_at: 2015-03-02 20:20:58.471397000 Z
updated_at: 2015-03-02 20:50:19.004934000 Z
', '2015-03-05 12:12:48.991321');
INSERT INTO versions VALUES (1643, 'Person', 270, 'update', NULL, '---
id: 270
salutation: 4
name: ''Arturo J. ''
lastnames: Siaca
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 36
created_at: 2015-02-24 17:41:40.122104000 Z
updated_at: 2015-03-02 19:21:46.312984000 Z
', '2015-03-05 12:12:53.216184');
INSERT INTO versions VALUES (1644, 'Person', 270, 'update', NULL, '---
id: 270
salutation: 4
name: ''Arturo J. ''
lastnames: Siaca
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 36
created_at: 2015-02-24 17:41:40.122104000 Z
updated_at: 2015-03-05 12:12:53.207329000 Z
', '2015-03-05 12:12:55.094011');
INSERT INTO versions VALUES (1645, 'Check', 36, 'create', NULL, NULL, '2015-03-05 12:13:29.143939');
INSERT INTO versions VALUES (1646, 'Person', 1, 'update', NULL, '---
id: 1
salutation: 1
name: ''Roy ''
lastnames: ''Acosta ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 108
created_at: 2015-02-23 22:21:49.889093000 Z
updated_at: 2015-03-02 19:23:25.695894000 Z
', '2015-03-05 12:14:02.283644');
INSERT INTO versions VALUES (1647, 'Person', 1, 'update', NULL, '---
id: 1
salutation: 1
name: ''Roy ''
lastnames: ''Acosta ''
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 108
created_at: 2015-02-23 22:21:49.889093000 Z
updated_at: 2015-03-05 12:14:02.277696000 Z
', '2015-03-05 12:14:03.601918');
INSERT INTO versions VALUES (1648, 'Person', 3, 'update', NULL, '---
id: 3
salutation: 
name: José
lastnames: ''Tejeda ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 108
created_at: 2015-02-23 22:23:11.598545000 Z
updated_at: 2015-03-02 19:23:22.487229000 Z
', '2015-03-05 12:14:21.974166');
INSERT INTO versions VALUES (1649, 'Person', 3, 'update', NULL, '---
id: 3
salutation: 
name: José
lastnames: ''Tejeda ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 108
created_at: 2015-02-23 22:23:11.598545000 Z
updated_at: 2015-03-05 12:14:21.964608000 Z
', '2015-03-05 12:14:23.49246');
INSERT INTO versions VALUES (1650, 'Person', 261, 'update', NULL, '---
id: 261
salutation: 
name: Carmen I.
lastnames: ''Fontanez ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 96
created_at: 2015-02-24 15:36:45.081695000 Z
updated_at: 2015-03-02 19:23:44.668935000 Z
', '2015-03-05 12:15:10.836165');
INSERT INTO versions VALUES (1651, 'Person', 261, 'update', NULL, '---
id: 261
salutation: 
name: Carmen I.
lastnames: ''Fontanez ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 96
created_at: 2015-02-24 15:36:45.081695000 Z
updated_at: 2015-03-05 12:15:10.826281000 Z
', '2015-03-05 12:15:12.760877');
INSERT INTO versions VALUES (1652, 'Person', 262, 'update', NULL, '---
id: 262
salutation: 
name: ''Luis ''
lastnames: ''Beltran ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 96
created_at: 2015-02-24 15:36:59.766195000 Z
updated_at: 2015-03-02 19:23:44.681075000 Z
', '2015-03-05 12:16:51.280975');
INSERT INTO versions VALUES (1636, 'Person', 466, 'update', NULL, '---
id: 466
salutation: 
name: Frank
lastnames: Perez
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 30
created_at: 2015-03-05 12:00:35.185212000 Z
updated_at: 2015-03-05 12:06:01.927850000 Z
', '2015-03-05 12:10:51.726654');
INSERT INTO versions VALUES (1637, 'Person', 465, 'update', NULL, '---
id: 465
salutation: 1
name: Guillermo
lastnames: Diaz
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 30
created_at: 2015-03-05 12:00:01.198987000 Z
updated_at: 2015-03-05 12:06:03.121545000 Z
', '2015-03-05 12:10:51.773177');
INSERT INTO versions VALUES (1638, 'Person', 467, 'update', NULL, '---
id: 467
salutation: 
name: Maria V.
lastnames: Coris
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 38
created_at: 2015-03-05 12:06:15.586260000 Z
updated_at: 2015-03-05 12:06:15.586260000 Z
', '2015-03-05 12:10:51.780276');
INSERT INTO versions VALUES (1639, 'Person', 468, 'update', NULL, '---
id: 468
salutation: 
name: ''Haydee ''
lastnames: Molina
sex: false
role: 3
description: Delegada
attended: true
printed: false
materials: true
church_id: 38
created_at: 2015-03-05 12:07:59.292427000 Z
updated_at: 2015-03-05 12:07:59.292427000 Z
', '2015-03-05 12:10:51.787797');
INSERT INTO versions VALUES (1640, 'Person', 469, 'update', NULL, '---
id: 469
salutation: 
name: ''Betty ''
lastnames: Hernández
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 125
created_at: 2015-03-05 12:09:50.841544000 Z
updated_at: 2015-03-05 12:09:50.841544000 Z
', '2015-03-05 12:10:51.792535');
INSERT INTO versions VALUES (1641, 'Person', 470, 'update', NULL, '---
id: 470
salutation: 
name: Carmen
lastnames: García
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 125
created_at: 2015-03-05 12:10:48.615878000 Z
updated_at: 2015-03-05 12:10:48.615878000 Z
', '2015-03-05 12:10:51.79854');
INSERT INTO versions VALUES (1720, 'Person', 341, 'update', NULL, '---
id: 341
salutation: 
name: ''Bonifacio ''
lastnames: Del Valle
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 86
created_at: 2015-03-02 20:20:58.471397000 Z
updated_at: 2015-03-05 12:12:48.986908000 Z
', '2015-03-05 12:28:55.839253');
INSERT INTO versions VALUES (1721, 'Person', 60, 'update', NULL, '---
id: 60
salutation: 
name: Angel L.
lastnames: Colon
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 33
created_at: 2015-02-24 02:00:59.145070000 Z
updated_at: 2015-03-05 12:18:11.171726000 Z
', '2015-03-05 12:28:56.018792');
INSERT INTO versions VALUES (1722, 'Person', 459, 'update', NULL, '---
id: 459
salutation: 
name: Alma
lastnames: Maldonado
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 48
created_at: 2015-03-04 21:31:38.650802000 Z
updated_at: 2015-03-05 12:23:00.529752000 Z
', '2015-03-05 12:28:56.033769');
INSERT INTO versions VALUES (1723, 'Person', 471, 'update', NULL, '---
id: 471
salutation: 
name: ''José ''
lastnames: Rodríguez Dieppa
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 54
created_at: 2015-03-05 12:27:42.225096000 Z
updated_at: 2015-03-05 12:27:42.225096000 Z
', '2015-03-05 12:28:56.042088');
INSERT INTO versions VALUES (1724, 'Person', 45, 'update', NULL, '---
id: 45
salutation: 
name: ''Leticia ''
lastnames: ''Santaella ''
sex: false
role: 4
description: ''''
attended: false
printed: false
materials: false
church_id: 112
created_at: 2015-02-24 01:51:34.052136000 Z
updated_at: 2015-03-05 12:27:57.943134000 Z
', '2015-03-05 12:28:56.048604');
INSERT INTO versions VALUES (1725, 'Person', 472, 'update', NULL, '---
id: 472
salutation: 
name: Maribel
lastnames: Barbosa
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 54
created_at: 2015-03-05 12:28:18.600277000 Z
updated_at: 2015-03-05 12:28:18.600277000 Z
', '2015-03-05 12:28:56.055557');
INSERT INTO versions VALUES (1653, 'Person', 262, 'update', NULL, '---
id: 262
salutation: 
name: ''Luis ''
lastnames: ''Beltran ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 96
created_at: 2015-02-24 15:36:59.766195000 Z
updated_at: 2015-03-05 12:16:51.271738000 Z
', '2015-03-05 12:16:52.983007');
INSERT INTO versions VALUES (1654, 'Person', 302, 'update', NULL, '---
id: 302
salutation: 
name: ''Ana ''
lastnames: ''Diaz ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 85
created_at: 2015-03-02 19:18:55.910737000 Z
updated_at: 2015-03-02 19:23:29.024259000 Z
', '2015-03-05 12:16:53.458172');
INSERT INTO versions VALUES (1655, 'Person', 302, 'update', NULL, '---
id: 302
salutation: 
name: ''Ana ''
lastnames: ''Diaz ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 85
created_at: 2015-03-02 19:18:55.910737000 Z
updated_at: 2015-03-05 12:16:53.448980000 Z
', '2015-03-05 12:16:54.642165');
INSERT INTO versions VALUES (1656, 'Person', 6, 'update', NULL, '---
id: 6
salutation: 1
name: ''Eneida ''
lastnames: Angleró
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 105
created_at: 2015-02-23 22:25:35.265226000 Z
updated_at: 2015-03-04 20:27:11.001228000 Z
', '2015-03-05 12:17:15.959475');
INSERT INTO versions VALUES (1657, 'Person', 6, 'update', NULL, '---
id: 6
salutation: 1
name: ''Eneida ''
lastnames: Angleró
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 105
created_at: 2015-02-23 22:25:35.265226000 Z
updated_at: 2015-03-05 12:17:15.955812000 Z
', '2015-03-05 12:17:17.982852');
INSERT INTO versions VALUES (1658, 'Check', 37, 'create', NULL, NULL, '2015-03-05 12:17:48.941209');
INSERT INTO versions VALUES (1659, 'Person', 60, 'update', NULL, '---
id: 60
salutation: 
name: ''Angel ''
lastnames: ''De Jesús ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 33
created_at: 2015-02-24 02:00:59.145070000 Z
updated_at: 2015-03-02 19:21:35.873780000 Z
', '2015-03-05 12:18:03.613731');
INSERT INTO versions VALUES (1660, 'Person', 60, 'update', NULL, '---
id: 60
salutation: 
name: Angel L.
lastnames: Colon
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 33
created_at: 2015-02-24 02:00:59.145070000 Z
updated_at: 2015-03-05 12:18:03.604456000 Z
', '2015-03-05 12:18:07.905053');
INSERT INTO versions VALUES (1661, 'Person', 183, 'update', NULL, '---
id: 183
salutation: 
name: ''Saúl ''
lastnames: Castillo
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 1
created_at: 2015-02-24 14:10:04.471921000 Z
updated_at: 2015-03-02 19:21:13.957971000 Z
', '2015-03-05 12:18:08.344553');
INSERT INTO versions VALUES (1662, 'Person', 60, 'update', NULL, '---
id: 60
salutation: 
name: Angel L.
lastnames: Colon
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 33
created_at: 2015-02-24 02:00:59.145070000 Z
updated_at: 2015-03-05 12:18:07.896412000 Z
', '2015-03-05 12:18:09.636625');
INSERT INTO versions VALUES (1663, 'Person', 183, 'update', NULL, '---
id: 183
salutation: 
name: ''Saúl ''
lastnames: Castillo
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 1
created_at: 2015-02-24 14:10:04.471921000 Z
updated_at: 2015-03-05 12:18:08.341759000 Z
', '2015-03-05 12:18:09.891283');
INSERT INTO versions VALUES (1664, 'Person', 60, 'update', NULL, '---
id: 60
salutation: 
name: Angel L.
lastnames: Colon
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: true
church_id: 33
created_at: 2015-02-24 02:00:59.145070000 Z
updated_at: 2015-03-05 12:18:09.627250000 Z
', '2015-03-05 12:18:11.18102');
INSERT INTO versions VALUES (1665, 'Person', 313, 'update', NULL, '---
id: 313
salutation: 
name: Ramón
lastnames: Negrón
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 2
created_at: 2015-03-02 19:30:39.762878000 Z
updated_at: 2015-03-02 19:33:00.426942000 Z
', '2015-03-05 12:18:32.705907');
INSERT INTO versions VALUES (1666, 'Person', 312, 'update', NULL, '---
id: 312
salutation: 0
name: Carlos I.
lastnames: ''López ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 2
created_at: 2015-03-02 19:30:21.919239000 Z
updated_at: 2015-03-02 19:33:00.278954000 Z
', '2015-03-05 12:18:37.52527');
INSERT INTO versions VALUES (1667, 'Person', 313, 'update', NULL, '---
id: 313
salutation: 
name: Ramón
lastnames: Negrón
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 2
created_at: 2015-03-02 19:30:39.762878000 Z
updated_at: 2015-03-05 12:18:32.696388000 Z
', '2015-03-05 12:18:38.613631');
INSERT INTO versions VALUES (1668, 'Person', 312, 'update', NULL, '---
id: 312
salutation: 0
name: Carlos I.
lastnames: ''López ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: true
church_id: 2
created_at: 2015-03-02 19:30:21.919239000 Z
updated_at: 2015-03-05 12:18:37.515618000 Z
', '2015-03-05 12:18:40.30044');
INSERT INTO versions VALUES (1669, 'Person', 446, 'update', NULL, '---
id: 446
salutation: 0
name: Felipe
lastnames: Candelaria
sex: true
role: 4
description: Representante en ABC
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:12:48.643667000 Z
updated_at: 2015-03-04 20:15:53.160322000 Z
', '2015-03-05 12:19:28.248337');
INSERT INTO versions VALUES (1670, 'Person', 446, 'update', NULL, '---
id: 446
salutation: 0
name: Felipe
lastnames: Candelaria
sex: true
role: 4
description: Representante en ABC
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:12:48.643667000 Z
updated_at: 2015-03-05 12:19:28.239737000 Z
', '2015-03-05 12:19:29.213666');
INSERT INTO versions VALUES (1671, 'Person', 435, 'update', NULL, '---
id: 435
salutation: 1
name: Aida
lastnames: Castillo
sex: false
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:03:16.083663000 Z
updated_at: 2015-03-04 20:03:46.316651000 Z
', '2015-03-05 12:19:46.714153');
INSERT INTO versions VALUES (1672, 'Person', 435, 'update', NULL, '---
id: 435
salutation: 1
name: Aida
lastnames: Castillo
sex: false
role: 2
description: ''''
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:03:16.083663000 Z
updated_at: 2015-03-05 12:19:46.709336000 Z
', '2015-03-05 12:19:47.750147');
INSERT INTO versions VALUES (1673, 'Person', 39, 'update', NULL, '---
id: 39
salutation: 
name: ''José ''
lastnames: ''Armenteros ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 107
created_at: 2015-02-24 01:46:09.753433000 Z
updated_at: 2015-03-02 19:23:18.474315000 Z
', '2015-03-05 12:20:51.438612');
INSERT INTO versions VALUES (1674, 'Person', 39, 'update', NULL, '---
id: 39
salutation: 
name: ''José ''
lastnames: ''Armenteros ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 107
created_at: 2015-02-24 01:46:09.753433000 Z
updated_at: 2015-03-05 12:20:51.429890000 Z
', '2015-03-05 12:20:52.418662');
INSERT INTO versions VALUES (1675, 'Person', 79, 'update', NULL, '---
id: 79
salutation: 1
name: ''Angel ''
lastnames: ''Cruz ''
sex: true
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:13:25.268081000 Z
updated_at: 2015-03-02 19:21:00.030796000 Z
', '2015-03-05 12:21:07.006634');
INSERT INTO versions VALUES (1676, 'Person', 79, 'update', NULL, '---
id: 79
salutation: 1
name: ''Angel ''
lastnames: ''Cruz ''
sex: true
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:13:25.268081000 Z
updated_at: 2015-03-05 12:21:06.997218000 Z
', '2015-03-05 12:21:08.410275');
INSERT INTO versions VALUES (1677, 'Check', 38, 'create', NULL, NULL, '2015-03-05 12:21:12.199919');
INSERT INTO versions VALUES (1678, 'Person', 182, 'update', NULL, '---
id: 182
salutation: 
name: ''Luis ''
lastnames: Osorio
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 1
created_at: 2015-02-24 14:09:37.573035000 Z
updated_at: 2015-03-02 19:21:10.311343000 Z
', '2015-03-05 12:21:37.78082');
INSERT INTO versions VALUES (1679, 'Person', 182, 'update', NULL, '---
id: 182
salutation: 
name: ''Luis ''
lastnames: Osorio
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 1
created_at: 2015-02-24 14:09:37.573035000 Z
updated_at: 2015-03-05 12:21:37.771492000 Z
', '2015-03-05 12:21:39.948733');
INSERT INTO versions VALUES (1680, 'Person', 459, 'update', NULL, '---
id: 459
salutation: 
name: Alma
lastnames: Morales
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 21:31:38.650802000 Z
updated_at: 2015-03-04 21:34:57.024462000 Z
', '2015-03-05 12:22:00.826848');
INSERT INTO versions VALUES (1681, 'Person', 105, 'update', NULL, '---
id: 105
salutation: 4
name: ''Nayda ''
lastnames: Márquez
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 52
created_at: 2015-02-24 02:30:38.332964000 Z
updated_at: 2015-03-02 19:22:04.362381000 Z
', '2015-03-05 12:22:04.03301');
INSERT INTO versions VALUES (1682, 'Person', 105, 'update', NULL, '---
id: 105
salutation: 4
name: ''Nayda ''
lastnames: Márquez
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 52
created_at: 2015-02-24 02:30:38.332964000 Z
updated_at: 2015-03-05 12:22:04.024453000 Z
', '2015-03-05 12:22:05.040302');
INSERT INTO versions VALUES (1683, 'Person', 459, 'update', NULL, '---
id: 459
salutation: 
name: Alma
lastnames: Maldonado
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 21:31:38.650802000 Z
updated_at: 2015-03-05 12:22:00.818043000 Z
', '2015-03-05 12:22:34.918102');
INSERT INTO versions VALUES (1684, 'Person', 62, 'update', NULL, '---
id: 62
salutation: 
name: ''Jorge L. ''
lastnames: ''Oquendo ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 33
created_at: 2015-02-24 02:01:45.246570000 Z
updated_at: 2015-03-02 19:21:36.004630000 Z
', '2015-03-05 12:22:42.781949');
INSERT INTO versions VALUES (1685, 'Person', 59, 'update', NULL, '---
id: 59
salutation: 
name: ''Antonio ''
lastnames: ''Cabrera ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 33
created_at: 2015-02-24 02:00:30.777975000 Z
updated_at: 2015-03-02 19:21:35.961554000 Z
', '2015-03-05 12:22:43.844606');
INSERT INTO versions VALUES (1686, 'Person', 62, 'update', NULL, '---
id: 62
salutation: 
name: ''Jorge L. ''
lastnames: ''Oquendo ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 33
created_at: 2015-02-24 02:01:45.246570000 Z
updated_at: 2015-03-05 12:22:42.774063000 Z
', '2015-03-05 12:22:44.523283');
INSERT INTO versions VALUES (1687, 'Person', 59, 'update', NULL, '---
id: 59
salutation: 
name: ''Antonio ''
lastnames: ''Cabrera ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 33
created_at: 2015-02-24 02:00:30.777975000 Z
updated_at: 2015-03-05 12:22:43.836454000 Z
', '2015-03-05 12:22:45.601784');
INSERT INTO versions VALUES (1688, 'Person', 459, 'update', NULL, '---
id: 459
salutation: 
name: Alma
lastnames: Maldonado
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 48
created_at: 2015-03-04 21:31:38.650802000 Z
updated_at: 2015-03-05 12:22:34.912307000 Z
', '2015-03-05 12:22:58.406863');
INSERT INTO versions VALUES (1689, 'Person', 459, 'update', NULL, '---
id: 459
salutation: 
name: Alma
lastnames: Maldonado
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: false
church_id: 48
created_at: 2015-03-04 21:31:38.650802000 Z
updated_at: 2015-03-05 12:22:58.397328000 Z
', '2015-03-05 12:23:00.537114');
INSERT INTO versions VALUES (1690, 'Person', 59, 'update', NULL, '---
id: 59
salutation: 
name: ''Antonio ''
lastnames: ''Cabrera ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 33
created_at: 2015-02-24 02:00:30.777975000 Z
updated_at: 2015-03-05 12:22:45.592430000 Z
', '2015-03-05 12:23:15.888435');
INSERT INTO versions VALUES (1691, 'Person', 271, 'update', NULL, '---
id: 271
salutation: 
name: ''Eddie ''
lastnames: Diaz
sex: true
role: 4
description: Representante Distrito
attended: false
printed: true
materials: false
church_id: 108
created_at: 2015-02-24 17:43:15.014054000 Z
updated_at: 2015-03-04 20:22:03.692430000 Z
', '2015-03-05 12:23:31.976475');
INSERT INTO versions VALUES (1692, 'Person', 271, 'update', NULL, '---
id: 271
salutation: 
name: ''Eddie ''
lastnames: Diaz
sex: true
role: 4
description: Representante Distrito
attended: true
printed: true
materials: false
church_id: 108
created_at: 2015-02-24 17:43:15.014054000 Z
updated_at: 2015-03-05 12:23:31.966244000 Z
', '2015-03-05 12:23:32.843488');
INSERT INTO versions VALUES (1693, 'Person', 458, 'update', NULL, '---
id: 458
salutation: 0
name: Rodolfo
lastnames: Castillo
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 21:30:50.350742000 Z
updated_at: 2015-03-04 21:34:57.082442000 Z
', '2015-03-05 12:23:52.768338');
INSERT INTO versions VALUES (1694, 'Person', 458, 'update', NULL, '---
id: 458
salutation: 0
name: Rodolfo
lastnames: Castillo
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 21:30:50.350742000 Z
updated_at: 2015-03-05 12:23:52.762018000 Z
', '2015-03-05 12:23:54.439134');
INSERT INTO versions VALUES (1695, 'Check', 39, 'create', NULL, NULL, '2015-03-05 12:24:08.055856');
INSERT INTO versions VALUES (1696, 'Person', 294, 'update', NULL, '---
id: 294
salutation: 4
name: ''Nilda E. ''
lastnames: ''García ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 83
created_at: 2015-02-27 02:39:11.936961000 Z
updated_at: 2015-03-02 19:22:25.734738000 Z
', '2015-03-05 12:24:37.227836');
INSERT INTO versions VALUES (1697, 'Person', 294, 'update', NULL, '---
id: 294
salutation: 4
name: ''Nilda E. ''
lastnames: ''García ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 83
created_at: 2015-02-27 02:39:11.936961000 Z
updated_at: 2015-03-05 12:24:37.219638000 Z
', '2015-03-05 12:24:38.618078');
INSERT INTO versions VALUES (1698, 'Person', 244, 'update', NULL, '---
id: 244
salutation: 
name: ''Delma ''
lastnames: Lananze
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 76
created_at: 2015-02-24 15:13:38.480586000 Z
updated_at: 2015-03-02 19:23:13.869827000 Z
', '2015-03-05 12:25:44.335197');
INSERT INTO versions VALUES (1699, 'Person', 242, 'update', NULL, '---
id: 242
salutation: 
name: ''Maribel ''
lastnames: Colón
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 76
created_at: 2015-02-24 15:12:49.333038000 Z
updated_at: 2015-03-02 19:23:17.033803000 Z
', '2015-03-05 12:25:46.187986');
INSERT INTO versions VALUES (1700, 'Person', 243, 'update', NULL, '---
id: 243
salutation: 
name: ''Minerva ''
lastnames: ''Costa ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 76
created_at: 2015-02-24 15:13:14.962885000 Z
updated_at: 2015-03-02 19:23:18.425352000 Z
', '2015-03-05 12:25:47.722066');
INSERT INTO versions VALUES (1701, 'Person', 244, 'update', NULL, '---
id: 244
salutation: 
name: ''Delma ''
lastnames: Lananze
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 76
created_at: 2015-02-24 15:13:38.480586000 Z
updated_at: 2015-03-05 12:25:44.326908000 Z
', '2015-03-05 12:25:50.055699');
INSERT INTO versions VALUES (1702, 'Person', 242, 'update', NULL, '---
id: 242
salutation: 
name: ''Maribel ''
lastnames: Colón
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 76
created_at: 2015-02-24 15:12:49.333038000 Z
updated_at: 2015-03-05 12:25:46.178777000 Z
', '2015-03-05 12:25:51.433306');
INSERT INTO versions VALUES (1703, 'Person', 243, 'update', NULL, '---
id: 243
salutation: 
name: ''Minerva ''
lastnames: ''Costa ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 76
created_at: 2015-02-24 15:13:14.962885000 Z
updated_at: 2015-03-05 12:25:47.712564000 Z
', '2015-03-05 12:25:52.676841');
INSERT INTO versions VALUES (1704, 'Person', 94, 'update', NULL, '---
id: 94
salutation: 0
name: ''Mario ''
lastnames: ''Rodas ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 59
created_at: 2015-02-24 02:24:44.088983000 Z
updated_at: 2015-03-02 19:22:42.643518000 Z
', '2015-03-05 12:26:04.600529');
INSERT INTO versions VALUES (1705, 'Person', 94, 'update', NULL, '---
id: 94
salutation: 0
name: ''Mario ''
lastnames: ''Rodas ''
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 59
created_at: 2015-02-24 02:24:44.088983000 Z
updated_at: 2015-03-05 12:26:04.593775000 Z
', '2015-03-05 12:26:05.601701');
INSERT INTO versions VALUES (1706, 'Person', 35, 'update', NULL, '---
id: 35
salutation: 
name: ''Carlos ''
lastnames: ''Maldonado ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 107
created_at: 2015-02-24 01:44:21.294952000 Z
updated_at: 2015-03-02 19:23:18.445558000 Z
', '2015-03-05 12:26:09.086607');
INSERT INTO versions VALUES (1707, 'Person', 35, 'update', NULL, '---
id: 35
salutation: 
name: ''Carlos ''
lastnames: ''Maldonado ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 107
created_at: 2015-02-24 01:44:21.294952000 Z
updated_at: 2015-03-05 12:26:09.078481000 Z
', '2015-03-05 12:26:10.913399');
INSERT INTO versions VALUES (1708, 'Person', 40, 'update', NULL, '---
id: 40
salutation: 
name: ''Margarita ''
lastnames: Fígaro
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 107
created_at: 2015-02-24 01:46:45.493396000 Z
updated_at: 2015-03-02 19:23:21.650214000 Z
', '2015-03-05 12:26:41.46576');
INSERT INTO versions VALUES (1709, 'Person', 40, 'update', NULL, '---
id: 40
salutation: 
name: ''Margarita ''
lastnames: Fígaro
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 107
created_at: 2015-02-24 01:46:45.493396000 Z
updated_at: 2015-03-05 12:26:41.457513000 Z
', '2015-03-05 12:26:42.359794');
INSERT INTO versions VALUES (1710, 'Person', 38, 'update', NULL, '---
id: 38
salutation: 
name: ''María de los A. ''
lastnames: ''Torres ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 107
created_at: 2015-02-24 01:45:45.277971000 Z
updated_at: 2015-03-02 19:23:22.443368000 Z
', '2015-03-05 12:27:20.44824');
INSERT INTO versions VALUES (1711, 'Person', 38, 'update', NULL, '---
id: 38
salutation: 
name: ''María de los A. ''
lastnames: ''Torres ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 107
created_at: 2015-02-24 01:45:45.277971000 Z
updated_at: 2015-03-05 12:27:20.438926000 Z
', '2015-03-05 12:27:22.313211');
INSERT INTO versions VALUES (1712, 'Person', 37, 'update', NULL, '---
id: 37
salutation: 
name: ''Fernando ''
lastnames: ''Toro ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 107
created_at: 2015-02-24 01:45:18.350020000 Z
updated_at: 2015-03-02 19:23:18.459680000 Z
', '2015-03-05 12:27:28.02108');
INSERT INTO versions VALUES (1713, 'Person', 37, 'update', NULL, '---
id: 37
salutation: 
name: ''Fernando ''
lastnames: ''Toro ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 107
created_at: 2015-02-24 01:45:18.350020000 Z
updated_at: 2015-03-05 12:27:28.011811000 Z
', '2015-03-05 12:27:33.925188');
INSERT INTO versions VALUES (1714, 'Person', 471, 'create', NULL, NULL, '2015-03-05 12:27:42.230662');
INSERT INTO versions VALUES (1715, 'Person', 45, 'update', NULL, '---
id: 45
salutation: 
name: ''Leticia ''
lastnames: ''Santaella ''
sex: false
role: 4
description: ''''
attended: false
printed: true
materials: false
church_id: 112
created_at: 2015-02-24 01:51:34.052136000 Z
updated_at: 2015-03-02 19:23:41.368628000 Z
', '2015-03-05 12:27:57.952358');
INSERT INTO versions VALUES (1716, 'Person', 472, 'create', NULL, NULL, '2015-03-05 12:28:18.60532');
INSERT INTO versions VALUES (1717, 'Person', 303, 'update', NULL, '---
id: 303
salutation: 
name: ''Mayra ''
lastnames: ''Rivera ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 85
created_at: 2015-03-02 19:19:17.181209000 Z
updated_at: 2015-03-02 19:23:29.482286000 Z
', '2015-03-05 12:28:40.289451');
INSERT INTO versions VALUES (1718, 'Person', 303, 'update', NULL, '---
id: 303
salutation: 
name: ''Mayra ''
lastnames: ''Rivera ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 85
created_at: 2015-03-02 19:19:17.181209000 Z
updated_at: 2015-03-05 12:28:40.283867000 Z
', '2015-03-05 12:28:41.5574');
INSERT INTO versions VALUES (1719, 'Person', 286, 'update', NULL, '---
id: 286
salutation: 2
name: ''Alejandrina ''
lastnames: ''Ortiz ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 119
created_at: 2015-02-25 14:50:38.256213000 Z
updated_at: 2015-03-05 11:40:43.372482000 Z
', '2015-03-05 12:28:55.53513');
INSERT INTO versions VALUES (1726, 'Person', 286, 'update', NULL, '---
id: 286
salutation: 2
name: ''Alejandrina ''
lastnames: ''Ortiz ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 119
created_at: 2015-02-25 14:50:38.256213000 Z
updated_at: 2015-03-05 12:28:55.517557000 Z
', '2015-03-05 12:28:57.085889');
INSERT INTO versions VALUES (1727, 'Person', 29, 'update', NULL, '---
id: 29
salutation: 
name: ''Carmen N. ''
lastnames: ''Negrón ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 12
created_at: 2015-02-24 01:39:08.318674000 Z
updated_at: 2015-03-02 19:22:07.737406000 Z
', '2015-03-05 12:29:11.016029');
INSERT INTO versions VALUES (1728, 'Person', 29, 'update', NULL, '---
id: 29
salutation: 
name: ''Carmen N. ''
lastnames: ''Negrón ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 12
created_at: 2015-02-24 01:39:08.318674000 Z
updated_at: 2015-03-05 12:29:11.009001000 Z
', '2015-03-05 12:29:12.498729');
INSERT INTO versions VALUES (1729, 'Person', 473, 'create', NULL, NULL, '2015-03-05 12:29:12.897314');
INSERT INTO versions VALUES (1730, 'Person', 258, 'update', NULL, '---
id: 258
salutation: 
name: ''Miguel ''
lastnames: ''Carrasquillo ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 18
created_at: 2015-02-24 15:31:57.720168000 Z
updated_at: 2015-03-02 19:21:17.578966000 Z
', '2015-03-05 12:29:23.09457');
INSERT INTO versions VALUES (1731, 'Person', 258, 'update', NULL, '---
id: 258
salutation: 
name: ''Miguel ''
lastnames: ''Carrasquillo ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 18
created_at: 2015-02-24 15:31:57.720168000 Z
updated_at: 2015-03-05 12:29:23.086759000 Z
', '2015-03-05 12:29:25.900645');
INSERT INTO versions VALUES (1732, 'Person', 279, 'update', NULL, '---
id: 279
salutation: 
name: ''Lilliam ''
lastnames: ''Santos ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 11
created_at: 2015-02-25 14:45:41.268414000 Z
updated_at: 2015-03-02 19:20:56.237664000 Z
', '2015-03-05 12:29:29.557943');
INSERT INTO versions VALUES (1733, 'Person', 279, 'update', NULL, '---
id: 279
salutation: 
name: ''Lilliam ''
lastnames: ''Santos ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 11
created_at: 2015-02-25 14:45:41.268414000 Z
updated_at: 2015-03-05 12:29:29.549595000 Z
', '2015-03-05 12:29:30.985253');
INSERT INTO versions VALUES (1734, 'Person', 145, 'update', NULL, '---
id: 145
salutation: 0
name: ''Margot ''
lastnames: ''Camacho ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:06.046467000 Z
updated_at: 2015-03-02 19:21:28.543638000 Z
', '2015-03-05 12:29:52.30825');
INSERT INTO versions VALUES (1735, 'Person', 145, 'update', NULL, '---
id: 145
salutation: 0
name: ''Margot ''
lastnames: ''Camacho ''
sex: false
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:06.046467000 Z
updated_at: 2015-03-05 12:29:52.298960000 Z
', '2015-03-05 12:29:54.062827');
INSERT INTO versions VALUES (1736, 'Person', 230, 'update', NULL, '---
id: 230
salutation: 
name: Norma I.
lastnames: Pérez
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 39
created_at: 2015-02-24 15:05:16.436013000 Z
updated_at: 2015-03-02 19:21:49.695806000 Z
', '2015-03-05 12:30:15.582676');
INSERT INTO versions VALUES (1737, 'Person', 230, 'update', NULL, '---
id: 230
salutation: 
name: Norma I.
lastnames: Pérez
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 39
created_at: 2015-02-24 15:05:16.436013000 Z
updated_at: 2015-03-05 12:30:15.572482000 Z
', '2015-03-05 12:30:16.403085');
INSERT INTO versions VALUES (1738, 'Person', 269, 'update', NULL, '---
id: 269
salutation: 0
name: ''Ramon ''
lastnames: Arroyo
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 40
created_at: 2015-02-24 17:40:29.026992000 Z
updated_at: 2015-03-02 19:21:52.908570000 Z
', '2015-03-05 12:30:41.000858');
INSERT INTO versions VALUES (1739, 'Person', 269, 'update', NULL, '---
id: 269
salutation: 0
name: ''Ramon ''
lastnames: Arroyo
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 40
created_at: 2015-02-24 17:40:29.026992000 Z
updated_at: 2015-03-05 12:30:40.991597000 Z
', '2015-03-05 12:30:42.550807');
INSERT INTO versions VALUES (1740, 'Person', 345, 'update', NULL, '---
id: 345
salutation: 0
name: Margarita
lastnames: Rodríguez
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 10:59:22.645046000 Z
updated_at: 2015-03-04 21:22:34.266173000 Z
', '2015-03-05 12:31:22.80945');
INSERT INTO versions VALUES (1741, 'Person', 124, 'update', NULL, '---
id: 124
salutation: 
name: ''Lilybeth ''
lastnames: Bosch
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 56
created_at: 2015-02-24 02:41:48.368594000 Z
updated_at: 2015-03-02 19:22:56.088595000 Z
', '2015-03-05 12:31:25.158025');
INSERT INTO versions VALUES (1742, 'Person', 345, 'update', NULL, '---
id: 345
salutation: 0
name: Margarita
lastnames: Rodríguez
sex: false
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 10:59:22.645046000 Z
updated_at: 2015-03-05 12:31:22.800247000 Z
', '2015-03-05 12:31:25.609117');
INSERT INTO versions VALUES (1743, 'Person', 124, 'update', NULL, '---
id: 124
salutation: 
name: ''Lilybeth ''
lastnames: Bosch
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 56
created_at: 2015-02-24 02:41:48.368594000 Z
updated_at: 2015-03-05 12:31:25.155427000 Z
', '2015-03-05 12:31:31.450142');
INSERT INTO versions VALUES (1744, 'Person', 29, 'update', NULL, '---
id: 29
salutation: 
name: ''Carmen N. ''
lastnames: ''Negrón ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 12
created_at: 2015-02-24 01:39:08.318674000 Z
updated_at: 2015-03-05 12:29:12.489671000 Z
', '2015-03-05 12:31:35.482498');
INSERT INTO versions VALUES (1745, 'Person', 122, 'update', NULL, '---
id: 122
salutation: 0
name: ''Alberto J. ''
lastnames: ''Díaz ''
sex: true
role: 4
description: Vice Presidente
attended: false
printed: true
materials: false
church_id: 56
created_at: 2015-02-24 02:40:50.078129000 Z
updated_at: 2015-03-04 21:29:18.138612000 Z
', '2015-03-05 12:31:55.165252');
INSERT INTO versions VALUES (1746, 'Person', 122, 'update', NULL, '---
id: 122
salutation: 0
name: ''Alberto J. ''
lastnames: ''Díaz ''
sex: true
role: 4
description: Vice Presidente
attended: true
printed: true
materials: false
church_id: 56
created_at: 2015-02-24 02:40:50.078129000 Z
updated_at: 2015-03-05 12:31:55.157828000 Z
', '2015-03-05 12:31:57.174935');
INSERT INTO versions VALUES (1747, 'Person', 474, 'create', NULL, NULL, '2015-03-05 12:32:18.734732');
INSERT INTO versions VALUES (1748, 'Person', 229, 'update', NULL, '---
id: 229
salutation: 
name: ''Lucy ''
lastnames: Muñoz
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 39
created_at: 2015-02-24 15:04:56.866984000 Z
updated_at: 2015-03-02 19:21:49.680004000 Z
', '2015-03-05 12:32:26.991562');
INSERT INTO versions VALUES (1749, 'Person', 229, 'update', NULL, '---
id: 229
salutation: 
name: ''Lucy ''
lastnames: Muñoz
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: true
church_id: 39
created_at: 2015-02-24 15:04:56.866984000 Z
updated_at: 2015-03-05 12:32:26.982699000 Z
', '2015-03-05 12:32:28.100828');
INSERT INTO versions VALUES (1750, 'Person', 475, 'create', NULL, NULL, '2015-03-05 12:33:06.607949');
INSERT INTO versions VALUES (1751, 'Person', 460, 'update', NULL, '---
id: 460
salutation: 
name: Damaris
lastnames: Pizarro
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 21:32:21.357256000 Z
updated_at: 2015-03-04 21:34:57.073046000 Z
', '2015-03-05 12:34:03.352708');
INSERT INTO versions VALUES (1752, 'Person', 460, 'update', NULL, '---
id: 460
salutation: 
name: Damaris
lastnames: Pizarro
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 21:32:21.357256000 Z
updated_at: 2015-03-05 12:34:03.343581000 Z
', '2015-03-05 12:34:06.493945');
INSERT INTO versions VALUES (1753, 'Person', 476, 'create', NULL, NULL, '2015-03-05 12:34:11.172805');
INSERT INTO versions VALUES (1754, 'Person', 477, 'create', NULL, NULL, '2015-03-05 12:34:16.572379');
INSERT INTO versions VALUES (1755, 'Person', 478, 'create', NULL, NULL, '2015-03-05 12:34:48.458373');
INSERT INTO versions VALUES (1756, 'Person', 473, 'update', NULL, '---
id: 473
salutation: 
name: Luz E.
lastnames: García
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 54
created_at: 2015-03-05 12:29:12.894792000 Z
updated_at: 2015-03-05 12:29:12.894792000 Z
', '2015-03-05 12:34:59.975359');
INSERT INTO versions VALUES (1757, 'Person', 29, 'update', NULL, '---
id: 29
salutation: 
name: ''Carmen N. ''
lastnames: ''Negrón ''
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 12
created_at: 2015-02-24 01:39:08.318674000 Z
updated_at: 2015-03-05 12:31:35.473122000 Z
', '2015-03-05 12:35:00.139599');
INSERT INTO versions VALUES (1758, 'Person', 474, 'update', NULL, '---
id: 474
salutation: 
name: José A.
lastnames: Montalvo
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 17
created_at: 2015-03-05 12:32:18.729196000 Z
updated_at: 2015-03-05 12:32:18.729196000 Z
', '2015-03-05 12:35:00.147557');
INSERT INTO versions VALUES (1759, 'Person', 475, 'update', NULL, '---
id: 475
salutation: 
name: Felix
lastnames: Dones
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 17
created_at: 2015-03-05 12:33:06.602482000 Z
updated_at: 2015-03-05 12:33:06.602482000 Z
', '2015-03-05 12:35:00.156896');
INSERT INTO versions VALUES (1760, 'Person', 476, 'update', NULL, '---
id: 476
salutation: 
name: Carmen
lastnames: Diaz
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 17
created_at: 2015-03-05 12:34:11.166891000 Z
updated_at: 2015-03-05 12:34:11.166891000 Z
', '2015-03-05 12:35:00.163456');
INSERT INTO versions VALUES (1761, 'Person', 477, 'update', NULL, '---
id: 477
salutation: 
name: ''Betzaida ''
lastnames: Rodríguez
sex: true
role: 1
description: ''''
attended: true
printed: false
materials: true
church_id: 70
created_at: 2015-03-05 12:34:16.566383000 Z
updated_at: 2015-03-05 12:34:16.566383000 Z
', '2015-03-05 12:35:00.170795');
INSERT INTO versions VALUES (1762, 'Person', 151, 'update', NULL, '---
id: 151
salutation: 
name: Maria E.
lastnames: ''Rivera Melendez ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:25:34.789697000 Z
updated_at: 2015-03-02 19:21:28.716968000 Z
', '2015-03-05 12:35:01.750907');
INSERT INTO versions VALUES (1763, 'Person', 151, 'update', NULL, '---
id: 151
salutation: 
name: Maria E.
lastnames: ''Rivera Melendez ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:25:34.789697000 Z
updated_at: 2015-03-05 12:35:01.741473000 Z
', '2015-03-05 12:35:02.517191');
INSERT INTO versions VALUES (1764, 'Person', 476, 'update', NULL, '---
id: 476
salutation: 
name: Carmen
lastnames: Diaz
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 17
created_at: 2015-03-05 12:34:11.166891000 Z
updated_at: 2015-03-05 12:35:00.158843000 Z
', '2015-03-05 12:35:20.998209');
INSERT INTO versions VALUES (1765, 'Person', 479, 'create', NULL, NULL, '2015-03-05 12:35:43.31883');
INSERT INTO versions VALUES (1766, 'Person', 150, 'update', NULL, '---
id: 150
salutation: 
name: ''Milagros ''
lastnames: Pizarrro
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:22:38.515628000 Z
updated_at: 2015-03-02 19:21:28.770468000 Z
', '2015-03-05 12:35:52.253271');
INSERT INTO versions VALUES (1767, 'Person', 150, 'update', NULL, '---
id: 150
salutation: 
name: ''Milagros ''
lastnames: Pizarrro
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:22:38.515628000 Z
updated_at: 2015-03-05 12:35:52.245274000 Z
', '2015-03-05 12:35:53.489193');
INSERT INTO versions VALUES (1768, 'Person', 480, 'create', NULL, NULL, '2015-03-05 12:36:34.942902');
INSERT INTO versions VALUES (1769, 'Person', 323, 'update', NULL, '---
id: 323
salutation: 
name: Anamaría
lastnames: Gallardo
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 102
created_at: 2015-03-02 19:43:37.463487000 Z
updated_at: 2015-03-02 19:47:08.031766000 Z
', '2015-03-05 12:36:42.842032');
INSERT INTO versions VALUES (1770, 'Person', 481, 'create', NULL, NULL, '2015-03-05 12:36:43.824004');
INSERT INTO versions VALUES (1771, 'Person', 323, 'update', NULL, '---
id: 323
salutation: 
name: Anamaría
lastnames: Gallardo
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 102
created_at: 2015-03-02 19:43:37.463487000 Z
updated_at: 2015-03-05 12:36:42.833374000 Z
', '2015-03-05 12:36:44.367323');
INSERT INTO versions VALUES (1772, 'Person', 324, 'update', NULL, '---
id: 324
salutation: 
name: ''Milagros ''
lastnames: Ortíz
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 102
created_at: 2015-03-02 19:44:00.215750000 Z
updated_at: 2015-03-02 19:47:08.665799000 Z
', '2015-03-05 12:36:47.404067');
INSERT INTO versions VALUES (1773, 'Person', 267, 'update', NULL, '---
id: 267
salutation: 
name: ''Wanda I. ''
lastnames: ''Rentas Morales ''
sex: false
role: 5
description: ''''
attended: false
printed: true
materials: false
church_id: 10
created_at: 2015-02-24 17:29:51.385662000 Z
updated_at: 2015-03-02 19:20:52.779351000 Z
', '2015-03-05 12:36:47.80609');
INSERT INTO versions VALUES (1774, 'Person', 324, 'update', NULL, '---
id: 324
salutation: 
name: ''Milagros ''
lastnames: Ortíz
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 102
created_at: 2015-03-02 19:44:00.215750000 Z
updated_at: 2015-03-05 12:36:47.394886000 Z
', '2015-03-05 12:36:48.673404');
INSERT INTO versions VALUES (1775, 'Person', 157, 'update', NULL, '---
id: 157
salutation: 
name: ''Sonia ''
lastnames: ''García Hernández ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:32:21.484489000 Z
updated_at: 2015-03-02 19:21:32.712273000 Z
', '2015-03-05 12:36:54.482174');
INSERT INTO versions VALUES (1776, 'Person', 267, 'update', NULL, '---
id: 267
salutation: 
name: ''Wanda I. ''
lastnames: ''Rentas Morales ''
sex: false
role: 5
description: ''''
attended: true
printed: true
materials: false
church_id: 10
created_at: 2015-02-24 17:29:51.385662000 Z
updated_at: 2015-03-05 12:36:47.797100000 Z
', '2015-03-05 12:36:54.527544');
INSERT INTO versions VALUES (1777, 'Person', 157, 'update', NULL, '---
id: 157
salutation: 
name: ''Sonia ''
lastnames: ''García Hernández ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:32:21.484489000 Z
updated_at: 2015-03-05 12:36:54.472780000 Z
', '2015-03-05 12:36:55.174524');
INSERT INTO versions VALUES (1778, 'Person', 55, 'update', NULL, '---
id: 55
salutation: 0
name: ''Geraldo ''
lastnames: ''Méndez ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 10
created_at: 2015-02-24 01:58:31.251653000 Z
updated_at: 2015-03-02 19:20:49.646754000 Z
', '2015-03-05 12:36:57.681924');
INSERT INTO versions VALUES (1779, 'Person', 322, 'update', NULL, '---
id: 322
salutation: 0
name: ''Eva ''
lastnames: Agosto
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 102
created_at: 2015-03-02 19:42:38.811020000 Z
updated_at: 2015-03-02 19:47:08.256696000 Z
', '2015-03-05 12:36:58.411908');
INSERT INTO versions VALUES (1780, 'Person', 322, 'update', NULL, '---
id: 322
salutation: 0
name: ''Eva ''
lastnames: Agosto
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 102
created_at: 2015-03-02 19:42:38.811020000 Z
updated_at: 2015-03-05 12:36:58.402942000 Z
', '2015-03-05 12:37:00.03478');
INSERT INTO versions VALUES (1781, 'Person', 55, 'update', NULL, '---
id: 55
salutation: 0
name: ''Geraldo ''
lastnames: ''Méndez ''
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 10
created_at: 2015-02-24 01:58:31.251653000 Z
updated_at: 2015-03-05 12:36:57.674489000 Z
', '2015-03-05 12:37:00.882485');
INSERT INTO versions VALUES (1782, 'Person', 482, 'create', NULL, NULL, '2015-03-05 12:37:26.116329');
INSERT INTO versions VALUES (1783, 'Person', 160, 'update', NULL, '---
id: 160
salutation: 
name: ''Carlos ''
lastnames: Dominguez Cristobal
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:33:40.851015000 Z
updated_at: 2015-03-02 19:21:20.732868000 Z
', '2015-03-05 12:37:59.639247');
INSERT INTO versions VALUES (1784, 'Person', 160, 'update', NULL, '---
id: 160
salutation: 
name: ''Carlos ''
lastnames: Dominguez Cristobal
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:33:40.851015000 Z
updated_at: 2015-03-05 12:37:59.631818000 Z
', '2015-03-05 12:38:00.626623');
INSERT INTO versions VALUES (1791, 'Person', 483, 'create', NULL, NULL, '2015-03-05 12:38:05.335781');
INSERT INTO versions VALUES (1792, 'Person', 483, 'update', NULL, '---
id: 483
salutation: 
name: ''Clarissa ''
lastnames: Santiago
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 92
created_at: 2015-03-05 12:38:05.332101000 Z
updated_at: 2015-03-05 12:38:05.332101000 Z
', '2015-03-05 12:38:36.08967');
INSERT INTO versions VALUES (1793, 'Person', 483, 'update', NULL, '---
id: 483
salutation: 
name: ''Clarissa ''
lastnames: Santiago
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: true
church_id: 92
created_at: 2015-03-05 12:38:05.332101000 Z
updated_at: 2015-03-05 12:38:36.079182000 Z
', '2015-03-05 12:38:37.271638');
INSERT INTO versions VALUES (1794, 'Person', 482, 'update', NULL, '---
id: 482
salutation: 
name: ''Eutimia ''
lastnames: Santiago
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 92
created_at: 2015-03-05 12:37:26.111157000 Z
updated_at: 2015-03-05 12:38:04.797205000 Z
', '2015-03-05 12:38:40.120656');
INSERT INTO versions VALUES (1795, 'Person', 482, 'update', NULL, '---
id: 482
salutation: 
name: ''Eutimia ''
lastnames: Santiago
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 92
created_at: 2015-03-05 12:37:26.111157000 Z
updated_at: 2015-03-05 12:38:40.111245000 Z
', '2015-03-05 12:38:41.28149');
INSERT INTO versions VALUES (1796, 'Person', 208, 'update', NULL, '---
id: 208
salutation: 
name: ''Anita ''
lastnames: González
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 84
created_at: 2015-02-24 14:43:53.101388000 Z
updated_at: 2015-03-02 19:23:07.131464000 Z
', '2015-03-05 12:39:01.46454');
INSERT INTO versions VALUES (1797, 'Person', 208, 'update', NULL, '---
id: 208
salutation: 
name: ''Anita ''
lastnames: González
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 84
created_at: 2015-02-24 14:43:53.101388000 Z
updated_at: 2015-03-05 12:39:01.459898000 Z
', '2015-03-05 12:39:02.669278');
INSERT INTO versions VALUES (1798, 'Person', 83, 'update', NULL, '---
id: 83
salutation: 
name: ''Noemí ''
lastnames: ''Ortiz ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:15:12.645890000 Z
updated_at: 2015-03-02 19:21:07.033712000 Z
', '2015-03-05 12:39:04.009747');
INSERT INTO versions VALUES (1799, 'Person', 83, 'update', NULL, '---
id: 83
salutation: 
name: ''Noemí ''
lastnames: ''Ortiz ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:15:12.645890000 Z
updated_at: 2015-03-05 12:39:04.001130000 Z
', '2015-03-05 12:39:05.524476');
INSERT INTO versions VALUES (1800, 'Person', 82, 'update', NULL, '---
id: 82
salutation: 
name: ''Alba ''
lastnames: ''Marín ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:14:48.426260000 Z
updated_at: 2015-03-02 19:21:00.014678000 Z
', '2015-03-05 12:39:17.612048');
INSERT INTO versions VALUES (1801, 'Person', 82, 'update', NULL, '---
id: 82
salutation: 
name: ''Alba ''
lastnames: ''Marín ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:14:48.426260000 Z
updated_at: 2015-03-05 12:39:17.603617000 Z
', '2015-03-05 12:39:18.906286');
INSERT INTO versions VALUES (1802, 'Person', 208, 'update', NULL, '---
id: 208
salutation: 
name: ''Anita ''
lastnames: González
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 84
created_at: 2015-02-24 14:43:53.101388000 Z
updated_at: 2015-03-05 12:39:02.659751000 Z
', '2015-03-05 12:39:20.224149');
INSERT INTO versions VALUES (1803, 'Person', 480, 'update', NULL, '---
id: 480
salutation: 0
name: Elias
lastnames: Ramirez
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: true
church_id: 92
created_at: 2015-03-05 12:36:34.927282000 Z
updated_at: 2015-03-05 12:38:04.785457000 Z
', '2015-03-05 12:39:38.263794');
INSERT INTO versions VALUES (1804, 'Person', 482, 'update', NULL, '---
id: 482
salutation: 
name: ''Eutimia ''
lastnames: Santiago
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 92
created_at: 2015-03-05 12:37:26.111157000 Z
updated_at: 2015-03-05 12:38:41.274367000 Z
', '2015-03-05 12:39:39.4161');
INSERT INTO versions VALUES (1785, 'Person', 478, 'update', NULL, '---
id: 478
salutation: 0
name: Efrain
lastnames: Torres
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 17
created_at: 2015-03-05 12:34:48.451627000 Z
updated_at: 2015-03-05 12:34:48.451627000 Z
', '2015-03-05 12:38:04.167172');
INSERT INTO versions VALUES (1786, 'Person', 476, 'update', NULL, '---
id: 476
salutation: 
name: Carmen
lastnames: Diaz
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 17
created_at: 2015-03-05 12:34:11.166891000 Z
updated_at: 2015-03-05 12:35:20.989027000 Z
', '2015-03-05 12:38:04.339437');
INSERT INTO versions VALUES (1787, 'Person', 479, 'update', NULL, '---
id: 479
salutation: 
name: Ilia
lastnames: Rivera
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 70
created_at: 2015-03-05 12:35:43.313739000 Z
updated_at: 2015-03-05 12:35:43.313739000 Z
', '2015-03-05 12:38:04.779801');
INSERT INTO versions VALUES (1788, 'Person', 480, 'update', NULL, '---
id: 480
salutation: 0
name: Elias
lastnames: Ramirez
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 92
created_at: 2015-03-05 12:36:34.927282000 Z
updated_at: 2015-03-05 12:36:34.927282000 Z
', '2015-03-05 12:38:04.787594');
INSERT INTO versions VALUES (1789, 'Person', 481, 'update', NULL, '---
id: 481
salutation: 
name: Angelique
lastnames: Acevedo
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 70
created_at: 2015-03-05 12:36:43.818287000 Z
updated_at: 2015-03-05 12:36:43.818287000 Z
', '2015-03-05 12:38:04.795442');
INSERT INTO versions VALUES (1790, 'Person', 482, 'update', NULL, '---
id: 482
salutation: 
name: ''Eutimia ''
lastnames: Santiago
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 92
created_at: 2015-03-05 12:37:26.111157000 Z
updated_at: 2015-03-05 12:37:26.111157000 Z
', '2015-03-05 12:38:04.804157');
INSERT INTO versions VALUES (1829, 'Person', 483, 'update', NULL, '---
id: 483
salutation: 
name: ''Clarissa ''
lastnames: Santiago
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 92
created_at: 2015-03-05 12:38:05.332101000 Z
updated_at: 2015-03-05 12:38:37.261686000 Z
', '2015-03-05 12:43:08.643264');
INSERT INTO versions VALUES (1830, 'Person', 480, 'update', NULL, '---
id: 480
salutation: 0
name: Elias
lastnames: Ramirez
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 92
created_at: 2015-03-05 12:36:34.927282000 Z
updated_at: 2015-03-05 12:39:38.254991000 Z
', '2015-03-05 12:43:08.692238');
INSERT INTO versions VALUES (1831, 'Person', 482, 'update', NULL, '---
id: 482
salutation: 
name: ''Eutimia ''
lastnames: Santiago
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 92
created_at: 2015-03-05 12:37:26.111157000 Z
updated_at: 2015-03-05 12:39:39.406270000 Z
', '2015-03-05 12:43:08.699267');
INSERT INTO versions VALUES (1832, 'Person', 484, 'update', NULL, '---
id: 484
salutation: 
name: Doris
lastnames: Díaz
sex: false
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 70
created_at: 2015-03-05 12:40:14.532288000 Z
updated_at: 2015-03-05 12:40:14.532288000 Z
', '2015-03-05 12:43:08.707504');
INSERT INTO versions VALUES (1833, 'Person', 82, 'update', NULL, '---
id: 82
salutation: 
name: ''Alba ''
lastnames: ''Martín ''
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 13
created_at: 2015-02-24 02:14:48.426260000 Z
updated_at: 2015-03-05 12:41:11.912536000 Z
', '2015-03-05 12:43:08.716415');
INSERT INTO versions VALUES (1834, 'Person', 485, 'update', NULL, '---
id: 485
salutation: 
name: Daniel
lastnames: Pérez
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 34
created_at: 2015-03-05 12:42:27.976789000 Z
updated_at: 2015-03-05 12:42:27.976789000 Z
', '2015-03-05 12:43:08.720854');
INSERT INTO versions VALUES (1890, 'Person', 5, 'update', NULL, '---
id: 5
salutation: 
name: ''Mary ''
lastnames: ''Vázquez ''
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 108
created_at: 2015-02-23 22:24:15.398515000 Z
updated_at: 2015-03-05 12:44:04.648612000 Z
', '2015-03-05 12:51:12.144531');
INSERT INTO versions VALUES (1891, 'Person', 486, 'update', NULL, '---
id: 486
salutation: 0
name: Ramón
lastnames: Rivera
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 106
created_at: 2015-03-05 12:48:48.557431000 Z
updated_at: 2015-03-05 12:48:48.557431000 Z
', '2015-03-05 12:51:12.480737');
INSERT INTO versions VALUES (1892, 'Person', 124, 'update', NULL, '---
id: 124
salutation: 
name: ''Lilybeth ''
lastnames: Bosch
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 56
created_at: 2015-02-24 02:41:48.368594000 Z
updated_at: 2015-03-05 12:49:05.951509000 Z
', '2015-03-05 12:51:12.924144');
INSERT INTO versions VALUES (1893, 'Person', 487, 'update', NULL, '---
id: 487
salutation: 
name: ''Heriberto ''
lastnames: Rivera Pabon
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 78
created_at: 2015-03-05 12:49:48.909547000 Z
updated_at: 2015-03-05 12:49:48.909547000 Z
', '2015-03-05 12:51:12.933752');
INSERT INTO versions VALUES (1894, 'Person', 488, 'update', NULL, '---
id: 488
salutation: 
name: Lucy
lastnames: Falero
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 106
created_at: 2015-03-05 12:50:36.762007000 Z
updated_at: 2015-03-05 12:50:36.762007000 Z
', '2015-03-05 12:51:12.938065');
INSERT INTO versions VALUES (1895, 'Person', 489, 'update', NULL, '---
id: 489
salutation: 
name: ''Dorcas ''
lastnames: Santiago Gonzalez
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 78
created_at: 2015-03-05 12:50:43.491764000 Z
updated_at: 2015-03-05 12:50:43.491764000 Z
', '2015-03-05 12:51:12.944455');
INSERT INTO versions VALUES (1805, 'Person', 82, 'update', NULL, '---
id: 82
salutation: 
name: ''Alba ''
lastnames: ''Marín ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 13
created_at: 2015-02-24 02:14:48.426260000 Z
updated_at: 2015-03-05 12:39:18.897503000 Z
', '2015-03-05 12:39:44.858218');
INSERT INTO versions VALUES (1806, 'Person', 87, 'update', NULL, '---
id: 87
salutation: 
name: ''Edgardo ''
lastnames: ''Miranda ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:17:00.753889000 Z
updated_at: 2015-03-02 19:21:03.405625000 Z
', '2015-03-05 12:40:13.591268');
INSERT INTO versions VALUES (1807, 'Person', 484, 'create', NULL, NULL, '2015-03-05 12:40:14.537801');
INSERT INTO versions VALUES (1808, 'Person', 87, 'update', NULL, '---
id: 87
salutation: 
name: ''Edgardo ''
lastnames: ''Miranda ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:17:00.753889000 Z
updated_at: 2015-03-05 12:40:13.580245000 Z
', '2015-03-05 12:40:15.604261');
INSERT INTO versions VALUES (1809, 'Person', 66, 'update', NULL, '---
id: 66
salutation: 1
name: ''Jaime ''
lastnames: ''Rodríguez ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 36
created_at: 2015-02-24 02:05:02.059083000 Z
updated_at: 2015-03-02 19:21:49.496708000 Z
', '2015-03-05 12:40:15.711216');
INSERT INTO versions VALUES (1810, 'Person', 66, 'update', NULL, '---
id: 66
salutation: 1
name: ''Jaime ''
lastnames: ''Rodríguez ''
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 36
created_at: 2015-02-24 02:05:02.059083000 Z
updated_at: 2015-03-05 12:40:15.702818000 Z
', '2015-03-05 12:40:17.086515');
INSERT INTO versions VALUES (1811, 'Person', 216, 'update', NULL, '---
id: 216
salutation: 1
name: ''Jose ''
lastnames: Calo Castro
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 84
created_at: 2015-02-24 14:46:58.269313000 Z
updated_at: 2015-03-02 19:23:10.289412000 Z
', '2015-03-05 12:40:20.021934');
INSERT INTO versions VALUES (1812, 'Person', 216, 'update', NULL, '---
id: 216
salutation: 1
name: ''Jose ''
lastnames: Calo Castro
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 84
created_at: 2015-02-24 14:46:58.269313000 Z
updated_at: 2015-03-05 12:40:20.012661000 Z
', '2015-03-05 12:40:21.616147');
INSERT INTO versions VALUES (1813, 'Person', 211, 'update', NULL, '---
id: 211
salutation: 
name: Glorielis
lastnames: ''Flores Rodriguez ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 84
created_at: 2015-02-24 14:45:14.699725000 Z
updated_at: 2015-03-02 19:23:07.145517000 Z
', '2015-03-05 12:40:49.110821');
INSERT INTO versions VALUES (1814, 'Person', 211, 'update', NULL, '---
id: 211
salutation: 
name: Glorielis
lastnames: ''Flores Rodriguez ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 84
created_at: 2015-02-24 14:45:14.699725000 Z
updated_at: 2015-03-05 12:40:49.102383000 Z
', '2015-03-05 12:40:50.368074');
INSERT INTO versions VALUES (1815, 'Person', 67, 'update', NULL, '---
id: 67
salutation: 
name: ''Cristina ''
lastnames: ''Báez ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 36
created_at: 2015-02-24 02:05:28.776187000 Z
updated_at: 2015-03-02 19:21:46.332961000 Z
', '2015-03-05 12:41:02.631353');
INSERT INTO versions VALUES (1816, 'Person', 67, 'update', NULL, '---
id: 67
salutation: 
name: ''Cristina ''
lastnames: ''Báez ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 36
created_at: 2015-02-24 02:05:28.776187000 Z
updated_at: 2015-03-05 12:41:02.625553000 Z
', '2015-03-05 12:41:04.172046');
INSERT INTO versions VALUES (1817, 'Person', 82, 'update', NULL, '---
id: 82
salutation: 
name: ''Alba ''
lastnames: ''Martín ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 13
created_at: 2015-02-24 02:14:48.426260000 Z
updated_at: 2015-03-05 12:39:44.849685000 Z
', '2015-03-05 12:41:11.921611');
INSERT INTO versions VALUES (1818, 'Person', 207, 'update', NULL, '---
id: 207
salutation: 
name: ''Migdalia ''
lastnames: Quiñones Pizarro
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 84
created_at: 2015-02-24 14:43:36.159235000 Z
updated_at: 2015-03-02 19:23:10.305692000 Z
', '2015-03-05 12:41:42.128358');
INSERT INTO versions VALUES (1819, 'Person', 207, 'update', NULL, '---
id: 207
salutation: 
name: ''Migdalia ''
lastnames: Quiñones Pizarro
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 84
created_at: 2015-02-24 14:43:36.159235000 Z
updated_at: 2015-03-05 12:41:42.119352000 Z
', '2015-03-05 12:41:43.62347');
INSERT INTO versions VALUES (1820, 'Person', 156, 'update', NULL, '---
id: 156
salutation: 
name: ''Norma ''
lastnames: Valentin Guerrero
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:31:44.768649000 Z
updated_at: 2015-03-02 19:21:32.175046000 Z
', '2015-03-05 12:42:03.471827');
INSERT INTO versions VALUES (1821, 'Person', 156, 'update', NULL, '---
id: 156
salutation: 
name: ''Norma ''
lastnames: Valentin Guerrero
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:31:44.768649000 Z
updated_at: 2015-03-05 12:42:03.464429000 Z
', '2015-03-05 12:42:04.645141');
INSERT INTO versions VALUES (1822, 'Person', 485, 'create', NULL, NULL, '2015-03-05 12:42:27.982453');
INSERT INTO versions VALUES (1823, 'Person', 4, 'update', NULL, '---
id: 4
salutation: 
name: ''Luis ''
lastnames: ''Vázquez ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 108
created_at: 2015-02-23 22:23:49.805825000 Z
updated_at: 2015-03-02 19:23:22.494498000 Z
', '2015-03-05 12:42:45.961351');
INSERT INTO versions VALUES (1824, 'Person', 161, 'update', NULL, '---
id: 161
salutation: 
name: ''Gladys ''
lastnames: Linares Estrada
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:34:03.070512000 Z
updated_at: 2015-03-02 19:21:24.093657000 Z
', '2015-03-05 12:42:47.262799');
INSERT INTO versions VALUES (1825, 'Person', 4, 'update', NULL, '---
id: 4
salutation: 
name: ''Luis ''
lastnames: ''Vázquez ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 108
created_at: 2015-02-23 22:23:49.805825000 Z
updated_at: 2015-03-05 12:42:45.951145000 Z
', '2015-03-05 12:42:47.699946');
INSERT INTO versions VALUES (1826, 'Person', 161, 'update', NULL, '---
id: 161
salutation: 
name: ''Gladys ''
lastnames: Linares Estrada
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:34:03.070512000 Z
updated_at: 2015-03-05 12:42:47.253747000 Z
', '2015-03-05 12:42:48.360264');
INSERT INTO versions VALUES (1827, 'Person', 5, 'update', NULL, '---
id: 5
salutation: 
name: ''Mary ''
lastnames: ''Vázquez ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 108
created_at: 2015-02-23 22:24:15.398515000 Z
updated_at: 2015-03-02 19:23:25.628125000 Z
', '2015-03-05 12:42:50.180495');
INSERT INTO versions VALUES (1828, 'Person', 5, 'update', NULL, '---
id: 5
salutation: 
name: ''Mary ''
lastnames: ''Vázquez ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 108
created_at: 2015-02-23 22:24:15.398515000 Z
updated_at: 2015-03-05 12:42:50.171961000 Z
', '2015-03-05 12:42:51.702134');
INSERT INTO versions VALUES (1835, 'Person', 208, 'update', NULL, '---
id: 208
salutation: 
name: ''Anita ''
lastnames: González
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 84
created_at: 2015-02-24 14:43:53.101388000 Z
updated_at: 2015-03-05 12:39:20.215122000 Z
', '2015-03-05 12:43:18.336817');
INSERT INTO versions VALUES (1836, 'Person', 132, 'update', NULL, '---
id: 132
salutation: 
name: ''Marisabel ''
lastnames: ''Beltrán ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 65
created_at: 2015-02-24 02:48:45.523712000 Z
updated_at: 2015-03-02 19:23:25.740772000 Z
', '2015-03-05 12:43:25.796432');
INSERT INTO versions VALUES (1837, 'Person', 46, 'update', NULL, '---
id: 46
salutation: 
name: ''Amelia ''
lastnames: Colón
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 112
created_at: 2015-02-24 01:51:58.622180000 Z
updated_at: 2015-03-02 19:23:41.237298000 Z
', '2015-03-05 12:43:34.488598');
INSERT INTO versions VALUES (1838, 'Person', 46, 'update', NULL, '---
id: 46
salutation: 
name: ''Amelia ''
lastnames: Colón
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 112
created_at: 2015-02-24 01:51:58.622180000 Z
updated_at: 2015-03-05 12:43:34.478797000 Z
', '2015-03-05 12:43:36.292653');
INSERT INTO versions VALUES (1839, 'Person', 228, 'update', NULL, '---
id: 228
salutation: 
name: ''Hector M. ''
lastnames: ''González ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 97
created_at: 2015-02-24 15:04:05.736746000 Z
updated_at: 2015-03-02 19:20:45.383146000 Z
', '2015-03-05 12:43:52.980192');
INSERT INTO versions VALUES (1840, 'Person', 228, 'update', NULL, '---
id: 228
salutation: 
name: ''Hector M. ''
lastnames: ''González ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 97
created_at: 2015-02-24 15:04:05.736746000 Z
updated_at: 2015-03-05 12:43:52.971136000 Z
', '2015-03-05 12:43:53.846392');
INSERT INTO versions VALUES (1841, 'Person', 5, 'update', NULL, '---
id: 5
salutation: 
name: ''Mary ''
lastnames: ''Vázquez ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 108
created_at: 2015-02-23 22:24:15.398515000 Z
updated_at: 2015-03-05 12:42:51.691199000 Z
', '2015-03-05 12:44:04.657688');
INSERT INTO versions VALUES (1842, 'Person', 214, 'update', NULL, '---
id: 214
salutation: 
name: ''Antonia ''
lastnames: ''Urbina ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 84
created_at: 2015-02-24 14:46:22.778430000 Z
updated_at: 2015-03-02 19:23:07.136456000 Z
', '2015-03-05 12:44:06.860041');
INSERT INTO versions VALUES (1843, 'Person', 214, 'update', NULL, '---
id: 214
salutation: 
name: ''Antonia ''
lastnames: ''Urbina ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 84
created_at: 2015-02-24 14:46:22.778430000 Z
updated_at: 2015-03-05 12:44:06.853316000 Z
', '2015-03-05 12:44:08.578552');
INSERT INTO versions VALUES (1844, 'Person', 213, 'update', NULL, '---
id: 213
salutation: 
name: ''Emma ''
lastnames: Figueroa Agosto
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 84
created_at: 2015-02-24 14:46:01.725059000 Z
updated_at: 2015-03-02 19:23:07.141197000 Z
', '2015-03-05 12:44:10.345351');
INSERT INTO versions VALUES (1845, 'Person', 227, 'update', NULL, '---
id: 227
salutation: 
name: ''Sheyla ''
lastnames: ''Quiros Vazquez ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 97
created_at: 2015-02-24 15:03:30.849620000 Z
updated_at: 2015-03-02 19:20:49.487681000 Z
', '2015-03-05 12:44:11.728129');
INSERT INTO versions VALUES (1846, 'Person', 213, 'update', NULL, '---
id: 213
salutation: 
name: ''Emma ''
lastnames: Figueroa Agosto
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 84
created_at: 2015-02-24 14:46:01.725059000 Z
updated_at: 2015-03-05 12:44:10.337292000 Z
', '2015-03-05 12:44:12.400744');
INSERT INTO versions VALUES (1847, 'Person', 227, 'update', NULL, '---
id: 227
salutation: 
name: ''Sheyla ''
lastnames: ''Quiros Vazquez ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 97
created_at: 2015-02-24 15:03:30.849620000 Z
updated_at: 2015-03-05 12:44:11.718847000 Z
', '2015-03-05 12:44:12.85996');
INSERT INTO versions VALUES (1848, 'Person', 210, 'update', NULL, '---
id: 210
salutation: 
name: ''Ismael ''
lastnames: González
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 84
created_at: 2015-02-24 14:44:40.125466000 Z
updated_at: 2015-03-02 19:23:07.149913000 Z
', '2015-03-05 12:44:17.621985');
INSERT INTO versions VALUES (1849, 'Person', 210, 'update', NULL, '---
id: 210
salutation: 
name: ''Ismael ''
lastnames: González
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 84
created_at: 2015-02-24 14:44:40.125466000 Z
updated_at: 2015-03-05 12:44:17.615662000 Z
', '2015-03-05 12:44:19.291799');
INSERT INTO versions VALUES (1850, 'Person', 149, 'update', NULL, '---
id: 149
salutation: 
name: ''José A. ''
lastnames: ''Fernández ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:40:17.711563000 Z
updated_at: 2015-03-02 19:21:24.183456000 Z
', '2015-03-05 12:45:07.364126');
INSERT INTO versions VALUES (1851, 'Person', 149, 'update', NULL, '---
id: 149
salutation: 
name: ''José A. ''
lastnames: ''Fernández ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:40:17.711563000 Z
updated_at: 2015-03-05 12:45:07.354609000 Z
', '2015-03-05 12:45:09.075823');
INSERT INTO versions VALUES (1852, 'Person', 16, 'update', NULL, '---
id: 16
salutation: 
name: ''Zoraida ''
lastnames: ''Rivera ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 103
created_at: 2015-02-24 01:20:55.459826000 Z
updated_at: 2015-03-02 19:21:56.779293000 Z
', '2015-03-05 12:45:10.303601');
INSERT INTO versions VALUES (1853, 'Person', 16, 'update', NULL, '---
id: 16
salutation: 
name: ''Zoraida ''
lastnames: ''Rivera ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 103
created_at: 2015-02-24 01:20:55.459826000 Z
updated_at: 2015-03-05 12:45:10.294789000 Z
', '2015-03-05 12:45:11.13865');
INSERT INTO versions VALUES (1854, 'Person', 155, 'update', NULL, '---
id: 155
salutation: 
name: ''Angela ''
lastnames: Arroyo Santiago
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:31:13.682457000 Z
updated_at: 2015-03-02 19:21:17.604378000 Z
', '2015-03-05 12:45:11.647001');
INSERT INTO versions VALUES (1855, 'Person', 155, 'update', NULL, '---
id: 155
salutation: 
name: ''Angela ''
lastnames: Arroyo Santiago
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:31:13.682457000 Z
updated_at: 2015-03-05 12:45:11.637644000 Z
', '2015-03-05 12:45:12.58887');
INSERT INTO versions VALUES (1856, 'Person', 185, 'update', NULL, '---
id: 185
salutation: 0
name: ''Javier E. ''
lastnames: Sosa Rodríguez
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 42
created_at: 2015-02-24 14:18:03.475814000 Z
updated_at: 2015-03-02 19:22:12.455974000 Z
', '2015-03-05 12:45:16.220914');
INSERT INTO versions VALUES (1857, 'Person', 185, 'update', NULL, '---
id: 185
salutation: 0
name: ''Javier E. ''
lastnames: Sosa Rodríguez
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 42
created_at: 2015-02-24 14:18:03.475814000 Z
updated_at: 2015-03-05 12:45:16.216579000 Z
', '2015-03-05 12:45:17.932123');
INSERT INTO versions VALUES (1858, 'Person', 53, 'update', NULL, '---
id: 53
salutation: 
name: ''Domingo ''
lastnames: ''Carrasquillo ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 7
created_at: 2015-02-24 01:56:49.327954000 Z
updated_at: 2015-03-02 19:20:45.165148000 Z
', '2015-03-05 12:45:54.243647');
INSERT INTO versions VALUES (1859, 'Person', 53, 'update', NULL, '---
id: 53
salutation: 
name: ''Domingo ''
lastnames: ''Carrasquillo ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 7
created_at: 2015-02-24 01:56:49.327954000 Z
updated_at: 2015-03-05 12:45:54.234506000 Z
', '2015-03-05 12:45:55.824643');
INSERT INTO versions VALUES (1860, 'Person', 142, 'update', NULL, '---
id: 142
salutation: 1
name: ''Carmen M. ''
lastnames: ''Arroyo ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:34:25.075862000 Z
updated_at: 2015-03-02 19:21:20.957026000 Z
', '2015-03-05 12:46:42.090018');
INSERT INTO versions VALUES (1861, 'Person', 142, 'update', NULL, '---
id: 142
salutation: 1
name: ''Carmen M. ''
lastnames: ''Arroyo ''
sex: false
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:34:25.075862000 Z
updated_at: 2015-03-05 12:46:42.087339000 Z
', '2015-03-05 12:46:43.547845');
INSERT INTO versions VALUES (1862, 'Person', 99, 'update', NULL, '---
id: 99
salutation: 
name: ''Idalia ''
lastnames: ''García ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 50
created_at: 2015-02-24 02:26:53.654669000 Z
updated_at: 2015-03-02 19:21:42.470883000 Z
', '2015-03-05 12:46:44.657116');
INSERT INTO versions VALUES (1863, 'Person', 99, 'update', NULL, '---
id: 99
salutation: 
name: ''Idalia ''
lastnames: ''García ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 50
created_at: 2015-02-24 02:26:53.654669000 Z
updated_at: 2015-03-05 12:46:44.647830000 Z
', '2015-03-05 12:46:46.026323');
INSERT INTO versions VALUES (1864, 'Person', 457, 'update', NULL, '---
id: 457
salutation: 
name: Héctor
lastnames: Soto
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 20:46:17.064976000 Z
updated_at: 2015-03-04 20:48:26.982732000 Z
', '2015-03-05 12:47:06.090548');
INSERT INTO versions VALUES (1865, 'Person', 457, 'update', NULL, '---
id: 457
salutation: 
name: Héctor
lastnames: Soto
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 48
created_at: 2015-03-04 20:46:17.064976000 Z
updated_at: 2015-03-05 12:47:06.082503000 Z
', '2015-03-05 12:47:07.385528');
INSERT INTO versions VALUES (1866, 'Person', 54, 'update', NULL, '---
id: 54
salutation: 
name: ''Israel ''
lastnames: ''Cotto ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 7
created_at: 2015-02-24 01:57:09.233216000 Z
updated_at: 2015-03-02 19:20:45.276294000 Z
', '2015-03-05 12:47:19.134064');
INSERT INTO versions VALUES (1867, 'Person', 54, 'update', NULL, '---
id: 54
salutation: 
name: ''Israel ''
lastnames: ''Cotto ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 7
created_at: 2015-02-24 01:57:09.233216000 Z
updated_at: 2015-03-05 12:47:19.124818000 Z
', '2015-03-05 12:47:20.947505');
INSERT INTO versions VALUES (1868, 'Person', 358, 'update', NULL, '---
id: 358
salutation: 0
name: David A.
lastnames: González
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:13:02.826787000 Z
updated_at: 2015-03-04 20:41:23.405353000 Z
', '2015-03-05 12:47:30.037593');
INSERT INTO versions VALUES (1869, 'Person', 358, 'update', NULL, '---
id: 358
salutation: 0
name: David A.
lastnames: González
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 16
created_at: 2015-03-04 11:13:02.826787000 Z
updated_at: 2015-03-05 12:47:30.026961000 Z
', '2015-03-05 12:47:31.342506');
INSERT INTO versions VALUES (1870, 'Check', 40, 'create', NULL, NULL, '2015-03-05 12:48:13.3457');
INSERT INTO versions VALUES (1871, 'Person', 42, 'update', NULL, '---
id: 42
salutation: 
name: ''Angel ''
lastnames: ''Torres ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 110
created_at: 2015-02-24 01:49:43.059036000 Z
updated_at: 2015-03-02 19:23:33.235933000 Z
', '2015-03-05 12:48:30.957883');
INSERT INTO versions VALUES (1872, 'Person', 42, 'update', NULL, '---
id: 42
salutation: 
name: ''Angel ''
lastnames: ''Torres ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 110
created_at: 2015-02-24 01:49:43.059036000 Z
updated_at: 2015-03-05 12:48:30.949221000 Z
', '2015-03-05 12:48:31.939679');
INSERT INTO versions VALUES (1873, 'Person', 486, 'create', NULL, NULL, '2015-03-05 12:48:48.559959');
INSERT INTO versions VALUES (1874, 'Person', 388, 'update', NULL, '---
id: 388
salutation: 1
name: Mayra
lastnames: Giovannetti
sex: false
role: 5
description: Misionera en Nicaragua
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:46:44.155826000 Z
updated_at: 2015-03-04 20:24:07.618008000 Z
', '2015-03-05 12:49:02.48195');
INSERT INTO versions VALUES (1875, 'Person', 388, 'update', NULL, '---
id: 388
salutation: 1
name: Mayra
lastnames: Giovannetti
sex: false
role: 5
description: Misionera en Nicaragua
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:46:44.155826000 Z
updated_at: 2015-03-05 12:49:02.477688000 Z
', '2015-03-05 12:49:04.131428');
INSERT INTO versions VALUES (1876, 'Person', 124, 'update', NULL, '---
id: 124
salutation: 
name: ''Lilybeth ''
lastnames: Bosch
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 56
created_at: 2015-02-24 02:41:48.368594000 Z
updated_at: 2015-03-05 12:31:31.445701000 Z
', '2015-03-05 12:49:05.958273');
INSERT INTO versions VALUES (1877, 'Check', 41, 'create', NULL, NULL, '2015-03-05 12:49:35.773649');
INSERT INTO versions VALUES (1878, 'Person', 487, 'create', NULL, NULL, '2015-03-05 12:49:48.915732');
INSERT INTO versions VALUES (1879, 'Person', 43, 'update', NULL, '---
id: 43
salutation: 
name: ''Luciano ''
lastnames: ''Ortiz ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 110
created_at: 2015-02-24 01:50:05.172259000 Z
updated_at: 2015-03-02 19:23:38.055145000 Z
', '2015-03-05 12:50:02.769322');
INSERT INTO versions VALUES (1880, 'Person', 43, 'update', NULL, '---
id: 43
salutation: 
name: ''Luciano ''
lastnames: ''Ortiz ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 110
created_at: 2015-02-24 01:50:05.172259000 Z
updated_at: 2015-03-05 12:50:02.760075000 Z
', '2015-03-05 12:50:03.707842');
INSERT INTO versions VALUES (1881, 'Person', 2, 'update', NULL, '---
id: 2
salutation: 
name: ''Susano ''
lastnames: ''Luzunaris ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 108
created_at: 2015-02-23 22:22:37.697968000 Z
updated_at: 2015-03-02 19:23:25.714348000 Z
', '2015-03-05 12:50:31.160842');
INSERT INTO versions VALUES (1882, 'Person', 2, 'update', NULL, '---
id: 2
salutation: 
name: ''Susano ''
lastnames: ''Luzunaris ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 108
created_at: 2015-02-23 22:22:37.697968000 Z
updated_at: 2015-03-05 12:50:31.154420000 Z
', '2015-03-05 12:50:32.388574');
INSERT INTO versions VALUES (1883, 'Person', 488, 'create', NULL, NULL, '2015-03-05 12:50:36.766155');
INSERT INTO versions VALUES (1884, 'Person', 344, 'update', NULL, '---
id: 344
salutation: 1
name: Clemente
lastnames: Flores
sex: true
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 10:57:43.865004000 Z
updated_at: 2015-03-04 20:52:30.315204000 Z
', '2015-03-05 12:50:37.106989');
INSERT INTO versions VALUES (1885, 'Person', 344, 'update', NULL, '---
id: 344
salutation: 1
name: Clemente
lastnames: Flores
sex: true
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 58
created_at: 2015-03-04 10:57:43.865004000 Z
updated_at: 2015-03-05 12:50:37.104311000 Z
', '2015-03-05 12:50:37.998415');
INSERT INTO versions VALUES (1886, 'Person', 489, 'create', NULL, NULL, '2015-03-05 12:50:43.497767');
INSERT INTO versions VALUES (1887, 'Person', 65, 'update', NULL, '---
id: 65
salutation: 1
name: ''Benigno ''
lastnames: ''Torres ''
sex: true
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 33
created_at: 2015-02-24 02:03:03.022471000 Z
updated_at: 2015-03-02 19:21:35.979171000 Z
', '2015-03-05 12:50:45.009916');
INSERT INTO versions VALUES (1888, 'Person', 65, 'update', NULL, '---
id: 65
salutation: 1
name: ''Benigno ''
lastnames: ''Torres ''
sex: true
role: 2
description: ''''
attended: true
printed: true
materials: false
church_id: 33
created_at: 2015-02-24 02:03:03.022471000 Z
updated_at: 2015-03-05 12:50:45.004285000 Z
', '2015-03-05 12:50:45.86838');
INSERT INTO versions VALUES (1889, 'Person', 490, 'create', NULL, NULL, '2015-03-05 12:51:03.184973');
INSERT INTO versions VALUES (1896, 'Person', 490, 'update', NULL, '---
id: 490
salutation: 
name: Carmen
lastnames: Avilés
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 106
created_at: 2015-03-05 12:51:03.182242000 Z
updated_at: 2015-03-05 12:51:03.182242000 Z
', '2015-03-05 12:51:18.516698');
INSERT INTO versions VALUES (1897, 'Person', 488, 'update', NULL, '---
id: 488
salutation: 
name: Lucy
lastnames: Falero
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 106
created_at: 2015-03-05 12:50:36.762007000 Z
updated_at: 2015-03-05 12:51:12.935720000 Z
', '2015-03-05 12:51:19.698037');
INSERT INTO versions VALUES (1898, 'Person', 490, 'update', NULL, '---
id: 490
salutation: 
name: Carmen
lastnames: Avilés
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: false
church_id: 106
created_at: 2015-03-05 12:51:03.182242000 Z
updated_at: 2015-03-05 12:51:18.506321000 Z
', '2015-03-05 12:51:21.053668');
INSERT INTO versions VALUES (1899, 'Person', 488, 'update', NULL, '---
id: 488
salutation: 
name: Lucy
lastnames: Falero
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 106
created_at: 2015-03-05 12:50:36.762007000 Z
updated_at: 2015-03-05 12:51:19.692501000 Z
', '2015-03-05 12:51:21.988661');
INSERT INTO versions VALUES (1900, 'Person', 89, 'update', NULL, '---
id: 89
salutation: 
name: ''Aurelina ''
lastnames: ''Roldán ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:17:55.397238000 Z
updated_at: 2015-03-02 19:21:00.045266000 Z
', '2015-03-05 12:51:28.022039');
INSERT INTO versions VALUES (1901, 'Person', 89, 'update', NULL, '---
id: 89
salutation: 
name: ''Aurelina ''
lastnames: ''Roldán ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:17:55.397238000 Z
updated_at: 2015-03-05 12:51:28.012575000 Z
', '2015-03-05 12:51:29.706319');
INSERT INTO versions VALUES (1902, 'Person', 457, 'update', NULL, '---
id: 457
salutation: 
name: Héctor
lastnames: Soto
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 48
created_at: 2015-03-04 20:46:17.064976000 Z
updated_at: 2015-03-05 12:47:07.377014000 Z
', '2015-03-05 12:52:04.900191');
INSERT INTO versions VALUES (1903, 'Person', 72, 'update', NULL, '---
id: 72
salutation: 
name: ''Fredeswilda ''
lastnames: ''Vargas ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 37
created_at: 2015-02-24 02:08:16.277270000 Z
updated_at: 2015-03-02 19:21:46.357545000 Z
', '2015-03-05 12:52:07.003395');
INSERT INTO versions VALUES (1904, 'Person', 72, 'update', NULL, '---
id: 72
salutation: 
name: ''Fredeswilda ''
lastnames: ''Vargas ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 37
created_at: 2015-02-24 02:08:16.277270000 Z
updated_at: 2015-03-05 12:52:06.994041000 Z
', '2015-03-05 12:52:08.27366');
INSERT INTO versions VALUES (1905, 'Person', 284, 'update', NULL, '---
id: 284
salutation: 6
name: ''Daniel ''
lastnames: Santos
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 120
created_at: 2015-02-25 14:49:00.280008000 Z
updated_at: 2015-03-02 19:22:59.348407000 Z
', '2015-03-05 12:52:37.612875');
INSERT INTO versions VALUES (1906, 'Person', 284, 'update', NULL, '---
id: 284
salutation: 6
name: ''Daniel ''
lastnames: Santos
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 120
created_at: 2015-02-25 14:49:00.280008000 Z
updated_at: 2015-03-05 12:52:37.603553000 Z
', '2015-03-05 12:52:38.742484');
INSERT INTO versions VALUES (1907, 'Check', 42, 'create', NULL, NULL, '2015-03-05 12:52:48.812535');
INSERT INTO versions VALUES (1908, 'Person', 164, 'update', NULL, '---
id: 164
salutation: 
name: ''Sonia ''
lastnames: ''Casillas ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 26
created_at: 2015-02-24 13:51:15.708854000 Z
updated_at: 2015-03-02 19:21:39.302297000 Z
', '2015-03-05 12:52:48.957963');
INSERT INTO versions VALUES (1909, 'Person', 164, 'update', NULL, '---
id: 164
salutation: 
name: ''Sonia ''
lastnames: ''Casillas ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 26
created_at: 2015-02-24 13:51:15.708854000 Z
updated_at: 2015-03-05 12:52:48.951486000 Z
', '2015-03-05 12:52:50.294877');
INSERT INTO versions VALUES (1910, 'Person', 120, 'update', NULL, '---
id: 120
salutation: 
name: ''Providencia ''
lastnames: ''Hernández ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 15
created_at: 2015-02-24 02:39:44.622382000 Z
updated_at: 2015-03-02 19:22:12.408945000 Z
', '2015-03-05 12:53:06.866746');
INSERT INTO versions VALUES (1911, 'Person', 120, 'update', NULL, '---
id: 120
salutation: 
name: ''Providencia ''
lastnames: ''Hernández ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 15
created_at: 2015-02-24 02:39:44.622382000 Z
updated_at: 2015-03-05 12:53:06.858241000 Z
', '2015-03-05 12:53:08.129014');
INSERT INTO versions VALUES (1912, 'Person', 86, 'update', NULL, '---
id: 86
salutation: 
name: ''Aurelio ''
lastnames: ''Ríos ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:16:38.054947000 Z
updated_at: 2015-03-02 19:21:03.179310000 Z
', '2015-03-05 12:53:08.154897');
INSERT INTO versions VALUES (1913, 'Person', 86, 'update', NULL, '---
id: 86
salutation: 
name: ''Aurelio ''
lastnames: ''Ríos ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:16:38.054947000 Z
updated_at: 2015-03-05 12:53:08.150811000 Z
', '2015-03-05 12:53:09.737312');
INSERT INTO versions VALUES (1914, 'Person', 90, 'update', NULL, '---
id: 90
salutation: 1
name: ''Félix ''
lastnames: ''Rivera ''
sex: true
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:18:41.545225000 Z
updated_at: 2015-03-02 19:21:03.428601000 Z
', '2015-03-05 12:53:14.056257');
INSERT INTO versions VALUES (1915, 'Person', 90, 'update', NULL, '---
id: 90
salutation: 1
name: ''Félix ''
lastnames: ''Rivera ''
sex: true
role: 2
description: ''''
attended: true
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:18:41.545225000 Z
updated_at: 2015-03-05 12:53:14.048680000 Z
', '2015-03-05 12:53:15.784664');
INSERT INTO versions VALUES (1916, 'Person', 51, 'update', NULL, '---
id: 51
salutation: 1
name: ''Ramón L. ''
lastnames: ''Díaz ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 7
created_at: 2015-02-24 01:56:07.756014000 Z
updated_at: 2015-03-02 19:20:45.324165000 Z
', '2015-03-05 12:53:30.774583');
INSERT INTO versions VALUES (1917, 'Person', 51, 'update', NULL, '---
id: 51
salutation: 1
name: ''Ramón L. ''
lastnames: ''Díaz ''
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 7
created_at: 2015-02-24 01:56:07.756014000 Z
updated_at: 2015-03-05 12:53:30.768034000 Z
', '2015-03-05 12:53:34.052173');
INSERT INTO versions VALUES (1918, 'Person', 121, 'update', NULL, '---
id: 121
salutation: 
name: ''Audrey ''
lastnames: ''Viera ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 15
created_at: 2015-02-24 02:40:13.362635000 Z
updated_at: 2015-03-02 19:22:07.754115000 Z
', '2015-03-05 12:54:12.645992');
INSERT INTO versions VALUES (1919, 'Person', 121, 'update', NULL, '---
id: 121
salutation: 
name: ''Audrey ''
lastnames: ''Viera ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 15
created_at: 2015-02-24 02:40:13.362635000 Z
updated_at: 2015-03-05 12:54:12.638276000 Z
', '2015-03-05 12:54:13.788428');
INSERT INTO versions VALUES (1920, 'Person', 158, 'update', NULL, '---
id: 158
salutation: 
name: ''Fernando ''
lastnames: ''Barreto Cardona ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:32:55.491074000 Z
updated_at: 2015-03-02 19:21:20.963343000 Z
', '2015-03-05 12:54:19.877667');
INSERT INTO versions VALUES (1921, 'Person', 158, 'update', NULL, '---
id: 158
salutation: 
name: ''Fernando ''
lastnames: ''Barreto Cardona ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:32:55.491074000 Z
updated_at: 2015-03-05 12:54:19.869891000 Z
', '2015-03-05 12:54:20.968514');
INSERT INTO versions VALUES (1922, 'Check', 43, 'create', NULL, NULL, '2015-03-05 12:54:45.071098');
INSERT INTO versions VALUES (1923, 'Check', 44, 'create', NULL, NULL, '2015-03-05 12:54:45.215853');
INSERT INTO versions VALUES (1924, 'Check', 44, 'destroy', NULL, '---
id: 44
number: 0
amount: 100.0
description: ''''
church_id: 26
created_at: 2015-03-05 12:54:45.214482000 Z
updated_at: 2015-03-05 12:54:45.214482000 Z
', '2015-03-05 12:54:56.281305');
INSERT INTO versions VALUES (1925, 'Person', 147, 'update', NULL, '---
id: 147
salutation: 
name: ''Mario ''
lastnames: ''Moya ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:38:43.989795000 Z
updated_at: 2015-03-02 19:21:28.764306000 Z
', '2015-03-05 12:54:59.778473');
INSERT INTO versions VALUES (1926, 'Person', 147, 'update', NULL, '---
id: 147
salutation: 
name: ''Mario ''
lastnames: ''Moya ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:38:43.989795000 Z
updated_at: 2015-03-05 12:54:59.772783000 Z
', '2015-03-05 12:55:00.974845');
INSERT INTO versions VALUES (1927, 'Person', 24, 'update', NULL, '---
id: 24
salutation: 
name: Nubia G.
lastnames: ''Santos ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 109
created_at: 2015-02-24 01:28:09.897945000 Z
updated_at: 2015-03-02 19:23:33.221753000 Z
', '2015-03-05 12:55:10.016259');
INSERT INTO versions VALUES (1928, 'Person', 24, 'update', NULL, '---
id: 24
salutation: 
name: Nubia G.
lastnames: ''Santos ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 109
created_at: 2015-02-24 01:28:09.897945000 Z
updated_at: 2015-03-05 12:55:10.007652000 Z
', '2015-03-05 12:55:11.554607');
INSERT INTO versions VALUES (1929, 'Person', 148, 'update', NULL, '---
id: 148
salutation: 
name: ''Carmen ''
lastnames: ''Morales ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:39:28.230070000 Z
updated_at: 2015-03-02 19:21:20.935369000 Z
', '2015-03-05 12:55:38.676386');
INSERT INTO versions VALUES (1930, 'Person', 148, 'update', NULL, '---
id: 148
salutation: 
name: ''Carmen ''
lastnames: ''Morales ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:39:28.230070000 Z
updated_at: 2015-03-05 12:55:38.667114000 Z
', '2015-03-05 12:55:39.678867');
INSERT INTO versions VALUES (1931, 'Person', 76, 'update', NULL, '---
id: 76
salutation: 3
name: ''Alfredo ''
lastnames: ''Méndez ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 64
created_at: 2015-02-24 02:11:21.043451000 Z
updated_at: 2015-03-02 19:22:45.784072000 Z
', '2015-03-05 12:55:40.932457');
INSERT INTO versions VALUES (1932, 'Person', 76, 'update', NULL, '---
id: 76
salutation: 3
name: ''Alfredo ''
lastnames: ''Méndez ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 64
created_at: 2015-02-24 02:11:21.043451000 Z
updated_at: 2015-03-05 12:55:40.929455000 Z
', '2015-03-05 12:55:42.245755');
INSERT INTO versions VALUES (1933, 'Person', 335, 'update', NULL, '---
id: 335
salutation: 0
name: ''Jesús E. ''
lastnames: García
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 29
created_at: 2015-03-02 19:54:39.652549000 Z
updated_at: 2015-03-02 20:00:15.970637000 Z
', '2015-03-05 12:56:16.115759');
INSERT INTO versions VALUES (1934, 'Person', 335, 'update', NULL, '---
id: 335
salutation: 0
name: ''Jesús E. ''
lastnames: García
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 29
created_at: 2015-03-02 19:54:39.652549000 Z
updated_at: 2015-03-05 12:56:16.106215000 Z
', '2015-03-05 12:56:17.629355');
INSERT INTO versions VALUES (1935, 'Person', 337, 'update', NULL, '---
id: 337
salutation: 
name: ''Ricartel ''
lastnames: Rivera
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 29
created_at: 2015-03-02 19:55:18.703264000 Z
updated_at: 2015-03-02 20:00:16.004022000 Z
', '2015-03-05 12:56:18.840255');
INSERT INTO versions VALUES (1936, 'Person', 337, 'update', NULL, '---
id: 337
salutation: 
name: ''Ricartel ''
lastnames: Rivera
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 29
created_at: 2015-03-02 19:55:18.703264000 Z
updated_at: 2015-03-05 12:56:18.831873000 Z
', '2015-03-05 12:56:23.627268');
INSERT INTO versions VALUES (1937, 'Person', 334, 'update', NULL, '---
id: 334
salutation: 
name: Luz D.
lastnames: Lamboy
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 91
created_at: 2015-03-02 19:52:43.963990000 Z
updated_at: 2015-03-02 19:53:12.531252000 Z
', '2015-03-05 12:56:38.446147');
INSERT INTO versions VALUES (1938, 'Person', 334, 'update', NULL, '---
id: 334
salutation: 
name: Luz D.
lastnames: Lamboy
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 91
created_at: 2015-03-02 19:52:43.963990000 Z
updated_at: 2015-03-05 12:56:38.436947000 Z
', '2015-03-05 12:56:39.786634');
INSERT INTO versions VALUES (1939, 'Person', 315, 'update', NULL, '---
id: 315
salutation: 
name: Carlos W.
lastnames: Filippetti
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 80
created_at: 2015-03-02 19:32:08.017509000 Z
updated_at: 2015-03-02 19:33:01.415532000 Z
', '2015-03-05 12:57:10.823473');
INSERT INTO versions VALUES (1940, 'Person', 315, 'update', NULL, '---
id: 315
salutation: 
name: Carlos W.
lastnames: Filippetti
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 80
created_at: 2015-03-02 19:32:08.017509000 Z
updated_at: 2015-03-05 12:57:10.816208000 Z
', '2015-03-05 12:57:12.52258');
INSERT INTO versions VALUES (1941, 'Person', 316, 'update', NULL, '---
id: 316
salutation: 
name: ''Daisy ''
lastnames: Cruz Torres
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 80
created_at: 2015-03-02 19:32:29.777240000 Z
updated_at: 2015-03-02 19:33:01.432588000 Z
', '2015-03-05 12:57:15.269543');
INSERT INTO versions VALUES (1942, 'Person', 316, 'update', NULL, '---
id: 316
salutation: 
name: ''Daisy ''
lastnames: Cruz Torres
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 80
created_at: 2015-03-02 19:32:29.777240000 Z
updated_at: 2015-03-05 12:57:15.261089000 Z
', '2015-03-05 12:57:17.920973');
INSERT INTO versions VALUES (1943, 'Person', 314, 'update', NULL, '---
id: 314
salutation: 1
name: ''Jaime ''
lastnames: Galarza Sierra
sex: true
role: 4
description: Representante Distrito
attended: false
printed: true
materials: false
church_id: 80
created_at: 2015-03-02 19:31:39.242967000 Z
updated_at: 2015-03-04 20:04:15.409063000 Z
', '2015-03-05 12:57:19.538858');
INSERT INTO versions VALUES (1944, 'Person', 314, 'update', NULL, '---
id: 314
salutation: 1
name: ''Jaime ''
lastnames: Galarza Sierra
sex: true
role: 4
description: Representante Distrito
attended: true
printed: true
materials: false
church_id: 80
created_at: 2015-03-02 19:31:39.242967000 Z
updated_at: 2015-03-05 12:57:19.529538000 Z
', '2015-03-05 12:57:21.409634');
INSERT INTO versions VALUES (1945, 'Person', 457, 'update', NULL, '---
id: 457
salutation: 
name: Héctor
lastnames: Soto
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: true
church_id: 48
created_at: 2015-03-04 20:46:17.064976000 Z
updated_at: 2015-03-05 12:52:04.891331000 Z
', '2015-03-05 12:57:28.828513');
INSERT INTO versions VALUES (1946, 'Check', 45, 'create', NULL, NULL, '2015-03-05 12:57:35.420844');
INSERT INTO versions VALUES (1947, 'Person', 491, 'create', NULL, NULL, '2015-03-05 12:58:40.010364');
INSERT INTO versions VALUES (1948, 'Person', 414, 'update', NULL, '---
id: 414
salutation: 6
name: ''Héctor ''
lastnames: González
sex: true
role: 5
description: Consejero Hispano, ABCCU/WMS
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:57:00.711374000 Z
updated_at: 2015-03-04 20:30:15.034148000 Z
', '2015-03-05 12:58:50.796064');
INSERT INTO versions VALUES (1949, 'Person', 414, 'update', NULL, '---
id: 414
salutation: 6
name: ''Héctor ''
lastnames: González
sex: true
role: 5
description: Consejero Hispano, ABCCU/WMS
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:57:00.711374000 Z
updated_at: 2015-03-05 12:58:50.792358000 Z
', '2015-03-05 12:58:51.636815');
INSERT INTO versions VALUES (1950, 'Person', 93, 'update', NULL, '---
id: 93
salutation: 
name: ''Oscar ''
lastnames: ''Lausell ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 14
created_at: 2015-02-24 02:23:34.710960000 Z
updated_at: 2015-03-02 19:21:07.051094000 Z
', '2015-03-05 12:59:01.357996');
INSERT INTO versions VALUES (1951, 'Person', 93, 'update', NULL, '---
id: 93
salutation: 
name: ''Oscar ''
lastnames: ''Lausell ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 14
created_at: 2015-02-24 02:23:34.710960000 Z
updated_at: 2015-03-05 12:59:01.348849000 Z
', '2015-03-05 12:59:03.324884');
INSERT INTO versions VALUES (1952, 'Person', 492, 'create', NULL, NULL, '2015-03-05 12:59:05.935769');
INSERT INTO versions VALUES (1953, 'Person', 493, 'create', NULL, NULL, '2015-03-05 12:59:14.383046');
INSERT INTO versions VALUES (1954, 'Person', 48, 'update', NULL, '---
id: 48
salutation: 1
name: ''Jimmy ''
lastnames: ''Vargas ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 113
created_at: 2015-02-24 01:53:09.270001000 Z
updated_at: 2015-03-02 19:21:42.485257000 Z
', '2015-03-05 12:59:25.380025');
INSERT INTO versions VALUES (1955, 'Person', 48, 'update', NULL, '---
id: 48
salutation: 1
name: ''Jimmy ''
lastnames: ''Vargas ''
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 113
created_at: 2015-02-24 01:53:09.270001000 Z
updated_at: 2015-03-05 12:59:25.370716000 Z
', '2015-03-05 12:59:26.150414');
INSERT INTO versions VALUES (1956, 'Person', 494, 'create', NULL, NULL, '2015-03-05 12:59:44.562519');
INSERT INTO versions VALUES (1957, 'Person', 495, 'create', NULL, NULL, '2015-03-05 12:59:49.99593');
INSERT INTO versions VALUES (1958, 'Person', 285, 'update', NULL, '---
id: 285
salutation: 
name: ''Awilda ''
lastnames: Bonilla
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 122
created_at: 2015-02-25 14:49:25.742138000 Z
updated_at: 2015-03-02 19:22:59.355341000 Z
', '2015-03-05 12:59:50.98805');
INSERT INTO versions VALUES (1959, 'Person', 27, 'update', NULL, '---
id: 27
salutation: 0
name: ''Migdalia ''
lastnames: ''Flores ''
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 100
created_at: 2015-02-24 01:37:45.571485000 Z
updated_at: 2015-03-02 19:20:49.633145000 Z
', '2015-03-05 13:00:01.366339');
INSERT INTO versions VALUES (1960, 'Person', 27, 'update', NULL, '---
id: 27
salutation: 0
name: ''Migdalia ''
lastnames: ''Flores ''
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 100
created_at: 2015-02-24 01:37:45.571485000 Z
updated_at: 2015-03-05 13:00:01.358196000 Z
', '2015-03-05 13:00:03.21582');
INSERT INTO versions VALUES (1961, 'Person', 491, 'update', NULL, '---
id: 491
salutation: 0
name: María E.
lastnames: García
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 62
created_at: 2015-03-05 12:58:40.007822000 Z
updated_at: 2015-03-05 12:58:40.007822000 Z
', '2015-03-05 13:00:04.63496');
INSERT INTO versions VALUES (1962, 'Person', 491, 'update', NULL, '---
id: 491
salutation: 0
name: María E.
lastnames: García
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: false
church_id: 62
created_at: 2015-03-05 12:58:40.007822000 Z
updated_at: 2015-03-05 13:00:04.629050000 Z
', '2015-03-05 13:00:05.843566');
INSERT INTO versions VALUES (1963, 'Person', 496, 'create', NULL, NULL, '2015-03-05 13:00:09.181462');
INSERT INTO versions VALUES (1964, 'Person', 490, 'update', NULL, '---
id: 490
salutation: 
name: Carmen
lastnames: Avilés
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 106
created_at: 2015-03-05 12:51:03.182242000 Z
updated_at: 2015-03-05 12:51:21.048538000 Z
', '2015-03-05 13:00:16.775482');
INSERT INTO versions VALUES (1965, 'Person', 457, 'update', NULL, '---
id: 457
salutation: 0
name: Héctor
lastnames: Soto
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 48
created_at: 2015-03-04 20:46:17.064976000 Z
updated_at: 2015-03-05 12:57:28.821180000 Z
', '2015-03-05 13:00:16.843495');
INSERT INTO versions VALUES (1966, 'Person', 492, 'update', NULL, '---
id: 492
salutation: 
name: Carmelo
lastnames: Garcia
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 28
created_at: 2015-03-05 12:59:05.928902000 Z
updated_at: 2015-03-05 12:59:05.928902000 Z
', '2015-03-05 13:00:16.851417');
INSERT INTO versions VALUES (1967, 'Person', 493, 'update', NULL, '---
id: 493
salutation: 
name: Héctor
lastnames: López
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 62
created_at: 2015-03-05 12:59:14.380473000 Z
updated_at: 2015-03-05 12:59:14.380473000 Z
', '2015-03-05 13:00:16.85741');
INSERT INTO versions VALUES (1968, 'Person', 494, 'update', NULL, '---
id: 494
salutation: 
name: Evelyn
lastnames: De Jesús
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 28
created_at: 2015-03-05 12:59:44.557784000 Z
updated_at: 2015-03-05 12:59:44.557784000 Z
', '2015-03-05 13:00:16.868248');
INSERT INTO versions VALUES (1969, 'Person', 495, 'update', NULL, '---
id: 495
salutation: 
name: Carmin
lastnames: Figueroa
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 62
created_at: 2015-03-05 12:59:49.993938000 Z
updated_at: 2015-03-05 12:59:49.993938000 Z
', '2015-03-05 13:00:16.873762');
INSERT INTO versions VALUES (1970, 'Person', 28, 'update', NULL, '---
id: 28
salutation: 
name: ''Angel ''
lastnames: ''Pérez ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 100
created_at: 2015-02-24 01:38:14.145202000 Z
updated_at: 2015-03-02 19:20:49.615064000 Z
', '2015-03-05 13:00:26.956346');
INSERT INTO versions VALUES (1971, 'Person', 28, 'update', NULL, '---
id: 28
salutation: 
name: ''Angel ''
lastnames: ''Pérez ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 100
created_at: 2015-02-24 01:38:14.145202000 Z
updated_at: 2015-03-05 13:00:26.951357000 Z
', '2015-03-05 13:00:28.72989');
INSERT INTO versions VALUES (1972, 'Person', 246, 'update', NULL, '---
id: 246
salutation: 
name: ''Raquel ''
lastnames: ''López Rodríguez ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 6
created_at: 2015-02-24 15:14:41.256116000 Z
updated_at: 2015-03-02 19:23:47.864632000 Z
', '2015-03-05 13:00:29.837452');
INSERT INTO versions VALUES (1973, 'Person', 246, 'update', NULL, '---
id: 246
salutation: 
name: ''Raquel ''
lastnames: ''López Rodríguez ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 6
created_at: 2015-02-24 15:14:41.256116000 Z
updated_at: 2015-03-05 13:00:29.828648000 Z
', '2015-03-05 13:00:30.974048');
INSERT INTO versions VALUES (1974, 'Person', 247, 'update', NULL, '---
id: 247
salutation: 
name: ''Roberto ''
lastnames: Vera Monroig
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 6
created_at: 2015-02-24 15:15:22.012673000 Z
updated_at: 2015-03-02 19:23:48.351136000 Z
', '2015-03-05 13:00:32.325882');
INSERT INTO versions VALUES (1975, 'Person', 247, 'update', NULL, '---
id: 247
salutation: 
name: ''Roberto ''
lastnames: Vera Monroig
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 6
created_at: 2015-02-24 15:15:22.012673000 Z
updated_at: 2015-03-05 13:00:32.316681000 Z
', '2015-03-05 13:00:33.434696');
INSERT INTO versions VALUES (1976, 'Person', 495, 'update', NULL, '---
id: 495
salutation: 
name: Carmin
lastnames: Figueroa
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 62
created_at: 2015-03-05 12:59:49.993938000 Z
updated_at: 2015-03-05 13:00:16.871204000 Z
', '2015-03-05 13:00:37.33917');
INSERT INTO versions VALUES (1977, 'Person', 497, 'create', NULL, NULL, '2015-03-05 13:00:37.956544');
INSERT INTO versions VALUES (1978, 'Person', 495, 'update', NULL, '---
id: 495
salutation: 
name: Carmin
lastnames: Figueroa
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 62
created_at: 2015-03-05 12:59:49.993938000 Z
updated_at: 2015-03-05 13:00:37.334334000 Z
', '2015-03-05 13:00:38.364497');
INSERT INTO versions VALUES (1979, 'Check', 46, 'create', NULL, NULL, '2015-03-05 13:00:39.9492');
INSERT INTO versions VALUES (1980, 'Person', 285, 'update', NULL, '---
id: 285
salutation: 
name: ''Awilda ''
lastnames: Bonilla
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 122
created_at: 2015-02-25 14:49:25.742138000 Z
updated_at: 2015-03-05 12:59:50.983670000 Z
', '2015-03-05 13:00:40.322614');
INSERT INTO versions VALUES (1981, 'Check', 47, 'create', NULL, NULL, '2015-03-05 13:01:24.101298');
INSERT INTO versions VALUES (1982, 'Person', 493, 'update', NULL, '---
id: 493
salutation: 
name: Héctor
lastnames: López
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 62
created_at: 2015-03-05 12:59:14.380473000 Z
updated_at: 2015-03-05 13:00:16.854244000 Z
', '2015-03-05 13:01:35.866716');
INSERT INTO versions VALUES (1983, 'Person', 493, 'update', NULL, '---
id: 493
salutation: 
name: Héctor
lastnames: López
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 62
created_at: 2015-03-05 12:59:14.380473000 Z
updated_at: 2015-03-05 13:01:35.862148000 Z
', '2015-03-05 13:01:37.755531');
INSERT INTO versions VALUES (1984, 'Person', 178, 'update', NULL, '---
id: 178
salutation: 0
name: ''Pedro ''
lastnames: Castro
sex: true
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 1
created_at: 2015-02-24 14:06:33.867690000 Z
updated_at: 2015-03-02 19:21:13.942482000 Z
', '2015-03-05 13:01:51.772151');
INSERT INTO versions VALUES (1985, 'Person', 493, 'update', NULL, '---
id: 493
salutation: 
name: Héctor
lastnames: López
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 62
created_at: 2015-03-05 12:59:14.380473000 Z
updated_at: 2015-03-05 13:01:37.751863000 Z
', '2015-03-05 13:01:52.107691');
INSERT INTO versions VALUES (1986, 'Person', 178, 'update', NULL, '---
id: 178
salutation: 0
name: ''Pedro ''
lastnames: Castro
sex: true
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 1
created_at: 2015-02-24 14:06:33.867690000 Z
updated_at: 2015-03-05 13:01:51.762840000 Z
', '2015-03-05 13:01:53.066538');
INSERT INTO versions VALUES (1987, 'Person', 493, 'update', NULL, '---
id: 493
salutation: 
name: Héctor
lastnames: López
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 62
created_at: 2015-03-05 12:59:14.380473000 Z
updated_at: 2015-03-05 13:01:52.101180000 Z
', '2015-03-05 13:01:53.185321');
INSERT INTO versions VALUES (1988, 'Person', 498, 'create', NULL, NULL, '2015-03-05 13:02:15.037251');
INSERT INTO versions VALUES (1989, 'Person', 95, 'update', NULL, '---
id: 95
salutation: 
name: ''Maribel ''
lastnames: ''González ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 59
created_at: 2015-02-24 02:25:06.878867000 Z
updated_at: 2015-03-02 19:22:42.638038000 Z
', '2015-03-05 13:02:40.145037');
INSERT INTO versions VALUES (1990, 'Person', 95, 'update', NULL, '---
id: 95
salutation: 
name: ''Maribel ''
lastnames: ''González ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 59
created_at: 2015-02-24 02:25:06.878867000 Z
updated_at: 2015-03-05 13:02:40.135590000 Z
', '2015-03-05 13:02:41.300597');
INSERT INTO versions VALUES (1991, 'Person', 499, 'create', NULL, NULL, '2015-03-05 13:03:09.86753');
INSERT INTO versions VALUES (1992, 'Check', 48, 'create', NULL, NULL, '2015-03-05 13:03:14.67072');
INSERT INTO versions VALUES (1993, 'Person', 68, 'update', NULL, '---
id: 68
salutation: 
name: ''Daniel ''
lastnames: ''Santos ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 36
created_at: 2015-02-24 02:05:58.200172000 Z
updated_at: 2015-03-02 19:21:46.345279000 Z
', '2015-03-05 13:03:16.420903');
INSERT INTO versions VALUES (1994, 'Person', 68, 'update', NULL, '---
id: 68
salutation: 
name: ''Daniel ''
lastnames: ''Santos ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 36
created_at: 2015-02-24 02:05:58.200172000 Z
updated_at: 2015-03-05 13:03:16.412580000 Z
', '2015-03-05 13:03:17.920281');
INSERT INTO versions VALUES (1995, 'Person', 169, 'update', NULL, '---
id: 169
salutation: 
name: ''Sonia ''
lastnames: Lugo
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 20
created_at: 2015-02-24 13:55:28.176248000 Z
updated_at: 2015-03-02 19:22:52.371374000 Z
', '2015-03-05 13:03:20.979794');
INSERT INTO versions VALUES (1996, 'Person', 169, 'update', NULL, '---
id: 169
salutation: 
name: ''Sonia ''
lastnames: Lugo
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 20
created_at: 2015-02-24 13:55:28.176248000 Z
updated_at: 2015-03-05 13:03:20.969856000 Z
', '2015-03-05 13:03:22.075756');
INSERT INTO versions VALUES (1997, 'Person', 25, 'update', NULL, '---
id: 25
salutation: 
name: ''Zoraida ''
lastnames: ''Derieux ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 109
created_at: 2015-02-24 01:28:40.668004000 Z
updated_at: 2015-03-02 19:23:33.229840000 Z
', '2015-03-05 13:03:48.515554');
INSERT INTO versions VALUES (1998, 'Person', 25, 'update', NULL, '---
id: 25
salutation: 
name: ''Zoraida ''
lastnames: ''Derieux ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 109
created_at: 2015-02-24 01:28:40.668004000 Z
updated_at: 2015-03-05 13:03:48.507021000 Z
', '2015-03-05 13:03:49.328623');
INSERT INTO versions VALUES (1999, 'Person', 500, 'create', NULL, NULL, '2015-03-05 13:04:25.480944');
INSERT INTO versions VALUES (2000, 'Person', 41, 'update', NULL, '---
id: 41
salutation: 1
name: ''Joel ''
lastnames: ''Velázquez ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 110
created_at: 2015-02-24 01:49:18.955261000 Z
updated_at: 2015-03-02 19:23:36.779611000 Z
', '2015-03-05 13:04:29.103721');
INSERT INTO versions VALUES (2001, 'Person', 41, 'update', NULL, '---
id: 41
salutation: 1
name: ''Joel ''
lastnames: ''Velázquez ''
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 110
created_at: 2015-02-24 01:49:18.955261000 Z
updated_at: 2015-03-05 13:04:29.092845000 Z
', '2015-03-05 13:04:30.645843');
INSERT INTO versions VALUES (2002, 'Person', 318, 'update', NULL, '---
id: 318
salutation: 
name: ''José M. ''
lastnames: Birriel
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 49
created_at: 2015-03-02 19:33:54.654529000 Z
updated_at: 2015-03-02 19:42:04.799335000 Z
', '2015-03-05 13:04:34.787972');
INSERT INTO versions VALUES (2003, 'Person', 318, 'update', NULL, '---
id: 318
salutation: 
name: ''José M. ''
lastnames: Birriel
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 49
created_at: 2015-03-02 19:33:54.654529000 Z
updated_at: 2015-03-05 13:04:34.778235000 Z
', '2015-03-05 13:04:37.231774');
INSERT INTO versions VALUES (2004, 'Person', 320, 'update', NULL, '---
id: 320
salutation: 
name: ''Ivonne ''
lastnames: Díaz Lombardo
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 49
created_at: 2015-03-02 19:36:14.365341000 Z
updated_at: 2015-03-02 19:42:04.787047000 Z
', '2015-03-05 13:04:45.830484');
INSERT INTO versions VALUES (2005, 'Person', 320, 'update', NULL, '---
id: 320
salutation: 
name: ''Ivonne ''
lastnames: Díaz Lombardo
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 49
created_at: 2015-03-02 19:36:14.365341000 Z
updated_at: 2015-03-05 13:04:45.822303000 Z
', '2015-03-05 13:04:47.360021');
INSERT INTO versions VALUES (2006, 'Person', 319, 'update', NULL, '---
id: 319
salutation: 
name: Lilliam
lastnames: Mas Birriel
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 49
created_at: 2015-03-02 19:34:27.418925000 Z
updated_at: 2015-03-02 19:42:04.807061000 Z
', '2015-03-05 13:04:52.379166');
INSERT INTO versions VALUES (2007, 'Person', 319, 'update', NULL, '---
id: 319
salutation: 
name: Lilliam
lastnames: Mas Birriel
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 49
created_at: 2015-03-02 19:34:27.418925000 Z
updated_at: 2015-03-05 13:04:52.370006000 Z
', '2015-03-05 13:04:55.004997');
INSERT INTO versions VALUES (2008, 'Person', 471, 'update', NULL, '---
id: 471
salutation: 
name: ''José ''
lastnames: Rodríguez Dieppa
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 54
created_at: 2015-03-05 12:27:42.225096000 Z
updated_at: 2015-03-05 12:28:56.038363000 Z
', '2015-03-05 13:05:04.668611');
INSERT INTO versions VALUES (2009, 'Person', 103, 'update', NULL, '---
id: 103
salutation: 
name: ''Samuel ''
lastnames: ''Acevedo ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 52
created_at: 2015-02-24 02:29:30.896712000 Z
updated_at: 2015-03-02 19:22:04.401628000 Z
', '2015-03-05 13:05:11.212968');
INSERT INTO versions VALUES (2010, 'Check', 49, 'create', NULL, NULL, '2015-03-05 13:05:12.622511');
INSERT INTO versions VALUES (2011, 'Person', 103, 'update', NULL, '---
id: 103
salutation: 
name: ''Samuel ''
lastnames: ''Acevedo ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 52
created_at: 2015-02-24 02:29:30.896712000 Z
updated_at: 2015-03-05 13:05:11.203592000 Z
', '2015-03-05 13:05:12.856487');
INSERT INTO versions VALUES (2012, 'Person', 103, 'update', NULL, '---
id: 103
salutation: 
name: ''Samuel ''
lastnames: ''Acevedo ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 52
created_at: 2015-02-24 02:29:30.896712000 Z
updated_at: 2015-03-05 13:05:12.852030000 Z
', '2015-03-05 13:05:18.899586');
INSERT INTO versions VALUES (2019, 'Person', 10, 'update', NULL, '---
id: 10
salutation: 1
name: ''Miriam ''
lastnames: Rodríguez de Gutiérrez
sex: false
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 103
created_at: 2015-02-24 01:17:20.485002000 Z
updated_at: 2015-03-02 19:21:56.762242000 Z
', '2015-03-05 13:05:22.486067');
INSERT INTO versions VALUES (2020, 'Person', 10, 'update', NULL, '---
id: 10
salutation: 1
name: ''Miriam ''
lastnames: Rodríguez de Gutiérrez
sex: false
role: 2
description: ''''
attended: true
printed: true
materials: false
church_id: 103
created_at: 2015-02-24 01:17:20.485002000 Z
updated_at: 2015-03-05 13:05:22.483291000 Z
', '2015-03-05 13:05:23.281336');
INSERT INTO versions VALUES (2021, 'Person', 195, 'update', NULL, '---
id: 195
salutation: 
name: ''Arelys ''
lastnames: Ortiz
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 69
created_at: 2015-02-24 14:34:57.882413000 Z
updated_at: 2015-03-04 20:24:07.595522000 Z
', '2015-03-05 13:05:31.653136');
INSERT INTO versions VALUES (2022, 'Person', 195, 'update', NULL, '---
id: 195
salutation: 
name: ''Arelys ''
lastnames: Ortiz
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 69
created_at: 2015-02-24 14:34:57.882413000 Z
updated_at: 2015-03-05 13:05:31.644005000 Z
', '2015-03-05 13:05:35.499629');
INSERT INTO versions VALUES (2013, 'Person', 491, 'update', NULL, '---
id: 491
salutation: 0
name: María E.
lastnames: García
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 62
created_at: 2015-03-05 12:58:40.007822000 Z
updated_at: 2015-03-05 13:00:05.838076000 Z
', '2015-03-05 13:05:21.247707');
INSERT INTO versions VALUES (2014, 'Person', 496, 'update', NULL, '---
id: 496
salutation: 
name: ''Migdalia ''
lastnames: Rivera
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 28
created_at: 2015-03-05 13:00:09.175655000 Z
updated_at: 2015-03-05 13:00:09.175655000 Z
', '2015-03-05 13:05:21.302346');
INSERT INTO versions VALUES (2015, 'Person', 497, 'update', NULL, '---
id: 497
salutation: 0
name: Victor
lastnames: Monzon
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 28
created_at: 2015-03-05 13:00:37.952783000 Z
updated_at: 2015-03-05 13:00:37.952783000 Z
', '2015-03-05 13:05:21.311923');
INSERT INTO versions VALUES (2016, 'Person', 498, 'update', NULL, '---
id: 498
salutation: 
name: ''Jose M ''
lastnames: carillo
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 43
created_at: 2015-03-05 13:02:15.031993000 Z
updated_at: 2015-03-05 13:02:15.031993000 Z
', '2015-03-05 13:05:21.321477');
INSERT INTO versions VALUES (2017, 'Person', 499, 'update', NULL, '---
id: 499
salutation: 
name: Richard D
lastnames: Braden Feliciano
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 43
created_at: 2015-03-05 13:03:09.861203000 Z
updated_at: 2015-03-05 13:03:09.861203000 Z
', '2015-03-05 13:05:21.331576');
INSERT INTO versions VALUES (2018, 'Person', 500, 'update', NULL, '---
id: 500
salutation: 1
name: Yolanda
lastnames: Ortiz
sex: false
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 35
created_at: 2015-03-05 13:04:25.476127000 Z
updated_at: 2015-03-05 13:04:25.476127000 Z
', '2015-03-05 13:05:21.336284');
INSERT INTO versions VALUES (2036, 'Person', 471, 'update', NULL, '---
id: 471
salutation: 
name: ''José ''
lastnames: Rodríguez Dieppa
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 54
created_at: 2015-03-05 12:27:42.225096000 Z
updated_at: 2015-03-05 13:05:04.664883000 Z
', '2015-03-05 13:07:24.581714');
INSERT INTO versions VALUES (2037, 'Person', 501, 'update', NULL, '---
id: 501
salutation: 
name: Carmín
lastnames: Rodríguez
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 35
created_at: 2015-03-05 13:05:38.226445000 Z
updated_at: 2015-03-05 13:05:38.226445000 Z
', '2015-03-05 13:07:24.689584');
INSERT INTO versions VALUES (2038, 'Person', 195, 'update', NULL, '---
id: 195
salutation: 
name: ''Arelys ''
lastnames: Ortiz
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 69
created_at: 2015-02-24 14:34:57.882413000 Z
updated_at: 2015-03-05 13:05:54.370240000 Z
', '2015-03-05 13:07:24.700151');
INSERT INTO versions VALUES (2039, 'Person', 502, 'update', NULL, '---
id: 502
salutation: 
name: Elizabeth
lastnames: Rodríguez
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 35
created_at: 2015-03-05 13:06:17.438532000 Z
updated_at: 2015-03-05 13:06:17.438532000 Z
', '2015-03-05 13:07:24.70443');
INSERT INTO versions VALUES (2040, 'Person', 503, 'update', NULL, '---
id: 503
salutation: 
name: José
lastnames: Nolasco
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 95
created_at: 2015-03-05 13:07:03.830000000 Z
updated_at: 2015-03-05 13:07:03.830000000 Z
', '2015-03-05 13:07:24.711502');
INSERT INTO versions VALUES (2041, 'Person', 199, 'update', NULL, '---
id: 199
salutation: 
name: ''David ''
lastnames: ''Morales ''
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 69
created_at: 2015-02-24 14:36:58.831092000 Z
updated_at: 2015-03-05 13:07:11.410634000 Z
', '2015-03-05 13:07:24.720228');
INSERT INTO versions VALUES (2060, 'Person', 504, 'update', NULL, '---
id: 504
salutation: 
name: Kenyi
lastnames: Negrón
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 35
created_at: 2015-03-05 13:07:13.613380000 Z
updated_at: 2015-03-05 13:07:13.613380000 Z
', '2015-03-05 13:11:28.340057');
INSERT INTO versions VALUES (2061, 'Person', 505, 'update', NULL, '---
id: 505
salutation: 
name: Rafael
lastnames: Negrón
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 95
created_at: 2015-03-05 13:08:14.657405000 Z
updated_at: 2015-03-05 13:08:14.657405000 Z
', '2015-03-05 13:11:28.417559');
INSERT INTO versions VALUES (2062, 'Person', 506, 'update', NULL, '---
id: 506
salutation: 
name: Leftie
lastnames: Millán
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 95
created_at: 2015-03-05 13:08:52.282620000 Z
updated_at: 2015-03-05 13:08:52.282620000 Z
', '2015-03-05 13:11:28.424729');
INSERT INTO versions VALUES (2063, 'Person', 197, 'update', NULL, '---
id: 197
salutation: 
name: ''Daisy ''
lastnames: García
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 69
created_at: 2015-02-24 14:36:01.266279000 Z
updated_at: 2015-03-05 13:10:11.752926000 Z
', '2015-03-05 13:11:28.433776');
INSERT INTO versions VALUES (2064, 'Person', 507, 'update', NULL, '---
id: 507
salutation: 
name: Neftalí
lastnames: Saldaña
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 23
created_at: 2015-03-05 13:10:34.933910000 Z
updated_at: 2015-03-05 13:10:34.933910000 Z
', '2015-03-05 13:11:28.440518');
INSERT INTO versions VALUES (2065, 'Person', 198, 'update', NULL, '---
id: 198
salutation: 
name: ''Antonio ''
lastnames: Freire
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 69
created_at: 2015-02-24 14:36:33.922822000 Z
updated_at: 2015-03-05 13:11:22.732449000 Z
', '2015-03-05 13:11:28.449567');
INSERT INTO versions VALUES (2098, 'Person', 30, 'update', NULL, '---
id: 30
salutation: 
name: Albertina
lastnames: Camacho
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 12
created_at: 2015-02-24 01:39:31.364703000 Z
updated_at: 2015-03-05 13:11:35.050792000 Z
', '2015-03-05 13:16:32.156079');
INSERT INTO versions VALUES (2099, 'Person', 508, 'update', NULL, '---
id: 508
salutation: 
name: Rafael
lastnames: Dávila
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 126
created_at: 2015-03-05 13:13:04.886243000 Z
updated_at: 2015-03-05 13:13:04.886243000 Z
', '2015-03-05 13:16:32.490513');
INSERT INTO versions VALUES (2101, 'Person', 504, 'update', NULL, '---
id: 504
salutation: 
name: Kenyi
lastnames: Negrón
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 35
created_at: 2015-03-05 13:07:13.613380000 Z
updated_at: 2015-03-05 13:15:16.826170000 Z
', '2015-03-05 13:16:32.889903');
INSERT INTO versions VALUES (2102, 'Person', 505, 'update', NULL, '---
id: 505
salutation: 
name: Rafael
lastnames: Negrón
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 95
created_at: 2015-03-05 13:08:14.657405000 Z
updated_at: 2015-03-05 13:15:25.053128000 Z
', '2015-03-05 13:16:32.906187');
INSERT INTO versions VALUES (2103, 'Person', 506, 'update', NULL, '---
id: 506
salutation: 
name: Leftie
lastnames: Millán
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 95
created_at: 2015-03-05 13:08:52.282620000 Z
updated_at: 2015-03-05 13:15:33.844114000 Z
', '2015-03-05 13:16:32.915744');
INSERT INTO versions VALUES (2104, 'Person', 197, 'update', NULL, '---
id: 197
salutation: 
name: ''Daisy ''
lastnames: García
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 69
created_at: 2015-02-24 14:36:01.266279000 Z
updated_at: 2015-03-05 13:15:45.057414000 Z
', '2015-03-05 13:16:32.927307');
INSERT INTO versions VALUES (2117, 'Person', 507, 'update', NULL, '---
id: 507
salutation: 
name: Neftalí
lastnames: Saldaña
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 23
created_at: 2015-03-05 13:10:34.933910000 Z
updated_at: 2015-03-05 13:15:53.735431000 Z
', '2015-03-05 13:18:37.026553');
INSERT INTO versions VALUES (2118, 'Person', 198, 'update', NULL, '---
id: 198
salutation: 
name: ''Antonio ''
lastnames: Freire
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 69
created_at: 2015-02-24 14:36:33.922822000 Z
updated_at: 2015-03-05 13:16:04.043095000 Z
', '2015-03-05 13:18:37.091148');
INSERT INTO versions VALUES (2025, 'Person', 195, 'update', NULL, '---
id: 195
salutation: 
name: ''Arelys ''
lastnames: Ortiz
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 69
created_at: 2015-02-24 14:34:57.882413000 Z
updated_at: 2015-03-05 13:05:35.490020000 Z
', '2015-03-05 13:05:54.376244');
INSERT INTO versions VALUES (2026, 'Person', 199, 'update', NULL, '---
id: 199
salutation: 
name: ''David ''
lastnames: ''Morales ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 69
created_at: 2015-02-24 14:36:58.831092000 Z
updated_at: 2015-03-04 20:24:07.608823000 Z
', '2015-03-05 13:06:13.092516');
INSERT INTO versions VALUES (2027, 'Person', 199, 'update', NULL, '---
id: 199
salutation: 
name: ''David ''
lastnames: ''Morales ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 69
created_at: 2015-02-24 14:36:58.831092000 Z
updated_at: 2015-03-05 13:06:13.085650000 Z
', '2015-03-05 13:06:14.013781');
INSERT INTO versions VALUES (2028, 'Person', 502, 'create', NULL, NULL, '2015-03-05 13:06:17.44579');
INSERT INTO versions VALUES (2029, 'Person', 296, 'update', NULL, '---
id: 296
salutation: 1
name: ''Félix ''
lastnames: ''López ''
sex: true
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 53
created_at: 2015-02-27 02:44:42.000719000 Z
updated_at: 2015-03-02 19:22:22.360211000 Z
', '2015-03-05 13:06:36.437808');
INSERT INTO versions VALUES (2030, 'Person', 296, 'update', NULL, '---
id: 296
salutation: 1
name: ''Félix ''
lastnames: ''López ''
sex: true
role: 2
description: ''''
attended: true
printed: true
materials: false
church_id: 53
created_at: 2015-02-27 02:44:42.000719000 Z
updated_at: 2015-03-05 13:06:36.430469000 Z
', '2015-03-05 13:06:37.395688');
INSERT INTO versions VALUES (2031, 'Person', 503, 'create', NULL, NULL, '2015-03-05 13:07:03.833588');
INSERT INTO versions VALUES (2032, 'Person', 199, 'update', NULL, '---
id: 199
salutation: 
name: ''David ''
lastnames: ''Morales ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 69
created_at: 2015-02-24 14:36:58.831092000 Z
updated_at: 2015-03-05 13:06:14.004758000 Z
', '2015-03-05 13:07:11.420001');
INSERT INTO versions VALUES (2033, 'Person', 308, 'update', NULL, '---
id: 308
salutation: 
name: Aida B.
lastnames: ''Cruz ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 51
created_at: 2015-03-02 19:26:14.724721000 Z
updated_at: 2015-03-02 19:26:56.654775000 Z
', '2015-03-05 13:07:11.806751');
INSERT INTO versions VALUES (2034, 'Person', 308, 'update', NULL, '---
id: 308
salutation: 
name: Aida B.
lastnames: ''Cruz ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 51
created_at: 2015-03-02 19:26:14.724721000 Z
updated_at: 2015-03-05 13:07:11.802394000 Z
', '2015-03-05 13:07:13.193577');
INSERT INTO versions VALUES (2035, 'Person', 504, 'create', NULL, NULL, '2015-03-05 13:07:13.619167');
INSERT INTO versions VALUES (2042, 'Person', 197, 'update', NULL, '---
id: 197
salutation: 
name: ''Daisy ''
lastnames: García
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 69
created_at: 2015-02-24 14:36:01.266279000 Z
updated_at: 2015-03-04 20:24:07.602654000 Z
', '2015-03-05 13:07:36.415195');
INSERT INTO versions VALUES (2043, 'Person', 197, 'update', NULL, '---
id: 197
salutation: 
name: ''Daisy ''
lastnames: García
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 69
created_at: 2015-02-24 14:36:01.266279000 Z
updated_at: 2015-03-05 13:07:36.405429000 Z
', '2015-03-05 13:07:37.37861');
INSERT INTO versions VALUES (2044, 'Person', 505, 'create', NULL, NULL, '2015-03-05 13:08:14.660187');
INSERT INTO versions VALUES (2045, 'Person', 372, 'update', NULL, '---
id: 372
salutation: 
name: José
lastnames: Candelaria
sex: true
role: 4
description: Tesorero
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:35:09.740009000 Z
updated_at: 2015-03-04 21:29:41.508813000 Z
', '2015-03-05 13:08:19.665082');
INSERT INTO versions VALUES (2046, 'Person', 372, 'update', NULL, '---
id: 372
salutation: 
name: José
lastnames: Candelaria
sex: true
role: 4
description: Tesorero
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:35:09.740009000 Z
updated_at: 2015-03-05 13:08:19.658025000 Z
', '2015-03-05 13:08:20.426355');
INSERT INTO versions VALUES (2047, 'Person', 196, 'update', NULL, '---
id: 196
salutation: 
name: ''Jossie ''
lastnames: Sostre
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 69
created_at: 2015-02-24 14:35:32.238243000 Z
updated_at: 2015-03-04 20:27:11.080616000 Z
', '2015-03-05 13:08:29.133531');
INSERT INTO versions VALUES (2048, 'Person', 196, 'update', NULL, '---
id: 196
salutation: 
name: ''Jossie ''
lastnames: Sostre
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 69
created_at: 2015-02-24 14:35:32.238243000 Z
updated_at: 2015-03-05 13:08:29.125158000 Z
', '2015-03-05 13:08:31.095479');
INSERT INTO versions VALUES (2049, 'Person', 506, 'create', NULL, NULL, '2015-03-05 13:08:52.285763');
INSERT INTO versions VALUES (2050, 'Person', 503, 'update', NULL, '---
id: 503
salutation: 
name: José
lastnames: Nolasco
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 95
created_at: 2015-03-05 13:07:03.830000000 Z
updated_at: 2015-03-05 13:07:24.706236000 Z
', '2015-03-05 13:09:10.809267');
INSERT INTO versions VALUES (2051, 'Person', 503, 'update', NULL, '---
id: 503
salutation: 
name: José
lastnames: Nolasco
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 95
created_at: 2015-03-05 13:07:03.830000000 Z
updated_at: 2015-03-05 13:09:10.801208000 Z
', '2015-03-05 13:09:13.210237');
INSERT INTO versions VALUES (2052, 'Person', 197, 'update', NULL, '---
id: 197
salutation: 
name: ''Daisy ''
lastnames: García
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 69
created_at: 2015-02-24 14:36:01.266279000 Z
updated_at: 2015-03-05 13:07:37.368729000 Z
', '2015-03-05 13:10:11.759961');
INSERT INTO versions VALUES (2053, 'Person', 507, 'create', NULL, NULL, '2015-03-05 13:10:34.93949');
INSERT INTO versions VALUES (2054, 'Person', 198, 'update', NULL, '---
id: 198
salutation: 
name: ''Antonio ''
lastnames: Freire
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 69
created_at: 2015-02-24 14:36:33.922822000 Z
updated_at: 2015-03-02 19:22:32.342910000 Z
', '2015-03-05 13:11:19.637171');
INSERT INTO versions VALUES (2055, 'Person', 198, 'update', NULL, '---
id: 198
salutation: 
name: ''Antonio ''
lastnames: Freire
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 69
created_at: 2015-02-24 14:36:33.922822000 Z
updated_at: 2015-03-05 13:11:19.627277000 Z
', '2015-03-05 13:11:20.837817');
INSERT INTO versions VALUES (2056, 'Person', 138, 'update', NULL, '---
id: 138
salutation: 1
name: ''Carmen C. ''
lastnames: ''Adames ''
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:30:24.198051000 Z
updated_at: 2015-03-02 19:21:20.950539000 Z
', '2015-03-05 13:11:21.974754');
INSERT INTO versions VALUES (2057, 'Person', 198, 'update', NULL, '---
id: 198
salutation: 
name: ''Antonio ''
lastnames: Freire
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 69
created_at: 2015-02-24 14:36:33.922822000 Z
updated_at: 2015-03-05 13:11:20.829565000 Z
', '2015-03-05 13:11:22.741711');
INSERT INTO versions VALUES (2058, 'Person', 138, 'update', NULL, '---
id: 138
salutation: 1
name: ''Carmen C. ''
lastnames: ''Adames ''
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:30:24.198051000 Z
updated_at: 2015-03-05 13:11:21.971157000 Z
', '2015-03-05 13:11:23.301709');
INSERT INTO versions VALUES (2059, 'Person', 30, 'update', NULL, '---
id: 30
salutation: 
name: ''Raquel ''
lastnames: ''Oquendo ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 12
created_at: 2015-02-24 01:39:31.364703000 Z
updated_at: 2015-03-02 19:22:07.747306000 Z
', '2015-03-05 13:11:26.020138');
INSERT INTO versions VALUES (2066, 'Person', 30, 'update', NULL, '---
id: 30
salutation: 
name: Albertina
lastnames: Camacho
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 12
created_at: 2015-02-24 01:39:31.364703000 Z
updated_at: 2015-03-05 13:11:26.011541000 Z
', '2015-03-05 13:11:33.640454');
INSERT INTO versions VALUES (2067, 'Person', 30, 'update', NULL, '---
id: 30
salutation: 
name: Albertina
lastnames: Camacho
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: false
church_id: 12
created_at: 2015-02-24 01:39:31.364703000 Z
updated_at: 2015-03-05 13:11:33.637101000 Z
', '2015-03-05 13:11:35.053649');
INSERT INTO versions VALUES (2068, 'Person', 224, 'update', NULL, '---
id: 224
salutation: 1
name: ''Efrain ''
lastnames: Figueroa
sex: true
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 1
created_at: 2015-02-24 15:01:02.222804000 Z
updated_at: 2015-03-02 19:21:10.286610000 Z
', '2015-03-05 13:11:44.821654');
INSERT INTO versions VALUES (2069, 'Person', 224, 'update', NULL, '---
id: 224
salutation: 1
name: ''Efrain ''
lastnames: Figueroa
sex: true
role: 2
description: ''''
attended: true
printed: true
materials: false
church_id: 1
created_at: 2015-02-24 15:01:02.222804000 Z
updated_at: 2015-03-05 13:11:44.812341000 Z
', '2015-03-05 13:11:46.486518');
INSERT INTO versions VALUES (2070, 'Person', 140, 'update', NULL, '---
id: 140
salutation: 1
name: ''Marilyn ''
lastnames: ''Ortiz ''
sex: true
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:32:32.978955000 Z
updated_at: 2015-03-02 19:21:28.754375000 Z
', '2015-03-05 13:12:10.238741');
INSERT INTO versions VALUES (2071, 'Person', 140, 'update', NULL, '---
id: 140
salutation: 1
name: ''Marilyn ''
lastnames: ''Ortiz ''
sex: true
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:32:32.978955000 Z
updated_at: 2015-03-05 13:12:10.231653000 Z
', '2015-03-05 13:12:12.52145');
INSERT INTO versions VALUES (2072, 'Person', 500, 'update', NULL, '---
id: 500
salutation: 1
name: Yolanda
lastnames: Ortiz
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: true
church_id: 35
created_at: 2015-03-05 13:04:25.476127000 Z
updated_at: 2015-03-05 13:05:21.333725000 Z
', '2015-03-05 13:12:38.782712');
INSERT INTO versions VALUES (2073, 'Check', 50, 'create', NULL, NULL, '2015-03-05 13:13:03.281593');
INSERT INTO versions VALUES (2074, 'Check', 51, 'create', NULL, NULL, '2015-03-05 13:13:03.437741');
INSERT INTO versions VALUES (2075, 'Person', 508, 'create', NULL, NULL, '2015-03-05 13:13:04.892913');
INSERT INTO versions VALUES (2076, 'Person', 291, 'update', NULL, '---
id: 291
salutation: 
name: ''Julio ''
lastnames: Cintrón
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 75
created_at: 2015-02-27 02:36:13.132308000 Z
updated_at: 2015-03-02 19:23:03.374810000 Z
', '2015-03-05 13:13:08.751332');
INSERT INTO versions VALUES (2077, 'Person', 291, 'update', NULL, '---
id: 291
salutation: 
name: ''Julio ''
lastnames: Cintrón
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 75
created_at: 2015-02-27 02:36:13.132308000 Z
updated_at: 2015-03-05 13:13:08.742666000 Z
', '2015-03-05 13:13:10.365448');
INSERT INTO versions VALUES (2078, 'Check', 51, 'destroy', NULL, '---
id: 51
number: 4243
amount: 75.0
description: ''''
church_id: 35
created_at: 2015-03-05 13:13:03.435802000 Z
updated_at: 2015-03-05 13:13:03.435802000 Z
', '2015-03-05 13:13:19.056849');
INSERT INTO versions VALUES (2079, 'Person', 101, 'update', NULL, '---
id: 101
salutation: 1
name: ''Juan ''
lastnames: ''Vergara ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 52
created_at: 2015-02-24 02:28:47.997609000 Z
updated_at: 2015-03-02 19:22:00.410288000 Z
', '2015-03-05 13:13:35.252683');
INSERT INTO versions VALUES (2080, 'Person', 101, 'update', NULL, '---
id: 101
salutation: 1
name: ''Juan ''
lastnames: ''Vergara ''
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 52
created_at: 2015-02-24 02:28:47.997609000 Z
updated_at: 2015-03-05 13:13:35.243036000 Z
', '2015-03-05 13:13:37.207595');
INSERT INTO versions VALUES (2081, 'Person', 119, 'update', NULL, '---
id: 119
salutation: 0
name: ''Blanca ''
lastnames: ''Velázquez ''
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 15
created_at: 2015-02-24 02:39:10.397961000 Z
updated_at: 2015-03-02 19:22:11.159838000 Z
', '2015-03-05 13:14:02.911333');
INSERT INTO versions VALUES (2082, 'Person', 119, 'update', NULL, '---
id: 119
salutation: 0
name: ''Blanca ''
lastnames: ''Velázquez ''
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 15
created_at: 2015-02-24 02:39:10.397961000 Z
updated_at: 2015-03-05 13:14:02.902680000 Z
', '2015-03-05 13:14:04.344783');
INSERT INTO versions VALUES (2083, 'Person', 97, 'update', NULL, '---
id: 97
salutation: 0
name: ''Carmen P. ''
lastnames: ''Pérez ''
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 50
created_at: 2015-02-24 02:26:09.989510000 Z
updated_at: 2015-03-02 19:21:42.458459000 Z
', '2015-03-05 13:14:04.369093');
INSERT INTO versions VALUES (2084, 'Person', 97, 'update', NULL, '---
id: 97
salutation: 0
name: ''Carmen P. ''
lastnames: ''Pérez ''
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 50
created_at: 2015-02-24 02:26:09.989510000 Z
updated_at: 2015-03-05 13:14:04.364475000 Z
', '2015-03-05 13:14:06.922185');
INSERT INTO versions VALUES (2085, 'Person', 231, 'update', NULL, '---
id: 231
salutation: 0
name: ''Celis ''
lastnames: Zambrana Batista
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 45
created_at: 2015-02-24 15:06:14.599552000 Z
updated_at: 2015-03-04 20:34:18.387448000 Z
', '2015-03-05 13:14:43.971324');
INSERT INTO versions VALUES (2086, 'Person', 231, 'update', NULL, '---
id: 231
salutation: 0
name: ''Celis ''
lastnames: Zambrana Batista
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 45
created_at: 2015-02-24 15:06:14.599552000 Z
updated_at: 2015-03-05 13:14:43.964255000 Z
', '2015-03-05 13:14:44.796853');
INSERT INTO versions VALUES (2087, 'Person', 504, 'update', NULL, '---
id: 504
salutation: 
name: Kenyi
lastnames: Negrón
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 35
created_at: 2015-03-05 13:07:13.613380000 Z
updated_at: 2015-03-05 13:11:28.335365000 Z
', '2015-03-05 13:15:16.836975');
INSERT INTO versions VALUES (2088, 'Person', 505, 'update', NULL, '---
id: 505
salutation: 
name: Rafael
lastnames: Negrón
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 95
created_at: 2015-03-05 13:08:14.657405000 Z
updated_at: 2015-03-05 13:11:28.414981000 Z
', '2015-03-05 13:15:25.059356');
INSERT INTO versions VALUES (2089, 'Person', 506, 'update', NULL, '---
id: 506
salutation: 
name: Leftie
lastnames: Millán
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 95
created_at: 2015-03-05 13:08:52.282620000 Z
updated_at: 2015-03-05 13:11:28.422655000 Z
', '2015-03-05 13:15:33.849787');
INSERT INTO versions VALUES (2090, 'Person', 197, 'update', NULL, '---
id: 197
salutation: 
name: ''Daisy ''
lastnames: García
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 69
created_at: 2015-02-24 14:36:01.266279000 Z
updated_at: 2015-03-05 13:11:28.426466000 Z
', '2015-03-05 13:15:45.066426');
INSERT INTO versions VALUES (2091, 'Person', 507, 'update', NULL, '---
id: 507
salutation: 
name: Neftalí
lastnames: Saldaña
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 23
created_at: 2015-03-05 13:10:34.933910000 Z
updated_at: 2015-03-05 13:11:28.435484000 Z
', '2015-03-05 13:15:53.739973');
INSERT INTO versions VALUES (2092, 'Person', 235, 'update', NULL, '---
id: 235
salutation: 
name: ''Luis ''
lastnames: ''Berrios Bones ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 45
created_at: 2015-02-24 15:08:07.300651000 Z
updated_at: 2015-03-02 19:22:19.241886000 Z
', '2015-03-05 13:15:55.141745');
INSERT INTO versions VALUES (2093, 'Person', 235, 'update', NULL, '---
id: 235
salutation: 
name: ''Luis ''
lastnames: ''Berrios Bones ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 45
created_at: 2015-02-24 15:08:07.300651000 Z
updated_at: 2015-03-05 13:15:55.130537000 Z
', '2015-03-05 13:15:56.13257');
INSERT INTO versions VALUES (2094, 'Person', 85, 'update', NULL, '---
id: 85
salutation: 
name: ''Aida I. ''
lastnames: ''López ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:16:06.984407000 Z
updated_at: 2015-03-02 19:20:59.612802000 Z
', '2015-03-05 13:15:57.553286');
INSERT INTO versions VALUES (2095, 'Person', 85, 'update', NULL, '---
id: 85
salutation: 
name: ''Aida I. ''
lastnames: ''López ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:16:06.984407000 Z
updated_at: 2015-03-05 13:15:57.543916000 Z
', '2015-03-05 13:15:58.889739');
INSERT INTO versions VALUES (2096, 'Person', 198, 'update', NULL, '---
id: 198
salutation: 
name: ''Antonio ''
lastnames: Freire
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 69
created_at: 2015-02-24 14:36:33.922822000 Z
updated_at: 2015-03-05 13:11:28.442546000 Z
', '2015-03-05 13:16:04.052697');
INSERT INTO versions VALUES (2097, 'Person', 509, 'create', NULL, NULL, '2015-03-05 13:16:29.511753');
INSERT INTO versions VALUES (2100, 'Person', 199, 'update', NULL, '---
id: 199
salutation: 
name: ''David ''
lastnames: ''Morales ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 69
created_at: 2015-02-24 14:36:58.831092000 Z
updated_at: 2015-03-05 13:07:24.713800000 Z
', '2015-03-05 13:16:32.711357');
INSERT INTO versions VALUES (2105, 'Person', 127, 'update', NULL, '---
id: 127
salutation: 0
name: ''Gladys ''
lastnames: ''Morales ''
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 124
created_at: 2015-02-24 02:45:36.537569000 Z
updated_at: 2015-03-02 19:23:03.359740000 Z
', '2015-03-05 13:16:42.961236');
INSERT INTO versions VALUES (2106, 'Person', 127, 'update', NULL, '---
id: 127
salutation: 0
name: ''Gladys ''
lastnames: ''Morales ''
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 124
created_at: 2015-02-24 02:45:36.537569000 Z
updated_at: 2015-03-05 13:16:42.952689000 Z
', '2015-03-05 13:16:44.111751');
INSERT INTO versions VALUES (2107, 'Person', 510, 'create', NULL, NULL, '2015-03-05 13:16:53.76873');
INSERT INTO versions VALUES (2108, 'Person', 14, 'update', NULL, '---
id: 14
salutation: 
name: ''Pedro ''
lastnames: ''Gely ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 103
created_at: 2015-02-24 01:19:45.854266000 Z
updated_at: 2015-03-02 19:21:56.774038000 Z
', '2015-03-05 13:16:55.141172');
INSERT INTO versions VALUES (2109, 'Person', 14, 'update', NULL, '---
id: 14
salutation: 
name: ''Pedro ''
lastnames: ''Gely ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 103
created_at: 2015-02-24 01:19:45.854266000 Z
updated_at: 2015-03-05 13:16:55.131491000 Z
', '2015-03-05 13:16:58.257526');
INSERT INTO versions VALUES (2110, 'Person', 237, 'update', NULL, '---
id: 237
salutation: 
name: ''Santos ''
lastnames: ''Torres Padilla ''
sex: true
role: 3
description: Sustituto
attended: false
printed: true
materials: false
church_id: 45
created_at: 2015-02-24 15:09:04.911706000 Z
updated_at: 2015-03-02 19:22:19.257221000 Z
', '2015-03-05 13:17:05.766589');
INSERT INTO versions VALUES (2111, 'Person', 237, 'update', NULL, '---
id: 237
salutation: 
name: ''Santos ''
lastnames: ''Torres Padilla ''
sex: true
role: 3
description: Sustituto
attended: true
printed: true
materials: false
church_id: 45
created_at: 2015-02-24 15:09:04.911706000 Z
updated_at: 2015-03-05 13:17:05.759941000 Z
', '2015-03-05 13:17:06.251099');
INSERT INTO versions VALUES (2112, 'Person', 128, 'update', NULL, '---
id: 128
salutation: 
name: ''Margarita ''
lastnames: ''Chico ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 124
created_at: 2015-02-24 02:46:03.776806000 Z
updated_at: 2015-03-02 19:23:03.364465000 Z
', '2015-03-05 13:17:30.756078');
INSERT INTO versions VALUES (2113, 'Person', 128, 'update', NULL, '---
id: 128
salutation: 
name: ''Margarita ''
lastnames: ''Chico ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 124
created_at: 2015-02-24 02:46:03.776806000 Z
updated_at: 2015-03-05 13:17:30.747675000 Z
', '2015-03-05 13:17:31.806187');
INSERT INTO versions VALUES (2114, 'Person', 511, 'create', NULL, NULL, '2015-03-05 13:18:08.431118');
INSERT INTO versions VALUES (2115, 'Person', 295, 'update', NULL, '---
id: 295
salutation: 1
name: ''José A. ''
lastnames: López
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 53
created_at: 2015-02-27 02:44:15.396685000 Z
updated_at: 2015-03-02 19:22:22.586231000 Z
', '2015-03-05 13:18:26.126579');
INSERT INTO versions VALUES (2116, 'Person', 295, 'update', NULL, '---
id: 295
salutation: 1
name: ''José A. ''
lastnames: López
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 53
created_at: 2015-02-27 02:44:15.396685000 Z
updated_at: 2015-03-05 13:18:26.120715000 Z
', '2015-03-05 13:18:27.559552');
INSERT INTO versions VALUES (2123, 'Person', 109, 'update', NULL, '---
id: 109
salutation: 
name: ''Vacilio ''
lastnames: ''Del Valle ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 87
created_at: 2015-02-24 02:33:49.139829000 Z
updated_at: 2015-03-02 19:22:32.305355000 Z
', '2015-03-05 13:18:46.157519');
INSERT INTO versions VALUES (2124, 'Person', 109, 'update', NULL, '---
id: 109
salutation: 
name: ''Vacilio ''
lastnames: ''Del Valle ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 87
created_at: 2015-02-24 02:33:49.139829000 Z
updated_at: 2015-03-05 13:18:46.152969000 Z
', '2015-03-05 13:18:50.89539');
INSERT INTO versions VALUES (2125, 'Person', 275, 'update', NULL, '---
id: 275
salutation: 
name: ''Diana ''
lastnames: Alomar
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 32
created_at: 2015-02-25 13:23:22.911890000 Z
updated_at: 2015-03-02 19:23:38.074162000 Z
', '2015-03-05 13:18:56.609779');
INSERT INTO versions VALUES (2126, 'Person', 275, 'update', NULL, '---
id: 275
salutation: 
name: ''Diana ''
lastnames: Alomar
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 32
created_at: 2015-02-25 13:23:22.911890000 Z
updated_at: 2015-03-05 13:18:56.600648000 Z
', '2015-03-05 13:18:57.57869');
INSERT INTO versions VALUES (2127, 'Person', 129, 'destroy', NULL, '---
id: 129
salutation: 
name: ''Carmen D. ''
lastnames: ''Hernández ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 124
created_at: 2015-02-24 02:46:39.451325000 Z
updated_at: 2015-03-02 19:23:03.341884000 Z
', '2015-03-05 13:19:08.536837');
INSERT INTO versions VALUES (2128, 'Person', 107, 'update', NULL, '---
id: 107
salutation: 0
name: Catalino
lastnames: ''Colón ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 87
created_at: 2015-02-24 02:32:59.759045000 Z
updated_at: 2015-03-02 19:22:30.802463000 Z
', '2015-03-05 13:19:09.953121');
INSERT INTO versions VALUES (2129, 'Person', 107, 'update', NULL, '---
id: 107
salutation: 0
name: Catalino
lastnames: ''Colón ''
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 87
created_at: 2015-02-24 02:32:59.759045000 Z
updated_at: 2015-03-05 13:19:09.944526000 Z
', '2015-03-05 13:19:10.972754');
INSERT INTO versions VALUES (2130, 'Person', 110, 'update', NULL, '---
id: 110
salutation: 
name: ''Wanda ''
lastnames: ''Acevedo ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 87
created_at: 2015-02-24 02:34:06.462161000 Z
updated_at: 2015-03-02 19:22:32.323145000 Z
', '2015-03-05 13:19:14.695846');
INSERT INTO versions VALUES (2131, 'Person', 110, 'update', NULL, '---
id: 110
salutation: 
name: ''Wanda ''
lastnames: ''Acevedo ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 87
created_at: 2015-02-24 02:34:06.462161000 Z
updated_at: 2015-03-05 13:19:14.686862000 Z
', '2015-03-05 13:19:15.772341');
INSERT INTO versions VALUES (2132, 'Person', 110, 'update', NULL, '---
id: 110
salutation: 
name: ''Wanda ''
lastnames: ''Acevedo ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 87
created_at: 2015-02-24 02:34:06.462161000 Z
updated_at: 2015-03-05 13:19:15.763060000 Z
', '2015-03-05 13:19:18.638444');
INSERT INTO versions VALUES (2133, 'Person', 110, 'update', NULL, '---
id: 110
salutation: 
name: ''Wanda ''
lastnames: ''Acevedo ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 87
created_at: 2015-02-24 02:34:06.462161000 Z
updated_at: 2015-03-05 13:19:18.630587000 Z
', '2015-03-05 13:19:19.667933');
INSERT INTO versions VALUES (2134, 'Person', 512, 'create', NULL, NULL, '2015-03-05 13:19:21.788337');
INSERT INTO versions VALUES (2135, 'Person', 195, 'update', NULL, '---
id: 195
salutation: 
name: ''Arelys ''
lastnames: Ortiz
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 69
created_at: 2015-02-24 14:34:57.882413000 Z
updated_at: 2015-03-05 13:07:24.692390000 Z
', '2015-03-05 13:19:23.862026');
INSERT INTO versions VALUES (2136, 'Person', 22, 'update', NULL, '---
id: 22
salutation: 0
name: ''Laura ''
lastnames: ''Ayala ''
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 109
created_at: 2015-02-24 01:27:13.149274000 Z
updated_at: 2015-03-02 19:23:33.204489000 Z
', '2015-03-05 13:19:26.785177');
INSERT INTO versions VALUES (2119, 'Person', 509, 'update', NULL, '---
id: 509
salutation: 
name: Eli Samuel
lastnames: Morales
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 53
created_at: 2015-03-05 13:16:29.505474000 Z
updated_at: 2015-03-05 13:16:29.505474000 Z
', '2015-03-05 13:18:37.100693');
INSERT INTO versions VALUES (2120, 'Person', 199, 'update', NULL, '---
id: 199
salutation: 
name: ''David ''
lastnames: ''Morales ''
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 69
created_at: 2015-02-24 14:36:58.831092000 Z
updated_at: 2015-03-05 13:16:32.704230000 Z
', '2015-03-05 13:18:37.107182');
INSERT INTO versions VALUES (2121, 'Person', 510, 'update', NULL, '---
id: 510
salutation: 
name: Priscila
lastnames: Morales
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 53
created_at: 2015-03-05 13:16:53.763294000 Z
updated_at: 2015-03-05 13:16:53.763294000 Z
', '2015-03-05 13:18:37.116672');
INSERT INTO versions VALUES (2122, 'Person', 511, 'update', NULL, '---
id: 511
salutation: 
name: Josue
lastnames: Gonzalez
sex: true
role: 5
description: ''''
attended: true
printed: false
materials: true
church_id: 45
created_at: 2015-03-05 13:18:08.428148000 Z
updated_at: 2015-03-05 13:18:08.428148000 Z
', '2015-03-05 13:18:37.121552');
INSERT INTO versions VALUES (2182, 'Person', 512, 'update', NULL, '---
id: 512
salutation: 1
name: Kemley
lastnames: Rhodes
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 9
created_at: 2015-03-05 13:19:21.784568000 Z
updated_at: 2015-03-05 13:19:21.784568000 Z
', '2015-03-05 13:27:41.035503');
INSERT INTO versions VALUES (2183, 'Person', 195, 'update', NULL, '---
id: 195
salutation: 
name: ''Arelys ''
lastnames: Ortiz
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 69
created_at: 2015-02-24 14:34:57.882413000 Z
updated_at: 2015-03-05 13:19:23.855685000 Z
', '2015-03-05 13:27:41.283252');
INSERT INTO versions VALUES (2184, 'Person', 274, 'update', NULL, '---
id: 274
salutation: 
name: Ramonita
lastnames: Martinez
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 32
created_at: 2015-02-25 13:22:58.907116000 Z
updated_at: 2015-03-05 13:22:40.324330000 Z
', '2015-03-05 13:27:41.665123');
INSERT INTO versions VALUES (2185, 'Person', 306, 'update', NULL, '---
id: 306
salutation: 
name: ''Lymaris ''
lastnames: Diaz
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 90
created_at: 2015-03-02 19:22:26.869249000 Z
updated_at: 2015-03-05 13:23:33.541427000 Z
', '2015-03-05 13:27:41.675781');
INSERT INTO versions VALUES (2186, 'Person', 513, 'update', NULL, '---
id: 513
salutation: 
name: Wilfredo
lastnames: Morales, CPA
sex: true
role: 5
description: Mision Bautista Kissimmee
attended: true
printed: false
materials: true
church_id: 
created_at: 2015-03-05 13:25:32.452347000 Z
updated_at: 2015-03-05 13:26:42.756606000 Z
', '2015-03-05 13:27:41.68328');
INSERT INTO versions VALUES (2187, 'Person', 514, 'update', NULL, '---
id: 514
salutation: 
name: Ana N.
lastnames: Montañez
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 111
created_at: 2015-03-05 13:26:47.165493000 Z
updated_at: 2015-03-05 13:26:47.165493000 Z
', '2015-03-05 13:27:41.687096');
INSERT INTO versions VALUES (2137, 'Person', 22, 'update', NULL, '---
id: 22
salutation: 0
name: ''Laura ''
lastnames: ''Ayala ''
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 109
created_at: 2015-02-24 01:27:13.149274000 Z
updated_at: 2015-03-05 13:19:26.776776000 Z
', '2015-03-05 13:19:28.749165');
INSERT INTO versions VALUES (2138, 'Person', 26, 'update', NULL, '---
id: 26
salutation: 
name: ''José D. ''
lastnames: Colón
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 109
created_at: 2015-02-24 01:29:09.930154000 Z
updated_at: 2015-03-02 19:23:32.666970000 Z
', '2015-03-05 13:19:30.078555');
INSERT INTO versions VALUES (2139, 'Person', 26, 'update', NULL, '---
id: 26
salutation: 
name: ''José D. ''
lastnames: Colón
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 109
created_at: 2015-02-24 01:29:09.930154000 Z
updated_at: 2015-03-05 13:19:30.075507000 Z
', '2015-03-05 13:19:31.512037');
INSERT INTO versions VALUES (2140, 'Check', 52, 'create', NULL, NULL, '2015-03-05 13:20:44.029443');
INSERT INTO versions VALUES (2141, 'Person', 217, 'update', NULL, '---
id: 217
salutation: 0
name: Abraham
lastnames: ''Morales ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 21
created_at: 2015-02-24 14:51:21.886829000 Z
updated_at: 2015-03-02 19:23:13.826165000 Z
', '2015-03-05 13:21:02.52775');
INSERT INTO versions VALUES (2142, 'Person', 217, 'update', NULL, '---
id: 217
salutation: 0
name: Abraham
lastnames: ''Morales ''
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 21
created_at: 2015-02-24 14:51:21.886829000 Z
updated_at: 2015-03-05 13:21:02.525162000 Z
', '2015-03-05 13:21:04.012583');
INSERT INTO versions VALUES (2143, 'Person', 276, 'update', NULL, '---
id: 276
salutation: 
name: Efraín
lastnames: ''Dávila ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 32
created_at: 2015-02-25 13:23:47.195972000 Z
updated_at: 2015-03-02 19:23:38.088581000 Z
', '2015-03-05 13:21:20.582377');
INSERT INTO versions VALUES (2144, 'Person', 276, 'update', NULL, '---
id: 276
salutation: 
name: Efraín
lastnames: ''Dávila ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 32
created_at: 2015-02-25 13:23:47.195972000 Z
updated_at: 2015-03-05 13:21:20.573499000 Z
', '2015-03-05 13:21:21.703138');
INSERT INTO versions VALUES (2145, 'Person', 218, 'update', NULL, '---
id: 218
salutation: 
name: ''Johnny ''
lastnames: Rivera
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 21
created_at: 2015-02-24 14:51:45.799248000 Z
updated_at: 2015-03-02 19:23:13.843973000 Z
', '2015-03-05 13:21:53.344087');
INSERT INTO versions VALUES (2146, 'Person', 218, 'update', NULL, '---
id: 218
salutation: 
name: ''Johnny ''
lastnames: Rivera
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 21
created_at: 2015-02-24 14:51:45.799248000 Z
updated_at: 2015-03-05 13:21:53.335414000 Z
', '2015-03-05 13:21:55.513616');
INSERT INTO versions VALUES (2147, 'Person', 274, 'update', NULL, '---
id: 274
salutation: 
name: ''María ''
lastnames: Benitez
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 32
created_at: 2015-02-25 13:22:58.907116000 Z
updated_at: 2015-03-02 19:23:38.094947000 Z
', '2015-03-05 13:22:05.273876');
INSERT INTO versions VALUES (2148, 'Person', 7, 'update', NULL, '---
id: 7
salutation: 
name: ''Yamalis ''
lastnames: ''González ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 105
created_at: 2015-02-23 22:26:10.392410000 Z
updated_at: 2015-03-04 20:30:14.989284000 Z
', '2015-03-05 13:22:17.734254');
INSERT INTO versions VALUES (2149, 'Person', 7, 'update', NULL, '---
id: 7
salutation: 
name: ''Yamalis ''
lastnames: ''González ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 105
created_at: 2015-02-23 22:26:10.392410000 Z
updated_at: 2015-03-05 13:22:17.727662000 Z
', '2015-03-05 13:22:18.771235');
INSERT INTO versions VALUES (2150, 'Person', 274, 'update', NULL, '---
id: 274
salutation: 
name: Ramonita
lastnames: Martinez
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 32
created_at: 2015-02-25 13:22:58.907116000 Z
updated_at: 2015-03-05 13:22:05.269137000 Z
', '2015-03-05 13:22:19.251353');
INSERT INTO versions VALUES (2151, 'Person', 274, 'update', NULL, '---
id: 274
salutation: 
name: Ramonita
lastnames: Martinez
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 32
created_at: 2015-02-25 13:22:58.907116000 Z
updated_at: 2015-03-05 13:22:19.243305000 Z
', '2015-03-05 13:22:19.718488');
INSERT INTO versions VALUES (2152, 'Person', 274, 'update', NULL, '---
id: 274
salutation: 
name: Ramonita
lastnames: Martinez
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 32
created_at: 2015-02-25 13:22:58.907116000 Z
updated_at: 2015-03-05 13:22:19.710038000 Z
', '2015-03-05 13:22:40.334175');
INSERT INTO versions VALUES (2153, 'Check', 53, 'create', NULL, NULL, '2015-03-05 13:23:08.723208');
INSERT INTO versions VALUES (2154, 'Person', 273, 'update', NULL, '---
id: 273
salutation: 0
name: ''Rolando ''
lastnames: ''Pabellón ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 32
created_at: 2015-02-25 13:22:35.132459000 Z
updated_at: 2015-03-02 19:23:38.101171000 Z
', '2015-03-05 13:23:14.513721');
INSERT INTO versions VALUES (2155, 'Person', 273, 'update', NULL, '---
id: 273
salutation: 0
name: ''Rolando ''
lastnames: ''Pabellón ''
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 32
created_at: 2015-02-25 13:22:35.132459000 Z
updated_at: 2015-03-05 13:23:14.504260000 Z
', '2015-03-05 13:23:15.600113');
INSERT INTO versions VALUES (2156, 'Person', 306, 'update', NULL, '---
id: 306
salutation: 
name: ''Leynaris ''
lastnames: Diaz
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 90
created_at: 2015-03-02 19:22:26.869249000 Z
updated_at: 2015-03-02 19:26:56.930039000 Z
', '2015-03-05 13:23:28.651674');
INSERT INTO versions VALUES (2157, 'Person', 299, 'update', NULL, '---
id: 299
salutation: 
name: ''Isabel ''
lastnames: ''Calderón ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 53
created_at: 2015-02-27 02:46:30.932917000 Z
updated_at: 2015-03-02 19:22:22.568483000 Z
', '2015-03-05 13:23:32.67951');
INSERT INTO versions VALUES (2158, 'Check', 54, 'create', NULL, NULL, '2015-03-05 13:23:33.062948');
INSERT INTO versions VALUES (2159, 'Person', 306, 'update', NULL, '---
id: 306
salutation: 
name: ''Lymaris ''
lastnames: Diaz
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 90
created_at: 2015-03-02 19:22:26.869249000 Z
updated_at: 2015-03-05 13:23:28.642072000 Z
', '2015-03-05 13:23:33.550802');
INSERT INTO versions VALUES (2160, 'Person', 299, 'update', NULL, '---
id: 299
salutation: 
name: ''Isabel ''
lastnames: ''Calderón ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 53
created_at: 2015-02-27 02:46:30.932917000 Z
updated_at: 2015-03-05 13:23:32.675681000 Z
', '2015-03-05 13:23:55.663316');
INSERT INTO versions VALUES (2161, 'Person', 141, 'update', NULL, '---
id: 141
salutation: 1
name: ''María E. ''
lastnames: ''Calderón ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:33:33.087962000 Z
updated_at: 2015-03-02 19:21:28.739718000 Z
', '2015-03-05 13:24:13.284777');
INSERT INTO versions VALUES (2162, 'Person', 141, 'update', NULL, '---
id: 141
salutation: 1
name: ''María E. ''
lastnames: ''Calderón ''
sex: false
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:33:33.087962000 Z
updated_at: 2015-03-05 13:24:13.275477000 Z
', '2015-03-05 13:24:14.140386');
INSERT INTO versions VALUES (2163, 'Person', 330, 'update', NULL, '---
id: 330
salutation: 1
name: ''David ''
lastnames: Casillas
sex: true
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 108
created_at: 2015-03-02 19:48:26.897330000 Z
updated_at: 2015-03-02 20:00:16.016850000 Z
', '2015-03-05 13:24:52.199824');
INSERT INTO versions VALUES (2164, 'Person', 330, 'update', NULL, '---
id: 330
salutation: 1
name: ''David ''
lastnames: Casillas
sex: true
role: 2
description: ''''
attended: false
printed: true
materials: true
church_id: 108
created_at: 2015-03-02 19:48:26.897330000 Z
updated_at: 2015-03-05 13:24:52.190054000 Z
', '2015-03-05 13:24:53.688983');
INSERT INTO versions VALUES (2165, 'Person', 154, 'update', NULL, '---
id: 154
salutation: 1
name: ''Madelyn ''
lastnames: Figueroa Alamo
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:30:40.268446000 Z
updated_at: 2015-03-02 19:21:24.695753000 Z
', '2015-03-05 13:25:09.140713');
INSERT INTO versions VALUES (2166, 'Person', 154, 'update', NULL, '---
id: 154
salutation: 1
name: ''Madelyn ''
lastnames: Figueroa Alamo
sex: false
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:30:40.268446000 Z
updated_at: 2015-03-05 13:25:09.130780000 Z
', '2015-03-05 13:25:10.798453');
INSERT INTO versions VALUES (2167, 'Person', 108, 'destroy', NULL, '---
id: 108
salutation: 
name: ''Heriberto ''
lastnames: ''Del Valle ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 87
created_at: 2015-02-24 02:33:19.629444000 Z
updated_at: 2015-03-02 19:22:30.908968000 Z
', '2015-03-05 13:25:27.963284');
INSERT INTO versions VALUES (2168, 'Person', 513, 'create', NULL, NULL, '2015-03-05 13:25:32.456519');
INSERT INTO versions VALUES (2169, 'Person', 91, 'update', NULL, '---
id: 91
salutation: 1
name: ''Edwin ''
lastnames: ''Rivera ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 14
created_at: 2015-02-24 02:22:48.675203000 Z
updated_at: 2015-03-02 19:21:03.421634000 Z
', '2015-03-05 13:25:33.313677');
INSERT INTO versions VALUES (2170, 'Person', 91, 'update', NULL, '---
id: 91
salutation: 1
name: ''Edwin ''
lastnames: ''Rivera ''
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 14
created_at: 2015-02-24 02:22:48.675203000 Z
updated_at: 2015-03-05 13:25:33.306146000 Z
', '2015-03-05 13:25:34.404971');
INSERT INTO versions VALUES (2171, 'Check', 55, 'create', NULL, NULL, '2015-03-05 13:25:44.631621');
INSERT INTO versions VALUES (2172, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-03-02 19:21:17.596458000 Z
', '2015-03-05 13:25:47.489551');
INSERT INTO versions VALUES (2173, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-03-05 13:25:47.478414000 Z
', '2015-03-05 13:25:49.394675');
INSERT INTO versions VALUES (2174, 'Person', 163, 'update', NULL, '---
id: 163
salutation: 
name: ''Neris ''
lastnames: ''Carrasquillo ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 26
created_at: 2015-02-24 13:50:59.036800000 Z
updated_at: 2015-03-02 19:21:39.293358000 Z
', '2015-03-05 13:26:19.477949');
INSERT INTO versions VALUES (2175, 'Person', 163, 'update', NULL, '---
id: 163
salutation: 
name: ''Neris ''
lastnames: ''Carrasquillo ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 26
created_at: 2015-02-24 13:50:59.036800000 Z
updated_at: 2015-03-05 13:26:19.468318000 Z
', '2015-03-05 13:26:20.68784');
INSERT INTO versions VALUES (2176, 'Person', 513, 'update', NULL, '---
id: 513
salutation: 
name: Wilfredo
lastnames: Morales
sex: true
role: 5
description: Mision Bautista Kissimmee
attended: true
printed: false
materials: true
church_id: 
created_at: 2015-03-05 13:25:32.452347000 Z
updated_at: 2015-03-05 13:25:32.452347000 Z
', '2015-03-05 13:26:42.761082');
INSERT INTO versions VALUES (2177, 'Person', 514, 'create', NULL, NULL, '2015-03-05 13:26:47.168035');
INSERT INTO versions VALUES (2178, 'Person', 515, 'create', NULL, NULL, '2015-03-05 13:26:48.838478');
INSERT INTO versions VALUES (2179, 'Person', 516, 'create', NULL, NULL, '2015-03-05 13:27:24.218707');
INSERT INTO versions VALUES (2180, 'Person', 517, 'create', NULL, NULL, '2015-03-05 13:27:26.388705');
INSERT INTO versions VALUES (2181, 'Person', 513, 'update', NULL, '---
id: 513
salutation: 
name: Wilfredo
lastnames: Morales, CPA
sex: true
role: 5
description: Mision Bautista Kissimmee
attended: true
printed: false
materials: true
church_id: 
created_at: 2015-03-05 13:25:32.452347000 Z
updated_at: 2015-03-05 13:26:42.756606000 Z
', '2015-03-05 13:27:40.43574');
INSERT INTO versions VALUES (2188, 'Person', 201, 'update', NULL, '---
id: 201
salutation: 0
name: ''Susana ''
lastnames: ''Rivera ''
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 67
created_at: 2015-02-24 14:39:41.628178000 Z
updated_at: 2015-03-02 19:22:47.455702000 Z
', '2015-03-05 13:27:44.295426');
INSERT INTO versions VALUES (2189, 'Person', 201, 'update', NULL, '---
id: 201
salutation: 0
name: ''Susana ''
lastnames: ''Rivera ''
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 67
created_at: 2015-02-24 14:39:41.628178000 Z
updated_at: 2015-03-05 13:27:44.286254000 Z
', '2015-03-05 13:27:45.670807');
INSERT INTO versions VALUES (2190, 'Person', 317, 'update', NULL, '---
id: 317
salutation: 1
name: ''Miladys ''
lastnames: Oliveras
sex: false
role: 4
description: Representante Distrito
attended: false
printed: true
materials: false
church_id: 49
created_at: 2015-03-02 19:33:26.920211000 Z
updated_at: 2015-03-04 20:22:03.702181000 Z
', '2015-03-05 13:27:53.878569');
INSERT INTO versions VALUES (2191, 'Person', 317, 'update', NULL, '---
id: 317
salutation: 1
name: ''Miladys ''
lastnames: Oliveras
sex: false
role: 4
description: Representante Distrito
attended: true
printed: true
materials: false
church_id: 49
created_at: 2015-03-02 19:33:26.920211000 Z
updated_at: 2015-03-05 13:27:53.869269000 Z
', '2015-03-05 13:27:55.111686');
INSERT INTO versions VALUES (2192, 'Person', 98, 'update', NULL, '---
id: 98
salutation: 0
name: ''Emma ''
lastnames: ''Méndez ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 50
created_at: 2015-02-24 02:26:31.869154000 Z
updated_at: 2015-03-02 19:21:42.465988000 Z
', '2015-03-05 13:27:56.590815');
INSERT INTO versions VALUES (2193, 'Person', 98, 'update', NULL, '---
id: 98
salutation: 0
name: ''Emma ''
lastnames: ''Méndez ''
sex: false
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 50
created_at: 2015-02-24 02:26:31.869154000 Z
updated_at: 2015-03-05 13:27:56.581524000 Z
', '2015-03-05 13:27:57.667085');
INSERT INTO versions VALUES (2194, 'Person', 331, 'update', NULL, '---
id: 331
salutation: 0
name: ''Marcela ''
lastnames: Ortíz
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 91
created_at: 2015-03-02 19:51:47.102612000 Z
updated_at: 2015-03-02 19:53:12.538427000 Z
', '2015-03-05 13:28:20.552081');
INSERT INTO versions VALUES (2195, 'Person', 331, 'update', NULL, '---
id: 331
salutation: 0
name: ''Marcela ''
lastnames: Ortíz
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 91
created_at: 2015-03-02 19:51:47.102612000 Z
updated_at: 2015-03-05 13:28:20.543694000 Z
', '2015-03-05 13:28:21.501022');
INSERT INTO versions VALUES (2196, 'Check', 56, 'create', NULL, NULL, '2015-03-05 13:28:24.730182');
INSERT INTO versions VALUES (2197, 'Person', 332, 'update', NULL, '---
id: 332
salutation: 0
name: ''Julio ''
lastnames: Graciani
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 91
created_at: 2015-03-02 19:52:12.063683000 Z
updated_at: 2015-03-02 19:53:12.491896000 Z
', '2015-03-05 13:28:32.742599');
INSERT INTO versions VALUES (2198, 'Person', 332, 'update', NULL, '---
id: 332
salutation: 0
name: ''Julio ''
lastnames: Graciani
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 91
created_at: 2015-03-02 19:52:12.063683000 Z
updated_at: 2015-03-05 13:28:32.733548000 Z
', '2015-03-05 13:28:33.846011');
INSERT INTO versions VALUES (2199, 'Person', 518, 'create', NULL, NULL, '2015-03-05 13:28:35.207828');
INSERT INTO versions VALUES (2200, 'Person', 378, 'update', NULL, '---
id: 378
salutation: 1
name: Julio
lastnames: Gónzalez
sex: true
role: 4
description: Vocal
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:39:38.442108000 Z
updated_at: 2015-03-04 21:30:59.787933000 Z
', '2015-03-05 13:28:48.4307');
INSERT INTO versions VALUES (2201, 'Person', 378, 'update', NULL, '---
id: 378
salutation: 1
name: Julio
lastnames: Gónzalez
sex: true
role: 4
description: Vocal
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:39:38.442108000 Z
updated_at: 2015-03-05 13:28:48.423926000 Z
', '2015-03-05 13:28:50.062613');
INSERT INTO versions VALUES (2202, 'Person', 220, 'update', NULL, '---
id: 220
salutation: 0
name: ''Elsa ''
lastnames: ''Rivera Martínez ''
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 68
created_at: 2015-02-24 14:54:01.686913000 Z
updated_at: 2015-03-02 19:23:41.373009000 Z
', '2015-03-05 13:29:02.543411');
INSERT INTO versions VALUES (2203, 'Person', 220, 'update', NULL, '---
id: 220
salutation: 0
name: ''Elsa ''
lastnames: ''Rivera Martínez ''
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 68
created_at: 2015-02-24 14:54:01.686913000 Z
updated_at: 2015-03-05 13:29:02.538025000 Z
', '2015-03-05 13:29:04.602085');
INSERT INTO versions VALUES (2204, 'Person', 20, 'update', NULL, '---
id: 20
salutation: 
name: ''Samuel ''
lastnames: Encarnación
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 3
created_at: 2015-02-24 01:26:07.105439000 Z
updated_at: 2015-03-02 19:22:00.404640000 Z
', '2015-03-05 13:29:07.742598');
INSERT INTO versions VALUES (2205, 'Person', 20, 'update', NULL, '---
id: 20
salutation: 
name: ''Samuel ''
lastnames: Encarnación
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 3
created_at: 2015-02-24 01:26:07.105439000 Z
updated_at: 2015-03-05 13:29:07.735011000 Z
', '2015-03-05 13:29:08.706832');
INSERT INTO versions VALUES (2206, 'Person', 493, 'update', NULL, '---
id: 493
salutation: 
name: Héctor
lastnames: López
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 62
created_at: 2015-03-05 12:59:14.380473000 Z
updated_at: 2015-03-05 13:01:53.179321000 Z
', '2015-03-05 13:29:26.043707');
INSERT INTO versions VALUES (2207, 'Person', 493, 'update', NULL, '---
id: 493
salutation: 
name: Héctor
lastnames: López
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 62
created_at: 2015-03-05 12:59:14.380473000 Z
updated_at: 2015-03-05 13:29:26.038703000 Z
', '2015-03-05 13:29:29.244851');
INSERT INTO versions VALUES (2208, 'Check', 57, 'create', NULL, NULL, '2015-03-05 13:29:52.496869');
INSERT INTO versions VALUES (2209, 'Person', 221, 'update', NULL, '---
id: 221
salutation: 
name: ''Lained ''
lastnames: ''Bonano ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 68
created_at: 2015-02-24 14:55:06.388086000 Z
updated_at: 2015-03-02 19:23:41.378443000 Z
', '2015-03-05 13:29:59.233775');
INSERT INTO versions VALUES (2210, 'Person', 221, 'update', NULL, '---
id: 221
salutation: 
name: ''Lained ''
lastnames: ''Bonano ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 68
created_at: 2015-02-24 14:55:06.388086000 Z
updated_at: 2015-03-05 13:29:59.225237000 Z
', '2015-03-05 13:30:00.645897');
INSERT INTO versions VALUES (2211, 'Person', 222, 'update', NULL, '---
id: 222
salutation: 
name: ''María ''
lastnames: Viera
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 68
created_at: 2015-02-24 14:56:17.092857000 Z
updated_at: 2015-03-02 20:01:51.746217000 Z
', '2015-03-05 13:30:03.94271');
INSERT INTO versions VALUES (2212, 'Person', 222, 'update', NULL, '---
id: 222
salutation: 
name: ''María ''
lastnames: Viera
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 68
created_at: 2015-02-24 14:56:17.092857000 Z
updated_at: 2015-03-05 13:30:03.933203000 Z
', '2015-03-05 13:30:04.866279');
INSERT INTO versions VALUES (2213, 'Person', 222, 'update', NULL, '---
id: 222
salutation: 
name: ''María ''
lastnames: Viera
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 68
created_at: 2015-02-24 14:56:17.092857000 Z
updated_at: 2015-03-05 13:30:04.858071000 Z
', '2015-03-05 13:30:55.800062');
INSERT INTO versions VALUES (2214, 'Person', 483, 'update', NULL, '---
id: 483
salutation: 
name: ''Clarissa ''
lastnames: Santiago
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 92
created_at: 2015-03-05 12:38:05.332101000 Z
updated_at: 2015-03-05 12:43:08.638647000 Z
', '2015-03-05 13:31:15.434904');
INSERT INTO versions VALUES (2215, 'Person', 483, 'update', NULL, '---
id: 483
salutation: 
name: Luis
lastnames: Feliborty
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 92
created_at: 2015-03-05 12:38:05.332101000 Z
updated_at: 2015-03-05 13:31:15.426998000 Z
', '2015-03-05 13:31:21.630067');
INSERT INTO versions VALUES (2216, 'Person', 519, 'create', NULL, NULL, '2015-03-05 13:31:24.923669');
INSERT INTO versions VALUES (2217, 'Person', 515, 'update', NULL, '---
id: 515
salutation: 
name: Jose A.
lastnames: Sanabria
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 77
created_at: 2015-03-05 13:26:48.833022000 Z
updated_at: 2015-03-05 13:26:48.833022000 Z
', '2015-03-05 13:31:45.103961');
INSERT INTO versions VALUES (2218, 'Person', 516, 'update', NULL, '---
id: 516
salutation: 
name: Rebecca
lastnames: Morales
sex: false
role: 5
description: Misión Bautista Kissimme
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-05 13:27:24.216283000 Z
updated_at: 2015-03-05 13:27:24.216283000 Z
', '2015-03-05 13:31:45.134832');
INSERT INTO versions VALUES (2219, 'Person', 517, 'update', NULL, '---
id: 517
salutation: 
name: Jose
lastnames: Tricoche
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 77
created_at: 2015-03-05 13:27:26.382803000 Z
updated_at: 2015-03-05 13:27:26.382803000 Z
', '2015-03-05 13:31:45.142188');
INSERT INTO versions VALUES (2220, 'Person', 518, 'update', NULL, '---
id: 518
salutation: 
name: Daysi
lastnames: Crespo Ramos
sex: false
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 111
created_at: 2015-03-05 13:28:35.201341000 Z
updated_at: 2015-03-05 13:28:35.201341000 Z
', '2015-03-05 13:31:45.149162');
INSERT INTO versions VALUES (2221, 'Person', 222, 'update', NULL, '---
id: 222
salutation: 
name: ''María ''
lastnames: Viera
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 68
created_at: 2015-02-24 14:56:17.092857000 Z
updated_at: 2015-03-05 13:30:55.791682000 Z
', '2015-03-05 13:31:45.156623');
INSERT INTO versions VALUES (2222, 'Person', 483, 'update', NULL, '---
id: 483
salutation: 
name: Luis
lastnames: Feliborty
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 92
created_at: 2015-03-05 12:38:05.332101000 Z
updated_at: 2015-03-05 13:31:21.620892000 Z
', '2015-03-05 13:31:45.162505');
INSERT INTO versions VALUES (2223, 'Person', 520, 'create', NULL, NULL, '2015-03-05 13:31:51.843065');
INSERT INTO versions VALUES (2224, 'Person', 177, 'update', NULL, '---
id: 177
salutation: 1
name: ''Irma ''
lastnames: ''Pastrana ''
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 1
created_at: 2015-02-24 14:06:06.140412000 Z
updated_at: 2015-03-02 19:21:10.304336000 Z
', '2015-03-05 13:32:04.51501');
INSERT INTO versions VALUES (2225, 'Person', 177, 'update', NULL, '---
id: 177
salutation: 1
name: ''Irma ''
lastnames: ''Pastrana ''
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 1
created_at: 2015-02-24 14:06:06.140412000 Z
updated_at: 2015-03-05 13:32:04.505777000 Z
', '2015-03-05 13:32:05.789677');
INSERT INTO versions VALUES (2226, 'Person', 521, 'create', NULL, NULL, '2015-03-05 13:32:15.251987');
INSERT INTO versions VALUES (2227, 'Person', 436, 'update', NULL, '---
id: 436
salutation: 0
name: Mercedes
lastnames: Ortiz
sex: false
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:03:38.673185000 Z
updated_at: 2015-03-04 20:09:49.606200000 Z
', '2015-03-05 13:32:23.437586');
INSERT INTO versions VALUES (2228, 'Person', 436, 'update', NULL, '---
id: 436
salutation: 0
name: Mercedes
lastnames: Ortiz
sex: false
role: 2
description: ''''
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:03:38.673185000 Z
updated_at: 2015-03-05 13:32:23.429234000 Z
', '2015-03-05 13:32:25.167948');
INSERT INTO versions VALUES (2229, 'Person', 180, 'update', NULL, '---
id: 180
salutation: 
name: ''Aida I. ''
lastnames: Torres
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 1
created_at: 2015-02-24 14:08:52.759995000 Z
updated_at: 2015-03-02 19:21:07.079189000 Z
', '2015-03-05 13:32:29.791267');
INSERT INTO versions VALUES (2230, 'Person', 385, 'update', NULL, '---
id: 385
salutation: 1
name: Paulita
lastnames: Matos Garcia
sex: false
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:46:07.861347000 Z
updated_at: 2015-03-04 19:49:48.521809000 Z
', '2015-03-05 13:32:30.222348');
INSERT INTO versions VALUES (2231, 'Person', 180, 'update', NULL, '---
id: 180
salutation: 
name: ''Aida I. ''
lastnames: Torres
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 1
created_at: 2015-02-24 14:08:52.759995000 Z
updated_at: 2015-03-05 13:32:29.787663000 Z
', '2015-03-05 13:32:30.609477');
INSERT INTO versions VALUES (2232, 'Person', 385, 'update', NULL, '---
id: 385
salutation: 1
name: Paulita
lastnames: Matos Garcia
sex: false
role: 2
description: ''''
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:46:07.861347000 Z
updated_at: 2015-03-05 13:32:30.215539000 Z
', '2015-03-05 13:32:31.513178');
INSERT INTO versions VALUES (2233, 'Person', 522, 'create', NULL, NULL, '2015-03-05 13:32:40.451753');
INSERT INTO versions VALUES (2234, 'Person', 11, 'update', NULL, '---
id: 11
salutation: 
name: ''Jessica ''
lastnames: ''Lugo ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 103
created_at: 2015-02-24 01:17:56.120307000 Z
updated_at: 2015-03-02 19:21:52.920092000 Z
', '2015-03-05 13:33:17.92275');
INSERT INTO versions VALUES (2235, 'Person', 11, 'update', NULL, '---
id: 11
salutation: 
name: ''Jessica ''
lastnames: ''Lugo ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 103
created_at: 2015-02-24 01:17:56.120307000 Z
updated_at: 2015-03-05 13:33:17.914414000 Z
', '2015-03-05 13:33:19.934642');
INSERT INTO versions VALUES (2236, 'Person', 220, 'update', NULL, '---
id: 220
salutation: 0
name: ''Elsa ''
lastnames: ''Rivera Martínez ''
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: true
church_id: 68
created_at: 2015-02-24 14:54:01.686913000 Z
updated_at: 2015-03-05 13:29:04.593363000 Z
', '2015-03-05 13:33:44.570915');
INSERT INTO versions VALUES (2237, 'Person', 220, 'update', NULL, '---
id: 220
salutation: 1
name: ''Elsa ''
lastnames: ''Rivera Martínez ''
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: true
church_id: 68
created_at: 2015-02-24 14:54:01.686913000 Z
updated_at: 2015-03-05 13:33:44.561319000 Z
', '2015-03-05 13:33:48.036089');
INSERT INTO versions VALUES (2238, 'Person', 162, 'update', NULL, '---
id: 162
salutation: 0
name: ''Nilsa ''
lastnames: Rodríguez Casillas
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 26
created_at: 2015-02-24 13:50:27.216163000 Z
updated_at: 2015-03-02 19:21:39.298287000 Z
', '2015-03-05 13:34:22.740741');
INSERT INTO versions VALUES (2239, 'Person', 162, 'update', NULL, '---
id: 162
salutation: 0
name: ''Nilsa ''
lastnames: Rodríguez Casillas
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 26
created_at: 2015-02-24 13:50:27.216163000 Z
updated_at: 2015-03-05 13:34:22.733162000 Z
', '2015-03-05 13:34:24.902481');
INSERT INTO versions VALUES (2240, 'Person', 523, 'create', NULL, NULL, '2015-03-05 13:34:40.153655');
INSERT INTO versions VALUES (2247, 'Person', 165, 'update', NULL, '---
id: 165
salutation: 
name: ''Margarita ''
lastnames: Rodríguez
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 26
created_at: 2015-02-24 13:51:43.982194000 Z
updated_at: 2015-03-02 19:21:39.288705000 Z
', '2015-03-05 13:35:04.281549');
INSERT INTO versions VALUES (2248, 'Person', 165, 'update', NULL, '---
id: 165
salutation: 
name: Maria V.
lastnames: ''Birriel ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 26
created_at: 2015-02-24 13:51:43.982194000 Z
updated_at: 2015-03-05 13:35:04.272163000 Z
', '2015-03-05 13:35:08.658604');
INSERT INTO versions VALUES (2249, 'Person', 84, 'update', NULL, '---
id: 84
salutation: 
name: ''Reinaldo ''
lastnames: ''Robles ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:15:41.375244000 Z
updated_at: 2015-03-02 19:21:07.060958000 Z
', '2015-03-05 13:35:16.45407');
INSERT INTO versions VALUES (2250, 'Person', 84, 'update', NULL, '---
id: 84
salutation: 
name: ''Reinaldo ''
lastnames: ''Robles ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:15:41.375244000 Z
updated_at: 2015-03-05 13:35:16.448086000 Z
', '2015-03-05 13:35:17.751823');
INSERT INTO versions VALUES (2251, 'Person', 153, 'update', NULL, '---
id: 153
salutation: 
name: Lillian
lastnames: Rivera Morales
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:26:47.056805000 Z
updated_at: 2015-03-02 19:21:24.215458000 Z
', '2015-03-05 13:35:21.578031');
INSERT INTO versions VALUES (2252, 'Person', 178, 'update', NULL, '---
id: 178
salutation: 0
name: ''Pedro ''
lastnames: Castro
sex: true
role: 1
description: ''''
attended: true
printed: true
materials: true
church_id: 1
created_at: 2015-02-24 14:06:33.867690000 Z
updated_at: 2015-03-05 13:01:53.056654000 Z
', '2015-03-05 13:35:22.200018');
INSERT INTO versions VALUES (2253, 'Person', 153, 'update', NULL, '---
id: 153
salutation: 
name: Lillian
lastnames: Rivera Morales
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:26:47.056805000 Z
updated_at: 2015-03-05 13:35:21.568481000 Z
', '2015-03-05 13:35:23.069122');
INSERT INTO versions VALUES (2254, 'Person', 204, 'update', NULL, '---
id: 204
salutation: 
name: ''Iris ''
lastnames: ''Colon Padilla ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 66
created_at: 2015-02-24 14:42:04.139904000 Z
updated_at: 2015-03-02 19:22:59.329954000 Z
', '2015-03-05 13:35:42.024042');
INSERT INTO versions VALUES (2255, 'Person', 204, 'update', NULL, '---
id: 204
salutation: 
name: ''Iris ''
lastnames: ''Colon Padilla ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 66
created_at: 2015-02-24 14:42:04.139904000 Z
updated_at: 2015-03-05 13:35:42.014505000 Z
', '2015-03-05 13:35:43.362276');
INSERT INTO versions VALUES (2256, 'Person', 203, 'update', NULL, '---
id: 203
salutation: 
name: ''Maria ''
lastnames: ''Quiñones ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 66
created_at: 2015-02-24 14:41:40.761442000 Z
updated_at: 2015-03-02 19:22:59.340989000 Z
', '2015-03-05 13:35:44.374097');
INSERT INTO versions VALUES (2257, 'Person', 203, 'update', NULL, '---
id: 203
salutation: 
name: ''Maria ''
lastnames: ''Quiñones ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 66
created_at: 2015-02-24 14:41:40.761442000 Z
updated_at: 2015-03-05 13:35:44.364512000 Z
', '2015-03-05 13:35:45.269086');
INSERT INTO versions VALUES (2258, 'Person', 153, 'update', NULL, '---
id: 153
salutation: 
name: Lillian
lastnames: Rivera Morales
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 25
created_at: 2015-02-24 13:26:47.056805000 Z
updated_at: 2015-03-05 13:35:23.061592000 Z
', '2015-03-05 13:35:53.268819');
INSERT INTO versions VALUES (2259, 'Person', 385, 'update', NULL, '---
id: 385
salutation: 1
name: Paulita
lastnames: Matos Garcia
sex: false
role: 2
description: ''''
attended: true
printed: true
materials: true
church_id: 
created_at: 2015-03-04 19:46:07.861347000 Z
updated_at: 2015-03-05 13:32:31.505364000 Z
', '2015-03-05 13:36:01.241115');
INSERT INTO versions VALUES (2260, 'Person', 385, 'update', NULL, '---
id: 385
salutation: 1
name: Paulita
lastnames: Matos De Garcia
sex: false
role: 2
description: ''''
attended: true
printed: true
materials: true
church_id: 
created_at: 2015-03-04 19:46:07.861347000 Z
updated_at: 2015-03-05 13:36:01.231518000 Z
', '2015-03-05 13:36:04.400718');
INSERT INTO versions VALUES (2261, 'Person', 96, 'update', NULL, '---
id: 96
salutation: 
name: Joanne
lastnames: ''Carrillo ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 59
created_at: 2015-02-24 02:25:30.268758000 Z
updated_at: 2015-03-02 19:22:42.633439000 Z
', '2015-03-05 13:36:11.636809');
INSERT INTO versions VALUES (2262, 'Person', 96, 'update', NULL, '---
id: 96
salutation: 
name: Joanne
lastnames: ''Carrillo ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 59
created_at: 2015-02-24 02:25:30.268758000 Z
updated_at: 2015-03-05 13:36:11.628348000 Z
', '2015-03-05 13:36:12.761617');
INSERT INTO versions VALUES (2263, 'Person', 524, 'create', NULL, NULL, '2015-03-05 13:36:13.040977');
INSERT INTO versions VALUES (2264, 'Person', 525, 'create', NULL, NULL, '2015-03-05 13:38:35.0309');
INSERT INTO versions VALUES (2265, 'Check', 58, 'create', NULL, NULL, '2015-03-05 13:38:55.717184');
INSERT INTO versions VALUES (2266, 'Check', 59, 'create', NULL, NULL, '2015-03-05 13:39:23.333012');
INSERT INTO versions VALUES (2267, 'Person', 236, 'update', NULL, '---
id: 236
salutation: 
name: ''Maria C. ''
lastnames: Gómez García
sex: false
role: 3
description: Sustituto
attended: false
printed: true
materials: false
church_id: 45
created_at: 2015-02-24 15:08:43.896090000 Z
updated_at: 2015-03-02 19:22:19.246407000 Z
', '2015-03-05 13:39:45.396292');
INSERT INTO versions VALUES (2241, 'Person', 519, 'update', NULL, '---
id: 519
salutation: 
name: Marilu
lastnames: Dones
sex: false
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 82
created_at: 2015-03-05 13:31:24.916843000 Z
updated_at: 2015-03-05 13:31:24.916843000 Z
', '2015-03-05 13:34:48.451041');
INSERT INTO versions VALUES (2242, 'Person', 520, 'update', NULL, '---
id: 520
salutation: 
name: ''Carlos ''
lastnames: Reyes
sex: true
role: 1
description: ''''
attended: true
printed: false
materials: true
church_id: 82
created_at: 2015-03-05 13:31:51.836493000 Z
updated_at: 2015-03-05 13:31:51.836493000 Z
', '2015-03-05 13:34:48.497598');
INSERT INTO versions VALUES (2243, 'Person', 521, 'update', NULL, '---
id: 521
salutation: 
name: Dolores
lastnames: Marquez
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 82
created_at: 2015-03-05 13:32:15.245989000 Z
updated_at: 2015-03-05 13:32:15.245989000 Z
', '2015-03-05 13:34:48.503889');
INSERT INTO versions VALUES (2244, 'Person', 522, 'update', NULL, '---
id: 522
salutation: 
name: Ydsia
lastnames: Reyes
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 82
created_at: 2015-03-05 13:32:40.448710000 Z
updated_at: 2015-03-05 13:32:40.448710000 Z
', '2015-03-05 13:34:48.510889');
INSERT INTO versions VALUES (2245, 'Person', 220, 'update', NULL, '---
id: 220
salutation: 1
name: ''Elsa ''
lastnames: ''Rivera Martínez ''
sex: false
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 68
created_at: 2015-02-24 14:54:01.686913000 Z
updated_at: 2015-03-05 13:33:48.029359000 Z
', '2015-03-05 13:34:48.519906');
INSERT INTO versions VALUES (2246, 'Person', 523, 'update', NULL, '---
id: 523
salutation: 
name: Zavier
lastnames: Báez
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 35
created_at: 2015-03-05 13:34:40.147305000 Z
updated_at: 2015-03-05 13:34:40.147305000 Z
', '2015-03-05 13:34:48.523647');
INSERT INTO versions VALUES (2276, 'Person', 165, 'update', NULL, '---
id: 165
salutation: 
name: Maria V.
lastnames: ''Birriel ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 26
created_at: 2015-02-24 13:51:43.982194000 Z
updated_at: 2015-03-05 13:35:08.649102000 Z
', '2015-03-05 13:44:52.698428');
INSERT INTO versions VALUES (2277, 'Person', 385, 'update', NULL, '---
id: 385
salutation: 1
name: Paulita
lastnames: Matos De Garcia
sex: false
role: 2
description: ''''
attended: true
printed: false
materials: true
church_id: 
created_at: 2015-03-04 19:46:07.861347000 Z
updated_at: 2015-03-05 13:36:04.398624000 Z
', '2015-03-05 13:44:52.81189');
INSERT INTO versions VALUES (2278, 'Person', 524, 'update', NULL, '---
id: 524
salutation: 
name: Carlos
lastnames: Nuñez
sex: true
role: 0
description: misión patillas
attended: true
printed: false
materials: true
church_id: 112
created_at: 2015-03-05 13:36:13.035129000 Z
updated_at: 2015-03-05 13:36:13.035129000 Z
', '2015-03-05 13:44:52.820922');
INSERT INTO versions VALUES (2279, 'Person', 525, 'update', NULL, '---
id: 525
salutation: 0
name: Rosa
lastnames: Meléndez Hesford
sex: false
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 108
created_at: 2015-03-05 13:38:35.024048000 Z
updated_at: 2015-03-05 13:38:35.024048000 Z
', '2015-03-05 13:44:52.832298');
INSERT INTO versions VALUES (2280, 'Person', 526, 'update', NULL, '---
id: 526
salutation: 
name: Olga
lastnames: Quiñones
sex: false
role: 5
description: ''''
attended: true
printed: false
materials: true
church_id: 84
created_at: 2015-03-05 13:40:27.940214000 Z
updated_at: 2015-03-05 13:40:27.940214000 Z
', '2015-03-05 13:44:52.840318');
INSERT INTO versions VALUES (2281, 'Person', 527, 'update', NULL, '---
id: 527
salutation: 
name: Ramón O.
lastnames: Martínez
sex: true
role: 5
description: Comité Organizador
attended: true
printed: false
materials: true
church_id: 12
created_at: 2015-03-05 13:44:27.324028000 Z
updated_at: 2015-03-05 13:44:27.324028000 Z
', '2015-03-05 13:44:52.849258');
INSERT INTO versions VALUES (2310, 'Person', 528, 'update', NULL, '---
id: 528
salutation: 
name: ''Carmen ''
lastnames: Quiros
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 78
created_at: 2015-03-05 13:50:47.132906000 Z
updated_at: 2015-03-05 13:50:47.132906000 Z
', '2015-03-05 13:57:56.295537');
INSERT INTO versions VALUES (2311, 'Person', 529, 'update', NULL, '---
id: 529
salutation: 
name: Saribel
lastnames: Sánchez
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 19
created_at: 2015-03-05 13:50:49.028085000 Z
updated_at: 2015-03-05 13:50:49.028085000 Z
', '2015-03-05 13:57:56.502775');
INSERT INTO versions VALUES (2312, 'Person', 530, 'update', NULL, '---
id: 530
salutation: 0
name: Adelaida
lastnames: Vázquez
sex: false
role: 5
description: Misión Bautista Puente de Salvación
attended: true
printed: false
materials: true
church_id: 
created_at: 2015-03-05 13:51:06.695452000 Z
updated_at: 2015-03-05 13:51:06.695452000 Z
', '2015-03-05 13:57:56.508037');
INSERT INTO versions VALUES (2313, 'Person', 249, 'update', NULL, '---
id: 249
salutation: 
name: ''Yolanda ''
lastnames: Orengo Montes
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 99
created_at: 2015-02-24 15:16:47.614559000 Z
updated_at: 2015-03-05 13:52:49.951929000 Z
', '2015-03-05 13:57:56.515364');
INSERT INTO versions VALUES (2314, 'Person', 531, 'update', NULL, '---
id: 531
salutation: 3
name: Juan
lastnames: León
sex: true
role: 5
description: Parlamentarista
attended: true
printed: false
materials: true
church_id: 
created_at: 2015-03-05 13:56:09.235463000 Z
updated_at: 2015-03-05 13:56:09.235463000 Z
', '2015-03-05 13:57:56.523769');
INSERT INTO versions VALUES (2315, 'Person', 297, 'update', NULL, '---
id: 297
salutation: 
name: ''María ''
lastnames: Díaz Castillo
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 53
created_at: 2015-02-27 02:45:46.184223000 Z
updated_at: 2015-03-05 13:57:45.694009000 Z
', '2015-03-05 13:57:56.527512');
INSERT INTO versions VALUES (2360, 'Person', 532, 'update', NULL, '---
id: 532
salutation: 0
name: ''Miguel ''
lastnames: ''Bonnet ''
sex: true
role: 5
description: Representante de las IBRD de IBaredo
attended: true
printed: false
materials: true
church_id: 
created_at: 2015-03-05 14:05:36.999307000 Z
updated_at: 2015-03-05 14:06:03.719530000 Z
', '2015-03-05 14:14:00.227531');
INSERT INTO versions VALUES (2361, 'Person', 219, 'update', NULL, '---
id: 219
salutation: 
name: Victor
lastnames: Marquez
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 21
created_at: 2015-02-24 14:51:58.885631000 Z
updated_at: 2015-03-05 14:08:28.141145000 Z
', '2015-03-05 14:14:00.335428');
INSERT INTO versions VALUES (2362, 'Person', 533, 'update', NULL, '---
id: 533
salutation: 0
name: José
lastnames: Ortiz Charriez
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 5
created_at: 2015-03-05 14:10:04.559612000 Z
updated_at: 2015-03-05 14:10:04.559612000 Z
', '2015-03-05 14:14:00.343456');
INSERT INTO versions VALUES (2363, 'Person', 451, 'update', NULL, '---
id: 451
salutation: 
name: ''Jim ''
lastnames: Wiegner
sex: true
role: 5
description: Ministerios Internacionales
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-03-04 20:17:52.985921000 Z
updated_at: 2015-03-05 14:10:42.254623000 Z
', '2015-03-05 14:14:00.350759');
INSERT INTO versions VALUES (2364, 'Person', 534, 'update', NULL, '---
id: 534
salutation: 
name: Karen
lastnames: Rosado
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 5
created_at: 2015-03-05 14:11:42.914838000 Z
updated_at: 2015-03-05 14:11:42.914838000 Z
', '2015-03-05 14:14:00.3604');
INSERT INTO versions VALUES (2365, 'Person', 535, 'update', NULL, '---
id: 535
salutation: 
name: Jennifer
lastnames: Rosado
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 5
created_at: 2015-03-05 14:13:41.265463000 Z
updated_at: 2015-03-05 14:13:41.265463000 Z
', '2015-03-05 14:14:00.364847');
INSERT INTO versions VALUES (2397, 'Person', 536, 'update', NULL, '---
id: 536
salutation: 
name: Belkis
lastnames: Gil
sex: false
role: 5
description: Representante de las IBRD de IBaredo
attended: true
printed: false
materials: true
church_id: 
created_at: 2015-03-05 14:14:55.178302000 Z
updated_at: 2015-03-05 14:14:55.178302000 Z
', '2015-03-05 14:44:03.087908');
INSERT INTO versions VALUES (2268, 'Person', 236, 'update', NULL, '---
id: 236
salutation: 
name: ''Maria C. ''
lastnames: Gómez García
sex: false
role: 3
description: Sustituto
attended: true
printed: true
materials: false
church_id: 45
created_at: 2015-02-24 15:08:43.896090000 Z
updated_at: 2015-03-05 13:39:45.386963000 Z
', '2015-03-05 13:39:46.4901');
INSERT INTO versions VALUES (2269, 'Check', 60, 'create', NULL, NULL, '2015-03-05 13:40:13.768141');
INSERT INTO versions VALUES (2270, 'Person', 526, 'create', NULL, NULL, '2015-03-05 13:40:27.941903');
INSERT INTO versions VALUES (2271, 'Person', 234, 'update', NULL, '---
id: 234
salutation: 
name: ''Digna ''
lastnames: Valdés Laboy
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 45
created_at: 2015-02-24 15:07:44.276170000 Z
updated_at: 2015-03-02 19:22:19.234242000 Z
', '2015-03-05 13:40:35.805801');
INSERT INTO versions VALUES (2272, 'Person', 234, 'update', NULL, '---
id: 234
salutation: 
name: ''Digna ''
lastnames: Valdés Laboy
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: true
church_id: 45
created_at: 2015-02-24 15:07:44.276170000 Z
updated_at: 2015-03-05 13:40:35.796511000 Z
', '2015-03-05 13:40:37.496221');
INSERT INTO versions VALUES (2273, 'Person', 298, 'update', NULL, '---
id: 298
salutation: 
name: ''Rebeca ''
lastnames: ''Rivera ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 53
created_at: 2015-02-27 02:46:06.542945000 Z
updated_at: 2015-03-02 19:22:22.607571000 Z
', '2015-03-05 13:42:28.711658');
INSERT INTO versions VALUES (2274, 'Person', 298, 'update', NULL, '---
id: 298
salutation: 
name: ''Rebeca ''
lastnames: ''Rivera ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 53
created_at: 2015-02-27 02:46:06.542945000 Z
updated_at: 2015-03-05 13:42:28.702192000 Z
', '2015-03-05 13:42:29.697459');
INSERT INTO versions VALUES (2275, 'Person', 527, 'create', NULL, NULL, '2015-03-05 13:44:27.326012');
INSERT INTO versions VALUES (2282, 'Person', 194, 'update', NULL, '---
id: 194
salutation: 
name: ''Maria ''
lastnames: ''Charles ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 19
created_at: 2015-02-24 14:32:01.785633000 Z
updated_at: 2015-03-02 19:22:27.143516000 Z
', '2015-03-05 13:47:27.644806');
INSERT INTO versions VALUES (2283, 'Person', 194, 'update', NULL, '---
id: 194
salutation: 
name: ''Maria ''
lastnames: ''Charles ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 19
created_at: 2015-02-24 14:32:01.785633000 Z
updated_at: 2015-03-05 13:47:27.635112000 Z
', '2015-03-05 13:47:29.630973');
INSERT INTO versions VALUES (2284, 'Person', 193, 'update', NULL, '---
id: 193
salutation: 
name: ''Nilda ''
lastnames: García
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 19
created_at: 2015-02-24 14:28:49.381875000 Z
updated_at: 2015-03-02 19:22:27.160673000 Z
', '2015-03-05 13:47:33.512193');
INSERT INTO versions VALUES (2285, 'Person', 193, 'update', NULL, '---
id: 193
salutation: 
name: ''Nilda ''
lastnames: García
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 19
created_at: 2015-02-24 14:28:49.381875000 Z
updated_at: 2015-03-05 13:47:33.505756000 Z
', '2015-03-05 13:47:35.087079');
INSERT INTO versions VALUES (2286, 'Person', 31, 'update', NULL, '---
id: 31
salutation: 0
name: ''Hipólito ''
lastnames: ''Félix ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 123
created_at: 2015-02-24 01:41:36.181148000 Z
updated_at: 2015-03-02 19:22:07.556478000 Z
', '2015-03-05 13:48:02.981654');
INSERT INTO versions VALUES (2287, 'Person', 31, 'update', NULL, '---
id: 31
salutation: 0
name: ''Hipólito ''
lastnames: ''Félix ''
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 123
created_at: 2015-02-24 01:41:36.181148000 Z
updated_at: 2015-03-05 13:48:02.973019000 Z
', '2015-03-05 13:48:04.03363');
INSERT INTO versions VALUES (2288, 'Person', 152, 'update', NULL, '---
id: 152
salutation: 
name: ''Victor ''
lastnames: Rivera Santiago
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:26:17.801431000 Z
updated_at: 2015-03-02 19:21:32.721760000 Z
', '2015-03-05 13:48:25.41175');
INSERT INTO versions VALUES (2289, 'Person', 152, 'update', NULL, '---
id: 152
salutation: 
name: ''Victor ''
lastnames: Rivera Santiago
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:26:17.801431000 Z
updated_at: 2015-03-05 13:48:25.402206000 Z
', '2015-03-05 13:48:27.106871');
INSERT INTO versions VALUES (2290, 'Person', 33, 'update', NULL, '---
id: 33
salutation: 
name: ''Awilda ''
lastnames: ''Hernández ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 123
created_at: 2015-02-24 01:42:32.458934000 Z
updated_at: 2015-03-02 19:22:04.410061000 Z
', '2015-03-05 13:49:00.528237');
INSERT INTO versions VALUES (2291, 'Person', 33, 'update', NULL, '---
id: 33
salutation: 
name: ''Awilda ''
lastnames: ''Hernández ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 123
created_at: 2015-02-24 01:42:32.458934000 Z
updated_at: 2015-03-05 13:49:00.517705000 Z
', '2015-03-05 13:49:01.727095');
INSERT INTO versions VALUES (2292, 'Person', 33, 'update', NULL, '---
id: 33
salutation: 
name: ''Awilda ''
lastnames: ''Hernández ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 123
created_at: 2015-02-24 01:42:32.458934000 Z
updated_at: 2015-03-05 13:49:01.716619000 Z
', '2015-03-05 13:49:17.654193');
INSERT INTO versions VALUES (2293, 'Person', 33, 'update', NULL, '---
id: 33
salutation: 
name: ''Awilda ''
lastnames: ''Hernández ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 123
created_at: 2015-02-24 01:42:32.458934000 Z
updated_at: 2015-03-05 13:49:17.644985000 Z
', '2015-03-05 13:49:18.694762');
INSERT INTO versions VALUES (2294, 'Person', 32, 'update', NULL, '---
id: 32
salutation: 
name: ''Lydia ''
lastnames: ''Camacho ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 123
created_at: 2015-02-24 01:42:07.441078000 Z
updated_at: 2015-03-02 19:22:07.702744000 Z
', '2015-03-05 13:49:22.022004');
INSERT INTO versions VALUES (2295, 'Person', 32, 'update', NULL, '---
id: 32
salutation: 
name: ''Lydia ''
lastnames: ''Camacho ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 123
created_at: 2015-02-24 01:42:07.441078000 Z
updated_at: 2015-03-05 13:49:22.012509000 Z
', '2015-03-05 13:49:23.278841');
INSERT INTO versions VALUES (2296, 'Person', 277, 'destroy', NULL, '---
id: 277
salutation: 
name: ''Daniel ''
lastnames: ''Pérez Medina ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 19
created_at: 2015-02-25 13:25:23.919180000 Z
updated_at: 2015-03-02 19:22:27.117159000 Z
', '2015-03-05 13:49:24.453095');
INSERT INTO versions VALUES (2297, 'Person', 192, 'destroy', NULL, '---
id: 192
salutation: 0
name: ''Abigail ''
lastnames: Castro
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 19
created_at: 2015-02-24 14:28:11.784210000 Z
updated_at: 2015-03-02 19:22:26.667565000 Z
', '2015-03-05 13:50:03.646385');
INSERT INTO versions VALUES (2298, 'Person', 528, 'create', NULL, NULL, '2015-03-05 13:50:47.134719');
INSERT INTO versions VALUES (2299, 'Person', 529, 'create', NULL, NULL, '2015-03-05 13:50:49.034584');
INSERT INTO versions VALUES (2300, 'Person', 530, 'create', NULL, NULL, '2015-03-05 13:51:06.699273');
INSERT INTO versions VALUES (2301, 'Person', 440, 'update', NULL, '---
id: 440
salutation: 
name: Luis
lastnames: Coreano
sex: true
role: 4
description: Comisión de Evangelismo
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:08:19.010844000 Z
updated_at: 2015-03-04 20:09:49.749301000 Z
', '2015-03-05 13:52:18.432791');
INSERT INTO versions VALUES (2302, 'Person', 440, 'update', NULL, '---
id: 440
salutation: 
name: Luis
lastnames: Coreano
sex: true
role: 4
description: Comisión de Evangelismo
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:08:19.010844000 Z
updated_at: 2015-03-05 13:52:18.423140000 Z
', '2015-03-05 13:52:21.892785');
INSERT INTO versions VALUES (2303, 'Person', 249, 'update', NULL, '---
id: 249
salutation: 
name: ''Yolanda ''
lastnames: Orendo Montes
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 99
created_at: 2015-02-24 15:16:47.614559000 Z
updated_at: 2015-03-05 11:14:49.862823000 Z
', '2015-03-05 13:52:45.980221');
INSERT INTO versions VALUES (2304, 'Person', 249, 'update', NULL, '---
id: 249
salutation: 
name: ''Yolanda ''
lastnames: Orengo Montes
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 99
created_at: 2015-02-24 15:16:47.614559000 Z
updated_at: 2015-03-05 13:52:45.971813000 Z
', '2015-03-05 13:52:49.960798');
INSERT INTO versions VALUES (2305, 'Person', 531, 'create', NULL, NULL, '2015-03-05 13:56:09.242196');
INSERT INTO versions VALUES (2306, 'Person', 297, 'update', NULL, '---
id: 297
salutation: 
name: ''María ''
lastnames: ''Castillo ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 53
created_at: 2015-02-27 02:45:46.184223000 Z
updated_at: 2015-03-02 19:22:22.601562000 Z
', '2015-03-05 13:57:01.510425');
INSERT INTO versions VALUES (2307, 'Person', 297, 'update', NULL, '---
id: 297
salutation: 
name: ''María ''
lastnames: ''Castillo ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 53
created_at: 2015-02-27 02:45:46.184223000 Z
updated_at: 2015-03-05 13:57:01.501969000 Z
', '2015-03-05 13:57:03.008434');
INSERT INTO versions VALUES (2308, 'Person', 297, 'update', NULL, '---
id: 297
salutation: 
name: ''María ''
lastnames: ''Castillo ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 53
created_at: 2015-02-27 02:45:46.184223000 Z
updated_at: 2015-03-05 13:57:02.999712000 Z
', '2015-03-05 13:57:42.726547');
INSERT INTO versions VALUES (2309, 'Person', 297, 'update', NULL, '---
id: 297
salutation: 
name: ''María ''
lastnames: Díaz Castillo
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 53
created_at: 2015-02-27 02:45:46.184223000 Z
updated_at: 2015-03-05 13:57:42.717089000 Z
', '2015-03-05 13:57:45.703625');
INSERT INTO versions VALUES (2316, 'Person', 254, 'update', NULL, '---
id: 254
salutation: 
name: ''Noel Y. ''
lastnames: ''Pachecho Alvarez ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 99
created_at: 2015-02-24 15:26:06.338909000 Z
updated_at: 2015-03-02 19:26:56.939029000 Z
', '2015-03-05 13:58:10.229875');
INSERT INTO versions VALUES (2317, 'Person', 254, 'update', NULL, '---
id: 254
salutation: 
name: ''Noel Y. ''
lastnames: ''Pachecho Alvarez ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 99
created_at: 2015-02-24 15:26:06.338909000 Z
updated_at: 2015-03-05 13:58:10.225340000 Z
', '2015-03-05 13:58:16.112212');
INSERT INTO versions VALUES (2318, 'Person', 411, 'update', NULL, '---
id: 411
salutation: 
name: José
lastnames: Pérez
sex: true
role: 4
description: Representante Distrito
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:55:52.843474000 Z
updated_at: 2015-03-04 19:56:32.903552000 Z
', '2015-03-05 14:02:08.147778');
INSERT INTO versions VALUES (2319, 'Person', 411, 'update', NULL, '---
id: 411
salutation: 
name: José
lastnames: Pérez
sex: true
role: 4
description: Representante Distrito
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:55:52.843474000 Z
updated_at: 2015-03-05 14:02:08.138935000 Z
', '2015-03-05 14:02:09.241111');
INSERT INTO versions VALUES (2320, 'Person', 374, 'update', NULL, '---
id: 374
salutation: 1
name: Madeline
lastnames: Flores
sex: false
role: 5
description: Misionera en República Dominicana
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:36:12.138507000 Z
updated_at: 2015-03-04 20:21:00.248150000 Z
', '2015-03-05 14:02:40.166289');
INSERT INTO versions VALUES (2321, 'Person', 374, 'update', NULL, '---
id: 374
salutation: 1
name: Madeline
lastnames: Flores
sex: false
role: 5
description: Misionera en República Dominicana
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:36:12.138507000 Z
updated_at: 2015-03-05 14:02:40.157753000 Z
', '2015-03-05 14:02:41.844812');
INSERT INTO versions VALUES (2322, 'Person', 81, 'update', NULL, '---
id: 81
salutation: 1
name: ''Héctor A. ''
lastnames: ''Rivera ''
sex: true
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:14:22.852503000 Z
updated_at: 2015-03-02 19:21:03.435069000 Z
', '2015-03-05 14:04:33.059434');
INSERT INTO versions VALUES (2323, 'Person', 81, 'update', NULL, '---
id: 81
salutation: 1
name: ''Héctor A. ''
lastnames: ''Rivera ''
sex: true
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:14:22.852503000 Z
updated_at: 2015-03-05 14:04:33.050040000 Z
', '2015-03-05 14:04:35.081759');
INSERT INTO versions VALUES (2324, 'Check', 61, 'create', NULL, NULL, '2015-03-05 14:04:37.793322');
INSERT INTO versions VALUES (2325, 'Person', 532, 'create', NULL, NULL, '2015-03-05 14:05:37.005782');
INSERT INTO versions VALUES (2326, 'Person', 532, 'update', NULL, '---
id: 532
salutation: 0
name: ''Miguel ''
lastnames: ''Bonnet ''
sex: true
role: 5
description: Representante de las Iglesias Bautistas de la República Dominicana de
  IBaredo
attended: true
printed: false
materials: true
church_id: 
created_at: 2015-03-05 14:05:36.999307000 Z
updated_at: 2015-03-05 14:05:36.999307000 Z
', '2015-03-05 14:06:03.725118');
INSERT INTO versions VALUES (2327, 'Person', 143, 'update', NULL, '---
id: 143
salutation: 1
name: ''Luis R. ''
lastnames: ''Quiñones ''
sex: true
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:35:16.499350000 Z
updated_at: 2015-03-02 19:21:24.678657000 Z
', '2015-03-05 14:06:09.027454');
INSERT INTO versions VALUES (2328, 'Person', 143, 'update', NULL, '---
id: 143
salutation: 1
name: ''Luis R. ''
lastnames: ''Quiñones ''
sex: true
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:35:16.499350000 Z
updated_at: 2015-03-05 14:06:09.020439000 Z
', '2015-03-05 14:06:11.050186');
INSERT INTO versions VALUES (2329, 'Person', 153, 'update', NULL, '---
id: 153
salutation: 
name: Lillian
lastnames: Rivera Morales
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 13:26:47.056805000 Z
updated_at: 2015-03-05 13:35:53.260763000 Z
', '2015-03-05 14:06:18.914504');
INSERT INTO versions VALUES (2330, 'Person', 304, 'update', NULL, '---
id: 304
salutation: 
name: ''Judith ''
lastnames: Castro
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 85
created_at: 2015-03-02 19:19:39.726530000 Z
updated_at: 2015-03-02 19:23:29.464743000 Z
', '2015-03-05 14:06:35.016134');
INSERT INTO versions VALUES (2331, 'Person', 304, 'update', NULL, '---
id: 304
salutation: 
name: ''Judith ''
lastnames: Castro
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 85
created_at: 2015-03-02 19:19:39.726530000 Z
updated_at: 2015-03-05 14:06:35.005887000 Z
', '2015-03-05 14:06:36.815923');
INSERT INTO versions VALUES (2332, 'Person', 300, 'update', NULL, '---
id: 300
salutation: 1
name: ''Miguel ''
lastnames: ''Acosta ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 85
created_at: 2015-03-02 19:17:29.658572000 Z
updated_at: 2015-03-02 19:23:29.498964000 Z
', '2015-03-05 14:07:09.862941');
INSERT INTO versions VALUES (2333, 'Person', 300, 'update', NULL, '---
id: 300
salutation: 1
name: ''Miguel ''
lastnames: ''Acosta ''
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 85
created_at: 2015-03-02 19:17:29.658572000 Z
updated_at: 2015-03-05 14:07:09.857916000 Z
', '2015-03-05 14:07:11.255172');
INSERT INTO versions VALUES (2334, 'Person', 325, 'update', NULL, '---
id: 325
salutation: 0
name: ''Zoraida ''
lastnames: Rivera Morales
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 41
created_at: 2015-03-02 19:46:12.671406000 Z
updated_at: 2015-03-02 19:47:09.139547000 Z
', '2015-03-05 14:07:24.508538');
INSERT INTO versions VALUES (2335, 'Person', 325, 'update', NULL, '---
id: 325
salutation: 0
name: ''Zoraida ''
lastnames: Rivera Morales
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 41
created_at: 2015-03-02 19:46:12.671406000 Z
updated_at: 2015-03-05 14:07:24.500303000 Z
', '2015-03-05 14:07:25.444393');
INSERT INTO versions VALUES (2336, 'Person', 328, 'update', NULL, '---
id: 328
salutation: 
name: ''Ruth ''
lastnames: Rosa
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 41
created_at: 2015-03-02 19:47:10.836208000 Z
updated_at: 2015-03-02 19:53:12.484202000 Z
', '2015-03-05 14:07:51.443988');
INSERT INTO versions VALUES (2337, 'Person', 328, 'update', NULL, '---
id: 328
salutation: 
name: ''Ruth ''
lastnames: Rosa
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 41
created_at: 2015-03-02 19:47:10.836208000 Z
updated_at: 2015-03-05 14:07:51.434713000 Z
', '2015-03-05 14:07:52.4803');
INSERT INTO versions VALUES (2338, 'Person', 219, 'update', NULL, '---
id: 219
salutation: 
name: ''Oscar ''
lastnames: Santiago
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 21
created_at: 2015-02-24 14:51:58.885631000 Z
updated_at: 2015-03-02 19:23:13.860305000 Z
', '2015-03-05 14:08:17.378826');
INSERT INTO versions VALUES (2339, 'Person', 219, 'update', NULL, '---
id: 219
salutation: 
name: Victor
lastnames: Marquez
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 21
created_at: 2015-02-24 14:51:58.885631000 Z
updated_at: 2015-03-05 14:08:17.369632000 Z
', '2015-03-05 14:08:24.073928');
INSERT INTO versions VALUES (2340, 'Person', 219, 'update', NULL, '---
id: 219
salutation: 
name: Victor
lastnames: Marquez
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 21
created_at: 2015-02-24 14:51:58.885631000 Z
updated_at: 2015-03-05 14:08:24.065329000 Z
', '2015-03-05 14:08:26.38436');
INSERT INTO versions VALUES (2341, 'Person', 219, 'update', NULL, '---
id: 219
salutation: 
name: Victor
lastnames: Marquez
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: true
church_id: 21
created_at: 2015-02-24 14:51:58.885631000 Z
updated_at: 2015-03-05 14:08:26.374758000 Z
', '2015-03-05 14:08:28.150761');
INSERT INTO versions VALUES (2342, 'Person', 34, 'update', NULL, '---
id: 34
salutation: 1
name: ''Heriberto ''
lastnames: ''Muñoz ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 107
created_at: 2015-02-24 01:43:56.325452000 Z
updated_at: 2015-03-02 19:23:18.466555000 Z
', '2015-03-05 14:09:09.901122');
INSERT INTO versions VALUES (2343, 'Person', 34, 'update', NULL, '---
id: 34
salutation: 1
name: ''Heriberto ''
lastnames: ''Muñoz ''
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 107
created_at: 2015-02-24 01:43:56.325452000 Z
updated_at: 2015-03-05 14:09:09.891502000 Z
', '2015-03-05 14:09:11.185796');
INSERT INTO versions VALUES (2344, 'Person', 533, 'create', NULL, NULL, '2015-03-05 14:10:04.566257');
INSERT INTO versions VALUES (2345, 'Person', 451, 'update', NULL, '---
id: 451
salutation: 
name: ''Jim ''
lastnames: Weigner
sex: true
role: 5
description: Ministerios Internacionales
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:17:52.985921000 Z
updated_at: 2015-03-04 20:19:56.669253000 Z
', '2015-03-05 14:10:39.440434');
INSERT INTO versions VALUES (2346, 'Person', 451, 'update', NULL, '---
id: 451
salutation: 
name: ''Jim ''
lastnames: Wiegner
sex: true
role: 5
description: Ministerios Internacionales
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:17:52.985921000 Z
updated_at: 2015-03-05 14:10:39.433430000 Z
', '2015-03-05 14:10:42.263656');
INSERT INTO versions VALUES (2347, 'Person', 44, 'update', NULL, '---
id: 44
salutation: 0
name: ''Carlos J. ''
lastnames: ''Montalvo ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 112
created_at: 2015-02-24 01:51:09.641324000 Z
updated_at: 2015-03-02 19:23:41.363513000 Z
', '2015-03-05 14:11:03.673232');
INSERT INTO versions VALUES (2348, 'Person', 44, 'update', NULL, '---
id: 44
salutation: 0
name: ''Carlos J. ''
lastnames: ''Montalvo ''
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 112
created_at: 2015-02-24 01:51:09.641324000 Z
updated_at: 2015-03-05 14:11:03.666744000 Z
', '2015-03-05 14:11:05.378796');
INSERT INTO versions VALUES (2349, 'Person', 534, 'create', NULL, NULL, '2015-03-05 14:11:42.920185');
INSERT INTO versions VALUES (2350, 'Person', 45, 'update', NULL, '---
id: 45
salutation: 
name: ''Leticia ''
lastnames: ''Santaella ''
sex: false
role: 4
description: ''''
attended: false
printed: true
materials: false
church_id: 112
created_at: 2015-02-24 01:51:34.052136000 Z
updated_at: 2015-03-05 12:28:56.045392000 Z
', '2015-03-05 14:11:55.798464');
INSERT INTO versions VALUES (2351, 'Person', 45, 'update', NULL, '---
id: 45
salutation: 
name: ''Leticia ''
lastnames: ''Santaella ''
sex: false
role: 4
description: ''''
attended: true
printed: true
materials: false
church_id: 112
created_at: 2015-02-24 01:51:34.052136000 Z
updated_at: 2015-03-05 14:11:55.788591000 Z
', '2015-03-05 14:11:57.191148');
INSERT INTO versions VALUES (2352, 'Check', 61, 'update', NULL, '---
id: 61
number: 9326
amount: 125.0
description: ''''
church_id: 41
created_at: 2015-03-05 14:04:37.788068000 Z
updated_at: 2015-03-05 14:04:37.788068000 Z
', '2015-03-05 14:12:01.917648');
INSERT INTO versions VALUES (2353, 'Person', 102, 'update', NULL, '---
id: 102
salutation: 
name: ''Marisol ''
lastnames: ''Rosa ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 52
created_at: 2015-02-24 02:29:10.040047000 Z
updated_at: 2015-03-02 19:22:03.575405000 Z
', '2015-03-05 14:12:38.159997');
INSERT INTO versions VALUES (2354, 'Person', 102, 'update', NULL, '---
id: 102
salutation: 
name: ''Marisol ''
lastnames: ''Rosa ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 52
created_at: 2015-02-24 02:29:10.040047000 Z
updated_at: 2015-03-05 14:12:38.150559000 Z
', '2015-03-05 14:12:38.948117');
INSERT INTO versions VALUES (2355, 'Person', 106, 'update', NULL, '---
id: 106
salutation: 0
name: ''Miguel A. ''
lastnames: ''Sánchez ''
sex: true
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 52
created_at: 2015-02-24 02:31:01.728234000 Z
updated_at: 2015-03-02 19:22:03.962802000 Z
', '2015-03-05 14:13:13.425487');
INSERT INTO versions VALUES (2356, 'Person', 106, 'update', NULL, '---
id: 106
salutation: 0
name: ''Miguel A. ''
lastnames: ''Sánchez ''
sex: true
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 52
created_at: 2015-02-24 02:31:01.728234000 Z
updated_at: 2015-03-05 14:13:13.418783000 Z
', '2015-03-05 14:13:14.271304');
INSERT INTO versions VALUES (2357, 'Person', 241, 'update', NULL, '---
id: 241
salutation: 1
name: ''Magda ''
lastnames: Aguirre
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 76
created_at: 2015-02-24 15:12:09.346928000 Z
updated_at: 2015-03-02 19:23:13.876034000 Z
', '2015-03-05 14:13:20.946295');
INSERT INTO versions VALUES (2358, 'Person', 241, 'update', NULL, '---
id: 241
salutation: 1
name: ''Magda ''
lastnames: Aguirre
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 76
created_at: 2015-02-24 15:12:09.346928000 Z
updated_at: 2015-03-05 14:13:20.937440000 Z
', '2015-03-05 14:13:22.732753');
INSERT INTO versions VALUES (2359, 'Person', 535, 'create', NULL, NULL, '2015-03-05 14:13:41.271022');
INSERT INTO versions VALUES (2366, 'Person', 536, 'create', NULL, NULL, '2015-03-05 14:14:55.182304');
INSERT INTO versions VALUES (2367, 'Person', 283, 'update', NULL, '---
id: 283
salutation: 
name: ''Daniris ''
lastnames: ''Sánchez ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 118
created_at: 2015-02-25 14:48:04.168582000 Z
updated_at: 2015-03-04 21:34:57.090357000 Z
', '2015-03-05 14:16:16.90186');
INSERT INTO versions VALUES (2368, 'Person', 283, 'update', NULL, '---
id: 283
salutation: 
name: ''Daniris ''
lastnames: ''Sánchez ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 118
created_at: 2015-02-25 14:48:04.168582000 Z
updated_at: 2015-03-05 14:16:16.892307000 Z
', '2015-03-05 14:16:18.22924');
INSERT INTO versions VALUES (2369, 'Person', 282, 'update', NULL, '---
id: 282
salutation: 1
name: ''Dr. Anibal ''
lastnames: ''Cruz ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 121
created_at: 2015-02-25 14:47:11.251809000 Z
updated_at: 2015-03-02 19:21:52.809001000 Z
', '2015-03-05 14:16:43.910802');
INSERT INTO versions VALUES (2370, 'Person', 282, 'update', NULL, '---
id: 282
salutation: 1
name: ''Dr. Anibal ''
lastnames: ''Cruz ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 121
created_at: 2015-02-25 14:47:11.251809000 Z
updated_at: 2015-03-05 14:16:43.902369000 Z
', '2015-03-05 14:16:45.00817');
INSERT INTO versions VALUES (2371, 'Person', 21, 'update', NULL, '---
id: 21
salutation: 
name: ''Miguel A. ''
lastnames: ''Rivera ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 3
created_at: 2015-02-24 01:26:30.752850000 Z
updated_at: 2015-03-02 19:22:00.396847000 Z
', '2015-03-05 14:17:50.10188');
INSERT INTO versions VALUES (2372, 'Person', 21, 'update', NULL, '---
id: 21
salutation: 
name: ''Miguel A. ''
lastnames: ''Rivera ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 3
created_at: 2015-02-24 01:26:30.752850000 Z
updated_at: 2015-03-05 14:17:50.093090000 Z
', '2015-03-05 14:17:51.025721');
INSERT INTO versions VALUES (2373, 'Person', 19, 'update', NULL, '---
id: 19
salutation: 
name: ''José A. ''
lastnames: ''Flores ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 3
created_at: 2015-02-24 01:25:39.803808000 Z
updated_at: 2015-03-02 19:22:00.391951000 Z
', '2015-03-05 14:17:52.957128');
INSERT INTO versions VALUES (2374, 'Person', 19, 'update', NULL, '---
id: 19
salutation: 
name: ''José A. ''
lastnames: ''Flores ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 3
created_at: 2015-02-24 01:25:39.803808000 Z
updated_at: 2015-03-05 14:17:52.947010000 Z
', '2015-03-05 14:17:54.193749');
INSERT INTO versions VALUES (2375, 'Person', 301, 'update', NULL, '---
id: 301
salutation: 
name: ''Sonia ''
lastnames: ''Nieves ''
sex: true
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 85
created_at: 2015-03-02 19:18:34.403674000 Z
updated_at: 2015-03-02 19:23:29.508207000 Z
', '2015-03-05 14:18:33.302087');
INSERT INTO versions VALUES (2376, 'Person', 301, 'update', NULL, '---
id: 301
salutation: 
name: ''Sonia ''
lastnames: ''Nieves ''
sex: true
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 85
created_at: 2015-03-02 19:18:34.403674000 Z
updated_at: 2015-03-05 14:18:33.292790000 Z
', '2015-03-05 14:18:34.89804');
INSERT INTO versions VALUES (2377, 'Person', 418, 'update', NULL, '---
id: 418
salutation: 1
name: Miriam
lastnames: Chacón Peralta
sex: false
role: 5
description: Representante Regional MMBB
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:57:59.789934000 Z
updated_at: 2015-03-04 20:34:19.751509000 Z
', '2015-03-05 14:20:46.201875');
INSERT INTO versions VALUES (2378, 'Person', 418, 'update', NULL, '---
id: 418
salutation: 1
name: Miriam
lastnames: Chacón Peralta
sex: false
role: 5
description: Representante Regional MMBB
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:57:59.789934000 Z
updated_at: 2015-03-05 14:20:46.192282000 Z
', '2015-03-05 14:20:48.09766');
INSERT INTO versions VALUES (2379, 'Person', 390, 'update', NULL, '---
id: 390
salutation: 1
name: Salvador
lastnames: Orellana
sex: true
role: 5
description: Coord. Nac. Minist. Inter.ABHMS
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:48:37.386472000 Z
updated_at: 2015-03-04 19:50:22.434521000 Z
', '2015-03-05 14:22:12.309468');
INSERT INTO versions VALUES (2380, 'Person', 390, 'update', NULL, '---
id: 390
salutation: 1
name: Salvador
lastnames: Orellana
sex: true
role: 5
description: Coord. Nac. Minist. Inter.ABHMS
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:48:37.386472000 Z
updated_at: 2015-03-05 14:22:12.301715000 Z
', '2015-03-05 14:22:13.665713');
INSERT INTO versions VALUES (2381, 'Person', 238, 'update', NULL, '---
id: 238
salutation: 0
name: ''Carlos A. ''
lastnames: ''Padilla Rivera ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 47
created_at: 2015-02-24 15:09:45.918708000 Z
updated_at: 2015-03-02 19:22:19.261533000 Z
', '2015-03-05 14:26:25.327689');
INSERT INTO versions VALUES (2382, 'Person', 238, 'update', NULL, '---
id: 238
salutation: 0
name: ''Carlos A. ''
lastnames: ''Padilla Rivera ''
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 47
created_at: 2015-02-24 15:09:45.918708000 Z
updated_at: 2015-03-05 14:26:25.318230000 Z
', '2015-03-05 14:26:27.228377');
INSERT INTO versions VALUES (2383, 'Person', 367, 'update', NULL, '---
id: 367
salutation: 
name: Margarita
lastnames: Ramírez
sex: false
role: 4
description: Presidenta IBPR
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:08:30.862204000 Z
updated_at: 2015-03-04 21:23:01.458547000 Z
', '2015-03-05 14:26:50.429047');
INSERT INTO versions VALUES (2384, 'Person', 367, 'update', NULL, '---
id: 367
salutation: 
name: Margarita
lastnames: Ramírez
sex: false
role: 4
description: Presidenta IBPR
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:08:30.862204000 Z
updated_at: 2015-03-05 14:26:50.419102000 Z
', '2015-03-05 14:26:51.64386');
INSERT INTO versions VALUES (2385, 'Person', 443, 'update', NULL, '---
id: 443
salutation: 1
name: Dr. Roberto
lastnames: Dieppa Baéz
sex: true
role: 4
description: Ministro Ejecutivo
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:11:24.743812000 Z
updated_at: 2015-03-05 11:09:24.884758000 Z
', '2015-03-05 14:27:10.222507');
INSERT INTO versions VALUES (2386, 'Person', 111, 'update', NULL, '---
id: 111
salutation: 1
name: ''Edwin ''
lastnames: ''Mojica ''
sex: true
role: 4
description: Vocal
attended: false
printed: true
materials: false
church_id: 60
created_at: 2015-02-24 02:34:40.419461000 Z
updated_at: 2015-03-04 20:19:56.510616000 Z
', '2015-03-05 14:27:36.413001');
INSERT INTO versions VALUES (2387, 'Person', 78, 'update', NULL, '---
id: 78
salutation: 1
name: ''César ''
lastnames: ''Maurás ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:12:58.693612000 Z
updated_at: 2015-03-02 19:21:03.386415000 Z
', '2015-03-05 14:29:09.916782');
INSERT INTO versions VALUES (2388, 'Person', 78, 'update', NULL, '---
id: 78
salutation: 1
name: ''César ''
lastnames: ''Maurás ''
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:12:58.693612000 Z
updated_at: 2015-03-05 14:29:09.907144000 Z
', '2015-03-05 14:29:12.663774');
INSERT INTO versions VALUES (2389, 'Person', 439, 'destroy', NULL, '---
id: 439
salutation: 
name: Xiomara A.
lastnames: Medina Ramos
sex: false
role: 4
description: Unión de Jóvenes Bautista de P.R.
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:06:10.236140000 Z
updated_at: 2015-03-04 20:09:49.741649000 Z
', '2015-03-05 14:30:55.069448');
INSERT INTO versions VALUES (2390, 'Person', 387, 'update', NULL, '---
id: 387
salutation: 
name: Julio
lastnames: Quiros
sex: true
role: 4
description: Representante General
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:46:11.562372000 Z
updated_at: 2015-03-04 19:47:19.109645000 Z
', '2015-03-05 14:31:41.791138');
INSERT INTO versions VALUES (2391, 'Person', 387, 'update', NULL, '---
id: 387
salutation: 
name: Julio
lastnames: Quiros
sex: true
role: 4
description: Representante General
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:46:11.562372000 Z
updated_at: 2015-03-05 14:31:41.781503000 Z
', '2015-03-05 14:31:43.210151');
INSERT INTO versions VALUES (2392, 'Person', 448, 'update', NULL, '---
id: 448
salutation: 2
name: Manuel
lastnames: Sarrias
sex: true
role: 5
description: Ministro Ejecutivo España
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:15:42.059218000 Z
updated_at: 2015-03-04 20:19:56.650558000 Z
', '2015-03-05 14:34:50.86782');
INSERT INTO versions VALUES (2393, 'Person', 448, 'update', NULL, '---
id: 448
salutation: 2
name: Manuel
lastnames: Sarrias
sex: true
role: 5
description: Ministro Ejecutivo España
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:15:42.059218000 Z
updated_at: 2015-03-05 14:34:50.857249000 Z
', '2015-03-05 14:34:53.374608');
INSERT INTO versions VALUES (2394, 'Person', 537, 'create', NULL, NULL, '2015-03-05 14:36:21.973599');
INSERT INTO versions VALUES (2395, 'Person', 538, 'create', NULL, NULL, '2015-03-05 14:36:37.776144');
INSERT INTO versions VALUES (2396, 'Person', 538, 'destroy', NULL, '---
id: 538
salutation: 
name: Damaris
lastnames: Diaz
sex: false
role: 5
description: Visita
attended: true
printed: false
materials: true
church_id: 
created_at: 2015-03-05 14:36:37.771662000 Z
updated_at: 2015-03-05 14:36:37.771662000 Z
', '2015-03-05 14:37:16.142251');
INSERT INTO versions VALUES (2399, 'Person', 245, 'update', NULL, '---
id: 245
salutation: 0
name: ''Luis ''
lastnames: Serrano
sex: true
role: 4
description: Representante General
attended: false
printed: true
materials: false
church_id: 6
created_at: 2015-02-24 15:14:15.607845000 Z
updated_at: 2015-03-04 20:21:00.218501000 Z
', '2015-03-05 14:45:07.198674');
INSERT INTO versions VALUES (2398, 'Person', 537, 'update', NULL, '---
id: 537
salutation: 
name: Damaris
lastnames: Diaz
sex: false
role: 5
description: ''''
attended: true
printed: false
materials: true
church_id: 
created_at: 2015-03-05 14:36:21.966876000 Z
updated_at: 2015-03-05 14:36:21.966876000 Z
', '2015-03-05 14:44:03.555799');
INSERT INTO versions VALUES (2438, 'Person', 498, 'update', NULL, '---
id: 498
salutation: 
name: ''Jose M ''
lastnames: Cariño
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 43
created_at: 2015-03-05 13:02:15.031993000 Z
updated_at: 2015-03-05 14:56:20.765089000 Z
', '2015-03-05 15:26:07.27672');
INSERT INTO versions VALUES (2439, 'Person', 539, 'update', NULL, '---
id: 539
salutation: 0
name: ''Felix ''
lastnames: Veléz
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 63
created_at: 2015-03-05 15:08:08.745526000 Z
updated_at: 2015-03-05 15:08:08.745526000 Z
', '2015-03-05 15:26:07.341438');
INSERT INTO versions VALUES (2456, 'Person', 144, 'update', NULL, '---
id: 144
salutation: 0
name: ''Omar A. ''
lastnames: ''Santiago ''
sex: true
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:36:11.543037000 Z
updated_at: 2015-03-02 19:21:32.694638000 Z
', '2015-03-05 16:19:39.102637');
INSERT INTO versions VALUES (2457, 'Person', 144, 'update', NULL, '---
id: 144
salutation: 0
name: ''Omar A. ''
lastnames: ''Santiago ''
sex: true
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:36:11.543037000 Z
updated_at: 2015-03-05 16:19:39.096102000 Z
', '2015-03-05 16:19:41.722953');
INSERT INTO versions VALUES (2458, 'Person', 441, 'update', NULL, '---
id: 441
salutation: 
name: ''Gloria ''
lastnames: Vázquez
sex: false
role: 4
description: Comisión de Eduación Cristiana
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:09:32.032224000 Z
updated_at: 2015-03-04 20:09:49.756798000 Z
', '2015-03-05 16:24:10.522582');
INSERT INTO versions VALUES (2459, 'Person', 441, 'update', NULL, '---
id: 441
salutation: 
name: ''Gloria ''
lastnames: Vázquez
sex: false
role: 4
description: Comisión de Eduación Cristiana
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:09:32.032224000 Z
updated_at: 2015-03-05 16:24:10.512661000 Z
', '2015-03-05 16:24:11.430883');
INSERT INTO versions VALUES (2460, 'Person', 441, 'update', NULL, '---
id: 441
salutation: 
name: ''Gloria ''
lastnames: Vázquez
sex: false
role: 4
description: Comisión de Eduación Cristiana
attended: true
printed: true
materials: true
church_id: 
created_at: 2015-03-04 20:09:32.032224000 Z
updated_at: 2015-03-05 16:24:11.422016000 Z
', '2015-03-05 16:25:21.398172');
INSERT INTO versions VALUES (2461, 'Person', 441, 'update', NULL, '---
id: 441
salutation: 
name: ''Gloria ''
lastnames: Vázquez
sex: false
role: 4
description: Comisión de Eduación Cristiana
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:09:32.032224000 Z
updated_at: 2015-03-05 16:25:21.391543000 Z
', '2015-03-05 16:25:24.158752');
INSERT INTO versions VALUES (2462, 'Person', 441, 'update', NULL, '---
id: 441
salutation: 
name: ''Gloria ''
lastnames: Vázquez
sex: false
role: 4
description: Comisión de Eduación Cristiana
attended: true
printed: true
materials: true
church_id: 
created_at: 2015-03-04 20:09:32.032224000 Z
updated_at: 2015-03-05 16:25:24.143825000 Z
', '2015-03-05 16:26:30.680811');
INSERT INTO versions VALUES (2463, 'Person', 441, 'update', NULL, '---
id: 441
salutation: 
name: ''Gloria ''
lastnames: Vázquez
sex: false
role: 4
description: Comisión de Eduación Cristiana
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:09:32.032224000 Z
updated_at: 2015-03-05 16:26:30.672880000 Z
', '2015-03-05 16:27:22.989286');
INSERT INTO versions VALUES (2464, 'Church', 127, 'create', NULL, NULL, '2015-03-05 16:46:20.608786');
INSERT INTO versions VALUES (2465, 'Person', 542, 'create', NULL, NULL, '2015-03-05 16:48:10.199934');
INSERT INTO versions VALUES (2466, 'Person', 543, 'create', NULL, NULL, '2015-03-05 16:48:35.888092');
INSERT INTO versions VALUES (2467, 'Person', 327, 'update', NULL, '---
id: 327
salutation: 
name: ''Carmelo ''
lastnames: ''Rivera ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 41
created_at: 2015-03-02 19:46:51.495269000 Z
updated_at: 2015-03-02 19:47:09.109413000 Z
', '2015-03-05 16:50:53.6182');
INSERT INTO versions VALUES (2468, 'Person', 327, 'update', NULL, '---
id: 327
salutation: 
name: ''Carmelo ''
lastnames: ''Rivera ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 41
created_at: 2015-03-02 19:46:51.495269000 Z
updated_at: 2015-03-05 16:50:53.608979000 Z
', '2015-03-05 16:50:55.610584');
INSERT INTO versions VALUES (2469, 'Person', 489, 'update', NULL, '---
id: 489
salutation: 
name: ''Dorcas ''
lastnames: Santiago Gonzalez
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 78
created_at: 2015-03-05 12:50:43.491764000 Z
updated_at: 2015-03-05 12:51:12.939690000 Z
', '2015-03-05 16:52:10.826144');
INSERT INTO versions VALUES (2470, 'Person', 487, 'update', NULL, '---
id: 487
salutation: 
name: ''Heriberto ''
lastnames: Rivera Pabon
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: true
church_id: 78
created_at: 2015-03-05 12:49:48.909547000 Z
updated_at: 2015-03-05 12:51:12.926031000 Z
', '2015-03-05 16:52:17.626201');
INSERT INTO versions VALUES (2471, 'Person', 139, 'update', NULL, '---
id: 139
salutation: 1
name: ''Juan E. ''
lastnames: ''Matias ''
sex: true
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:31:25.127264000 Z
updated_at: 2015-03-02 19:21:24.200077000 Z
', '2015-03-05 16:53:41.714614');
INSERT INTO versions VALUES (2472, 'Person', 139, 'update', NULL, '---
id: 139
salutation: 1
name: ''Juan E. ''
lastnames: ''Matias ''
sex: true
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:31:25.127264000 Z
updated_at: 2015-03-05 16:53:41.705415000 Z
', '2015-03-05 16:53:43.518182');
INSERT INTO versions VALUES (2400, 'Person', 245, 'update', NULL, '---
id: 245
salutation: 0
name: ''Luis ''
lastnames: Serrano
sex: true
role: 4
description: Representante General
attended: true
printed: true
materials: false
church_id: 6
created_at: 2015-02-24 15:14:15.607845000 Z
updated_at: 2015-03-05 14:45:07.189772000 Z
', '2015-03-05 14:45:08.331826');
INSERT INTO versions VALUES (2401, 'Person', 80, 'update', NULL, '---
id: 80
salutation: 1
name: ''Yamina ''
lastnames: ''Apolinaris ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:13:57.475449000 Z
updated_at: 2015-03-02 19:21:07.069482000 Z
', '2015-03-05 14:50:45.50642');
INSERT INTO versions VALUES (2402, 'Person', 80, 'update', NULL, '---
id: 80
salutation: 1
name: ''Yamina ''
lastnames: ''Apolinaris ''
sex: false
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 13
created_at: 2015-02-24 02:13:57.475449000 Z
updated_at: 2015-03-05 14:50:45.497944000 Z
', '2015-03-05 14:50:48.023038');
INSERT INTO versions VALUES (2403, 'Person', 447, 'update', NULL, '---
id: 447
salutation: 
name: Mary
lastnames: Weaver
sex: false
role: 5
description: Asistente Admin. M.I.
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:14:55.937201000 Z
updated_at: 2015-03-04 20:30:15.023655000 Z
', '2015-03-05 14:53:54.470367');
INSERT INTO versions VALUES (2404, 'Person', 447, 'update', NULL, '---
id: 447
salutation: 
name: Mary
lastnames: Weaver
sex: false
role: 5
description: Asistente Admin. M.I.
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:14:55.937201000 Z
updated_at: 2015-03-05 14:53:54.460807000 Z
', '2015-03-05 14:53:55.857449');
INSERT INTO versions VALUES (2405, 'Person', 382, 'update', NULL, '---
id: 382
salutation: 1
name: ''Carlos ''
lastnames: Gomez
sex: true
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:43:50.921234000 Z
updated_at: 2015-03-04 19:44:15.817561000 Z
', '2015-03-05 14:55:44.777126');
INSERT INTO versions VALUES (2406, 'Person', 498, 'update', NULL, '---
id: 498
salutation: 
name: ''Jose M ''
lastnames: carillo
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: true
church_id: 43
created_at: 2015-03-05 13:02:15.031993000 Z
updated_at: 2015-03-05 13:05:21.318746000 Z
', '2015-03-05 14:56:01.960328');
INSERT INTO versions VALUES (2407, 'Person', 382, 'update', NULL, '---
id: 382
salutation: 1
name: ''Carlos ''
lastnames: Gomez
sex: true
role: 2
description: ''''
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:43:50.921234000 Z
updated_at: 2015-03-05 14:55:44.767505000 Z
', '2015-03-05 14:56:18.966065');
INSERT INTO versions VALUES (2408, 'Person', 498, 'update', NULL, '---
id: 498
salutation: 
name: ''Jose M ''
lastnames: Cariño
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: true
church_id: 43
created_at: 2015-03-05 13:02:15.031993000 Z
updated_at: 2015-03-05 14:56:01.956450000 Z
', '2015-03-05 14:56:20.771425');
INSERT INTO versions VALUES (2409, 'Person', 267, 'update', NULL, '---
id: 267
salutation: 
name: ''Wanda I. ''
lastnames: ''Rentas Morales ''
sex: false
role: 5
description: ''''
attended: true
printed: true
materials: true
church_id: 10
created_at: 2015-02-24 17:29:51.385662000 Z
updated_at: 2015-03-05 12:36:54.515989000 Z
', '2015-03-05 15:00:14.250879');
INSERT INTO versions VALUES (2410, 'Person', 381, 'update', NULL, '---
id: 381
salutation: 
name: Alexandra
lastnames: Zavala
sex: true
role: 4
description: Representante General
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:43:36.645025000 Z
updated_at: 2015-03-04 19:44:15.792061000 Z
', '2015-03-05 15:03:51.86416');
INSERT INTO versions VALUES (2411, 'Person', 381, 'update', NULL, '---
id: 381
salutation: 
name: Alexandra
lastnames: Zavala
sex: true
role: 4
description: Representante General
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:43:36.645025000 Z
updated_at: 2015-03-05 15:03:51.852990000 Z
', '2015-03-05 15:03:56.214133');
INSERT INTO versions VALUES (2412, 'Person', 352, 'update', NULL, '---
id: 352
salutation: 1
name: Luis F.
lastnames: Alicea Caraballo
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 55
created_at: 2015-03-04 11:04:46.844147000 Z
updated_at: 2015-03-04 21:22:33.660285000 Z
', '2015-03-05 15:04:15.612086');
INSERT INTO versions VALUES (2413, 'Person', 352, 'update', NULL, '---
id: 352
salutation: 1
name: Luis F.
lastnames: Alicea Caraballo
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 55
created_at: 2015-03-04 11:04:46.844147000 Z
updated_at: 2015-03-05 15:04:15.602297000 Z
', '2015-03-05 15:04:17.53817');
INSERT INTO versions VALUES (2414, 'Person', 209, 'update', NULL, '---
id: 209
salutation: 
name: ''Víctor ''
lastnames: Valentín
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 84
created_at: 2015-02-24 14:44:22.637707000 Z
updated_at: 2015-03-02 19:23:13.651663000 Z
', '2015-03-05 15:04:38.521258');
INSERT INTO versions VALUES (2415, 'Person', 209, 'update', NULL, '---
id: 209
salutation: 
name: ''Víctor ''
lastnames: Valentín
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 84
created_at: 2015-02-24 14:44:22.637707000 Z
updated_at: 2015-03-05 15:04:38.512785000 Z
', '2015-03-05 15:04:39.821881');
INSERT INTO versions VALUES (2416, 'Person', 380, 'update', NULL, '---
id: 380
salutation: 1
name: ''Dr. Daniel Luis ''
lastnames: Flores
sex: true
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:42:34.058117000 Z
updated_at: 2015-03-04 19:44:15.779993000 Z
', '2015-03-05 15:05:05.037371');
INSERT INTO versions VALUES (2417, 'Person', 380, 'update', NULL, '---
id: 380
salutation: 1
name: ''Dr. Daniel Luis ''
lastnames: Flores
sex: true
role: 2
description: ''''
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:42:34.058117000 Z
updated_at: 2015-03-05 15:05:05.032800000 Z
', '2015-03-05 15:05:06.326683');
INSERT INTO versions VALUES (2418, 'Person', 268, 'update', NULL, '---
id: 268
salutation: 1
name: Carmen J.
lastnames: ''Pagan ''
sex: false
role: 3
description: Sustituto
attended: false
printed: true
materials: false
church_id: 103
created_at: 2015-02-24 17:33:42.659320000 Z
updated_at: 2015-03-02 19:21:52.915677000 Z
', '2015-03-05 15:05:08.013933');
INSERT INTO versions VALUES (2419, 'Person', 268, 'update', NULL, '---
id: 268
salutation: 1
name: Carmen J.
lastnames: ''Pagan ''
sex: false
role: 3
description: Sustituto
attended: true
printed: true
materials: false
church_id: 103
created_at: 2015-02-24 17:33:42.659320000 Z
updated_at: 2015-03-05 15:05:08.005558000 Z
', '2015-03-05 15:05:09.022446');
INSERT INTO versions VALUES (2420, 'Person', 386, 'update', NULL, '---
id: 386
salutation: 1
name: José
lastnames: Norat Rodríguez
sex: true
role: 5
description: Dir. Area Iberoamérica-Caribe Minist. Inter.
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:46:11.213459000 Z
updated_at: 2015-03-04 19:47:19.102863000 Z
', '2015-03-05 15:05:58.160086');
INSERT INTO versions VALUES (2421, 'Person', 386, 'update', NULL, '---
id: 386
salutation: 1
name: José
lastnames: Norat Rodríguez
sex: true
role: 5
description: Dir. Area Iberoamérica-Caribe Minist. Inter.
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:46:11.213459000 Z
updated_at: 2015-03-05 15:05:58.149588000 Z
', '2015-03-05 15:05:59.361929');
INSERT INTO versions VALUES (2422, 'Person', 77, 'update', NULL, '---
id: 77
salutation: 
name: ''Lorenzo A. ''
lastnames: ''Fuentes ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 64
created_at: 2015-02-24 02:11:56.858646000 Z
updated_at: 2015-03-02 19:22:45.990580000 Z
', '2015-03-05 15:06:09.474382');
INSERT INTO versions VALUES (2423, 'Person', 77, 'update', NULL, '---
id: 77
salutation: 
name: ''Lorenzo A. ''
lastnames: ''Fuentes ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 64
created_at: 2015-02-24 02:11:56.858646000 Z
updated_at: 2015-03-05 15:06:09.468110000 Z
', '2015-03-05 15:06:16.102949');
INSERT INTO versions VALUES (2424, 'Person', 539, 'create', NULL, NULL, '2015-03-05 15:08:08.751482');
INSERT INTO versions VALUES (2425, 'Check', 62, 'create', NULL, NULL, '2015-03-05 15:08:25.059519');
INSERT INTO versions VALUES (2426, 'Person', 370, 'update', NULL, '---
id: 370
salutation: 1
name: Dra. Doris
lastnames: García
sex: true
role: 5
description: Presidenta, SEPR
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:34:30.906062000 Z
updated_at: 2015-03-04 19:44:15.787550000 Z
', '2015-03-05 15:08:54.689209');
INSERT INTO versions VALUES (2427, 'Person', 370, 'update', NULL, '---
id: 370
salutation: 1
name: Dra. Doris
lastnames: García
sex: true
role: 5
description: Presidenta, SEPR
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:34:30.906062000 Z
updated_at: 2015-03-05 15:08:54.683402000 Z
', '2015-03-05 15:08:55.965472');
INSERT INTO versions VALUES (2428, 'Person', 131, 'update', NULL, '---
id: 131
salutation: 0
name: ''Glenda L. ''
lastnames: ''De León ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 65
created_at: 2015-02-24 02:48:14.616949000 Z
updated_at: 2015-03-02 19:23:25.727843000 Z
', '2015-03-05 15:09:11.032577');
INSERT INTO versions VALUES (2429, 'Person', 131, 'update', NULL, '---
id: 131
salutation: 0
name: ''Glenda L. ''
lastnames: ''De León ''
sex: false
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 65
created_at: 2015-02-24 02:48:14.616949000 Z
updated_at: 2015-03-05 15:09:11.024502000 Z
', '2015-03-05 15:09:12.639757');
INSERT INTO versions VALUES (2430, 'Person', 110, 'update', NULL, '---
id: 110
salutation: 
name: ''Wanda ''
lastnames: ''Acevedo ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 87
created_at: 2015-02-24 02:34:06.462161000 Z
updated_at: 2015-03-05 13:19:19.658801000 Z
', '2015-03-05 15:14:29.153755');
INSERT INTO versions VALUES (2431, 'Person', 110, 'update', NULL, '---
id: 110
salutation: 
name: ''Wanda ''
lastnames: ''Acevedo ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 87
created_at: 2015-02-24 02:34:06.462161000 Z
updated_at: 2015-03-05 15:14:29.145256000 Z
', '2015-03-05 15:14:31.232491');
INSERT INTO versions VALUES (2432, 'Person', 288, 'update', NULL, '---
id: 288
salutation: 
name: ''Rosa ''
lastnames: ''Capellán ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 27
created_at: 2015-02-27 02:30:14.499799000 Z
updated_at: 2015-03-05 11:49:10.242837000 Z
', '2015-03-05 15:15:23.517839');
INSERT INTO versions VALUES (2433, 'Person', 288, 'update', NULL, '---
id: 288
salutation: 
name: ''Rosa ''
lastnames: ''Capellán ''
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 27
created_at: 2015-02-27 02:30:14.499799000 Z
updated_at: 2015-03-05 15:15:23.513858000 Z
', '2015-03-05 15:17:11.815721');
INSERT INTO versions VALUES (2434, 'Person', 373, 'update', NULL, '---
id: 373
salutation: 1
name: Deliris
lastnames: Carrión
sex: false
role: 5
description: Misionera en Haíti
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:35:40.279900000 Z
updated_at: 2015-03-04 20:21:00.231759000 Z
', '2015-03-05 15:21:08.013591');
INSERT INTO versions VALUES (2435, 'Person', 373, 'update', NULL, '---
id: 373
salutation: 1
name: Deliris
lastnames: Carrión
sex: false
role: 5
description: Misionera en Haíti
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:35:40.279900000 Z
updated_at: 2015-03-05 15:21:08.004755000 Z
', '2015-03-05 15:21:09.695629');
INSERT INTO versions VALUES (2436, 'Person', 112, 'update', NULL, '---
id: 112
salutation: 1
name: ''Norma I. ''
lastnames: ''Torres ''
sex: false
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 60
created_at: 2015-02-24 02:35:11.391098000 Z
updated_at: 2015-03-02 19:22:42.556980000 Z
', '2015-03-05 15:24:32.819438');
INSERT INTO versions VALUES (2437, 'Person', 112, 'update', NULL, '---
id: 112
salutation: 1
name: ''Norma I. ''
lastnames: ''Torres ''
sex: false
role: 2
description: ''''
attended: true
printed: true
materials: false
church_id: 60
created_at: 2015-02-24 02:35:11.391098000 Z
updated_at: 2015-03-05 15:24:32.803594000 Z
', '2015-03-05 15:24:34.341417');
INSERT INTO versions VALUES (2440, 'Person', 223, 'update', NULL, '---
id: 223
salutation: 1
name: ''Myrna I. ''
lastnames: Ramos
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 1
created_at: 2015-02-24 15:00:38.844886000 Z
updated_at: 2015-03-02 19:21:13.925564000 Z
', '2015-03-05 15:28:20.464003');
INSERT INTO versions VALUES (2441, 'Person', 223, 'update', NULL, '---
id: 223
salutation: 1
name: ''Myrna I. ''
lastnames: Ramos
sex: false
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 1
created_at: 2015-02-24 15:00:38.844886000 Z
updated_at: 2015-03-05 15:28:20.454588000 Z
', '2015-03-05 15:28:21.88541');
INSERT INTO versions VALUES (2442, 'Person', 292, 'update', NULL, '---
id: 292
salutation: 0
name: ''Karilyn ''
lastnames: ''Galarza ''
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 98
created_at: 2015-02-27 02:37:13.680893000 Z
updated_at: 2015-03-02 19:21:32.736502000 Z
', '2015-03-05 15:30:43.994755');
INSERT INTO versions VALUES (2443, 'Person', 292, 'update', NULL, '---
id: 292
salutation: 0
name: ''Karilyn ''
lastnames: ''Galarza ''
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 98
created_at: 2015-02-27 02:37:13.680893000 Z
updated_at: 2015-03-05 15:30:43.987158000 Z
', '2015-03-05 15:30:45.487502');
INSERT INTO versions VALUES (2444, 'Person', 293, 'update', NULL, '---
id: 293
salutation: 
name: ''Diana ''
lastnames: ''Medina ''
sex: false
role: 4
description: ''''
attended: false
printed: true
materials: false
church_id: 98
created_at: 2015-02-27 02:37:49.971019000 Z
updated_at: 2015-03-02 19:21:32.729340000 Z
', '2015-03-05 15:30:57.758531');
INSERT INTO versions VALUES (2445, 'Person', 293, 'update', NULL, '---
id: 293
salutation: 
name: ''Diana ''
lastnames: ''Medina ''
sex: false
role: 4
description: ''''
attended: true
printed: true
materials: false
church_id: 98
created_at: 2015-02-27 02:37:49.971019000 Z
updated_at: 2015-03-05 15:30:57.749725000 Z
', '2015-03-05 15:30:58.841319');
INSERT INTO versions VALUES (2446, 'Person', 292, 'update', NULL, '---
id: 292
salutation: 0
name: ''Karilyn ''
lastnames: ''Galarza ''
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: true
church_id: 98
created_at: 2015-02-27 02:37:13.680893000 Z
updated_at: 2015-03-05 15:30:45.477955000 Z
', '2015-03-05 15:32:04.529496');
INSERT INTO versions VALUES (2447, 'Person', 292, 'update', NULL, '---
id: 292
salutation: 0
name: ''Karilyn ''
lastnames: ''Galarza ''
sex: false
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 98
created_at: 2015-02-27 02:37:13.680893000 Z
updated_at: 2015-03-05 15:32:04.520840000 Z
', '2015-03-05 15:32:51.27683');
INSERT INTO versions VALUES (2448, 'Person', 52, 'update', NULL, '---
id: 52
salutation: 
name: ''Wilfredo ''
lastnames: ''Mercado ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 7
created_at: 2015-02-24 01:56:28.001371000 Z
updated_at: 2015-03-02 19:20:45.370543000 Z
', '2015-03-05 15:37:35.617631');
INSERT INTO versions VALUES (2449, 'Person', 52, 'update', NULL, '---
id: 52
salutation: 
name: ''Wilfredo ''
lastnames: ''Mercado ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 7
created_at: 2015-02-24 01:56:28.001371000 Z
updated_at: 2015-03-05 15:37:35.607788000 Z
', '2015-03-05 15:37:36.309662');
INSERT INTO versions VALUES (2450, 'Person', 540, 'create', NULL, NULL, '2015-03-05 15:39:27.618615');
INSERT INTO versions VALUES (2451, 'Person', 541, 'create', NULL, NULL, '2015-03-05 15:48:45.700636');
INSERT INTO versions VALUES (2452, 'Person', 422, 'update', NULL, '---
id: 422
salutation: 1
name: Don
lastnames: Ng
sex: true
role: 5
description: Presidente IBA
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:58:55.198491000 Z
updated_at: 2015-03-04 19:59:39.504164000 Z
', '2015-03-05 15:58:08.073512');
INSERT INTO versions VALUES (2453, 'Person', 422, 'update', NULL, '---
id: 422
salutation: 1
name: Don
lastnames: Ng
sex: true
role: 5
description: Presidente IBA
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:58:55.198491000 Z
updated_at: 2015-03-05 15:58:08.064116000 Z
', '2015-03-05 15:58:10.473351');
INSERT INTO versions VALUES (2454, 'Person', 540, 'update', NULL, '---
id: 540
salutation: 
name: María C.
lastnames: Torres Rodríguez
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 112
created_at: 2015-03-05 15:39:27.615587000 Z
updated_at: 2015-03-05 15:39:27.615587000 Z
', '2015-03-05 16:09:10.575263');
INSERT INTO versions VALUES (2455, 'Person', 541, 'update', NULL, '---
id: 541
salutation: 3
name: Josué
lastnames: Gómez
sex: true
role: 4
description: ''''
attended: true
printed: false
materials: true
church_id: 
created_at: 2015-03-05 15:48:45.698732000 Z
updated_at: 2015-03-05 15:48:45.698732000 Z
', '2015-03-05 16:09:10.915072');
INSERT INTO versions VALUES (2473, 'Person', 321, 'update', NULL, '---
id: 321
salutation: 1
name: Carmen Z.
lastnames: Díaz
sex: false
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 77
created_at: 2015-03-02 19:41:17.833786000 Z
updated_at: 2015-03-02 19:42:04.744795000 Z
', '2015-03-05 16:54:39.126322');
INSERT INTO versions VALUES (2474, 'Person', 321, 'update', NULL, '---
id: 321
salutation: 1
name: Carmen Z.
lastnames: Díaz
sex: false
role: 2
description: ''''
attended: true
printed: true
materials: false
church_id: 77
created_at: 2015-03-02 19:41:17.833786000 Z
updated_at: 2015-03-05 16:54:39.117451000 Z
', '2015-03-05 16:54:40.675207');
INSERT INTO versions VALUES (2475, 'Check', 63, 'create', NULL, NULL, '2015-03-05 17:09:52.193507');
INSERT INTO versions VALUES (2476, 'Check', 64, 'create', NULL, NULL, '2015-03-05 17:11:53.615511');
INSERT INTO versions VALUES (2477, 'Person', 542, 'update', NULL, '---
id: 542
salutation: 
name: María E.
lastnames: Lozada
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 127
created_at: 2015-03-05 16:48:10.197718000 Z
updated_at: 2015-03-05 16:48:10.197718000 Z
', '2015-03-05 17:17:16.150017');
INSERT INTO versions VALUES (2478, 'Person', 543, 'update', NULL, '---
id: 543
salutation: 
name: Héctor
lastnames: Fonseca
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 127
created_at: 2015-03-05 16:48:35.884359000 Z
updated_at: 2015-03-05 16:48:35.884359000 Z
', '2015-03-05 17:17:16.260743');
INSERT INTO versions VALUES (2479, 'Person', 489, 'update', NULL, '---
id: 489
salutation: 
name: ''Dorcas ''
lastnames: Santiago Gonzalez
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 78
created_at: 2015-03-05 12:50:43.491764000 Z
updated_at: 2015-03-05 16:52:10.822176000 Z
', '2015-03-05 17:17:16.268688');
INSERT INTO versions VALUES (2480, 'Person', 487, 'update', NULL, '---
id: 487
salutation: 
name: ''Heriberto ''
lastnames: Rivera Pabon
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 78
created_at: 2015-03-05 12:49:48.909547000 Z
updated_at: 2015-03-05 16:52:17.622820000 Z
', '2015-03-05 17:17:16.280742');
INSERT INTO versions VALUES (2481, 'Person', 544, 'create', NULL, NULL, '2015-03-05 17:17:45.98347');
INSERT INTO versions VALUES (2482, 'Check', 65, 'create', NULL, NULL, '2015-03-05 17:37:20.68833');
INSERT INTO versions VALUES (2483, 'Person', 545, 'create', NULL, NULL, '2015-03-05 17:43:14.915712');
INSERT INTO versions VALUES (2484, 'Person', 544, 'update', NULL, '---
id: 544
salutation: 0
name: María M.
lastnames: Maysonet
sex: false
role: 2
description: ''''
attended: true
printed: false
materials: true
church_id: 123
created_at: 2015-03-05 17:17:45.981067000 Z
updated_at: 2015-03-05 17:17:45.981067000 Z
', '2015-03-05 17:47:18.771554');
INSERT INTO versions VALUES (2485, 'Person', 545, 'update', NULL, '---
id: 545
salutation: 1
name: Pedro
lastnames: Hernández Cortés
sex: true
role: 2
description: ''''
attended: true
printed: false
materials: true
church_id: 53
created_at: 2015-03-05 17:43:14.912393000 Z
updated_at: 2015-03-05 17:43:14.912393000 Z
', '2015-03-05 17:47:18.956634');
INSERT INTO versions VALUES (2486, 'Person', 17, 'update', NULL, '---
id: 17
salutation: 1
name: ''David ''
lastnames: ''Valentín ''
sex: true
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 3
created_at: 2015-02-24 01:24:22.065414000 Z
updated_at: 2015-03-02 19:21:56.784549000 Z
', '2015-03-05 17:50:45.306618');
INSERT INTO versions VALUES (2487, 'Person', 17, 'update', NULL, '---
id: 17
salutation: 1
name: ''David ''
lastnames: ''Valentín ''
sex: true
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 3
created_at: 2015-02-24 01:24:22.065414000 Z
updated_at: 2015-03-05 17:50:45.302087000 Z
', '2015-03-05 17:50:46.255326');
INSERT INTO versions VALUES (2488, 'Person', 126, 'update', NULL, '---
id: 126
salutation: 
name: ''Abner E. ''
lastnames: ''Cotto ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 56
created_at: 2015-02-24 02:42:55.836961000 Z
updated_at: 2015-03-02 19:22:55.509093000 Z
', '2015-03-05 18:17:04.147612');
INSERT INTO versions VALUES (2489, 'Person', 126, 'update', NULL, '---
id: 126
salutation: 
name: ''Abner E. ''
lastnames: ''Cotto ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 56
created_at: 2015-02-24 02:42:55.836961000 Z
updated_at: 2015-03-05 18:17:04.138621000 Z
', '2015-03-05 18:17:05.706316');
INSERT INTO versions VALUES (2490, 'Person', 167, 'update', NULL, '---
id: 167
salutation: 
name: ''Francisco ''
lastnames: ''Medina ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 20
created_at: 2015-02-24 13:54:46.987425000 Z
updated_at: 2015-03-02 19:22:47.488154000 Z
', '2015-03-05 18:31:26.409056');
INSERT INTO versions VALUES (2491, 'Person', 167, 'update', NULL, '---
id: 167
salutation: 
name: ''Francisco ''
lastnames: ''Medina ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 20
created_at: 2015-02-24 13:54:46.987425000 Z
updated_at: 2015-03-05 18:31:26.400206000 Z
', '2015-03-05 18:31:29.087319');
INSERT INTO versions VALUES (2492, 'Person', 168, 'update', NULL, '---
id: 168
salutation: 
name: ''Lilliana ''
lastnames: Landrón
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 20
created_at: 2015-02-24 13:55:10.762190000 Z
updated_at: 2015-03-02 19:22:47.498048000 Z
', '2015-03-05 19:07:02.928087');
INSERT INTO versions VALUES (2493, 'Person', 168, 'update', NULL, '---
id: 168
salutation: 
name: ''Lilliana ''
lastnames: Landrón
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 20
created_at: 2015-02-24 13:55:10.762190000 Z
updated_at: 2015-03-05 19:07:02.920414000 Z
', '2015-03-05 19:07:05.804064');
INSERT INTO versions VALUES (2494, 'Person', 445, 'update', NULL, '---
id: 445
salutation: 1
name: Noelia
lastnames: Rodríguez
sex: false
role: 4
description: Ministra Ejecutiva Asociada
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:12:43.119888000 Z
updated_at: 2015-03-05 10:58:44.328077000 Z
', '2015-03-05 19:13:55.791607');
INSERT INTO versions VALUES (2495, 'Person', 445, 'update', NULL, '---
id: 445
salutation: 1
name: Noelia
lastnames: Rodríguez
sex: false
role: 4
description: Ministra Ejecutiva Asociada
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 20:12:43.119888000 Z
updated_at: 2015-03-05 19:13:55.781939000 Z
', '2015-03-05 19:13:57.218407');
INSERT INTO versions VALUES (2496, 'Person', 546, 'create', NULL, NULL, '2015-03-05 19:16:44.973874');
INSERT INTO versions VALUES (2497, 'Person', 547, 'create', NULL, NULL, '2015-03-06 11:35:20.81063');
INSERT INTO versions VALUES (2498, 'Person', 547, 'update', NULL, '---
id: 547
salutation: 
name: Edwin
lastnames: Cancel
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 116
created_at: 2015-03-06 11:35:20.713531000 Z
updated_at: 2015-03-06 11:35:20.713531000 Z
', '2015-03-06 12:04:56.737278');
INSERT INTO versions VALUES (2499, 'Person', 240, 'update', NULL, '---
id: 240
salutation: 
name: ''Priscilla ''
lastnames: Esteves Ponde de León
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 71
created_at: 2015-02-24 15:11:09.635891000 Z
updated_at: 2015-03-02 19:22:56.107741000 Z
', '2015-03-06 12:05:16.303076');
INSERT INTO versions VALUES (2500, 'Person', 240, 'update', NULL, '---
id: 240
salutation: 
name: ''Priscilla ''
lastnames: Esteves Ponde de León
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 71
created_at: 2015-02-24 15:11:09.635891000 Z
updated_at: 2015-03-06 12:05:16.222864000 Z
', '2015-03-06 12:05:19.473574');
INSERT INTO versions VALUES (2501, 'Person', 239, 'update', NULL, '---
id: 239
salutation: 
name: ''Robert ''
lastnames: Quintero Negrón
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 71
created_at: 2015-02-24 15:10:43.116616000 Z
updated_at: 2015-03-02 19:22:59.234674000 Z
', '2015-03-06 12:05:57.568146');
INSERT INTO versions VALUES (2502, 'Person', 239, 'update', NULL, '---
id: 239
salutation: 
name: ''Robert ''
lastnames: Quintero Negrón
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 71
created_at: 2015-02-24 15:10:43.116616000 Z
updated_at: 2015-03-06 12:05:57.558796000 Z
', '2015-03-06 12:05:59.964122');
INSERT INTO versions VALUES (2503, 'Person', 547, 'update', NULL, '---
id: 547
salutation: 
name: Edwin
lastnames: Cancel
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 116
created_at: 2015-03-06 11:35:20.713531000 Z
updated_at: 2015-03-06 12:04:56.720468000 Z
', '2015-03-06 12:06:20.128208');
INSERT INTO versions VALUES (2505, 'Person', 548, 'create', NULL, NULL, '2015-03-06 12:06:37.748118');
INSERT INTO versions VALUES (2504, 'Person', 547, 'update', NULL, '---
id: 547
salutation: 
name: Edwin
lastnames: Cancel
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 116
created_at: 2015-03-06 11:35:20.713531000 Z
updated_at: 2015-03-06 12:06:20.123318000 Z
', '2015-03-06 12:06:33.943933');
INSERT INTO versions VALUES (2506, 'Person', 413, 'update', NULL, '---
id: 413
salutation: 0
name: Migdalia
lastnames: Núñez
sex: false
role: 2
description: ''''
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:56:46.628594000 Z
updated_at: 2015-03-04 19:57:36.159355000 Z
', '2015-03-06 12:10:15.342851');
INSERT INTO versions VALUES (2507, 'Person', 413, 'update', NULL, '---
id: 413
salutation: 0
name: Migdalia
lastnames: Núñez
sex: false
role: 2
description: ''''
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:56:46.628594000 Z
updated_at: 2015-03-06 12:10:15.220631000 Z
', '2015-03-06 12:10:19.640347');
INSERT INTO versions VALUES (2508, 'Check', 66, 'create', NULL, NULL, '2015-03-06 12:11:01.258446');
INSERT INTO versions VALUES (2509, 'Check', 67, 'create', NULL, NULL, '2015-03-06 12:11:02.163632');
INSERT INTO versions VALUES (2510, 'Person', 547, 'update', NULL, '---
id: 547
salutation: 
name: Edwin
lastnames: Cancel
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 116
created_at: 2015-03-06 11:35:20.713531000 Z
updated_at: 2015-03-06 12:06:33.937234000 Z
', '2015-03-06 12:11:10.747418');
INSERT INTO versions VALUES (2511, 'Check', 68, 'create', NULL, NULL, '2015-03-06 12:11:50.633454');
INSERT INTO versions VALUES (2512, 'Person', 75, 'update', NULL, '---
id: 75
salutation: 
name: ''David ''
lastnames: ''Calderón ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 40
created_at: 2015-02-24 02:10:31.344285000 Z
updated_at: 2015-03-02 19:21:52.893119000 Z
', '2015-03-06 12:13:58.584459');
INSERT INTO versions VALUES (2513, 'Person', 75, 'update', NULL, '---
id: 75
salutation: 
name: ''David ''
lastnames: ''Calderón ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 40
created_at: 2015-02-24 02:10:31.344285000 Z
updated_at: 2015-03-06 12:13:58.575764000 Z
', '2015-03-06 12:13:59.902681');
INSERT INTO versions VALUES (2514, 'Person', 74, 'update', NULL, '---
id: 74
salutation: 
name: ''Luis ''
lastnames: ''López ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 40
created_at: 2015-02-24 02:09:58.047775000 Z
updated_at: 2015-03-02 19:21:52.901359000 Z
', '2015-03-06 12:14:02.368759');
INSERT INTO versions VALUES (2515, 'Person', 74, 'update', NULL, '---
id: 74
salutation: 
name: ''Luis ''
lastnames: ''López ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 40
created_at: 2015-02-24 02:09:58.047775000 Z
updated_at: 2015-03-06 12:14:02.359758000 Z
', '2015-03-06 12:14:03.135942');
INSERT INTO versions VALUES (2516, 'Check', 69, 'create', NULL, NULL, '2015-03-06 12:17:09.387364');
INSERT INTO versions VALUES (2517, 'Person', 186, 'update', NULL, '---
id: 186
salutation: 
name: ''Carmen ''
lastnames: ''Johnson ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 42
created_at: 2015-02-24 14:18:37.601020000 Z
updated_at: 2015-03-02 19:22:12.446809000 Z
', '2015-03-06 12:22:24.110083');
INSERT INTO versions VALUES (2518, 'Person', 186, 'update', NULL, '---
id: 186
salutation: 
name: Félix A.
lastnames: Torres
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 42
created_at: 2015-02-24 14:18:37.601020000 Z
updated_at: 2015-03-06 12:22:24.101641000 Z
', '2015-03-06 12:22:30.610799');
INSERT INTO versions VALUES (2519, 'Person', 186, 'update', NULL, '---
id: 186
salutation: 
name: Félix A.
lastnames: Torres
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 42
created_at: 2015-02-24 14:18:37.601020000 Z
updated_at: 2015-03-06 12:22:30.602587000 Z
', '2015-03-06 12:22:32.061113');
INSERT INTO versions VALUES (2520, 'Person', 186, 'update', NULL, '---
id: 186
salutation: 
name: Félix A.
lastnames: Torres
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 42
created_at: 2015-02-24 14:18:37.601020000 Z
updated_at: 2015-03-06 12:22:32.051851000 Z
', '2015-03-06 12:23:00.241966');
INSERT INTO versions VALUES (2521, 'Person', 354, 'update', NULL, '---
id: 354
salutation: 
name: Ramón
lastnames: García
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 55
created_at: 2015-03-04 11:05:35.219957000 Z
updated_at: 2015-03-04 20:52:30.303775000 Z
', '2015-03-06 12:30:15.152645');
INSERT INTO versions VALUES (2522, 'Person', 354, 'update', NULL, '---
id: 354
salutation: 
name: Ramón
lastnames: García
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 55
created_at: 2015-03-04 11:05:35.219957000 Z
updated_at: 2015-03-06 12:30:15.143286000 Z
', '2015-03-06 12:30:16.829692');
INSERT INTO versions VALUES (2523, 'Person', 278, 'update', NULL, '---
id: 278
salutation: 0
name: ''Germán ''
lastnames: Malavé
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: true
church_id: 11
created_at: 2015-02-25 14:45:14.416172000 Z
updated_at: 2015-03-05 11:44:50.264524000 Z
', '2015-03-06 12:33:58.961859');
INSERT INTO versions VALUES (2524, 'Person', 499, 'update', NULL, '---
id: 499
salutation: 
name: Richard D
lastnames: Braden Feliciano
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 43
created_at: 2015-03-05 13:03:09.861203000 Z
updated_at: 2015-03-05 13:05:21.324303000 Z
', '2015-03-06 12:36:43.925826');
INSERT INTO versions VALUES (2525, 'Person', 549, 'create', NULL, NULL, '2015-03-06 12:39:31.885501');
INSERT INTO versions VALUES (2526, 'Person', 548, 'update', NULL, '---
id: 548
salutation: 0
name: Luis
lastnames: Soto
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 125
created_at: 2015-03-06 12:06:37.744966000 Z
updated_at: 2015-03-06 12:06:37.744966000 Z
', '2015-03-06 12:40:21.391471');
INSERT INTO versions VALUES (2527, 'Person', 547, 'update', NULL, '---
id: 547
salutation: 
name: Edwin
lastnames: Cancel
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 116
created_at: 2015-03-06 11:35:20.713531000 Z
updated_at: 2015-03-06 12:11:10.741122000 Z
', '2015-03-06 12:40:21.445142');
INSERT INTO versions VALUES (2528, 'Person', 186, 'update', NULL, '---
id: 186
salutation: 
name: Félix A.
lastnames: Torres
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 42
created_at: 2015-02-24 14:18:37.601020000 Z
updated_at: 2015-03-06 12:23:00.232214000 Z
', '2015-03-06 12:40:21.490234');
INSERT INTO versions VALUES (2529, 'Person', 278, 'update', NULL, '---
id: 278
salutation: 0
name: ''Germán ''
lastnames: Malavé
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 11
created_at: 2015-02-25 14:45:14.416172000 Z
updated_at: 2015-03-06 12:33:58.956203000 Z
', '2015-03-06 12:40:21.511352');
INSERT INTO versions VALUES (2530, 'Person', 499, 'update', NULL, '---
id: 499
salutation: 
name: Richard D
lastnames: Braden Feliciano
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 43
created_at: 2015-03-05 13:03:09.861203000 Z
updated_at: 2015-03-06 12:36:43.917221000 Z
', '2015-03-06 12:40:21.539048');
INSERT INTO versions VALUES (2531, 'Person', 549, 'update', NULL, '---
id: 549
salutation: 0
name: José
lastnames: Torres
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 38
created_at: 2015-03-06 12:39:31.774863000 Z
updated_at: 2015-03-06 12:39:31.774863000 Z
', '2015-03-06 12:40:21.563247');
INSERT INTO versions VALUES (2532, 'Person', 550, 'create', NULL, NULL, '2015-03-06 12:41:18.189482');
INSERT INTO versions VALUES (2533, 'Person', 551, 'create', NULL, NULL, '2015-03-06 12:41:53.064609');
INSERT INTO versions VALUES (2534, 'Person', 174, 'update', NULL, '---
id: 174
salutation: 0
name: ''Rosalba ''
lastnames: Velez
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 24
created_at: 2015-02-24 14:01:17.186728000 Z
updated_at: 2015-03-02 19:20:59.460200000 Z
', '2015-03-06 12:43:07.419429');
INSERT INTO versions VALUES (2535, 'Person', 174, 'update', NULL, '---
id: 174
salutation: 0
name: ''Rosalba ''
lastnames: Velez
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 24
created_at: 2015-02-24 14:01:17.186728000 Z
updated_at: 2015-03-06 12:43:07.416496000 Z
', '2015-03-06 12:43:09.026981');
INSERT INTO versions VALUES (2536, 'Check', 70, 'create', NULL, NULL, '2015-03-06 12:44:50.733802');
INSERT INTO versions VALUES (2537, 'Person', 550, 'update', NULL, '---
id: 550
salutation: 0
name: Victor R.
lastnames: Medina
sex: true
role: 0
description: ''''
attended: true
printed: false
materials: true
church_id: 46
created_at: 2015-03-06 12:41:18.183018000 Z
updated_at: 2015-03-06 12:41:18.183018000 Z
', '2015-03-06 13:11:14.295579');
INSERT INTO versions VALUES (2538, 'Person', 551, 'update', NULL, '---
id: 551
salutation: 
name: ''Marcial ''
lastnames: Morales
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 46
created_at: 2015-03-06 12:41:53.058655000 Z
updated_at: 2015-03-06 12:41:53.058655000 Z
', '2015-03-06 13:11:14.440975');
INSERT INTO versions VALUES (2550, 'Person', 254, 'update', NULL, '---
id: 254
salutation: 
name: Noel Yamil
lastnames: ''Pacheco Alvarez ''
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 99
created_at: 2015-02-24 15:26:06.338909000 Z
updated_at: 2015-03-06 14:18:49.698511000 Z
', '2015-03-06 14:48:18.31829');
INSERT INTO versions VALUES (2560, 'Person', 2, 'update', NULL, '---
id: 2
salutation: 
name: ''Susano ''
lastnames: ''Luzunaris ''
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 108
created_at: 2015-02-23 22:22:37.697968000 Z
updated_at: 2015-03-06 15:01:03.988897000 Z
', '2015-03-06 15:30:22.210116');
INSERT INTO versions VALUES (2561, 'Person', 504, 'update', NULL, '---
id: 504
salutation: 
name: Kenyi
lastnames: Negrón
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 35
created_at: 2015-03-05 13:07:13.613380000 Z
updated_at: 2015-03-06 15:01:22.449514000 Z
', '2015-03-06 15:30:22.247541');
INSERT INTO versions VALUES (2562, 'Person', 505, 'update', NULL, '---
id: 505
salutation: 
name: Rafael
lastnames: Lebrón
sex: true
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 95
created_at: 2015-03-05 13:08:14.657405000 Z
updated_at: 2015-03-06 15:03:22.204518000 Z
', '2015-03-06 15:30:22.25683');
INSERT INTO versions VALUES (2563, 'Person', 552, 'update', NULL, '---
id: 552
salutation: 
name: Maria A.
lastnames: Molina
sex: false
role: 3
description: ''''
attended: true
printed: false
materials: true
church_id: 95
created_at: 2015-03-06 15:05:11.084802000 Z
updated_at: 2015-03-06 15:05:11.084802000 Z
', '2015-03-06 15:30:22.26072');
INSERT INTO versions VALUES (2566, 'Person', 553, 'update', NULL, '---
id: 553
salutation: 1
name: Eddie
lastnames: Cruz
sex: true
role: 5
description: Director Asociado Ejecutivo ABC USA
attended: true
printed: false
materials: true
church_id: 
created_at: 2015-03-06 15:30:48.911573000 Z
updated_at: 2015-03-06 15:31:29.832013000 Z
', '2015-03-06 16:00:24.517843');
INSERT INTO versions VALUES (2539, 'Person', 339, 'update', NULL, '---
id: 339
salutation: 
name: Rubén
lastnames: ''Jiménez ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 75
created_at: 2015-03-02 20:00:08.946664000 Z
updated_at: 2015-03-02 20:00:16.010615000 Z
', '2015-03-06 13:23:04.160424');
INSERT INTO versions VALUES (2540, 'Person', 339, 'update', NULL, '---
id: 339
salutation: 
name: Rubén
lastnames: ''Jiménez ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 75
created_at: 2015-03-02 20:00:08.946664000 Z
updated_at: 2015-03-06 13:23:04.150777000 Z
', '2015-03-06 13:23:06.467856');
INSERT INTO versions VALUES (2541, 'Check', 71, 'create', NULL, NULL, '2015-03-06 13:28:42.570679');
INSERT INTO versions VALUES (2542, 'Person', 336, 'update', NULL, '---
id: 336
salutation: 
name: ''Alexander ''
lastnames: ''Cruz ''
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 29
created_at: 2015-03-02 19:54:54.858849000 Z
updated_at: 2015-03-02 20:00:15.866581000 Z
', '2015-03-06 13:45:55.938642');
INSERT INTO versions VALUES (2543, 'Person', 336, 'update', NULL, '---
id: 336
salutation: 
name: ''Alexander ''
lastnames: ''Cruz ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 29
created_at: 2015-03-02 19:54:54.858849000 Z
updated_at: 2015-03-06 13:45:55.932714000 Z
', '2015-03-06 13:45:58.182665');
INSERT INTO versions VALUES (2544, 'Person', 369, 'update', NULL, '---
id: 369
salutation: 1
name: Heriberto
lastnames: Martínez
sex: true
role: 5
description: Secretario, SBPR
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:31:21.974401000 Z
updated_at: 2015-03-04 19:44:15.774616000 Z
', '2015-03-06 13:51:14.15478');
INSERT INTO versions VALUES (2545, 'Person', 369, 'update', NULL, '---
id: 369
salutation: 1
name: Heriberto
lastnames: Martínez
sex: true
role: 5
description: Secretario, SBPR
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:31:21.974401000 Z
updated_at: 2015-03-06 13:51:14.150281000 Z
', '2015-03-06 13:51:15.469796');
INSERT INTO versions VALUES (2546, 'Person', 369, 'update', NULL, '---
id: 369
salutation: 1
name: Heriberto
lastnames: Martínez
sex: true
role: 5
description: Secretario, SBPR
attended: true
printed: true
materials: true
church_id: 
created_at: 2015-03-04 19:31:21.974401000 Z
updated_at: 2015-03-06 13:51:15.466757000 Z
', '2015-03-06 13:51:52.724605');
INSERT INTO versions VALUES (2547, 'Person', 272, 'update', NULL, '---
id: 272
salutation: 
name: ''Debora ''
lastnames: Varona Guerrero
sex: false
role: 4
description: ''''
attended: false
printed: true
materials: false
church_id: 3
created_at: 2015-02-24 18:10:46.124550000 Z
updated_at: 2015-03-02 19:22:00.358862000 Z
', '2015-03-06 14:05:32.920834');
INSERT INTO versions VALUES (2548, 'Person', 272, 'update', NULL, '---
id: 272
salutation: 
name: ''Debora ''
lastnames: Varona Guerrero
sex: false
role: 4
description: ''''
attended: true
printed: true
materials: false
church_id: 3
created_at: 2015-02-24 18:10:46.124550000 Z
updated_at: 2015-03-06 14:05:32.912357000 Z
', '2015-03-06 14:05:36.11751');
INSERT INTO versions VALUES (2549, 'Person', 254, 'update', NULL, '---
id: 254
salutation: 
name: ''Noel Y. ''
lastnames: ''Pachecho Alvarez ''
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 99
created_at: 2015-02-24 15:26:06.338909000 Z
updated_at: 2015-03-05 13:58:16.103664000 Z
', '2015-03-06 14:18:49.709854');
INSERT INTO versions VALUES (2551, 'Person', 364, 'update', NULL, '---
id: 364
salutation: 1
name: Héctor F
lastnames: Soto
sex: true
role: 5
description: Secretario Interino CIPR
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 11:19:31.038158000 Z
updated_at: 2015-03-04 20:45:40.469062000 Z
', '2015-03-06 14:51:39.478953');
INSERT INTO versions VALUES (2552, 'Person', 364, 'update', NULL, '---
id: 364
salutation: 1
name: Héctor F
lastnames: Soto
sex: true
role: 5
description: Secretario Interino CIPR
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 11:19:31.038158000 Z
updated_at: 2015-03-06 14:51:39.469423000 Z
', '2015-03-06 14:51:41.833641');
INSERT INTO versions VALUES (2553, 'Person', 2, 'update', NULL, '---
id: 2
salutation: 
name: ''Susano ''
lastnames: ''Luzunaris ''
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 108
created_at: 2015-02-23 22:22:37.697968000 Z
updated_at: 2015-03-05 12:50:32.379455000 Z
', '2015-03-06 15:01:03.994312');
INSERT INTO versions VALUES (2554, 'Person', 504, 'update', NULL, '---
id: 504
salutation: 
name: Kenyi
lastnames: Negrón
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 35
created_at: 2015-03-05 13:07:13.613380000 Z
updated_at: 2015-03-05 13:16:32.887302000 Z
', '2015-03-06 15:01:22.454296');
INSERT INTO versions VALUES (2555, 'Person', 505, 'update', NULL, '---
id: 505
salutation: 
name: Rafael
lastnames: Negrón
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 95
created_at: 2015-03-05 13:08:14.657405000 Z
updated_at: 2015-03-05 13:16:32.898126000 Z
', '2015-03-06 15:01:43.93214');
INSERT INTO versions VALUES (2556, 'Person', 505, 'update', NULL, '---
id: 505
salutation: 
name: Rafael
lastnames: Negrón
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 95
created_at: 2015-03-05 13:08:14.657405000 Z
updated_at: 2015-03-06 15:01:43.922963000 Z
', '2015-03-06 15:01:48.464212');
INSERT INTO versions VALUES (2557, 'Person', 505, 'update', NULL, '---
id: 505
salutation: 
name: Rafael
lastnames: Negrón
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 95
created_at: 2015-03-05 13:08:14.657405000 Z
updated_at: 2015-03-06 15:01:48.455356000 Z
', '2015-03-06 15:03:14.907028');
INSERT INTO versions VALUES (2558, 'Person', 505, 'update', NULL, '---
id: 505
salutation: 
name: Rafael
lastnames: Lebrón
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 95
created_at: 2015-03-05 13:08:14.657405000 Z
updated_at: 2015-03-06 15:03:14.898044000 Z
', '2015-03-06 15:03:22.213662');
INSERT INTO versions VALUES (2559, 'Person', 552, 'create', NULL, NULL, '2015-03-06 15:05:11.091024');
INSERT INTO versions VALUES (2564, 'Person', 553, 'create', NULL, NULL, '2015-03-06 15:30:48.918434');
INSERT INTO versions VALUES (2565, 'Person', 553, 'update', NULL, '---
id: 553
salutation: 1
name: Eddie
lastnames: Cruz
sex: true
role: 5
description: ''''
attended: true
printed: false
materials: true
church_id: 
created_at: 2015-03-06 15:30:48.911573000 Z
updated_at: 2015-03-06 15:30:48.911573000 Z
', '2015-03-06 15:31:29.841638');
INSERT INTO versions VALUES (2567, 'Person', 134, 'update', NULL, '---
id: 134
salutation: 0
name: ''Lizette ''
lastnames: ''Hernández ''
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 23
created_at: 2015-02-24 02:52:08.030117000 Z
updated_at: 2015-03-02 19:20:52.889255000 Z
', '2015-03-06 17:26:26.966483');
INSERT INTO versions VALUES (2568, 'Person', 134, 'update', NULL, '---
id: 134
salutation: 0
name: ''Lizette ''
lastnames: ''Hernández ''
sex: false
role: 0
description: ''''
attended: true
printed: true
materials: false
church_id: 23
created_at: 2015-02-24 02:52:08.030117000 Z
updated_at: 2015-03-06 17:26:26.958687000 Z
', '2015-03-06 17:26:29.277963');
INSERT INTO versions VALUES (2569, 'Person', 507, 'update', NULL, '---
id: 507
salutation: 
name: Neftalí
lastnames: Saldaña
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 23
created_at: 2015-03-05 13:10:34.933910000 Z
updated_at: 2015-03-05 13:18:37.020667000 Z
', '2015-03-06 17:26:31.420493');
INSERT INTO versions VALUES (2570, 'Person', 507, 'update', NULL, '---
id: 507
salutation: 
name: Neftalí
lastnames: Saldaña
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: true
church_id: 23
created_at: 2015-03-05 13:10:34.933910000 Z
updated_at: 2015-03-06 17:26:31.398026000 Z
', '2015-03-06 17:26:32.980976');
INSERT INTO versions VALUES (2571, 'Person', 507, 'update', NULL, '---
id: 507
salutation: 
name: Neftalí
lastnames: Saldaña
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 23
created_at: 2015-03-05 13:10:34.933910000 Z
updated_at: 2015-03-06 17:26:32.972384000 Z
', '2015-03-06 17:26:58.701936');
INSERT INTO versions VALUES (2572, 'Person', 507, 'update', NULL, '---
id: 507
salutation: 
name: Neftalí
lastnames: Saldaña
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 23
created_at: 2015-03-05 13:10:34.933910000 Z
updated_at: 2015-03-06 17:26:58.692438000 Z
', '2015-03-06 17:27:00.40798');
INSERT INTO versions VALUES (2573, 'Person', 507, 'update', NULL, '---
id: 507
salutation: 
name: Neftalí
lastnames: Saldaña
sex: true
role: 3
description: ''''
attended: true
printed: true
materials: true
church_id: 23
created_at: 2015-03-05 13:10:34.933910000 Z
updated_at: 2015-03-06 17:27:00.396826000 Z
', '2015-03-06 17:27:05.823092');
INSERT INTO versions VALUES (2574, 'Person', 507, 'update', NULL, '---
id: 507
salutation: 
name: Neftalí
lastnames: Saldaña
sex: true
role: 3
description: ''''
attended: false
printed: true
materials: true
church_id: 23
created_at: 2015-03-05 13:10:34.933910000 Z
updated_at: 2015-03-06 17:27:05.814743000 Z
', '2015-03-06 17:27:07.566262');
INSERT INTO versions VALUES (2575, 'Person', 393, 'update', NULL, '---
id: 393
salutation: 
name: Gonzalo
lastnames: Alers
sex: true
role: 4
description: Representante Distrito
attended: false
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:49:31.948319000 Z
updated_at: 2015-03-04 19:50:22.475097000 Z
', '2015-03-07 12:23:03.721926');
INSERT INTO versions VALUES (2576, 'Person', 393, 'update', NULL, '---
id: 393
salutation: 
name: Gonzalo
lastnames: Alers
sex: true
role: 4
description: Representante Distrito
attended: true
printed: true
materials: false
church_id: 
created_at: 2015-03-04 19:49:31.948319000 Z
updated_at: 2015-03-07 12:23:03.672188000 Z
', '2015-03-07 12:23:04.867291');
INSERT INTO versions VALUES (2577, 'Person', 326, 'update', NULL, '---
id: 326
salutation: 0
name: Luis O.
lastnames: Arizmendi
sex: true
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 41
created_at: 2015-03-02 19:46:33.155905000 Z
updated_at: 2015-03-02 19:47:09.126753000 Z
', '2015-03-07 12:35:27.492382');
INSERT INTO versions VALUES (2578, 'Person', 326, 'update', NULL, '---
id: 326
salutation: 0
name: Luis O.
lastnames: Arizmendi
sex: true
role: 1
description: ''''
attended: true
printed: true
materials: false
church_id: 41
created_at: 2015-03-02 19:46:33.155905000 Z
updated_at: 2015-03-07 12:35:27.486912000 Z
', '2015-03-07 12:35:29.713036');
INSERT INTO versions VALUES (2579, 'Person', 329, 'update', NULL, '---
id: 329
salutation: 
name: ''Elena ''
lastnames: Rivera
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 41
created_at: 2015-03-02 19:47:39.758229000 Z
updated_at: 2015-03-02 19:53:12.392495000 Z
', '2015-03-07 13:11:41.477309');
INSERT INTO versions VALUES (2580, 'Person', 329, 'update', NULL, '---
id: 329
salutation: 
name: ''Elena ''
lastnames: Rivera
sex: false
role: 3
description: ''''
attended: true
printed: true
materials: false
church_id: 41
created_at: 2015-03-02 19:47:39.758229000 Z
updated_at: 2015-03-07 13:11:41.468516000 Z
', '2015-03-07 13:11:42.916784');
INSERT INTO versions VALUES (2581, 'Person', 114, 'update', NULL, '---
id: 114
salutation: 
name: ''Carmen ''
lastnames: ''Leduc ''
sex: false
role: 3
description: ''''
attended: false
printed: true
materials: false
church_id: 60
created_at: 2015-02-24 02:35:59.457418000 Z
updated_at: 2015-03-02 19:22:38.922802000 Z
', '2015-03-07 16:15:30.656878');


--
-- Name: versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marcel
--

SELECT pg_catalog.setval('versions_id_seq', 2581, true);


--
-- Name: checks_pkey; Type: CONSTRAINT; Schema: public; Owner: marcel; Tablespace: 
--

ALTER TABLE ONLY checks
    ADD CONSTRAINT checks_pkey PRIMARY KEY (id);


--
-- Name: churches_pkey; Type: CONSTRAINT; Schema: public; Owner: marcel; Tablespace: 
--

ALTER TABLE ONLY churches
    ADD CONSTRAINT churches_pkey PRIMARY KEY (id);


--
-- Name: people_pkey; Type: CONSTRAINT; Schema: public; Owner: marcel; Tablespace: 
--

ALTER TABLE ONLY people
    ADD CONSTRAINT people_pkey PRIMARY KEY (id);


--
-- Name: versions_pkey; Type: CONSTRAINT; Schema: public; Owner: marcel; Tablespace: 
--

ALTER TABLE ONLY versions
    ADD CONSTRAINT versions_pkey PRIMARY KEY (id);


--
-- Name: index_checks_on_church_id; Type: INDEX; Schema: public; Owner: marcel; Tablespace: 
--

CREATE INDEX index_checks_on_church_id ON checks USING btree (church_id);


--
-- Name: index_people_on_church_id; Type: INDEX; Schema: public; Owner: marcel; Tablespace: 
--

CREATE INDEX index_people_on_church_id ON people USING btree (church_id);


--
-- Name: index_versions_on_item_type_and_item_id; Type: INDEX; Schema: public; Owner: marcel; Tablespace: 
--

CREATE INDEX index_versions_on_item_type_and_item_id ON versions USING btree (item_type, item_id);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: marcel; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

