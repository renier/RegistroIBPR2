--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

--
-- Data for Name: checks; Type: TABLE DATA; Schema: public; Owner: registroibpr
--

INSERT INTO checks VALUES (1, 14652, 125.00, '', 103, '2015-02-24 01:21:39.715528', '2015-02-24 01:21:39.715528');
INSERT INTO checks VALUES (2, 9226, 75.00, '', 105, '2015-02-24 01:23:13.969563', '2015-02-24 01:23:13.969563');
INSERT INTO checks VALUES (3, 16766, 125.00, 'Pagó 6-febrero-2015', 109, '2015-02-24 01:30:55.87832', '2015-02-24 01:31:24.075276');
INSERT INTO checks VALUES (4, 4683, 50.00, 'Pagó 10-febrer0-2015', 12, '2015-02-24 01:40:25.870939', '2015-02-24 01:40:25.870939');
INSERT INTO checks VALUES (5, 40, 75.00, 'Pago 5-febrero-2015', 123, '2015-02-24 01:43:19.618534', '2015-02-24 01:43:19.618534');
INSERT INTO checks VALUES (6, 14836, 175.00, 'Pago 30-enero-2015', 107, '2015-02-24 01:48:40.58787', '2015-02-24 01:48:40.58787');
INSERT INTO checks VALUES (7, 2594, 75.00, 'Recibido 5-febrero-2015', 113, '2015-02-24 01:54:18.601953', '2015-02-24 01:54:45.952991');
INSERT INTO checks VALUES (8, 24496, 325.00, '', 13, '2015-02-24 02:19:44.588789', '2015-02-24 02:19:44.588789');
INSERT INTO checks VALUES (9, 3353, 150.00, 'Recibido 13-febrero-2015', 52, '2015-02-24 02:31:36.763363', '2015-02-24 02:32:04.575217');
INSERT INTO checks VALUES (10, 14697, 175.00, 'Recibido 6-febrero-2015', 60, '2015-02-24 02:38:19.292961', '2015-02-24 02:38:19.292961');
INSERT INTO checks VALUES (11, 2735, 100.00, 'Recibido 5-febrero-2015  Balance $25.00', 56, '2015-02-24 02:44:41.807723', '2015-02-24 02:44:41.807723');
INSERT INTO checks VALUES (12, 11897, 100.00, '15/01/2015', 42, '2015-02-24 14:20:37.47591', '2015-02-24 14:20:37.47591');
INSERT INTO checks VALUES (13, 1295, 200.00, '02/09/2015', 69, '2015-02-24 14:38:44.973039', '2015-02-24 14:38:44.973039');
INSERT INTO checks VALUES (14, 3776, 25.00, '', 67, '2015-02-24 14:40:06.2477', '2015-02-24 14:40:06.2477');
INSERT INTO checks VALUES (15, NULL, 300.00, 'Ref. PDD0Q21315173352', 84, '2015-02-24 14:48:15.864611', '2015-02-24 14:48:15.864611');
INSERT INTO checks VALUES (16, 1378, 75.00, '', 21, '2015-02-24 14:52:32.776465', '2015-02-24 14:52:32.776465');
INSERT INTO checks VALUES (17, 3821, 75.00, '', 68, '2015-02-24 14:57:39.190401', '2015-02-24 14:57:39.190401');
INSERT INTO checks VALUES (18, 13515, 75.00, '', 83, '2015-02-27 02:39:49.732', '2015-02-27 02:39:49.732');


--
-- Name: checks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: registroibpr
--

SELECT pg_catalog.setval('checks_id_seq', 18, true);


--
-- Data for Name: churches; Type: TABLE DATA; Schema: public; Owner: registroibpr
--

INSERT INTO churches VALUES (2, 11, 0, 'Iglesia Bautista de', 'Belén', '', 'Canóvanas', 1, NULL, '2014-03-04 15:14:57.140922', '2014-03-04 15:14:57.140922');
INSERT INTO churches VALUES (3, 36, 0, 'Iglesia Bautista de', 'Cupey', 'Venus Gardens', 'San Juan', 3, NULL, '2014-03-04 15:14:57.147675', '2014-03-04 15:14:57.147675');
INSERT INTO churches VALUES (5, 1, 1, 'Iglesia Bautista de', 'Adjuntas', '', 'Adjuntas', 1, NULL, '2014-03-04 15:14:57.14938', '2014-03-04 15:14:57.14938');
INSERT INTO churches VALUES (6, 111, 0, 'Iglesia Bautista de', 'Yahuecas', 'Yahuecas Arriba', 'Adjuntas', 1, NULL, '2014-03-04 15:14:57.151158', '2014-03-04 15:14:57.151158');
INSERT INTO churches VALUES (7, 2, 0, 'Iglesia Bautista de', 'Aguas Buenas', '', 'Aguas Buenas', 2, NULL, '2014-03-04 15:14:57.152687', '2014-03-04 15:14:57.152687');
INSERT INTO churches VALUES (8, 10, 0, 'Iglesia Bautista de', 'Bayamoncito', '', 'Aguas Buenas', 3, NULL, '2014-03-04 15:14:57.154161', '2014-03-04 15:14:57.154161');
INSERT INTO churches VALUES (9, 95, 0, 'Iglesia Bautista ', 'Reconciliación', 'Pajuil', 'Arecibo', 1, NULL, '2014-03-04 15:14:57.155515', '2014-03-04 15:14:57.155515');
INSERT INTO churches VALUES (10, 6, 0, 'Iglesia Bautista de', 'Barranquitas', '', 'Barranquitas', 2, NULL, '2014-03-04 15:14:57.156882', '2014-03-04 15:14:57.156882');
INSERT INTO churches VALUES (11, 9, 1, 'Iglesia Bautista de', 'Bayamón', '', 'Bayamón', 2, NULL, '2014-03-04 15:14:57.1581', '2014-03-04 15:14:57.1581');
INSERT INTO churches VALUES (12, 42, 0, 'Iglesia Bautista ', 'El Redentor', '', 'Bayamón', 2, NULL, '2014-03-04 15:14:57.159322', '2014-03-04 15:14:57.159322');
INSERT INTO churches VALUES (13, 16, 1, 'Iglesia Bautista de', 'Caguas', '', 'Caguas', 3, NULL, '2014-03-04 15:14:57.160513', '2014-03-04 15:14:57.160513');
INSERT INTO churches VALUES (14, 17, 2, 'Iglesia Bautista de', 'Caguas', '', 'Caguas', 3, NULL, '2014-03-04 15:14:57.161614', '2014-03-04 15:14:57.161614');
INSERT INTO churches VALUES (15, 43, 0, 'Iglesia Bautista ', 'El Verbo de Dios', '', 'Caguas', 1, NULL, '2014-03-04 15:14:57.162717', '2014-03-04 15:14:57.162717');
INSERT INTO churches VALUES (16, 65, 0, 'Iglesia Bautista de', 'Las Cruces', '', 'Caguas', 3, NULL, '2014-03-04 15:14:57.16381', '2014-03-04 15:14:57.16381');
INSERT INTO churches VALUES (17, 60, 0, 'Iglesia Bautista ', 'La Esperanza', 'Villa Esperanza', 'Caguas', 2, NULL, '2014-03-04 15:14:57.164867', '2014-03-04 15:14:57.164867');
INSERT INTO churches VALUES (18, 19, 0, 'Iglesia Bautista de', 'Canóvanas', '', 'Canóvanas', 3, NULL, '2014-03-04 15:14:57.165962', '2014-03-04 15:14:57.165962');
INSERT INTO churches VALUES (19, 53, 0, 'Iglesia Bautista ', 'Hosanna', 'San Isidro', 'Canóvanas', 2, NULL, '2014-03-04 15:14:57.167007', '2014-03-04 15:14:57.167007');
INSERT INTO churches VALUES (20, 69, 0, 'Iglesia Bautista de', 'Lomas', '', 'Canóvanas', 3, NULL, '2014-03-04 15:14:57.168099', '2014-03-04 15:14:57.168099');
INSERT INTO churches VALUES (21, 84, 0, 'Iglesia Bautista de', 'Peniel', '', 'Canóvanas', 1, NULL, '2014-03-04 15:14:57.169212', '2014-03-04 15:14:57.169212');
INSERT INTO churches VALUES (22, 5, 0, 'Iglesia Bautista de', 'Antioquía', 'Canovanillas', 'Carolina', 1, NULL, '2014-03-04 15:14:57.170294', '2014-03-04 15:14:57.170294');
INSERT INTO churches VALUES (23, 7, 0, 'Iglesia Bautista de', 'Barrazas', '', 'Carolina', 3, NULL, '2014-03-04 15:14:57.171423', '2014-03-04 15:14:57.171423');
INSERT INTO churches VALUES (24, 15, 0, 'Iglesia Bautista de', 'Cacao', '', 'Carolina', 2, NULL, '2014-03-04 15:14:57.172543', '2014-03-04 15:14:57.172543');
INSERT INTO churches VALUES (25, 20, 1, 'Iglesia Bautista de', 'Carolina', '', 'Carolina', 3, NULL, '2014-03-04 15:14:57.17361', '2014-03-04 15:14:57.17361');
INSERT INTO churches VALUES (26, 27, 0, 'Iglesia Bautista de', 'Cedros', '', 'Carolina', 2, NULL, '2014-03-04 15:14:57.174724', '2014-03-04 15:14:57.174724');
INSERT INTO churches VALUES (27, 22, 0, 'Iglesia Bautista ', 'Los Ángeles', 'Los Ángeles', 'Carolina', 1, NULL, '2014-03-04 15:14:57.175774', '2014-03-04 15:14:57.175774');
INSERT INTO churches VALUES (28, 71, 0, 'Iglesia Bautista', 'Luz de Salvación de Buenaventura', '', 'Carolina', 3, NULL, '2014-03-04 15:14:57.176893', '2014-03-04 15:14:57.176893');
INSERT INTO churches VALUES (29, 77, 0, 'Iglesia Bautista de', 'Metrópolis', '', 'Carolina', 3, NULL, '2014-03-04 15:14:57.177967', '2014-03-04 15:14:57.177967');
INSERT INTO churches VALUES (30, 80, 0, 'Iglesia Bautista ', 'Oasis de Bendición', 'Villa Fontana', 'Carolina', 3, NULL, '2014-03-04 15:14:57.179014', '2014-03-04 15:14:57.179014');
INSERT INTO churches VALUES (31, 97, 0, 'Iglesia Bautista de', 'Rolling Hills', '', 'Carolina', 1, NULL, '2014-03-04 15:14:57.180067', '2014-03-04 15:14:57.180067');
INSERT INTO churches VALUES (32, 101, 0, 'Iglesia Bautista de', 'San Antón', '', 'Carolina', 3, NULL, '2014-03-04 15:14:57.181115', '2014-03-04 15:14:57.181115');
INSERT INTO churches VALUES (33, 26, 1, 'Iglesia Bautista de', 'Cayey', 'Montellano', 'Cayey', 3, NULL, '2014-03-04 15:14:57.182157', '2014-03-04 15:14:57.182157');
INSERT INTO churches VALUES (34, 106, 0, 'Iglesia Bautista de', 'Toíta', '', 'Cayey', 2, NULL, '2014-03-04 15:14:57.183256', '2014-03-04 15:14:57.183256');
INSERT INTO churches VALUES (35, 67, 0, 'Iglesia Bautista ', 'Las Vegas-Farallón Unida', '', 'Cayey', 2, NULL, '2014-03-04 15:14:57.184309', '2014-03-04 15:14:57.184309');
INSERT INTO churches VALUES (36, 30, 1, 'Iglesia Bautista de', 'Cidra', '', 'Cidra', 3, NULL, '2014-03-04 15:14:57.185366', '2014-03-04 15:14:57.185366');
INSERT INTO churches VALUES (37, 31, 2, 'Iglesia Bautista de', 'Cidra', '', 'Cidra', 2, NULL, '2014-03-04 15:14:57.186414', '2014-03-04 15:14:57.186414');
INSERT INTO churches VALUES (38, 61, 0, 'Iglesia Bautista ', 'La Nueva Ebenezer', 'Rincón', 'Cidra', 2, NULL, '2014-03-04 15:14:57.187483', '2014-03-04 15:14:57.187483');
INSERT INTO churches VALUES (39, 32, 1, 'Iglesia Bautista de', 'Coamo', '', 'Coamo', 2, NULL, '2014-03-04 15:14:57.188544', '2014-03-04 15:14:57.188544');
INSERT INTO churches VALUES (40, 33, 1, 'Bautista de', 'Corozal', '', 'Corozal', 1, NULL, '2014-03-04 15:14:57.189609', '2014-03-04 15:14:57.189609');
INSERT INTO churches VALUES (41, 37, 1, 'Iglesia Bautista de', 'Dorado', '', 'Dorado', 3, NULL, '2014-03-04 15:14:57.190879', '2014-03-04 15:14:57.190879');
INSERT INTO churches VALUES (42, 44, 1, 'Iglesia Bautista de', 'Fajardo', '', 'Fajardo', 3, NULL, '2014-03-04 15:14:57.19201', '2014-03-04 15:14:57.19201');
INSERT INTO churches VALUES (43, 62, 0, 'Iglesia Bautista', 'La Nueva Jerusalén', '', 'Fajardo', 1, NULL, '2014-03-04 15:14:57.193105', '2014-03-04 15:14:57.193105');
INSERT INTO churches VALUES (46, 47, 0, 'Iglesia Bautista de', 'Guayama Corazón', 'Corazón', 'Guayama', 1, NULL, '2014-03-04 15:14:57.19531', '2014-03-04 15:14:57.19531');
INSERT INTO churches VALUES (47, 48, 0, 'Iglesia Bautista de', 'Guayanilla', '', 'Guayanilla', 2, NULL, '2014-03-04 15:14:57.196359', '2014-03-04 15:14:57.196359');
INSERT INTO churches VALUES (48, 49, 0, 'Iglesia Bautista de', 'Guaynabo', '', 'Guaynabo', 3, NULL, '2014-03-04 15:14:57.197405', '2014-03-04 15:14:57.197405');
INSERT INTO churches VALUES (50, 28, 0, 'Iglesia Bautista de', 'Celada', '', 'Gurabo', 2, NULL, '2014-03-04 15:14:57.199499', '2014-03-04 15:14:57.199499');
INSERT INTO churches VALUES (51, 40, 0, 'Iglesia Bautista de', 'El Cielito', 'Navarro', 'Gurabo', 3, NULL, '2014-03-04 15:14:57.200591', '2014-03-04 15:14:57.200591');
INSERT INTO churches VALUES (52, 38, 0, 'Iglesia Bautista ', 'Ebenezer', '', 'Gurabo', 2, NULL, '2014-03-04 15:14:57.201707', '2014-03-04 15:14:57.201707');
INSERT INTO churches VALUES (53, 50, 1, 'Iglesia Bautista de', 'Gurabo', '', 'Gurabo', 3, NULL, '2014-03-04 15:14:57.202808', '2014-03-04 15:14:57.202808');
INSERT INTO churches VALUES (55, 52, 0, 'Iglesia Bautista de', 'Hato Nuevo', '', 'Gurabo', 3, NULL, '2014-03-04 15:14:57.204994', '2014-03-04 15:14:57.204994');
INSERT INTO churches VALUES (56, 73, 0, 'Iglesia Bautista de', 'Mamey', '', 'Gurabo', 3, NULL, '2014-03-04 15:14:57.20605', '2014-03-04 15:14:57.20605');
INSERT INTO churches VALUES (57, 74, 0, 'Iglesia Bautista de', 'Masas II', '', 'Gurabo', 1, NULL, '2014-03-04 15:14:57.207092', '2014-03-04 15:14:57.207092');
INSERT INTO churches VALUES (58, 54, 0, 'Iglesia Bautista de', 'Humacao', '', 'Humacao', 3, NULL, '2014-03-04 15:14:57.208231', '2014-03-04 15:14:57.208231');
INSERT INTO churches VALUES (59, 59, 0, 'Iglesia Bautista ', 'La Ciudad Deseada', 'Cantagallo', 'Juncos', 1, NULL, '2014-03-04 15:14:57.209269', '2014-03-04 15:14:57.209269');
INSERT INTO churches VALUES (60, 58, 1, 'Iglesia Bautista de', 'Juncos', '', 'Juncos', 3, NULL, '2014-03-04 15:14:57.210329', '2014-03-04 15:14:57.210329');
INSERT INTO churches VALUES (61, 63, 0, 'Iglesia Bautista ', 'La Placita', '', 'Juncos', 0, NULL, '2014-03-04 15:14:57.211396', '2014-03-04 15:14:57.211396');
INSERT INTO churches VALUES (62, 81, 0, 'Iglesia Bautista ', 'Oasis de Paz', 'Lirios', 'Juncos', 1, NULL, '2014-03-04 15:14:57.212605', '2014-03-04 15:14:57.212605');
INSERT INTO churches VALUES (63, 25, 0, 'Iglesia Bautista de', 'Castañer', '', 'Lares', 1, NULL, '2014-03-04 15:14:57.213668', '2014-03-04 15:14:57.213668');
INSERT INTO churches VALUES (64, 66, 0, 'Iglesia Bautista de', 'Las Piedras', 'Arenas', 'Las Piedras', 1, NULL, '2014-03-04 15:14:57.214743', '2014-03-04 15:14:57.214743');
INSERT INTO churches VALUES (65, 96, 0, 'Iglesia Bautista ', 'Restauración Las Piedras', '', 'Las Piedras', 3, NULL, '2014-03-04 15:14:57.215784', '2014-03-04 15:14:57.215784');
INSERT INTO churches VALUES (66, 76, 0, 'Iglesia Bautista de', 'Medianía Alta', '', 'Loíza', 0, NULL, '2014-03-04 15:14:57.21683', '2014-03-04 15:14:57.21683');
INSERT INTO churches VALUES (67, 68, 0, 'Iglesia Bautista de', 'Loí­za', '', 'Loíza', 2, NULL, '2014-03-04 15:14:57.218024', '2014-03-04 15:14:57.218024');
INSERT INTO churches VALUES (68, 109, 0, 'Iglesia Bautista de', 'Villas de Loíza', '', 'Canóvanas', 2, NULL, '2014-03-04 15:14:57.219064', '2014-03-04 15:14:57.219064');
INSERT INTO churches VALUES (69, 57, 0, 'Iglesia Bautista de', 'Jerusalén', 'Mata de Plátano', 'Luquillo', 3, NULL, '2014-03-04 15:14:57.220107', '2014-03-04 15:14:57.220107');
INSERT INTO churches VALUES (70, 70, 0, 'Iglesia Bautista de', 'Luquillo Mar', '', 'Luquillo', 3, NULL, '2014-03-04 15:14:57.221156', '2014-03-04 15:14:57.221156');
INSERT INTO churches VALUES (71, 75, 0, 'Iglesia Bautista de', 'Mayagüez', '', 'Mayagüez', 1, NULL, '2014-03-04 15:14:57.222209', '2014-03-04 15:14:57.222209');
INSERT INTO churches VALUES (72, 78, 0, 'Iglesia Bautista de', 'Morovis', '', 'Morovis', 1, NULL, '2014-03-04 15:14:57.223646', '2014-03-04 15:14:57.223646');
INSERT INTO churches VALUES (75, 82, 1, 'Iglesia Bautista de', 'Orocovis', '', 'Orocovis', 2, NULL, '2014-03-04 15:14:57.225185', '2014-03-04 15:14:57.225185');
INSERT INTO churches VALUES (76, 86, 1, 'Iglesia Bautista de', 'Ponce', '', 'Ponce', 1, NULL, '2014-03-04 15:14:57.226479', '2014-03-04 15:14:57.226479');
INSERT INTO churches VALUES (49, 108, NULL, 'Iglesia Bautista', 'Unida El Salvador', 'Monacillos', 'San Juan', 2, '', '2014-03-04 15:14:57.198448', '2014-03-07 14:48:32.269695');
INSERT INTO churches VALUES (77, 85, 0, 'Primera Iglesia Bautista', 'Playa de Ponce', '', 'Ponce', 2, NULL, '2014-03-04 15:14:57.227659', '2014-03-04 15:14:57.227659');
INSERT INTO churches VALUES (78, 34, 0, 'Iglesia Bautista de', 'Corral Viejo', '', 'Ponce', 1, NULL, '2014-03-04 15:14:57.228907', '2014-03-04 15:14:57.228907');
INSERT INTO churches VALUES (79, 87, 2, 'Iglesia Bautista de', 'Ponce', '', 'Ponce', 0, NULL, '2014-03-04 15:14:57.23001', '2014-03-04 15:14:57.23001');
INSERT INTO churches VALUES (80, 88, 3, 'Iglesia Bautista de', 'Ponce', '', 'Ponce', 3, NULL, '2014-03-04 15:14:57.231249', '2014-03-04 15:14:57.231249');
INSERT INTO churches VALUES (81, 64, 0, 'Iglesia Bautista ', 'La Roca', '', 'Quebradillas', 0, NULL, '2014-03-04 15:14:57.232327', '2014-03-04 15:14:57.232327');
INSERT INTO churches VALUES (82, 14, 0, 'Iglesia Bautista ', 'Bethel', 'Malpica', 'Río Grande', 3, NULL, '2014-03-04 15:14:57.233418', '2014-03-04 15:14:57.233418');
INSERT INTO churches VALUES (83, 51, 0, 'Iglesia Bautista de', 'Guzmán Arriba', '', 'Río Grande', 2, NULL, '2014-03-04 15:14:57.234484', '2014-03-04 15:14:57.234484');
INSERT INTO churches VALUES (84, 83, 0, 'Iglesia Bautista de', 'Palmer', '', 'Río Grande', 3, NULL, '2014-03-04 15:14:57.235609', '2014-03-04 15:14:57.235609');
INSERT INTO churches VALUES (85, 93, 1, 'Iglesia Bautista de', 'Rí­o Grande', '', 'Río Grande', 3, NULL, '2014-03-04 15:14:57.236668', '2014-03-04 15:14:57.236668');
INSERT INTO churches VALUES (86, 102, 0, 'Iglesia Bautista de', 'San Lorenzo', '', 'San Lorenzo', 2, NULL, '2014-03-04 15:14:57.237762', '2014-03-04 15:14:57.237762');
INSERT INTO churches VALUES (87, 55, 0, 'Iglesia Bautista de', 'Jagual', '', 'San Lorenzo', 1, NULL, '2014-03-04 15:14:57.238806', '2014-03-04 15:14:57.238806');
INSERT INTO churches VALUES (89, 21, 0, 'Iglesia Bautista de', 'Carraí­zo', '', 'Trujillo Alto', 2, NULL, '2014-03-04 15:14:57.239854', '2014-03-04 15:14:57.239854');
INSERT INTO churches VALUES (90, 41, 0, 'Iglesia Bautista ', 'El Lago', '', 'Trujillo Alto', 2, NULL, '2014-03-04 15:14:57.240889', '2014-03-04 15:14:57.240889');
INSERT INTO churches VALUES (91, 72, 0, 'Iglesia Bautista ', 'Luz del Mundo', '', 'Trujillo Alto', 3, NULL, '2014-03-04 15:14:57.24196', '2014-03-04 15:14:57.24196');
INSERT INTO churches VALUES (92, 100, 0, 'Iglesia Bautista de', 'Saint Just', '', 'Trujillo Alto', 0, NULL, '2014-03-04 15:14:57.243014', '2014-03-04 15:14:57.243014');
INSERT INTO churches VALUES (93, 104, 0, 'Iglesia Bautista de', 'Sión', 'Quebrada Negrito', 'Trujillo Alto', 2, NULL, '2014-03-04 15:14:57.244093', '2014-03-04 15:14:57.244093');
INSERT INTO churches VALUES (94, 107, 0, 'Iglesia Bautista de', 'Trujillo Alto', '', 'Trujillo Alto', 2, NULL, '2014-03-04 15:14:57.245144', '2014-03-04 15:14:57.245144');
INSERT INTO churches VALUES (95, 12, 0, 'Iglesia Bautista ', 'Berea', '', 'Yabucoa', 0, NULL, '2014-03-04 15:14:57.246182', '2014-03-04 15:14:57.246182');
INSERT INTO churches VALUES (96, 110, 1, 'Iglesia Bautista de', 'Yabucoa', 'Juan Martí­n', 'Yabucoa', 2, NULL, '2014-03-04 15:14:57.247256', '2014-03-04 15:14:57.247256');
INSERT INTO churches VALUES (97, 3, 0, 'Iglesia Bautista de', 'Almácigo', '', 'Yauco', 1, NULL, '2014-03-04 15:14:57.248334', '2014-03-04 15:14:57.248334');
INSERT INTO churches VALUES (98, 24, 0, 'Iglesia Bautista ', 'Casa de Oración de Carrizales', '', 'Yauco', 2, NULL, '2014-03-04 15:14:57.249377', '2014-03-04 15:14:57.249377');
INSERT INTO churches VALUES (99, 112, 1, 'Iglesia Bautista de', 'Yauco', 'Jácanas', 'Yauco', 3, NULL, '2014-03-04 15:14:57.250432', '2014-03-04 15:14:57.250432');
INSERT INTO churches VALUES (100, 4, 0, 'Iglesia Bautista de', 'Altamesa', '', 'San Juan', 1, NULL, '2014-03-04 15:14:57.251482', '2014-03-04 15:14:57.251482');
INSERT INTO churches VALUES (102, 13, 0, 'Iglesia Bautista ', 'Betesda', '', 'San Juan', 2, NULL, '2014-03-04 15:14:57.25251', '2014-03-04 15:14:57.25251');
INSERT INTO churches VALUES (103, 35, 0, 'Iglesia Bautista de', 'Country Club', '', 'San Juan', 3, NULL, '2014-03-04 15:14:57.253565', '2014-03-04 15:14:57.253565');
INSERT INTO churches VALUES (105, 45, 0, 'Iglesia Bautista ', 'Getsemaní­ de Colinas Verdes', '', 'San Juan', 2, NULL, '2014-03-04 15:14:57.254678', '2014-03-04 15:14:57.254678');
INSERT INTO churches VALUES (106, 89, 0, 'Iglesia Bautista de', 'Puerta de Tierra', '', 'San Juan', 2, NULL, '2014-03-04 15:14:57.255795', '2014-03-04 15:14:57.255795');
INSERT INTO churches VALUES (107, 90, 0, 'Iglesia Bautista de', 'Puerto Nuevo', '', 'San Juan', 3, NULL, '2014-03-04 15:14:57.256852', '2014-03-04 15:14:57.256852');
INSERT INTO churches VALUES (108, 92, 0, 'Iglesia Bautista de', 'Quintana', '', 'San Juan', 3, NULL, '2014-03-04 15:14:57.257902', '2014-03-04 15:14:57.257902');
INSERT INTO churches VALUES (109, 94, 1, 'Iglesia Bautista de', 'Rí­o Piedras', '', 'San Juan', 3, NULL, '2014-03-04 15:14:57.25895', '2014-03-04 15:14:57.25895');
INSERT INTO churches VALUES (110, 98, 0, 'Iglesia Bautista de', 'Roosevelt', '', 'San Juan', 2, NULL, '2014-03-04 15:14:57.259999', '2014-03-04 15:14:57.259999');
INSERT INTO churches VALUES (111, 99, 0, 'Iglesia Bautista de', 'Sabana Llana', '', 'San Juan', 1, NULL, '2014-03-04 15:14:57.261054', '2014-03-04 15:14:57.261054');
INSERT INTO churches VALUES (112, 103, 1, 'Iglesia Bautista de', 'Santurce', '', 'San Juan', 2, NULL, '2014-03-04 15:14:57.262093', '2014-03-04 15:14:57.262093');
INSERT INTO churches VALUES (113, 29, 0, 'Iglesia Bautista', 'Central de Villa Las Lomas', '', 'San Juan', 2, NULL, '2014-03-04 15:14:57.263151', '2014-03-04 15:14:57.263151');
INSERT INTO churches VALUES (114, 23, 0, 'Iglesia Bautista', 'Casa de Dios', 'Santa Cruz', 'Islas Vírgenes', 1, NULL, '2014-03-04 15:14:57.264209', '2014-03-04 15:14:57.264209');
INSERT INTO churches VALUES (116, 56, 0, 'Iglesia Bautista de', 'Jaguas', '', 'Gurabo', 1, NULL, '2014-03-04 15:14:57.265303', '2014-03-04 15:14:57.265303');
INSERT INTO churches VALUES (117, 105, 0, 'Iglesia Bautista de ', 'Sinaí Guánica', '', 'Guánica', 2, NULL, '2014-03-04 15:14:57.266333', '2014-03-04 15:14:57.266333');
INSERT INTO churches VALUES (118, 0, 0, '', 'Junta Directiva UJBPR', '', '', 0, NULL, '2014-03-04 15:14:57.26738', '2014-03-04 15:14:57.26738');
INSERT INTO churches VALUES (119, 0, 0, '', 'Ministerios de Mujeres Bautistas de PR', '', '', 0, NULL, '2014-03-04 15:14:57.268461', '2014-03-04 15:14:57.268461');
INSERT INTO churches VALUES (120, 0, 0, '', 'Ministerio de Hombres Bautistas de PR', '', '', 0, NULL, '2014-03-04 15:14:57.269571', '2014-03-04 15:14:57.269571');
INSERT INTO churches VALUES (121, 0, 0, '', 'Concilio Ministerial', '', '', 0, NULL, '2014-03-04 15:14:57.270659', '2014-03-04 15:14:57.270659');
INSERT INTO churches VALUES (122, 0, 0, '', 'Ministerios Adultos Mayores', '', '', 0, NULL, '2014-03-04 15:14:57.271711', '2014-03-04 15:14:57.271711');
INSERT INTO churches VALUES (123, 39, 0, 'Iglesia Bautista de', 'Ebenezer de Levittown Lakes', '', 'Toa Baja', 0, NULL, '2014-03-04 15:14:57.272752', '2014-03-04 15:14:57.272752');
INSERT INTO churches VALUES (124, 79, 1, 'Iglesia Bautista de', 'Naguabo', '', 'Naguabo', 0, NULL, '2014-03-04 15:14:57.273831', '2014-03-04 15:14:57.273831');
INSERT INTO churches VALUES (125, 8, 1, 'Iglesia Bautista de', 'Barrio Obrero', '', 'San Juan', 0, NULL, '2014-03-04 15:14:57.274898', '2014-03-04 15:14:57.274898');
INSERT INTO churches VALUES (126, 113, 0, 'Iglesia Bautista de', 'Faro de Luz', '', 'Río Grande', 0, NULL, '2014-03-04 15:14:57.275971', '2014-03-04 15:14:57.275971');
INSERT INTO churches VALUES (1, 18, 0, 'Iglesia Bautista de', 'Campo Rico', NULL, 'Canóvanas', 0, NULL, '2014-03-05 12:19:16.930414', '2014-03-05 12:20:01.832083');
INSERT INTO churches VALUES (54, 91, NULL, 'Iglesia Bautista de', 'Quebrada', '', 'Gurabo', 1, '', '2014-03-04 15:14:57.203929', '2015-02-28 19:25:41.256119');
INSERT INTO churches VALUES (45, 46, 1, 'Iglesia Bautista de', 'Guayama', '', 'Guayama', 2, '', '2014-03-04 15:14:57.194239', '2015-02-28 19:25:58.59266');


--
-- Name: churches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: registroibpr
--

SELECT pg_catalog.setval('churches_id_seq', 118, false);


--
-- Data for Name: people; Type: TABLE DATA; Schema: public; Owner: registroibpr
--

INSERT INTO people VALUES (1, 1, 'Roy ', 'Acosta ', true, 0, '', false, false, false, 108, '2015-02-23 22:21:49.889093', '2015-02-23 22:21:49.889093');
INSERT INTO people VALUES (3, NULL, 'José', 'Tejeda ', true, 3, '', false, false, false, 108, '2015-02-23 22:23:11.598545', '2015-02-23 22:23:11.598545');
INSERT INTO people VALUES (4, NULL, 'Luis ', 'Vázquez ', true, 3, '', false, false, false, 108, '2015-02-23 22:23:49.805825', '2015-02-23 22:23:49.805825');
INSERT INTO people VALUES (5, NULL, 'Mary ', 'Vázquez ', false, 3, '', false, false, false, 108, '2015-02-23 22:24:15.398515', '2015-02-23 22:24:15.398515');
INSERT INTO people VALUES (6, 1, 'Eneida ', 'Angleró', false, 0, '', false, false, false, 105, '2015-02-23 22:25:35.265226', '2015-02-23 22:25:35.265226');
INSERT INTO people VALUES (7, NULL, 'Yamalis ', 'González ', false, 3, '', false, false, false, 105, '2015-02-23 22:26:10.39241', '2015-02-23 22:26:10.39241');
INSERT INTO people VALUES (8, NULL, 'Rómulo ', 'Ortiz ', true, 3, '', false, false, false, 105, '2015-02-23 22:26:41.58849', '2015-02-23 22:26:41.58849');
INSERT INTO people VALUES (9, NULL, 'Wilfredo ', 'Torres ', true, 3, '', false, false, false, 105, '2015-02-23 22:27:06.708956', '2015-02-23 22:27:06.708956');
INSERT INTO people VALUES (10, 1, 'Miriam ', 'Rodríguez de Gutiérrez', false, 2, '', false, false, false, 103, '2015-02-24 01:17:20.485002', '2015-02-24 01:17:20.485002');
INSERT INTO people VALUES (11, NULL, 'Jessica ', 'Lugo ', false, 3, '', false, false, false, 103, '2015-02-24 01:17:56.120307', '2015-02-24 01:17:56.120307');
INSERT INTO people VALUES (12, NULL, 'Mary Leen ', 'Marrero', false, 3, '', false, false, false, 103, '2015-02-24 01:18:51.363156', '2015-02-24 01:18:51.363156');
INSERT INTO people VALUES (13, NULL, 'Noel ', 'Ortiz ', true, 3, '', false, false, false, 103, '2015-02-24 01:19:13.409094', '2015-02-24 01:19:13.409094');
INSERT INTO people VALUES (14, NULL, 'Pedro ', 'Gely ', true, 3, '', false, false, false, 103, '2015-02-24 01:19:45.854266', '2015-02-24 01:19:45.854266');
INSERT INTO people VALUES (16, NULL, 'Zoraida ', 'Rivera ', false, 3, '', false, false, false, 103, '2015-02-24 01:20:55.459826', '2015-02-24 01:20:55.459826');
INSERT INTO people VALUES (17, 1, 'David ', 'Valentín ', true, 0, '', false, false, false, 3, '2015-02-24 01:24:22.065414', '2015-02-24 01:24:22.065414');
INSERT INTO people VALUES (18, NULL, 'Jennie ', 'Cintrón ', false, 3, '', false, false, false, 3, '2015-02-24 01:25:06.338216', '2015-02-24 01:25:06.338216');
INSERT INTO people VALUES (19, NULL, 'José A. ', 'Flores ', true, 3, '', false, false, false, 3, '2015-02-24 01:25:39.803808', '2015-02-24 01:25:39.803808');
INSERT INTO people VALUES (20, NULL, 'Samuel ', 'Encarnación', true, 3, '', false, false, false, 3, '2015-02-24 01:26:07.105439', '2015-02-24 01:26:07.105439');
INSERT INTO people VALUES (21, NULL, 'Miguel A. ', 'Rivera ', true, 3, '', false, false, false, 3, '2015-02-24 01:26:30.75285', '2015-02-24 01:26:30.75285');
INSERT INTO people VALUES (22, 0, 'Laura ', 'Ayala ', false, 0, '', false, false, false, 109, '2015-02-24 01:27:13.149274', '2015-02-24 01:27:13.149274');
INSERT INTO people VALUES (24, NULL, 'Nubia G.', 'Santos ', true, 3, '', false, false, false, 109, '2015-02-24 01:28:09.897945', '2015-02-24 01:28:09.897945');
INSERT INTO people VALUES (25, NULL, 'Zoraida ', 'Derieux ', false, 3, '', false, false, false, 109, '2015-02-24 01:28:40.668004', '2015-02-24 01:28:40.668004');
INSERT INTO people VALUES (26, NULL, 'José D. ', 'Colón', true, 3, '', false, false, false, 109, '2015-02-24 01:29:09.930154', '2015-02-24 01:29:09.930154');
INSERT INTO people VALUES (23, NULL, 'Juan C.', 'Rivera ', true, 3, '', false, false, false, 109, '2015-02-24 01:27:43.735306', '2015-02-24 01:30:11.04502');
INSERT INTO people VALUES (27, 0, 'Migdalia ', 'Flores ', false, 0, '', false, false, false, 100, '2015-02-24 01:37:45.571485', '2015-02-24 01:37:45.571485');
INSERT INTO people VALUES (28, NULL, 'Angel ', 'Pérez ', true, 3, '', false, false, false, 100, '2015-02-24 01:38:14.145202', '2015-02-24 01:38:14.145202');
INSERT INTO people VALUES (29, NULL, 'Carmen N. ', 'Negrón ', false, 3, '', false, false, false, 12, '2015-02-24 01:39:08.318674', '2015-02-24 01:39:08.318674');
INSERT INTO people VALUES (30, NULL, 'Raquel ', 'Oquendo ', false, 3, '', false, false, false, 12, '2015-02-24 01:39:31.364703', '2015-02-24 01:39:31.364703');
INSERT INTO people VALUES (31, 0, 'Hipólito ', 'Félix ', true, 0, '', false, false, false, 123, '2015-02-24 01:41:36.181148', '2015-02-24 01:41:36.181148');
INSERT INTO people VALUES (32, NULL, 'Lydia ', 'Camacho ', false, 3, '', false, false, false, 123, '2015-02-24 01:42:07.441078', '2015-02-24 01:42:07.441078');
INSERT INTO people VALUES (33, NULL, 'Awilda ', 'Hernández ', false, 3, '', false, false, false, 123, '2015-02-24 01:42:32.458934', '2015-02-24 01:42:32.458934');
INSERT INTO people VALUES (34, 1, 'Heriberto ', 'Muñoz ', true, 0, '', false, false, false, 107, '2015-02-24 01:43:56.325452', '2015-02-24 01:43:56.325452');
INSERT INTO people VALUES (35, NULL, 'Carlos ', 'Maldonado ', true, 3, '', false, false, false, 107, '2015-02-24 01:44:21.294952', '2015-02-24 01:44:21.294952');
INSERT INTO people VALUES (36, NULL, 'Vivian ', 'Pagán', false, 3, '', false, false, false, 107, '2015-02-24 01:44:56.280726', '2015-02-24 01:44:56.280726');
INSERT INTO people VALUES (37, NULL, 'Fernando ', 'Toro ', true, 3, '', false, false, false, 107, '2015-02-24 01:45:18.35002', '2015-02-24 01:45:18.35002');
INSERT INTO people VALUES (38, NULL, 'María de los A. ', 'Torres ', false, 3, '', false, false, false, 107, '2015-02-24 01:45:45.277971', '2015-02-24 01:45:45.277971');
INSERT INTO people VALUES (39, NULL, 'José ', 'Armenteros ', true, 3, '', false, false, false, 107, '2015-02-24 01:46:09.753433', '2015-02-24 01:46:09.753433');
INSERT INTO people VALUES (40, NULL, 'Margarita ', 'Fígaro', false, 3, '', false, false, false, 107, '2015-02-24 01:46:45.493396', '2015-02-24 01:46:45.493396');
INSERT INTO people VALUES (41, 1, 'Joel ', 'Velázquez ', true, 0, '', false, false, false, 110, '2015-02-24 01:49:18.955261', '2015-02-24 01:49:18.955261');
INSERT INTO people VALUES (42, NULL, 'Angel ', 'Torres ', true, 3, '', false, false, false, 110, '2015-02-24 01:49:43.059036', '2015-02-24 01:49:43.059036');
INSERT INTO people VALUES (43, NULL, 'Luciano ', 'Ortiz ', true, 3, '', false, false, false, 110, '2015-02-24 01:50:05.172259', '2015-02-24 01:50:05.172259');
INSERT INTO people VALUES (44, 0, 'Carlos J. ', 'Montalvo ', true, 0, '', false, false, false, 112, '2015-02-24 01:51:09.641324', '2015-02-24 01:51:09.641324');
INSERT INTO people VALUES (45, NULL, 'Leticia ', 'Santaella ', false, 4, '', false, false, false, 112, '2015-02-24 01:51:34.052136', '2015-02-24 01:51:34.052136');
INSERT INTO people VALUES (46, NULL, 'Amelia ', 'Colón', false, 3, '', false, false, false, 112, '2015-02-24 01:51:58.62218', '2015-02-24 01:51:58.62218');
INSERT INTO people VALUES (47, NULL, 'Ana Petra ', 'Félix ', false, 3, '', false, false, false, 112, '2015-02-24 01:52:30.066319', '2015-02-24 01:52:30.066319');
INSERT INTO people VALUES (48, 1, 'Jimmy ', 'Vargas ', true, 0, '', false, false, false, 113, '2015-02-24 01:53:09.270001', '2015-02-24 01:53:09.270001');
INSERT INTO people VALUES (49, NULL, 'Víctor ', 'Rivera ', true, 3, '', false, false, false, 113, '2015-02-24 01:53:29.17058', '2015-02-24 01:53:29.17058');
INSERT INTO people VALUES (50, NULL, 'Ahmed ', 'Díaz ', true, 3, '', false, false, false, 113, '2015-02-24 01:53:49.390545', '2015-02-24 01:53:49.390545');
INSERT INTO people VALUES (51, 1, 'Ramón L. ', 'Díaz ', true, 0, '', false, false, false, 7, '2015-02-24 01:56:07.756014', '2015-02-24 01:56:07.756014');
INSERT INTO people VALUES (52, NULL, 'Wilfredo ', 'Mercado ', true, 3, '', false, false, false, 7, '2015-02-24 01:56:28.001371', '2015-02-24 01:56:28.001371');
INSERT INTO people VALUES (53, NULL, 'Domingo ', 'Carrasquillo ', true, 3, '', false, false, false, 7, '2015-02-24 01:56:49.327954', '2015-02-24 01:56:49.327954');
INSERT INTO people VALUES (54, NULL, 'Israel ', 'Cotto ', true, 3, '', false, false, false, 7, '2015-02-24 01:57:09.233216', '2015-02-24 01:57:09.233216');
INSERT INTO people VALUES (55, 0, 'Geraldo ', 'Méndez ', true, 0, '', false, false, false, 10, '2015-02-24 01:58:31.251653', '2015-02-24 01:58:31.251653');
INSERT INTO people VALUES (56, NULL, 'Héctor N. ', 'López ', true, 3, '', false, false, false, 10, '2015-02-24 01:58:53.431612', '2015-02-24 01:58:53.431612');
INSERT INTO people VALUES (57, NULL, 'Lillian', 'Rivera ', false, 3, '', false, false, false, 10, '2015-02-24 01:59:18.740724', '2015-02-24 01:59:18.740724');
INSERT INTO people VALUES (58, 0, 'Jorge L. ', 'Cintrón ', true, 0, '', false, false, false, 33, '2015-02-24 02:00:09.302735', '2015-02-24 02:00:09.302735');
INSERT INTO people VALUES (59, NULL, 'Antonio ', 'Cabrera ', true, 3, '', false, false, false, 33, '2015-02-24 02:00:30.777975', '2015-02-24 02:00:30.777975');
INSERT INTO people VALUES (60, NULL, 'Angel ', 'De Jesús ', true, 3, '', false, false, false, 33, '2015-02-24 02:00:59.14507', '2015-02-24 02:00:59.14507');
INSERT INTO people VALUES (61, NULL, 'José A. ', 'Cotto ', true, 3, '', false, false, false, 33, '2015-02-24 02:01:25.367756', '2015-02-24 02:01:25.367756');
INSERT INTO people VALUES (62, NULL, 'Jorge L. ', 'Oquendo ', true, 3, '', false, false, false, 33, '2015-02-24 02:01:45.24657', '2015-02-24 02:01:45.24657');
INSERT INTO people VALUES (63, NULL, 'María del C. ', 'Meléndez ', false, 3, '', false, false, false, 33, '2015-02-24 02:02:14.53627', '2015-02-24 02:02:14.53627');
INSERT INTO people VALUES (64, NULL, 'Emérito ', 'Sánchez ', true, 3, '', false, false, false, 33, '2015-02-24 02:02:38.334079', '2015-02-24 02:02:38.334079');
INSERT INTO people VALUES (65, 1, 'Benigno ', 'Torres ', true, 2, '', false, false, false, 33, '2015-02-24 02:03:03.022471', '2015-02-24 02:03:54.746047');
INSERT INTO people VALUES (66, 1, 'Jaime ', 'Rodríguez ', true, 0, '', false, false, false, 36, '2015-02-24 02:05:02.059083', '2015-02-24 02:05:02.059083');
INSERT INTO people VALUES (67, NULL, 'Cristina ', 'Báez ', false, 3, '', false, false, false, 36, '2015-02-24 02:05:28.776187', '2015-02-24 02:05:28.776187');
INSERT INTO people VALUES (68, NULL, 'Daniel ', 'Santos ', true, 3, '', false, false, false, 36, '2015-02-24 02:05:58.200172', '2015-02-24 02:05:58.200172');
INSERT INTO people VALUES (69, 0, 'Juan C. ', 'Navarro ', true, 0, '', false, false, false, 37, '2015-02-24 02:06:47.609568', '2015-02-24 02:06:47.609568');
INSERT INTO people VALUES (70, NULL, 'Zoraida I. ', 'Serrano', false, 3, '', false, false, false, 37, '2015-02-24 02:07:15.106485', '2015-02-24 02:07:15.106485');
INSERT INTO people VALUES (71, NULL, 'Dora ', 'Cruz ', false, 3, '', false, false, false, 37, '2015-02-24 02:07:36.947044', '2015-02-24 02:07:36.947044');
INSERT INTO people VALUES (72, NULL, 'Fredeswilda ', 'Vargas ', false, 3, '', false, false, false, 37, '2015-02-24 02:08:16.27727', '2015-02-24 02:08:16.27727');
INSERT INTO people VALUES (73, NULL, 'Yolaris ', 'Negrón ', false, 3, '', false, false, false, 37, '2015-02-24 02:08:54.002502', '2015-02-24 02:08:54.002502');
INSERT INTO people VALUES (74, NULL, 'Luis ', 'López ', true, 3, '', false, false, false, 40, '2015-02-24 02:09:58.047775', '2015-02-24 02:09:58.047775');
INSERT INTO people VALUES (75, NULL, 'David ', 'Calderón ', true, 3, '', false, false, false, 40, '2015-02-24 02:10:31.344285', '2015-02-24 02:10:31.344285');
INSERT INTO people VALUES (76, 3, 'Alfredo ', 'Méndez ', true, 3, '', false, false, false, 64, '2015-02-24 02:11:21.043451', '2015-02-24 02:11:21.043451');
INSERT INTO people VALUES (77, NULL, 'Lorenzo A. ', 'Fuentes ', true, 3, '', false, false, false, 64, '2015-02-24 02:11:56.858646', '2015-02-24 02:11:56.858646');
INSERT INTO people VALUES (78, 1, 'César ', 'Maurás ', true, 0, '', false, false, false, 13, '2015-02-24 02:12:58.693612', '2015-02-24 02:12:58.693612');
INSERT INTO people VALUES (79, 1, 'Angel ', 'Cruz ', true, 1, '', false, false, false, 13, '2015-02-24 02:13:25.268081', '2015-02-24 02:13:25.268081');
INSERT INTO people VALUES (80, 1, 'Yamina ', 'Apolinaris ', false, 1, '', false, false, false, 13, '2015-02-24 02:13:57.475449', '2015-02-24 02:13:57.475449');
INSERT INTO people VALUES (81, 1, 'Héctor A. ', 'Rivera ', true, 1, '', false, false, false, 13, '2015-02-24 02:14:22.852503', '2015-02-24 02:14:22.852503');
INSERT INTO people VALUES (82, NULL, 'Alba ', 'Marín ', false, 3, '', false, false, false, 13, '2015-02-24 02:14:48.42626', '2015-02-24 02:14:48.42626');
INSERT INTO people VALUES (83, NULL, 'Noemí ', 'Ortiz ', false, 3, '', false, false, false, 13, '2015-02-24 02:15:12.64589', '2015-02-24 02:15:12.64589');
INSERT INTO people VALUES (84, NULL, 'Reinaldo ', 'Robles ', true, 3, '', false, false, false, 13, '2015-02-24 02:15:41.375244', '2015-02-24 02:15:41.375244');
INSERT INTO people VALUES (85, NULL, 'Aida I. ', 'López ', false, 3, '', false, false, false, 13, '2015-02-24 02:16:06.984407', '2015-02-24 02:16:06.984407');
INSERT INTO people VALUES (86, NULL, 'Aurelio ', 'Ríos ', true, 3, '', false, false, false, 13, '2015-02-24 02:16:38.054947', '2015-02-24 02:16:38.054947');
INSERT INTO people VALUES (87, NULL, 'Edgardo ', 'Miranda ', true, 3, '', false, false, false, 13, '2015-02-24 02:17:00.753889', '2015-02-24 02:17:00.753889');
INSERT INTO people VALUES (88, NULL, 'Angel ', 'Sierra ', true, 3, '', false, false, false, 13, '2015-02-24 02:17:31.008629', '2015-02-24 02:17:31.008629');
INSERT INTO people VALUES (89, NULL, 'Aurelina ', 'Roldán ', false, 3, '', false, false, false, 13, '2015-02-24 02:17:55.397238', '2015-02-24 02:17:55.397238');
INSERT INTO people VALUES (90, 1, 'Félix ', 'Rivera ', true, 2, '', false, false, false, 13, '2015-02-24 02:18:41.545225', '2015-02-24 02:18:41.545225');
INSERT INTO people VALUES (91, 1, 'Edwin ', 'Rivera ', true, 0, '', false, false, false, 14, '2015-02-24 02:22:48.675203', '2015-02-24 02:22:48.675203');
INSERT INTO people VALUES (92, NULL, 'Juan R.', 'Flusa ', true, 3, '', false, false, false, 14, '2015-02-24 02:23:11.719046', '2015-02-24 02:23:11.719046');
INSERT INTO people VALUES (93, NULL, 'Oscar ', 'Lausell ', true, 3, '', false, false, false, 14, '2015-02-24 02:23:34.71096', '2015-02-24 02:23:34.71096');
INSERT INTO people VALUES (94, 0, 'Mario ', 'Rodas ', true, 0, '', false, false, false, 59, '2015-02-24 02:24:44.088983', '2015-02-24 02:24:44.088983');
INSERT INTO people VALUES (95, NULL, 'Maribel ', 'González ', false, 3, '', false, false, false, 59, '2015-02-24 02:25:06.878867', '2015-02-24 02:25:06.878867');
INSERT INTO people VALUES (96, NULL, 'Joanne', 'Carrillo ', false, 3, '', false, false, false, 59, '2015-02-24 02:25:30.268758', '2015-02-24 02:25:30.268758');
INSERT INTO people VALUES (97, 0, 'Carmen P. ', 'Pérez ', false, 0, '', false, false, false, 50, '2015-02-24 02:26:09.98951', '2015-02-24 02:26:09.98951');
INSERT INTO people VALUES (98, 0, 'Emma ', 'Méndez ', false, 1, '', false, false, false, 50, '2015-02-24 02:26:31.869154', '2015-02-24 02:26:31.869154');
INSERT INTO people VALUES (99, NULL, 'Idalia ', 'García ', false, 3, '', false, false, false, 50, '2015-02-24 02:26:53.654669', '2015-02-24 02:26:53.654669');
INSERT INTO people VALUES (100, NULL, 'José A. ', 'Boria ', true, 3, '', false, false, false, 50, '2015-02-24 02:27:18.420492', '2015-02-24 02:27:18.420492');
INSERT INTO people VALUES (101, 1, 'Juan ', 'Vergara ', true, 0, '', false, false, false, 52, '2015-02-24 02:28:47.997609', '2015-02-24 02:28:47.997609');
INSERT INTO people VALUES (102, NULL, 'Marisol ', 'Rosa ', true, 3, '', false, false, false, 52, '2015-02-24 02:29:10.040047', '2015-02-24 02:29:10.040047');
INSERT INTO people VALUES (103, NULL, 'Samuel ', 'Acevedo ', true, 3, '', false, false, false, 52, '2015-02-24 02:29:30.896712', '2015-02-24 02:29:30.896712');
INSERT INTO people VALUES (104, NULL, 'Roberto ', 'Rodríguez ', true, 3, '', false, false, false, 52, '2015-02-24 02:30:03.651506', '2015-02-24 02:30:03.651506');
INSERT INTO people VALUES (105, 4, 'Nayda ', 'Márquez', true, 3, '', false, false, false, 52, '2015-02-24 02:30:38.332964', '2015-02-24 02:30:38.332964');
INSERT INTO people VALUES (106, 0, 'Miguel A. ', 'Sánchez ', true, 1, '', false, false, false, 52, '2015-02-24 02:31:01.728234', '2015-02-24 02:31:01.728234');
INSERT INTO people VALUES (107, 0, 'Catalino', 'Colón ', true, 0, '', false, false, false, 87, '2015-02-24 02:32:59.759045', '2015-02-24 02:32:59.759045');
INSERT INTO people VALUES (108, NULL, 'Heriberto ', 'Del Valle ', true, 3, '', false, false, false, 87, '2015-02-24 02:33:19.629444', '2015-02-24 02:33:19.629444');
INSERT INTO people VALUES (109, NULL, 'Vacilio ', 'Del Valle ', true, 3, '', false, false, false, 87, '2015-02-24 02:33:49.139829', '2015-02-24 02:33:49.139829');
INSERT INTO people VALUES (110, NULL, 'Wanda ', 'Acevedo ', false, 3, '', false, false, false, 87, '2015-02-24 02:34:06.462161', '2015-02-24 02:34:06.462161');
INSERT INTO people VALUES (111, 1, 'Edwin ', 'Mojica ', true, 0, '', false, false, false, 60, '2015-02-24 02:34:40.419461', '2015-02-24 02:34:40.419461');
INSERT INTO people VALUES (112, 1, 'Norma I. ', 'Torres ', false, 2, '', false, false, false, 60, '2015-02-24 02:35:11.391098', '2015-02-24 02:35:11.391098');
INSERT INTO people VALUES (113, NULL, 'Maria de los A. ', 'Rolón', false, 3, '', false, false, false, 60, '2015-02-24 02:35:37.036285', '2015-02-24 02:35:37.036285');
INSERT INTO people VALUES (114, NULL, 'Carmen ', 'Leduc ', false, 3, '', false, false, false, 60, '2015-02-24 02:35:59.457418', '2015-02-24 02:35:59.457418');
INSERT INTO people VALUES (115, NULL, 'Jossie ', 'Cardona ', false, 3, '', false, false, false, 60, '2015-02-24 02:36:19.732517', '2015-02-24 02:36:19.732517');
INSERT INTO people VALUES (116, NULL, 'Daniel ', 'Cardona ', true, 3, '', false, false, false, 60, '2015-02-24 02:36:47.171359', '2015-02-24 02:36:47.171359');
INSERT INTO people VALUES (117, NULL, 'Carmen L. ', 'Santos ', false, 3, '', false, false, false, 60, '2015-02-24 02:37:12.731568', '2015-02-24 02:37:12.731568');
INSERT INTO people VALUES (118, NULL, 'Wilda ', 'Lugo ', false, 3, '', false, false, false, 60, '2015-02-24 02:37:32.520058', '2015-02-24 02:37:32.520058');
INSERT INTO people VALUES (119, 0, 'Blanca ', 'Velázquez ', false, 0, '', false, false, false, 15, '2015-02-24 02:39:10.397961', '2015-02-24 02:39:10.397961');
INSERT INTO people VALUES (120, NULL, 'Providencia ', 'Hernández ', false, 3, '', false, false, false, 15, '2015-02-24 02:39:44.622382', '2015-02-24 02:39:44.622382');
INSERT INTO people VALUES (121, NULL, 'Audrey ', 'Viera ', false, 3, '', false, false, false, 15, '2015-02-24 02:40:13.362635', '2015-02-24 02:40:13.362635');
INSERT INTO people VALUES (122, 0, 'Alberto J. ', 'Díaz ', true, 0, '', false, false, false, 56, '2015-02-24 02:40:50.078129', '2015-02-24 02:40:50.078129');
INSERT INTO people VALUES (123, 4, 'Sonia ', 'Villodas', false, 3, '', false, false, false, 56, '2015-02-24 02:41:19.738212', '2015-02-24 02:41:19.738212');
INSERT INTO people VALUES (124, NULL, 'Lilybeth ', 'Bosch', false, 3, '', false, false, false, 56, '2015-02-24 02:41:48.368594', '2015-02-24 02:41:48.368594');
INSERT INTO people VALUES (125, NULL, 'Félix J. ', 'Colón ', true, 3, '', false, false, false, 56, '2015-02-24 02:42:20.49519', '2015-02-24 02:42:20.49519');
INSERT INTO people VALUES (126, NULL, 'Abner E. ', 'Cotto ', true, 3, '', false, false, false, 56, '2015-02-24 02:42:55.836961', '2015-02-24 02:42:55.836961');
INSERT INTO people VALUES (127, 0, 'Gladys ', 'Morales ', false, 0, '', false, false, false, 124, '2015-02-24 02:45:36.537569', '2015-02-24 02:45:36.537569');
INSERT INTO people VALUES (128, NULL, 'Margarita ', 'Chico ', false, 3, '', false, false, false, 124, '2015-02-24 02:46:03.776806', '2015-02-24 02:46:03.776806');
INSERT INTO people VALUES (129, NULL, 'Carmen D. ', 'Hernández ', false, 3, '', false, false, false, 124, '2015-02-24 02:46:39.451325', '2015-02-24 02:46:39.451325');
INSERT INTO people VALUES (130, 0, 'Ulbencio ', 'Rivera ', true, 0, '', false, false, false, 65, '2015-02-24 02:47:50.485002', '2015-02-24 02:47:50.485002');
INSERT INTO people VALUES (131, 0, 'Glenda L. ', 'De León ', false, 1, '', false, false, false, 65, '2015-02-24 02:48:14.616949', '2015-02-24 02:48:14.616949');
INSERT INTO people VALUES (132, NULL, 'Marisabel ', 'Beltrán ', false, 3, '', false, false, false, 65, '2015-02-24 02:48:45.523712', '2015-02-24 02:48:45.523712');
INSERT INTO people VALUES (133, NULL, 'Lizvette ', 'Rodríguez ', false, 3, '', false, false, false, 65, '2015-02-24 02:49:09.238478', '2015-02-24 02:49:09.238478');
INSERT INTO people VALUES (134, 0, 'Lizette ', 'Hernández ', false, 0, '', false, false, false, 23, '2015-02-24 02:52:08.030117', '2015-02-24 02:52:08.030117');
INSERT INTO people VALUES (135, NULL, 'Irving ', 'Rivera ', true, 3, '', false, false, false, 23, '2015-02-24 02:52:29.814474', '2015-02-24 02:52:29.814474');
INSERT INTO people VALUES (136, NULL, 'Luz D. ', 'Lozada ', false, 3, '', false, false, false, 23, '2015-02-24 02:52:52.625027', '2015-02-24 02:52:52.625027');
INSERT INTO people VALUES (137, NULL, 'Grisel ', 'Díaz ', false, 3, '', false, false, false, 23, '2015-02-24 02:53:15.800547', '2015-02-24 02:53:15.800547');
INSERT INTO people VALUES (138, 1, 'Carmen C. ', 'Adames ', false, 0, '', false, false, false, 25, '2015-02-24 04:30:24.198051', '2015-02-24 04:30:24.198051');
INSERT INTO people VALUES (139, 1, 'Juan E. ', 'Matias ', true, 1, '', false, false, false, 25, '2015-02-24 04:31:25.127264', '2015-02-24 04:31:25.127264');
INSERT INTO people VALUES (140, 1, 'Marilyn ', 'Ortiz ', true, 1, '', false, false, false, 25, '2015-02-24 04:32:32.978955', '2015-02-24 04:32:32.978955');
INSERT INTO people VALUES (141, 1, 'María E. ', 'Calderón ', false, 1, '', false, false, false, 25, '2015-02-24 04:33:33.087962', '2015-02-24 04:33:33.087962');
INSERT INTO people VALUES (142, 1, 'Carmen M. ', 'Arroyo ', false, 1, '', false, false, false, 25, '2015-02-24 04:34:25.075862', '2015-02-24 04:34:25.075862');
INSERT INTO people VALUES (143, 1, 'Luis R. ', 'Quiñones ', true, 1, '', false, false, false, 25, '2015-02-24 04:35:16.49935', '2015-02-24 04:35:16.49935');
INSERT INTO people VALUES (144, 0, 'Omar A. ', 'Santiago ', true, 1, '', false, false, false, 25, '2015-02-24 04:36:11.543037', '2015-02-24 04:36:11.543037');
INSERT INTO people VALUES (145, 0, 'Margot ', 'Camacho ', false, 1, '', false, false, false, 25, '2015-02-24 04:37:06.046467', '2015-02-24 04:37:06.046467');
INSERT INTO people VALUES (147, NULL, 'Mario ', 'Moya ', true, 3, '', false, false, false, 25, '2015-02-24 04:38:43.989795', '2015-02-24 04:38:43.989795');
INSERT INTO people VALUES (148, NULL, 'Carmen ', 'Morales ', false, 3, '', false, false, false, 25, '2015-02-24 04:39:28.23007', '2015-02-24 04:39:28.23007');
INSERT INTO people VALUES (149, NULL, 'José A. ', 'Fernández ', true, 3, '', false, false, false, 25, '2015-02-24 04:40:17.711563', '2015-02-24 04:40:17.711563');
INSERT INTO people VALUES (154, 1, 'Madelyn ', 'Figueroa Alamo', false, 1, '', false, false, false, 25, '2015-02-24 13:30:40.268446', '2015-02-24 13:30:40.268446');
INSERT INTO people VALUES (155, NULL, 'Angela ', 'Arroyo Santiago', false, 3, '', false, false, false, 25, '2015-02-24 13:31:13.682457', '2015-02-24 13:31:13.682457');
INSERT INTO people VALUES (156, NULL, 'Norma ', 'Valentin Guerrero', false, 3, '', false, false, false, 25, '2015-02-24 13:31:44.768649', '2015-02-24 13:31:44.768649');
INSERT INTO people VALUES (157, NULL, 'Sonia ', 'García Hernández ', false, 3, '', false, false, false, 25, '2015-02-24 13:32:21.484489', '2015-02-24 13:32:21.484489');
INSERT INTO people VALUES (158, NULL, 'Fernando ', 'Barreto Cardona ', true, 3, '', false, false, false, 25, '2015-02-24 13:32:55.491074', '2015-02-24 13:32:55.491074');
INSERT INTO people VALUES (159, NULL, 'Carlos ', 'Rodriguez Delannoy', true, 3, '', false, false, false, 25, '2015-02-24 13:33:17.399365', '2015-02-24 13:33:17.399365');
INSERT INTO people VALUES (160, NULL, 'Carlos ', 'Dominguez Cristobal', true, 3, '', false, false, false, 25, '2015-02-24 13:33:40.851015', '2015-02-24 13:33:40.851015');
INSERT INTO people VALUES (161, NULL, 'Gladys ', 'Linares Estrada', false, 3, '', false, false, false, 25, '2015-02-24 13:34:03.070512', '2015-02-24 13:34:03.070512');
INSERT INTO people VALUES (162, 0, 'Nilsa ', 'Rodríguez Casillas', false, 0, '', false, false, false, 26, '2015-02-24 13:50:27.216163', '2015-02-24 13:50:27.216163');
INSERT INTO people VALUES (163, NULL, 'Neris ', 'Carrasquillo ', false, 3, '', false, false, false, 26, '2015-02-24 13:50:59.0368', '2015-02-24 13:50:59.0368');
INSERT INTO people VALUES (164, NULL, 'Sonia ', 'Casillas ', false, 3, '', false, false, false, 26, '2015-02-24 13:51:15.708854', '2015-02-24 13:51:15.708854');
INSERT INTO people VALUES (165, NULL, 'Margarita ', 'Rodríguez', false, 3, '', false, false, false, 26, '2015-02-24 13:51:43.982194', '2015-02-24 13:51:43.982194');
INSERT INTO people VALUES (166, 0, 'Pedro', 'González', true, 0, '', false, false, false, 20, '2015-02-24 13:52:46.225562', '2015-02-24 13:52:46.225562');
INSERT INTO people VALUES (167, NULL, 'Francisco ', 'Medina ', false, 3, '', false, false, false, 20, '2015-02-24 13:54:46.987425', '2015-02-24 13:54:46.987425');
INSERT INTO people VALUES (168, NULL, 'Lilliana ', 'Landrón', false, 3, '', false, false, false, 20, '2015-02-24 13:55:10.76219', '2015-02-24 13:55:10.76219');
INSERT INTO people VALUES (169, NULL, 'Sonia ', 'Lugo', false, 3, '', false, false, false, 20, '2015-02-24 13:55:28.176248', '2015-02-24 13:55:28.176248');
INSERT INTO people VALUES (170, NULL, 'Nilsa ', 'Muñoz', false, 3, '', false, false, false, 20, '2015-02-24 13:55:46.930581', '2015-02-24 13:55:46.930581');
INSERT INTO people VALUES (171, NULL, 'Rebeca', 'Castro', false, 3, 'Sustituto', false, false, false, 20, '2015-02-24 13:56:21.984322', '2015-02-24 13:56:21.984322');
INSERT INTO people VALUES (172, NULL, 'Cecilio', 'Rivera', true, 3, 'Sustituto', false, false, false, 20, '2015-02-24 13:58:26.021753', '2015-02-24 13:58:26.021753');
INSERT INTO people VALUES (173, 0, 'Margarita ', 'Santana ', false, 0, '', false, false, false, 24, '2015-02-24 14:00:34.174153', '2015-02-24 14:00:34.174153');
INSERT INTO people VALUES (146, 0, 'Alicia E. ', 'Liard ', false, 1, '', false, false, false, 25, '2015-02-24 04:37:52.518536', '2015-02-24 11:55:05.277009');
INSERT INTO people VALUES (150, NULL, 'Milagros ', 'Pizarrro', false, 3, '', false, false, false, 25, '2015-02-24 13:22:38.515628', '2015-02-24 13:22:38.515628');
INSERT INTO people VALUES (151, NULL, 'Maria E.', 'Rivera Melendez ', false, 3, '', false, false, false, 25, '2015-02-24 13:25:34.789697', '2015-02-24 13:25:34.789697');
INSERT INTO people VALUES (152, NULL, 'Victor ', 'Rivera Santiago', true, 3, '', false, false, false, 25, '2015-02-24 13:26:17.801431', '2015-02-24 13:26:17.801431');
INSERT INTO people VALUES (153, NULL, 'Lillian', 'Rivera Morales', false, 3, '', false, false, false, 25, '2015-02-24 13:26:47.056805', '2015-02-24 13:27:22.975993');
INSERT INTO people VALUES (175, NULL, 'Marisol ', 'Sanchez ', false, 3, '', false, false, false, 24, '2015-02-24 14:03:07.962388', '2015-02-24 14:03:07.962388');
INSERT INTO people VALUES (176, NULL, 'Juan ', 'Morales ', true, 3, '', false, false, false, 24, '2015-02-24 14:03:23.99237', '2015-02-24 14:03:23.99237');
INSERT INTO people VALUES (177, 1, 'Irma ', 'Pastrana ', false, 0, '', false, false, false, 1, '2015-02-24 14:06:06.140412', '2015-02-24 14:06:06.140412');
INSERT INTO people VALUES (178, 0, 'Pedro ', 'Castro', true, 1, '', false, false, false, 1, '2015-02-24 14:06:33.86769', '2015-02-24 14:06:33.86769');
INSERT INTO people VALUES (179, 1, 'Angel ', 'Mundo', true, 1, '', false, false, false, 1, '2015-02-24 14:07:06.346536', '2015-02-24 14:07:06.346536');
INSERT INTO people VALUES (180, NULL, 'Aida I. ', 'Torres', false, 3, '', false, false, false, 1, '2015-02-24 14:08:52.759995', '2015-02-24 14:08:52.759995');
INSERT INTO people VALUES (181, NULL, 'Luis ', 'Rosario ', true, 3, '', false, false, false, 1, '2015-02-24 14:09:15.743096', '2015-02-24 14:09:15.743096');
INSERT INTO people VALUES (182, NULL, 'Luis ', 'Osorio', true, 3, '', false, false, false, 1, '2015-02-24 14:09:37.573035', '2015-02-24 14:09:37.573035');
INSERT INTO people VALUES (183, NULL, 'Saúl ', 'Castillo', true, 3, '', false, false, false, 1, '2015-02-24 14:10:04.471921', '2015-02-24 14:10:04.471921');
INSERT INTO people VALUES (184, NULL, 'Carlos ', 'Febo ', true, 3, '', false, false, false, 1, '2015-02-24 14:10:25.178415', '2015-02-24 14:10:25.178415');
INSERT INTO people VALUES (185, 0, 'Javier E. ', 'Sosa Rodríguez', true, 0, '', false, false, false, 42, '2015-02-24 14:18:03.475814', '2015-02-24 14:18:03.475814');
INSERT INTO people VALUES (186, NULL, 'Carmen ', 'Johnson ', false, 3, '', false, false, false, 42, '2015-02-24 14:18:37.60102', '2015-02-24 14:18:37.60102');
INSERT INTO people VALUES (187, NULL, 'Ada N.', 'Quiñones', false, 3, '', false, false, false, 42, '2015-02-24 14:19:01.547741', '2015-02-24 14:19:01.547741');
INSERT INTO people VALUES (188, NULL, 'Anidalia ', 'Rivera', false, 3, '', false, false, false, 42, '2015-02-24 14:19:32.496052', '2015-02-24 14:19:32.496052');
INSERT INTO people VALUES (190, NULL, 'Joel ', 'Roldán Oquendo ', true, 3, '', false, false, false, 83, '2015-02-24 14:26:26.019892', '2015-02-24 14:26:26.019892');
INSERT INTO people VALUES (191, NULL, 'Raúl ', 'Matos Castilo', true, 3, '', false, false, false, 83, '2015-02-24 14:26:50.425779', '2015-02-24 14:26:50.425779');
INSERT INTO people VALUES (193, NULL, 'Nilda ', 'García', false, 3, '', false, false, false, 19, '2015-02-24 14:28:49.381875', '2015-02-24 14:28:49.381875');
INSERT INTO people VALUES (194, NULL, 'Maria ', 'Charles ', false, 3, '', false, false, false, 19, '2015-02-24 14:32:01.785633', '2015-02-24 14:32:01.785633');
INSERT INTO people VALUES (195, NULL, 'Arelys ', 'Ortiz', true, 3, '', false, false, false, 69, '2015-02-24 14:34:57.882413', '2015-02-24 14:34:57.882413');
INSERT INTO people VALUES (196, NULL, 'Jossie ', 'Sostre', false, 3, '', false, false, false, 69, '2015-02-24 14:35:32.238243', '2015-02-24 14:35:32.238243');
INSERT INTO people VALUES (197, NULL, 'Daisy ', 'García', false, 3, '', false, false, false, 69, '2015-02-24 14:36:01.266279', '2015-02-24 14:36:01.266279');
INSERT INTO people VALUES (198, NULL, 'Antonio ', 'Freire', true, 3, '', false, false, false, 69, '2015-02-24 14:36:33.922822', '2015-02-24 14:36:33.922822');
INSERT INTO people VALUES (199, NULL, 'David ', 'Morales ', true, 3, '', false, false, false, 69, '2015-02-24 14:36:58.831092', '2015-02-24 14:36:58.831092');
INSERT INTO people VALUES (200, NULL, 'Minerva ', 'Rivera', false, 3, '', false, false, false, 69, '2015-02-24 14:37:42.741944', '2015-02-24 14:37:42.741944');
INSERT INTO people VALUES (201, 0, 'Susana ', 'Rivera ', false, 0, '', false, false, false, 67, '2015-02-24 14:39:41.628178', '2015-02-24 14:39:41.628178');
INSERT INTO people VALUES (202, 1, 'Aniceto', 'Sustache', true, 0, '', false, false, false, 66, '2015-02-24 14:41:07.88743', '2015-02-24 14:41:07.88743');
INSERT INTO people VALUES (203, NULL, 'Maria ', 'Quiñones ', false, 3, '', false, false, false, 66, '2015-02-24 14:41:40.761442', '2015-02-24 14:41:40.761442');
INSERT INTO people VALUES (204, NULL, 'Iris ', 'Colon Padilla ', false, 3, '', false, false, false, 66, '2015-02-24 14:42:04.139904', '2015-02-24 14:42:04.139904');
INSERT INTO people VALUES (206, NULL, 'Nilsa L. ', 'Torres Correa', true, 3, '', false, false, false, 84, '2015-02-24 14:43:11.47927', '2015-02-24 14:43:11.47927');
INSERT INTO people VALUES (207, NULL, 'Migdalia ', 'Quiñones Pizarro', false, 3, '', false, false, false, 84, '2015-02-24 14:43:36.159235', '2015-02-24 14:43:36.159235');
INSERT INTO people VALUES (208, NULL, 'Anita ', 'González', false, 3, '', false, false, false, 84, '2015-02-24 14:43:53.101388', '2015-02-24 14:43:53.101388');
INSERT INTO people VALUES (209, NULL, 'Víctor ', 'Valentín', true, 3, '', false, false, false, 84, '2015-02-24 14:44:22.637707', '2015-02-24 14:44:22.637707');
INSERT INTO people VALUES (210, NULL, 'Ismael ', 'González', true, 3, '', false, false, false, 84, '2015-02-24 14:44:40.125466', '2015-02-24 14:44:40.125466');
INSERT INTO people VALUES (211, NULL, 'Glorielis', 'Flores Rodriguez ', false, 3, '', false, false, false, 84, '2015-02-24 14:45:14.699725', '2015-02-24 14:45:14.699725');
INSERT INTO people VALUES (212, NULL, 'María del C.', 'Lanzo', false, 3, '', false, false, false, 84, '2015-02-24 14:45:35.727958', '2015-02-24 14:45:35.727958');
INSERT INTO people VALUES (213, NULL, 'Emma ', 'Figueroa Agosto', false, 3, '', false, false, false, 84, '2015-02-24 14:46:01.725059', '2015-02-24 14:46:01.725059');
INSERT INTO people VALUES (214, NULL, 'Antonia ', 'Urbina ', false, 3, '', false, false, false, 84, '2015-02-24 14:46:22.77843', '2015-02-24 14:46:22.77843');
INSERT INTO people VALUES (215, NULL, 'Pedro ', 'Carrasquillo ', true, 3, '', false, false, false, 84, '2015-02-24 14:46:39.863971', '2015-02-24 14:46:39.863971');
INSERT INTO people VALUES (216, 1, 'Jose ', 'Calo Castro', true, 0, '', false, false, false, 84, '2015-02-24 14:46:58.269313', '2015-02-24 14:46:58.269313');
INSERT INTO people VALUES (205, 1, 'Luz E.', 'Rodríguez', false, 1, '', false, false, false, 84, '2015-02-24 14:42:43.920366', '2015-02-24 14:47:16.099342');
INSERT INTO people VALUES (217, 0, 'Abraham', 'Morales ', true, 0, '', false, false, false, 21, '2015-02-24 14:51:21.886829', '2015-02-24 14:51:21.886829');
INSERT INTO people VALUES (218, NULL, 'Johnny ', 'Rivera', true, 3, '', false, false, false, 21, '2015-02-24 14:51:45.799248', '2015-02-24 14:51:45.799248');
INSERT INTO people VALUES (219, NULL, 'Oscar ', 'Santiago', true, 3, '', false, false, false, 21, '2015-02-24 14:51:58.885631', '2015-02-24 14:51:58.885631');
INSERT INTO people VALUES (220, 0, 'Elsa ', 'Rivera Martínez ', false, 0, '', false, false, false, 68, '2015-02-24 14:54:01.686913', '2015-02-24 14:54:01.686913');
INSERT INTO people VALUES (221, NULL, 'Lained ', 'Bonano ', false, 3, '', false, false, false, 68, '2015-02-24 14:55:06.388086', '2015-02-24 14:55:06.388086');
INSERT INTO people VALUES (222, NULL, 'Marcelina ', 'Escalera ', true, 3, '', false, false, false, 68, '2015-02-24 14:56:17.092857', '2015-02-24 14:56:17.092857');
INSERT INTO people VALUES (225, 0, 'Francisco', 'Pinto', true, 2, '', false, false, false, 1, '2015-02-24 15:01:44.624629', '2015-02-24 15:01:44.624629');
INSERT INTO people VALUES (226, 0, 'Hilda G.', 'Acosta Rivera', false, 0, '', false, false, false, 97, '2015-02-24 15:02:58.244599', '2015-02-24 15:02:58.244599');
INSERT INTO people VALUES (227, NULL, 'Sheyla ', 'Quiros Vazquez ', false, 3, '', false, false, false, 97, '2015-02-24 15:03:30.84962', '2015-02-24 15:03:30.84962');
INSERT INTO people VALUES (228, NULL, 'Hector M. ', 'González ', true, 3, '', false, false, false, 97, '2015-02-24 15:04:05.736746', '2015-02-24 15:04:05.736746');
INSERT INTO people VALUES (229, NULL, 'Lucy ', 'Muñoz', false, 3, '', false, false, false, 39, '2015-02-24 15:04:56.866984', '2015-02-24 15:04:56.866984');
INSERT INTO people VALUES (230, NULL, 'Norma I.', 'Pérez', false, 3, '', false, false, false, 39, '2015-02-24 15:05:16.436013', '2015-02-24 15:05:16.436013');
INSERT INTO people VALUES (231, 0, 'Celis ', 'Zambrana Batista', false, 0, '', false, false, false, 45, '2015-02-24 15:06:14.599552', '2015-02-24 15:06:14.599552');
INSERT INTO people VALUES (232, NULL, 'Nilma Y. ', 'Agosto García', false, 5, '', false, false, false, 45, '2015-02-24 15:06:56.720207', '2015-02-24 15:06:56.720207');
INSERT INTO people VALUES (233, NULL, 'David ', 'Soto Cardona ', true, 3, '', false, false, false, 45, '2015-02-24 15:07:18.502531', '2015-02-24 15:07:18.502531');
INSERT INTO people VALUES (234, NULL, 'Digna ', 'Valdés Laboy', false, 3, '', false, false, false, 45, '2015-02-24 15:07:44.27617', '2015-02-24 15:07:44.27617');
INSERT INTO people VALUES (235, NULL, 'Luis ', 'Berrios Bones ', true, 3, '', false, false, false, 45, '2015-02-24 15:08:07.300651', '2015-02-24 15:08:07.300651');
INSERT INTO people VALUES (236, NULL, 'Maria C. ', 'Gómez García', false, 3, 'Sustituto', false, false, false, 45, '2015-02-24 15:08:43.89609', '2015-02-24 15:08:43.89609');
INSERT INTO people VALUES (237, NULL, 'Santos ', 'Torres Padilla ', true, 3, 'Sustituto', false, false, false, 45, '2015-02-24 15:09:04.911706', '2015-02-24 15:09:04.911706');
INSERT INTO people VALUES (238, 0, 'Carlos A. ', 'Padilla Rivera ', true, 0, '', false, false, false, 47, '2015-02-24 15:09:45.918708', '2015-02-24 15:09:45.918708');
INSERT INTO people VALUES (239, NULL, 'Robert ', 'Quintero Negrón', true, 3, '', false, false, false, 71, '2015-02-24 15:10:43.116616', '2015-02-24 15:10:43.116616');
INSERT INTO people VALUES (240, NULL, 'Priscilla ', 'Esteves Ponde de León', false, 3, '', false, false, false, 71, '2015-02-24 15:11:09.635891', '2015-02-24 15:11:09.635891');
INSERT INTO people VALUES (241, 1, 'Magda ', 'Aguirre', false, 0, '', false, false, false, 76, '2015-02-24 15:12:09.346928', '2015-02-24 15:12:09.346928');
INSERT INTO people VALUES (242, NULL, 'Maribel ', 'Colón', true, 3, '', false, false, false, 76, '2015-02-24 15:12:49.333038', '2015-02-24 15:12:49.333038');
INSERT INTO people VALUES (243, NULL, 'Minerva ', 'Costa ', false, 3, '', false, false, false, 76, '2015-02-24 15:13:14.962885', '2015-02-24 15:13:14.962885');
INSERT INTO people VALUES (244, NULL, 'Delma ', 'Lananze', false, 3, '', false, false, false, 76, '2015-02-24 15:13:38.480586', '2015-02-24 15:13:38.480586');
INSERT INTO people VALUES (245, 0, 'Luis ', 'Serrano', true, 0, '', false, false, false, 6, '2015-02-24 15:14:15.607845', '2015-02-24 15:14:15.607845');
INSERT INTO people VALUES (246, NULL, 'Raquel ', 'López Rodríguez ', false, 3, '', false, false, false, 6, '2015-02-24 15:14:41.256116', '2015-02-24 15:14:41.256116');
INSERT INTO people VALUES (247, NULL, 'Roberto ', 'Vera Monroig', true, 3, '', false, false, false, 6, '2015-02-24 15:15:22.012673', '2015-02-24 15:15:22.012673');
INSERT INTO people VALUES (248, 1, 'Juan N. ', 'Medina Argueta', true, 0, '', false, false, false, 99, '2015-02-24 15:16:16.155526', '2015-02-24 15:16:16.155526');
INSERT INTO people VALUES (249, NULL, 'Yolanda ', 'Orendo Montes', false, 3, '', false, false, false, 99, '2015-02-24 15:16:47.614559', '2015-02-24 15:16:47.614559');
INSERT INTO people VALUES (250, NULL, 'Elsa I. ', 'Mercado Torres', false, 3, '', false, false, false, 99, '2015-02-24 15:17:04.962409', '2015-02-24 15:17:04.962409');
INSERT INTO people VALUES (253, NULL, 'Marta ', 'Ayala Vega ', false, 3, '', false, false, false, 99, '2015-02-24 15:18:59.956187', '2015-02-24 15:18:59.956187');
INSERT INTO people VALUES (254, NULL, 'Noel Y. ', 'Pachecho Alvarez ', true, 3, '', false, false, false, 99, '2015-02-24 15:26:06.338909', '2015-02-24 15:26:06.338909');
INSERT INTO people VALUES (251, NULL, 'Clarissa', 'Rodríguez', false, 3, '', false, false, false, 99, '2015-02-24 15:17:40.919683', '2015-02-24 15:27:46.077982');
INSERT INTO people VALUES (255, 0, 'Edgardo ', 'Caraballo', true, 0, '', false, false, false, 18, '2015-02-24 15:30:51.289108', '2015-02-24 15:30:51.289108');
INSERT INTO people VALUES (256, NULL, 'Miguel ', 'Vázquez ', true, 3, '', false, false, false, 18, '2015-02-24 15:31:15.04761', '2015-02-24 15:31:15.04761');
INSERT INTO people VALUES (257, NULL, 'Matilde ', 'Dávila ', false, 3, '', false, false, false, 18, '2015-02-24 15:31:36.90614', '2015-02-24 15:31:36.90614');
INSERT INTO people VALUES (258, NULL, 'Miguel ', 'Carrasquillo ', true, 3, '', false, false, false, 18, '2015-02-24 15:31:57.720168', '2015-02-24 15:31:57.720168');
INSERT INTO people VALUES (259, NULL, 'Benjamín ', 'Ortiz ', true, 3, '', false, false, false, 18, '2015-02-24 15:32:15.70409', '2015-02-24 15:32:15.70409');
INSERT INTO people VALUES (260, NULL, 'Libertad ', 'Carrión ', false, 3, '', false, false, false, 18, '2015-02-24 15:32:33.980877', '2015-02-24 15:32:33.980877');
INSERT INTO people VALUES (261, NULL, 'Carmen I.', 'Fontanez ', false, 3, '', false, false, false, 96, '2015-02-24 15:36:45.081695', '2015-02-24 15:36:45.081695');
INSERT INTO people VALUES (262, NULL, 'Luis ', 'Beltran ', true, 3, '', false, false, false, 96, '2015-02-24 15:36:59.766195', '2015-02-24 15:36:59.766195');
INSERT INTO people VALUES (263, NULL, 'Evelyn ', 'Cruz ', false, 3, '', false, false, false, 96, '2015-02-24 15:37:12.574595', '2015-02-24 15:37:12.574595');
INSERT INTO people VALUES (264, NULL, 'Luis A. ', 'Poggi', true, 3, '', false, false, false, 96, '2015-02-24 15:37:27.835344', '2015-02-24 15:37:27.835344');
INSERT INTO people VALUES (266, NULL, 'Deliris ', 'Carrión ', false, 5, '', false, false, false, 69, '2015-02-24 15:41:10.184324', '2015-02-24 15:41:10.184324');
INSERT INTO people VALUES (267, NULL, 'Wanda I. ', 'Rentas Morales ', false, 5, '', false, false, false, 10, '2015-02-24 17:29:51.385662', '2015-02-24 17:29:51.385662');
INSERT INTO people VALUES (268, 1, 'Carmen J.', 'Pagan ', false, 3, 'Sustituto', false, false, false, 103, '2015-02-24 17:33:42.65932', '2015-02-24 17:33:42.65932');
INSERT INTO people VALUES (269, 0, 'Ramon ', 'Arroyo', true, 0, '', false, false, false, 40, '2015-02-24 17:40:29.026992', '2015-02-24 17:40:29.026992');
INSERT INTO people VALUES (270, 4, 'Arturo J. ', 'Siaca', true, 3, '', false, false, false, 36, '2015-02-24 17:41:40.122104', '2015-02-24 17:41:40.122104');
INSERT INTO people VALUES (271, NULL, 'Eddie ', 'Diaz', true, 4, '', false, false, false, 108, '2015-02-24 17:43:15.014054', '2015-02-24 17:43:15.014054');
INSERT INTO people VALUES (2, NULL, 'Susano ', 'Luzunaris ', false, 3, '', false, false, false, 108, '2015-02-23 22:22:37.697968', '2015-02-24 17:44:05.226801');
INSERT INTO people VALUES (174, 0, 'Rosalba ', 'Velez', false, 3, '', false, false, false, 24, '2015-02-24 14:01:17.186728', '2015-02-24 17:48:37.171553');
INSERT INTO people VALUES (223, 1, 'Myrna I. ', 'Ramos', false, 1, '', false, false, false, 1, '2015-02-24 15:00:38.844886', '2015-02-24 17:49:13.571321');
INSERT INTO people VALUES (224, 1, 'Efrain ', 'Figueroa', true, 2, '', false, false, false, 1, '2015-02-24 15:01:02.222804', '2015-02-24 17:49:30.479334');
INSERT INTO people VALUES (192, 0, 'Abigail ', 'Castro', false, 0, '', false, false, false, 19, '2015-02-24 14:28:11.78421', '2015-02-28 19:27:39.692859');
INSERT INTO people VALUES (265, NULL, 'Angel M. ', 'García', true, 1, '', false, false, false, 69, '2015-02-24 15:40:47.634235', '2015-02-24 17:46:07.909895');
INSERT INTO people VALUES (272, NULL, 'Debora ', 'Varona Guerrero', false, 4, '', false, false, false, 3, '2015-02-24 18:10:46.12455', '2015-02-24 18:10:46.12455');
INSERT INTO people VALUES (273, 0, 'Rolando ', 'Pabellón ', true, 0, '', false, false, false, 32, '2015-02-25 13:22:35.132459', '2015-02-25 13:22:35.132459');
INSERT INTO people VALUES (274, NULL, 'María ', 'Benitez', false, 3, '', false, false, false, 32, '2015-02-25 13:22:58.907116', '2015-02-25 13:22:58.907116');
INSERT INTO people VALUES (275, NULL, 'Diana ', 'Alomar', false, 3, '', false, false, false, 32, '2015-02-25 13:23:22.91189', '2015-02-25 13:23:22.91189');
INSERT INTO people VALUES (276, NULL, 'Efraín', 'Dávila ', true, 3, '', false, false, false, 32, '2015-02-25 13:23:47.195972', '2015-02-25 13:23:47.195972');
INSERT INTO people VALUES (277, NULL, 'Daniel ', 'Pérez Medina ', true, 3, '', false, false, false, 19, '2015-02-25 13:25:23.91918', '2015-02-25 13:25:23.91918');
INSERT INTO people VALUES (278, 0, 'Germán ', 'Malavé', false, 0, '', false, false, false, 11, '2015-02-25 14:45:14.416172', '2015-02-25 14:45:14.416172');
INSERT INTO people VALUES (279, NULL, 'Lilliam ', 'Santos ', false, 3, '', false, false, false, 11, '2015-02-25 14:45:41.268414', '2015-02-25 14:45:41.268414');
INSERT INTO people VALUES (280, NULL, 'Lydia ', 'Del Valle', false, 3, '', false, false, false, 11, '2015-02-25 14:46:00.734214', '2015-02-25 14:46:00.734214');
INSERT INTO people VALUES (281, NULL, 'Carmen ', 'Zayas ', false, 3, '', false, false, false, 11, '2015-02-25 14:46:16.166752', '2015-02-25 14:46:16.166752');
INSERT INTO people VALUES (282, 1, 'Dr. Anibal ', 'Cruz ', true, 3, '', false, false, false, 121, '2015-02-25 14:47:11.251809', '2015-02-25 14:47:11.251809');
INSERT INTO people VALUES (283, NULL, 'Danirys ', 'Sánchez ', false, 3, '', false, false, false, 118, '2015-02-25 14:48:04.168582', '2015-02-25 14:48:04.168582');
INSERT INTO people VALUES (284, 6, 'Daniel ', 'Santos', true, 3, '', false, false, false, 120, '2015-02-25 14:49:00.280008', '2015-02-25 14:49:00.280008');
INSERT INTO people VALUES (285, NULL, 'Awilda ', 'Bonilla', false, 3, '', false, false, false, 122, '2015-02-25 14:49:25.742138', '2015-02-25 14:49:25.742138');
INSERT INTO people VALUES (286, 2, 'Alejandrina ', 'Ortiz ', true, 3, '', false, false, false, 119, '2015-02-25 14:50:38.256213', '2015-02-25 14:50:38.256213');
INSERT INTO people VALUES (287, 1, 'Efraín ', 'Rosario ', true, 0, '', false, false, false, 27, '2015-02-27 02:29:25.417229', '2015-02-27 02:29:25.417229');
INSERT INTO people VALUES (288, NULL, 'Rosa ', 'Capellán ', false, 3, '', false, false, false, 27, '2015-02-27 02:30:14.499799', '2015-02-27 02:30:14.499799');
INSERT INTO people VALUES (289, 1, 'Angel L. ', 'Pabellón', true, 0, '', false, false, false, 75, '2015-02-27 02:34:55.182295', '2015-02-27 02:34:55.182295');
INSERT INTO people VALUES (290, NULL, 'María D.', 'Nuñez ', false, 3, '', false, false, false, 75, '2015-02-27 02:35:45.393998', '2015-02-27 02:35:45.393998');
INSERT INTO people VALUES (291, NULL, 'Julio ', 'Cintrón', true, 3, '', false, false, false, 75, '2015-02-27 02:36:13.132308', '2015-02-27 02:36:13.132308');
INSERT INTO people VALUES (292, 0, 'Karilyn ', 'Galarza ', false, 0, '', false, false, false, 98, '2015-02-27 02:37:13.680893', '2015-02-27 02:37:13.680893');
INSERT INTO people VALUES (293, NULL, 'Diana ', 'Medina ', false, 4, '', false, false, false, 98, '2015-02-27 02:37:49.971019', '2015-02-27 02:37:49.971019');
INSERT INTO people VALUES (294, 4, 'Nilda E. ', 'García ', false, 3, '', false, false, false, 83, '2015-02-27 02:39:11.936961', '2015-02-27 02:39:11.936961');
INSERT INTO people VALUES (295, 1, 'José A. ', 'López', true, 0, '', false, false, false, 53, '2015-02-27 02:44:15.396685', '2015-02-27 02:44:15.396685');
INSERT INTO people VALUES (296, 1, 'Félix ', 'López ', true, 2, '', false, false, false, 53, '2015-02-27 02:44:42.000719', '2015-02-27 02:44:42.000719');
INSERT INTO people VALUES (297, NULL, 'María ', 'Castillo ', false, 3, '', false, false, false, 53, '2015-02-27 02:45:46.184223', '2015-02-27 02:45:46.184223');
INSERT INTO people VALUES (298, NULL, 'Rebeca ', 'Rivera ', false, 3, '', false, false, false, 53, '2015-02-27 02:46:06.542945', '2015-02-27 02:46:06.542945');
INSERT INTO people VALUES (299, NULL, 'Isabel ', 'Calderón ', true, 3, '', false, false, false, 53, '2015-02-27 02:46:30.932917', '2015-02-27 02:46:30.932917');


--
-- Name: people_id_seq; Type: SEQUENCE SET; Schema: public; Owner: registroibpr
--

SELECT pg_catalog.setval('people_id_seq', 299, true);

--
-- Data for Name: versions; Type: TABLE DATA; Schema: public; Owner: registroibpr
--

INSERT INTO versions VALUES (1, 'Person', 1, 'create', NULL, NULL, '2015-02-23 22:21:49.901745');
INSERT INTO versions VALUES (2, 'Person', 2, 'create', NULL, NULL, '2015-02-23 22:22:37.699667');
INSERT INTO versions VALUES (3, 'Person', 3, 'create', NULL, NULL, '2015-02-23 22:23:11.600129');
INSERT INTO versions VALUES (4, 'Person', 4, 'create', NULL, NULL, '2015-02-23 22:23:49.80735');
INSERT INTO versions VALUES (5, 'Person', 5, 'create', NULL, NULL, '2015-02-23 22:24:15.400077');
INSERT INTO versions VALUES (6, 'Person', 6, 'create', NULL, NULL, '2015-02-23 22:25:35.266899');
INSERT INTO versions VALUES (7, 'Person', 7, 'create', NULL, NULL, '2015-02-23 22:26:10.39383');
INSERT INTO versions VALUES (8, 'Person', 8, 'create', NULL, NULL, '2015-02-23 22:26:41.589916');
INSERT INTO versions VALUES (9, 'Person', 9, 'create', NULL, NULL, '2015-02-23 22:27:06.710312');
INSERT INTO versions VALUES (10, 'Person', 10, 'create', NULL, NULL, '2015-02-24 01:17:20.486627');
INSERT INTO versions VALUES (11, 'Person', 11, 'create', NULL, NULL, '2015-02-24 01:17:56.12176');
INSERT INTO versions VALUES (12, 'Person', 12, 'create', NULL, NULL, '2015-02-24 01:18:51.364555');
INSERT INTO versions VALUES (13, 'Person', 13, 'create', NULL, NULL, '2015-02-24 01:19:13.410593');
INSERT INTO versions VALUES (14, 'Person', 14, 'create', NULL, NULL, '2015-02-24 01:19:45.855661');
INSERT INTO versions VALUES (15, 'Person', 15, 'create', NULL, NULL, '2015-02-24 01:20:22.246963');
INSERT INTO versions VALUES (16, 'Person', 16, 'create', NULL, NULL, '2015-02-24 01:20:55.461292');
INSERT INTO versions VALUES (17, 'Check', 1, 'create', NULL, NULL, '2015-02-24 01:21:39.718015');
INSERT INTO versions VALUES (18, 'Person', 15, 'destroy', NULL, '---
id: 15
salutation: 
name: ''Zoraida ''
lastnames: ''Rivera ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 103
created_at: 2015-02-24 01:20:22.245553000 Z
updated_at: 2015-02-24 01:20:22.245553000 Z
', '2015-02-24 01:22:09.972554');
INSERT INTO versions VALUES (19, 'Check', 2, 'create', NULL, NULL, '2015-02-24 01:23:13.970975');
INSERT INTO versions VALUES (20, 'Person', 17, 'create', NULL, NULL, '2015-02-24 01:24:22.066956');
INSERT INTO versions VALUES (21, 'Person', 18, 'create', NULL, NULL, '2015-02-24 01:25:06.339546');
INSERT INTO versions VALUES (22, 'Person', 19, 'create', NULL, NULL, '2015-02-24 01:25:39.805253');
INSERT INTO versions VALUES (23, 'Person', 20, 'create', NULL, NULL, '2015-02-24 01:26:07.106909');
INSERT INTO versions VALUES (24, 'Person', 21, 'create', NULL, NULL, '2015-02-24 01:26:30.754324');
INSERT INTO versions VALUES (25, 'Person', 22, 'create', NULL, NULL, '2015-02-24 01:27:13.15084');
INSERT INTO versions VALUES (26, 'Person', 23, 'create', NULL, NULL, '2015-02-24 01:27:43.736633');
INSERT INTO versions VALUES (27, 'Person', 24, 'create', NULL, NULL, '2015-02-24 01:28:09.899319');
INSERT INTO versions VALUES (28, 'Person', 25, 'create', NULL, NULL, '2015-02-24 01:28:40.669437');
INSERT INTO versions VALUES (29, 'Person', 26, 'create', NULL, NULL, '2015-02-24 01:29:09.931762');
INSERT INTO versions VALUES (30, 'Person', 23, 'update', NULL, '---
id: 23
salutation: 
name: ''Juan C ''
lastnames: ''Rivera ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 109
created_at: 2015-02-24 01:27:43.735306000 Z
updated_at: 2015-02-24 01:27:43.735306000 Z
', '2015-02-24 01:30:11.04792');
INSERT INTO versions VALUES (31, 'Check', 3, 'create', NULL, NULL, '2015-02-24 01:30:55.879659');
INSERT INTO versions VALUES (32, 'Check', 3, 'update', NULL, '---
id: 3
number: 16766
amount: 125.0
description: ''''
church_id: 109
created_at: 2015-02-24 01:30:55.878320000 Z
updated_at: 2015-02-24 01:30:55.878320000 Z
', '2015-02-24 01:31:24.07793');
INSERT INTO versions VALUES (33, 'Person', 27, 'create', NULL, NULL, '2015-02-24 01:37:45.572934');
INSERT INTO versions VALUES (34, 'Person', 28, 'create', NULL, NULL, '2015-02-24 01:38:14.146665');
INSERT INTO versions VALUES (35, 'Person', 29, 'create', NULL, NULL, '2015-02-24 01:39:08.320145');
INSERT INTO versions VALUES (36, 'Person', 30, 'create', NULL, NULL, '2015-02-24 01:39:31.366065');
INSERT INTO versions VALUES (37, 'Check', 4, 'create', NULL, NULL, '2015-02-24 01:40:25.872369');
INSERT INTO versions VALUES (38, 'Person', 31, 'create', NULL, NULL, '2015-02-24 01:41:36.18275');
INSERT INTO versions VALUES (39, 'Person', 32, 'create', NULL, NULL, '2015-02-24 01:42:07.442615');
INSERT INTO versions VALUES (40, 'Person', 33, 'create', NULL, NULL, '2015-02-24 01:42:32.460378');
INSERT INTO versions VALUES (41, 'Check', 5, 'create', NULL, NULL, '2015-02-24 01:43:19.619947');
INSERT INTO versions VALUES (42, 'Person', 34, 'create', NULL, NULL, '2015-02-24 01:43:56.326921');
INSERT INTO versions VALUES (43, 'Person', 35, 'create', NULL, NULL, '2015-02-24 01:44:21.296323');
INSERT INTO versions VALUES (44, 'Person', 36, 'create', NULL, NULL, '2015-02-24 01:44:56.282279');
INSERT INTO versions VALUES (45, 'Person', 37, 'create', NULL, NULL, '2015-02-24 01:45:18.351672');
INSERT INTO versions VALUES (46, 'Person', 38, 'create', NULL, NULL, '2015-02-24 01:45:45.279442');
INSERT INTO versions VALUES (47, 'Person', 39, 'create', NULL, NULL, '2015-02-24 01:46:09.754894');
INSERT INTO versions VALUES (48, 'Person', 40, 'create', NULL, NULL, '2015-02-24 01:46:45.494842');
INSERT INTO versions VALUES (49, 'Check', 6, 'create', NULL, NULL, '2015-02-24 01:48:40.589248');
INSERT INTO versions VALUES (50, 'Person', 41, 'create', NULL, NULL, '2015-02-24 01:49:18.956842');
INSERT INTO versions VALUES (51, 'Person', 42, 'create', NULL, NULL, '2015-02-24 01:49:43.060769');
INSERT INTO versions VALUES (52, 'Person', 43, 'create', NULL, NULL, '2015-02-24 01:50:05.17372');
INSERT INTO versions VALUES (53, 'Person', 44, 'create', NULL, NULL, '2015-02-24 01:51:09.642834');
INSERT INTO versions VALUES (54, 'Person', 45, 'create', NULL, NULL, '2015-02-24 01:51:34.053568');
INSERT INTO versions VALUES (55, 'Person', 46, 'create', NULL, NULL, '2015-02-24 01:51:58.623805');
INSERT INTO versions VALUES (56, 'Person', 47, 'create', NULL, NULL, '2015-02-24 01:52:30.067777');
INSERT INTO versions VALUES (57, 'Person', 48, 'create', NULL, NULL, '2015-02-24 01:53:09.271451');
INSERT INTO versions VALUES (58, 'Person', 49, 'create', NULL, NULL, '2015-02-24 01:53:29.172016');
INSERT INTO versions VALUES (59, 'Person', 50, 'create', NULL, NULL, '2015-02-24 01:53:49.392172');
INSERT INTO versions VALUES (60, 'Check', 7, 'create', NULL, NULL, '2015-02-24 01:54:18.603347');
INSERT INTO versions VALUES (61, 'Check', 7, 'update', NULL, '---
id: 7
number: 2594
amount: 75.0
description: ''''
church_id: 113
created_at: 2015-02-24 01:54:18.601953000 Z
updated_at: 2015-02-24 01:54:18.601953000 Z
', '2015-02-24 01:54:45.955145');
INSERT INTO versions VALUES (62, 'Person', 51, 'create', NULL, NULL, '2015-02-24 01:56:07.757841');
INSERT INTO versions VALUES (63, 'Person', 52, 'create', NULL, NULL, '2015-02-24 01:56:28.002852');
INSERT INTO versions VALUES (64, 'Person', 53, 'create', NULL, NULL, '2015-02-24 01:56:49.329393');
INSERT INTO versions VALUES (65, 'Person', 54, 'create', NULL, NULL, '2015-02-24 01:57:09.234681');
INSERT INTO versions VALUES (66, 'Person', 55, 'create', NULL, NULL, '2015-02-24 01:58:31.253179');
INSERT INTO versions VALUES (67, 'Person', 56, 'create', NULL, NULL, '2015-02-24 01:58:53.433009');
INSERT INTO versions VALUES (68, 'Person', 57, 'create', NULL, NULL, '2015-02-24 01:59:18.742186');
INSERT INTO versions VALUES (69, 'Person', 58, 'create', NULL, NULL, '2015-02-24 02:00:09.304152');
INSERT INTO versions VALUES (70, 'Person', 59, 'create', NULL, NULL, '2015-02-24 02:00:30.779435');
INSERT INTO versions VALUES (71, 'Person', 60, 'create', NULL, NULL, '2015-02-24 02:00:59.146573');
INSERT INTO versions VALUES (72, 'Person', 61, 'create', NULL, NULL, '2015-02-24 02:01:25.369135');
INSERT INTO versions VALUES (73, 'Person', 62, 'create', NULL, NULL, '2015-02-24 02:01:45.247966');
INSERT INTO versions VALUES (74, 'Person', 63, 'create', NULL, NULL, '2015-02-24 02:02:14.537637');
INSERT INTO versions VALUES (75, 'Person', 64, 'create', NULL, NULL, '2015-02-24 02:02:38.335515');
INSERT INTO versions VALUES (76, 'Person', 65, 'create', NULL, NULL, '2015-02-24 02:03:03.024245');
INSERT INTO versions VALUES (77, 'Person', 65, 'update', NULL, '---
id: 65
salutation: 1
name: ''Benigno ''
lastnames: ''Torres ''
sex: true
role: 2
description: ''''
attended: false
printed: false
materials: false
church_id: 
created_at: 2015-02-24 02:03:03.022471000 Z
updated_at: 2015-02-24 02:03:03.022471000 Z
', '2015-02-24 02:03:54.748409');
INSERT INTO versions VALUES (78, 'Person', 66, 'create', NULL, NULL, '2015-02-24 02:05:02.060645');
INSERT INTO versions VALUES (79, 'Person', 67, 'create', NULL, NULL, '2015-02-24 02:05:28.777575');
INSERT INTO versions VALUES (80, 'Person', 68, 'create', NULL, NULL, '2015-02-24 02:05:58.201675');
INSERT INTO versions VALUES (81, 'Person', 69, 'create', NULL, NULL, '2015-02-24 02:06:47.611025');
INSERT INTO versions VALUES (82, 'Person', 70, 'create', NULL, NULL, '2015-02-24 02:07:15.108041');
INSERT INTO versions VALUES (83, 'Person', 71, 'create', NULL, NULL, '2015-02-24 02:07:36.948529');
INSERT INTO versions VALUES (84, 'Person', 72, 'create', NULL, NULL, '2015-02-24 02:08:16.278744');
INSERT INTO versions VALUES (85, 'Person', 73, 'create', NULL, NULL, '2015-02-24 02:08:54.003985');
INSERT INTO versions VALUES (86, 'Person', 74, 'create', NULL, NULL, '2015-02-24 02:09:58.049222');
INSERT INTO versions VALUES (87, 'Person', 75, 'create', NULL, NULL, '2015-02-24 02:10:31.345772');
INSERT INTO versions VALUES (88, 'Person', 76, 'create', NULL, NULL, '2015-02-24 02:11:21.045009');
INSERT INTO versions VALUES (89, 'Person', 77, 'create', NULL, NULL, '2015-02-24 02:11:56.860112');
INSERT INTO versions VALUES (90, 'Person', 78, 'create', NULL, NULL, '2015-02-24 02:12:58.695113');
INSERT INTO versions VALUES (91, 'Person', 79, 'create', NULL, NULL, '2015-02-24 02:13:25.269547');
INSERT INTO versions VALUES (92, 'Person', 80, 'create', NULL, NULL, '2015-02-24 02:13:57.476863');
INSERT INTO versions VALUES (93, 'Person', 81, 'create', NULL, NULL, '2015-02-24 02:14:22.854026');
INSERT INTO versions VALUES (94, 'Person', 82, 'create', NULL, NULL, '2015-02-24 02:14:48.427723');
INSERT INTO versions VALUES (95, 'Person', 83, 'create', NULL, NULL, '2015-02-24 02:15:12.647318');
INSERT INTO versions VALUES (96, 'Person', 84, 'create', NULL, NULL, '2015-02-24 02:15:41.376716');
INSERT INTO versions VALUES (97, 'Person', 85, 'create', NULL, NULL, '2015-02-24 02:16:06.985908');
INSERT INTO versions VALUES (98, 'Person', 86, 'create', NULL, NULL, '2015-02-24 02:16:38.056363');
INSERT INTO versions VALUES (99, 'Person', 87, 'create', NULL, NULL, '2015-02-24 02:17:00.755377');
INSERT INTO versions VALUES (100, 'Person', 88, 'create', NULL, NULL, '2015-02-24 02:17:31.010378');
INSERT INTO versions VALUES (101, 'Person', 89, 'create', NULL, NULL, '2015-02-24 02:17:55.398765');
INSERT INTO versions VALUES (102, 'Person', 90, 'create', NULL, NULL, '2015-02-24 02:18:41.546845');
INSERT INTO versions VALUES (103, 'Check', 8, 'create', NULL, NULL, '2015-02-24 02:19:44.590197');
INSERT INTO versions VALUES (104, 'Person', 91, 'create', NULL, NULL, '2015-02-24 02:22:48.676859');
INSERT INTO versions VALUES (105, 'Person', 92, 'create', NULL, NULL, '2015-02-24 02:23:11.720458');
INSERT INTO versions VALUES (106, 'Person', 93, 'create', NULL, NULL, '2015-02-24 02:23:34.712691');
INSERT INTO versions VALUES (107, 'Person', 94, 'create', NULL, NULL, '2015-02-24 02:24:44.09048');
INSERT INTO versions VALUES (108, 'Person', 95, 'create', NULL, NULL, '2015-02-24 02:25:06.880322');
INSERT INTO versions VALUES (109, 'Person', 96, 'create', NULL, NULL, '2015-02-24 02:25:30.270239');
INSERT INTO versions VALUES (110, 'Person', 97, 'create', NULL, NULL, '2015-02-24 02:26:09.99092');
INSERT INTO versions VALUES (111, 'Person', 98, 'create', NULL, NULL, '2015-02-24 02:26:31.870618');
INSERT INTO versions VALUES (112, 'Person', 99, 'create', NULL, NULL, '2015-02-24 02:26:53.656163');
INSERT INTO versions VALUES (113, 'Person', 100, 'create', NULL, NULL, '2015-02-24 02:27:18.422051');
INSERT INTO versions VALUES (114, 'Person', 101, 'create', NULL, NULL, '2015-02-24 02:28:47.99973');
INSERT INTO versions VALUES (115, 'Person', 102, 'create', NULL, NULL, '2015-02-24 02:29:10.041458');
INSERT INTO versions VALUES (116, 'Person', 103, 'create', NULL, NULL, '2015-02-24 02:29:30.898235');
INSERT INTO versions VALUES (117, 'Person', 104, 'create', NULL, NULL, '2015-02-24 02:30:03.653599');
INSERT INTO versions VALUES (118, 'Person', 105, 'create', NULL, NULL, '2015-02-24 02:30:38.334674');
INSERT INTO versions VALUES (119, 'Person', 106, 'create', NULL, NULL, '2015-02-24 02:31:01.729791');
INSERT INTO versions VALUES (120, 'Check', 9, 'create', NULL, NULL, '2015-02-24 02:31:36.764952');
INSERT INTO versions VALUES (121, 'Check', 9, 'update', NULL, '---
id: 9
number: 3353
amount: 150.0
description: ''''
church_id: 52
created_at: 2015-02-24 02:31:36.763363000 Z
updated_at: 2015-02-24 02:31:36.763363000 Z
', '2015-02-24 02:32:04.577361');
INSERT INTO versions VALUES (122, 'Person', 107, 'create', NULL, NULL, '2015-02-24 02:32:59.76088');
INSERT INTO versions VALUES (123, 'Person', 108, 'create', NULL, NULL, '2015-02-24 02:33:19.630873');
INSERT INTO versions VALUES (124, 'Person', 109, 'create', NULL, NULL, '2015-02-24 02:33:49.141266');
INSERT INTO versions VALUES (125, 'Person', 110, 'create', NULL, NULL, '2015-02-24 02:34:06.463615');
INSERT INTO versions VALUES (126, 'Person', 111, 'create', NULL, NULL, '2015-02-24 02:34:40.420902');
INSERT INTO versions VALUES (127, 'Person', 112, 'create', NULL, NULL, '2015-02-24 02:35:11.392678');
INSERT INTO versions VALUES (128, 'Person', 113, 'create', NULL, NULL, '2015-02-24 02:35:37.037745');
INSERT INTO versions VALUES (129, 'Person', 114, 'create', NULL, NULL, '2015-02-24 02:35:59.458846');
INSERT INTO versions VALUES (130, 'Person', 115, 'create', NULL, NULL, '2015-02-24 02:36:19.733987');
INSERT INTO versions VALUES (131, 'Person', 116, 'create', NULL, NULL, '2015-02-24 02:36:47.172787');
INSERT INTO versions VALUES (132, 'Person', 117, 'create', NULL, NULL, '2015-02-24 02:37:12.733112');
INSERT INTO versions VALUES (133, 'Person', 118, 'create', NULL, NULL, '2015-02-24 02:37:32.521526');
INSERT INTO versions VALUES (134, 'Check', 10, 'create', NULL, NULL, '2015-02-24 02:38:19.294466');
INSERT INTO versions VALUES (135, 'Person', 119, 'create', NULL, NULL, '2015-02-24 02:39:10.399414');
INSERT INTO versions VALUES (136, 'Person', 120, 'create', NULL, NULL, '2015-02-24 02:39:44.623836');
INSERT INTO versions VALUES (137, 'Person', 121, 'create', NULL, NULL, '2015-02-24 02:40:13.364407');
INSERT INTO versions VALUES (138, 'Person', 122, 'create', NULL, NULL, '2015-02-24 02:40:50.080239');
INSERT INTO versions VALUES (139, 'Person', 123, 'create', NULL, NULL, '2015-02-24 02:41:19.739725');
INSERT INTO versions VALUES (140, 'Person', 124, 'create', NULL, NULL, '2015-02-24 02:41:48.370063');
INSERT INTO versions VALUES (141, 'Person', 125, 'create', NULL, NULL, '2015-02-24 02:42:20.49695');
INSERT INTO versions VALUES (142, 'Person', 126, 'create', NULL, NULL, '2015-02-24 02:42:55.83851');
INSERT INTO versions VALUES (143, 'Check', 11, 'create', NULL, NULL, '2015-02-24 02:44:41.809206');
INSERT INTO versions VALUES (144, 'Person', 127, 'create', NULL, NULL, '2015-02-24 02:45:36.539014');
INSERT INTO versions VALUES (145, 'Person', 128, 'create', NULL, NULL, '2015-02-24 02:46:03.77818');
INSERT INTO versions VALUES (146, 'Person', 129, 'create', NULL, NULL, '2015-02-24 02:46:39.452835');
INSERT INTO versions VALUES (147, 'Person', 130, 'create', NULL, NULL, '2015-02-24 02:47:50.486513');
INSERT INTO versions VALUES (148, 'Person', 131, 'create', NULL, NULL, '2015-02-24 02:48:14.618443');
INSERT INTO versions VALUES (149, 'Person', 132, 'create', NULL, NULL, '2015-02-24 02:48:45.525139');
INSERT INTO versions VALUES (150, 'Person', 133, 'create', NULL, NULL, '2015-02-24 02:49:09.239835');
INSERT INTO versions VALUES (151, 'Person', 134, 'create', NULL, NULL, '2015-02-24 02:52:08.031716');
INSERT INTO versions VALUES (152, 'Person', 135, 'create', NULL, NULL, '2015-02-24 02:52:29.815935');
INSERT INTO versions VALUES (153, 'Person', 136, 'create', NULL, NULL, '2015-02-24 02:52:52.626386');
INSERT INTO versions VALUES (154, 'Person', 137, 'create', NULL, NULL, '2015-02-24 02:53:15.80197');
INSERT INTO versions VALUES (155, 'Person', 138, 'create', NULL, NULL, '2015-02-24 04:30:24.199759');
INSERT INTO versions VALUES (156, 'Person', 139, 'create', NULL, NULL, '2015-02-24 04:31:25.128997');
INSERT INTO versions VALUES (157, 'Person', 140, 'create', NULL, NULL, '2015-02-24 04:32:32.980474');
INSERT INTO versions VALUES (158, 'Person', 141, 'create', NULL, NULL, '2015-02-24 04:33:33.089332');
INSERT INTO versions VALUES (159, 'Person', 142, 'create', NULL, NULL, '2015-02-24 04:34:25.077273');
INSERT INTO versions VALUES (160, 'Person', 143, 'create', NULL, NULL, '2015-02-24 04:35:16.500817');
INSERT INTO versions VALUES (161, 'Person', 144, 'create', NULL, NULL, '2015-02-24 04:36:11.544534');
INSERT INTO versions VALUES (162, 'Person', 145, 'create', NULL, NULL, '2015-02-24 04:37:06.047981');
INSERT INTO versions VALUES (163, 'Person', 146, 'create', NULL, NULL, '2015-02-24 04:37:52.520168');
INSERT INTO versions VALUES (164, 'Person', 147, 'create', NULL, NULL, '2015-02-24 04:38:43.992218');
INSERT INTO versions VALUES (165, 'Person', 148, 'create', NULL, NULL, '2015-02-24 04:39:28.231812');
INSERT INTO versions VALUES (166, 'Person', 149, 'create', NULL, NULL, '2015-02-24 04:40:17.713045');
INSERT INTO versions VALUES (167, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 04:37:52.518536000 Z
', '2015-02-24 11:46:38.002538');
INSERT INTO versions VALUES (168, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:46:37.999776000 Z
', '2015-02-24 11:46:40.295241');
INSERT INTO versions VALUES (169, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:46:40.292341000 Z
', '2015-02-24 11:46:42.116302');
INSERT INTO versions VALUES (170, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:46:42.114299000 Z
', '2015-02-24 11:46:43.220322');
INSERT INTO versions VALUES (171, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:46:43.217077000 Z
', '2015-02-24 11:46:47.516684');
INSERT INTO versions VALUES (172, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:46:47.514111000 Z
', '2015-02-24 11:53:58.238955');
INSERT INTO versions VALUES (173, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:53:58.235747000 Z
', '2015-02-24 11:53:59.44038');
INSERT INTO versions VALUES (174, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:53:59.438244000 Z
', '2015-02-24 11:54:00.903114');
INSERT INTO versions VALUES (175, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:00.900951000 Z
', '2015-02-24 11:54:02.702871');
INSERT INTO versions VALUES (176, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:02.700718000 Z
', '2015-02-24 11:54:03.684528');
INSERT INTO versions VALUES (177, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:03.681401000 Z
', '2015-02-24 11:54:04.886565');
INSERT INTO versions VALUES (178, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:04.884076000 Z
', '2015-02-24 11:54:05.774973');
INSERT INTO versions VALUES (179, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:05.772188000 Z
', '2015-02-24 11:54:06.696389');
INSERT INTO versions VALUES (180, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:06.694427000 Z
', '2015-02-24 11:54:07.607898');
INSERT INTO versions VALUES (181, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:07.605728000 Z
', '2015-02-24 11:54:13.435703');
INSERT INTO versions VALUES (182, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:13.433344000 Z
', '2015-02-24 11:54:14.323893');
INSERT INTO versions VALUES (183, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:14.321943000 Z
', '2015-02-24 11:54:15.077901');
INSERT INTO versions VALUES (184, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:15.075681000 Z
', '2015-02-24 11:54:19.028317');
INSERT INTO versions VALUES (185, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:19.025839000 Z
', '2015-02-24 11:54:20.568488');
INSERT INTO versions VALUES (186, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:20.565654000 Z
', '2015-02-24 11:54:25.30584');
INSERT INTO versions VALUES (187, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:25.302562000 Z
', '2015-02-24 11:54:29.454923');
INSERT INTO versions VALUES (188, 'Person', 146, 'update', NULL, '---
id: 146
salutation: 0
name: ''Alicia E. ''
lastnames: ''Liard ''
sex: false
role: 1
description: ''''
attended: false
printed: true
materials: false
church_id: 25
created_at: 2015-02-24 04:37:52.518536000 Z
updated_at: 2015-02-24 11:54:29.452886000 Z
', '2015-02-24 11:55:05.279387');
INSERT INTO versions VALUES (189, 'Person', 150, 'create', NULL, NULL, '2015-02-24 13:22:38.517374');
INSERT INTO versions VALUES (190, 'Person', 151, 'create', NULL, NULL, '2015-02-24 13:25:34.791304');
INSERT INTO versions VALUES (191, 'Person', 152, 'create', NULL, NULL, '2015-02-24 13:26:17.802922');
INSERT INTO versions VALUES (192, 'Person', 153, 'create', NULL, NULL, '2015-02-24 13:26:47.058171');
INSERT INTO versions VALUES (193, 'Person', 153, 'update', NULL, '---
id: 153
salutation: 
name: Lillian
lastnames: Rivera Morales
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 25
created_at: 2015-02-24 13:26:47.056805000 Z
updated_at: 2015-02-24 13:26:47.056805000 Z
', '2015-02-24 13:27:22.978194');
INSERT INTO versions VALUES (194, 'Person', 154, 'create', NULL, NULL, '2015-02-24 13:30:40.270092');
INSERT INTO versions VALUES (195, 'Person', 155, 'create', NULL, NULL, '2015-02-24 13:31:13.6839');
INSERT INTO versions VALUES (196, 'Person', 156, 'create', NULL, NULL, '2015-02-24 13:31:44.770139');
INSERT INTO versions VALUES (197, 'Person', 157, 'create', NULL, NULL, '2015-02-24 13:32:21.485896');
INSERT INTO versions VALUES (198, 'Person', 158, 'create', NULL, NULL, '2015-02-24 13:32:55.492542');
INSERT INTO versions VALUES (199, 'Person', 159, 'create', NULL, NULL, '2015-02-24 13:33:17.400851');
INSERT INTO versions VALUES (200, 'Person', 160, 'create', NULL, NULL, '2015-02-24 13:33:40.852475');
INSERT INTO versions VALUES (201, 'Person', 161, 'create', NULL, NULL, '2015-02-24 13:34:03.072028');
INSERT INTO versions VALUES (202, 'Person', 162, 'create', NULL, NULL, '2015-02-24 13:50:27.218475');
INSERT INTO versions VALUES (203, 'Person', 163, 'create', NULL, NULL, '2015-02-24 13:50:59.038312');
INSERT INTO versions VALUES (204, 'Person', 164, 'create', NULL, NULL, '2015-02-24 13:51:15.710274');
INSERT INTO versions VALUES (205, 'Person', 165, 'create', NULL, NULL, '2015-02-24 13:51:43.983766');
INSERT INTO versions VALUES (206, 'Person', 166, 'create', NULL, NULL, '2015-02-24 13:52:46.227022');
INSERT INTO versions VALUES (207, 'Person', 167, 'create', NULL, NULL, '2015-02-24 13:54:46.989559');
INSERT INTO versions VALUES (208, 'Person', 168, 'create', NULL, NULL, '2015-02-24 13:55:10.763636');
INSERT INTO versions VALUES (209, 'Person', 169, 'create', NULL, NULL, '2015-02-24 13:55:28.177839');
INSERT INTO versions VALUES (210, 'Person', 170, 'create', NULL, NULL, '2015-02-24 13:55:46.932084');
INSERT INTO versions VALUES (211, 'Person', 171, 'create', NULL, NULL, '2015-02-24 13:56:21.985752');
INSERT INTO versions VALUES (212, 'Person', 172, 'create', NULL, NULL, '2015-02-24 13:58:26.023248');
INSERT INTO versions VALUES (213, 'Person', 173, 'create', NULL, NULL, '2015-02-24 14:00:34.17568');
INSERT INTO versions VALUES (214, 'Person', 174, 'create', NULL, NULL, '2015-02-24 14:01:17.188198');
INSERT INTO versions VALUES (215, 'Person', 174, 'update', NULL, '---
id: 174
salutation: 0
name: ''Rosalba ''
lastnames: Vila
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 24
created_at: 2015-02-24 14:01:17.186728000 Z
updated_at: 2015-02-24 14:01:17.186728000 Z
', '2015-02-24 14:01:55.519213');
INSERT INTO versions VALUES (216, 'Person', 175, 'create', NULL, NULL, '2015-02-24 14:03:07.963799');
INSERT INTO versions VALUES (217, 'Person', 176, 'create', NULL, NULL, '2015-02-24 14:03:23.993745');
INSERT INTO versions VALUES (218, 'Person', 177, 'create', NULL, NULL, '2015-02-24 14:06:06.142529');
INSERT INTO versions VALUES (219, 'Person', 178, 'create', NULL, NULL, '2015-02-24 14:06:33.869547');
INSERT INTO versions VALUES (220, 'Person', 179, 'create', NULL, NULL, '2015-02-24 14:07:06.34803');
INSERT INTO versions VALUES (221, 'Person', 180, 'create', NULL, NULL, '2015-02-24 14:08:52.761461');
INSERT INTO versions VALUES (222, 'Person', 181, 'create', NULL, NULL, '2015-02-24 14:09:15.74451');
INSERT INTO versions VALUES (223, 'Person', 182, 'create', NULL, NULL, '2015-02-24 14:09:37.57454');
INSERT INTO versions VALUES (224, 'Person', 183, 'create', NULL, NULL, '2015-02-24 14:10:04.473562');
INSERT INTO versions VALUES (225, 'Person', 184, 'create', NULL, NULL, '2015-02-24 14:10:25.179844');
INSERT INTO versions VALUES (226, 'Person', 185, 'create', NULL, NULL, '2015-02-24 14:18:03.477371');
INSERT INTO versions VALUES (227, 'Person', 186, 'create', NULL, NULL, '2015-02-24 14:18:37.602559');
INSERT INTO versions VALUES (228, 'Person', 187, 'create', NULL, NULL, '2015-02-24 14:19:01.549231');
INSERT INTO versions VALUES (229, 'Person', 188, 'create', NULL, NULL, '2015-02-24 14:19:32.497465');
INSERT INTO versions VALUES (230, 'Check', 12, 'create', NULL, NULL, '2015-02-24 14:20:37.477361');
INSERT INTO versions VALUES (231, 'Person', 189, 'create', NULL, NULL, '2015-02-24 14:24:45.330794');
INSERT INTO versions VALUES (232, 'Person', 190, 'create', NULL, NULL, '2015-02-24 14:26:26.021491');
INSERT INTO versions VALUES (233, 'Person', 191, 'create', NULL, NULL, '2015-02-24 14:26:50.4275');
INSERT INTO versions VALUES (234, 'Person', 192, 'create', NULL, NULL, '2015-02-24 14:28:11.785658');
INSERT INTO versions VALUES (235, 'Person', 193, 'create', NULL, NULL, '2015-02-24 14:28:49.383363');
INSERT INTO versions VALUES (236, 'Person', 194, 'create', NULL, NULL, '2015-02-24 14:32:01.787631');
INSERT INTO versions VALUES (237, 'Person', 195, 'create', NULL, NULL, '2015-02-24 14:34:57.884085');
INSERT INTO versions VALUES (238, 'Person', 196, 'create', NULL, NULL, '2015-02-24 14:35:32.23974');
INSERT INTO versions VALUES (239, 'Person', 197, 'create', NULL, NULL, '2015-02-24 14:36:01.267754');
INSERT INTO versions VALUES (240, 'Person', 198, 'create', NULL, NULL, '2015-02-24 14:36:33.924204');
INSERT INTO versions VALUES (241, 'Person', 199, 'create', NULL, NULL, '2015-02-24 14:36:58.832552');
INSERT INTO versions VALUES (242, 'Person', 200, 'create', NULL, NULL, '2015-02-24 14:37:42.743459');
INSERT INTO versions VALUES (243, 'Check', 13, 'create', NULL, NULL, '2015-02-24 14:38:44.974435');
INSERT INTO versions VALUES (244, 'Person', 201, 'create', NULL, NULL, '2015-02-24 14:39:41.629697');
INSERT INTO versions VALUES (245, 'Check', 14, 'create', NULL, NULL, '2015-02-24 14:40:06.249185');
INSERT INTO versions VALUES (246, 'Person', 202, 'create', NULL, NULL, '2015-02-24 14:41:07.88917');
INSERT INTO versions VALUES (247, 'Person', 203, 'create', NULL, NULL, '2015-02-24 14:41:40.762995');
INSERT INTO versions VALUES (248, 'Person', 204, 'create', NULL, NULL, '2015-02-24 14:42:04.141506');
INSERT INTO versions VALUES (249, 'Person', 205, 'create', NULL, NULL, '2015-02-24 14:42:43.921755');
INSERT INTO versions VALUES (250, 'Person', 206, 'create', NULL, NULL, '2015-02-24 14:43:11.480913');
INSERT INTO versions VALUES (251, 'Person', 207, 'create', NULL, NULL, '2015-02-24 14:43:36.160917');
INSERT INTO versions VALUES (252, 'Person', 208, 'create', NULL, NULL, '2015-02-24 14:43:53.103039');
INSERT INTO versions VALUES (253, 'Person', 209, 'create', NULL, NULL, '2015-02-24 14:44:22.639564');
INSERT INTO versions VALUES (254, 'Person', 210, 'create', NULL, NULL, '2015-02-24 14:44:40.126982');
INSERT INTO versions VALUES (255, 'Person', 211, 'create', NULL, NULL, '2015-02-24 14:45:14.701311');
INSERT INTO versions VALUES (256, 'Person', 212, 'create', NULL, NULL, '2015-02-24 14:45:35.729465');
INSERT INTO versions VALUES (257, 'Person', 213, 'create', NULL, NULL, '2015-02-24 14:46:01.726522');
INSERT INTO versions VALUES (258, 'Person', 214, 'create', NULL, NULL, '2015-02-24 14:46:22.78016');
INSERT INTO versions VALUES (259, 'Person', 215, 'create', NULL, NULL, '2015-02-24 14:46:39.865416');
INSERT INTO versions VALUES (260, 'Person', 216, 'create', NULL, NULL, '2015-02-24 14:46:58.270888');
INSERT INTO versions VALUES (261, 'Person', 205, 'update', NULL, '---
id: 205
salutation: 1
name: Luz E.
lastnames: Rodríguez
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 84
created_at: 2015-02-24 14:42:43.920366000 Z
updated_at: 2015-02-24 14:42:43.920366000 Z
', '2015-02-24 14:47:16.12489');
INSERT INTO versions VALUES (262, 'Check', 15, 'create', NULL, NULL, '2015-02-24 14:48:15.866233');
INSERT INTO versions VALUES (263, 'Person', 189, 'destroy', NULL, '---
id: 189
salutation: 0
name: ''Nilsa E. ''
lastnames: García García
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 83
created_at: 2015-02-24 14:24:45.329288000 Z
updated_at: 2015-02-24 14:24:45.329288000 Z
', '2015-02-24 14:50:11.859041');
INSERT INTO versions VALUES (264, 'Person', 217, 'create', NULL, NULL, '2015-02-24 14:51:21.888396');
INSERT INTO versions VALUES (265, 'Person', 218, 'create', NULL, NULL, '2015-02-24 14:51:45.800687');
INSERT INTO versions VALUES (266, 'Person', 219, 'create', NULL, NULL, '2015-02-24 14:51:58.887121');
INSERT INTO versions VALUES (267, 'Check', 16, 'create', NULL, NULL, '2015-02-24 14:52:32.777828');
INSERT INTO versions VALUES (268, 'Person', 220, 'create', NULL, NULL, '2015-02-24 14:54:01.688405');
INSERT INTO versions VALUES (269, 'Person', 221, 'create', NULL, NULL, '2015-02-24 14:55:06.389431');
INSERT INTO versions VALUES (270, 'Person', 222, 'create', NULL, NULL, '2015-02-24 14:56:17.094444');
INSERT INTO versions VALUES (271, 'Check', 17, 'create', NULL, NULL, '2015-02-24 14:57:39.191883');
INSERT INTO versions VALUES (272, 'Person', 223, 'create', NULL, NULL, '2015-02-24 15:00:38.846428');
INSERT INTO versions VALUES (273, 'Person', 224, 'create', NULL, NULL, '2015-02-24 15:01:02.224339');
INSERT INTO versions VALUES (274, 'Person', 225, 'create', NULL, NULL, '2015-02-24 15:01:44.626128');
INSERT INTO versions VALUES (275, 'Person', 226, 'create', NULL, NULL, '2015-02-24 15:02:58.246178');
INSERT INTO versions VALUES (276, 'Person', 227, 'create', NULL, NULL, '2015-02-24 15:03:30.851255');
INSERT INTO versions VALUES (277, 'Person', 228, 'create', NULL, NULL, '2015-02-24 15:04:05.738242');
INSERT INTO versions VALUES (278, 'Person', 229, 'create', NULL, NULL, '2015-02-24 15:04:56.868511');
INSERT INTO versions VALUES (279, 'Person', 230, 'create', NULL, NULL, '2015-02-24 15:05:16.437552');
INSERT INTO versions VALUES (280, 'Person', 231, 'create', NULL, NULL, '2015-02-24 15:06:14.601159');
INSERT INTO versions VALUES (281, 'Person', 232, 'create', NULL, NULL, '2015-02-24 15:06:56.721672');
INSERT INTO versions VALUES (282, 'Person', 233, 'create', NULL, NULL, '2015-02-24 15:07:18.50397');
INSERT INTO versions VALUES (283, 'Person', 234, 'create', NULL, NULL, '2015-02-24 15:07:44.277752');
INSERT INTO versions VALUES (284, 'Person', 235, 'create', NULL, NULL, '2015-02-24 15:08:07.302391');
INSERT INTO versions VALUES (285, 'Person', 236, 'create', NULL, NULL, '2015-02-24 15:08:43.897686');
INSERT INTO versions VALUES (286, 'Person', 237, 'create', NULL, NULL, '2015-02-24 15:09:04.913212');
INSERT INTO versions VALUES (287, 'Person', 238, 'create', NULL, NULL, '2015-02-24 15:09:45.920205');
INSERT INTO versions VALUES (288, 'Person', 239, 'create', NULL, NULL, '2015-02-24 15:10:43.118174');
INSERT INTO versions VALUES (289, 'Person', 240, 'create', NULL, NULL, '2015-02-24 15:11:09.637334');
INSERT INTO versions VALUES (290, 'Person', 241, 'create', NULL, NULL, '2015-02-24 15:12:09.348457');
INSERT INTO versions VALUES (291, 'Person', 242, 'create', NULL, NULL, '2015-02-24 15:12:49.334472');
INSERT INTO versions VALUES (292, 'Person', 243, 'create', NULL, NULL, '2015-02-24 15:13:14.964399');
INSERT INTO versions VALUES (293, 'Person', 244, 'create', NULL, NULL, '2015-02-24 15:13:38.482052');
INSERT INTO versions VALUES (294, 'Person', 245, 'create', NULL, NULL, '2015-02-24 15:14:15.609322');
INSERT INTO versions VALUES (295, 'Person', 246, 'create', NULL, NULL, '2015-02-24 15:14:41.257614');
INSERT INTO versions VALUES (296, 'Person', 247, 'create', NULL, NULL, '2015-02-24 15:15:22.014131');
INSERT INTO versions VALUES (297, 'Person', 248, 'create', NULL, NULL, '2015-02-24 15:16:16.159813');
INSERT INTO versions VALUES (298, 'Person', 249, 'create', NULL, NULL, '2015-02-24 15:16:47.616154');
INSERT INTO versions VALUES (299, 'Person', 250, 'create', NULL, NULL, '2015-02-24 15:17:04.963835');
INSERT INTO versions VALUES (300, 'Person', 251, 'create', NULL, NULL, '2015-02-24 15:17:40.921135');
INSERT INTO versions VALUES (301, 'Person', 252, 'create', NULL, NULL, '2015-02-24 15:18:21.474507');
INSERT INTO versions VALUES (302, 'Person', 253, 'create', NULL, NULL, '2015-02-24 15:18:59.957656');
INSERT INTO versions VALUES (303, 'Person', 254, 'create', NULL, NULL, '2015-02-24 15:26:06.340561');
INSERT INTO versions VALUES (304, 'Person', 251, 'update', NULL, '---
id: 251
salutation: 
name: ''Noel ''
lastnames: ''Pacheco Eraticelli ''
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 99
created_at: 2015-02-24 15:17:40.919683000 Z
updated_at: 2015-02-24 15:17:40.919683000 Z
', '2015-02-24 15:27:46.080326');
INSERT INTO versions VALUES (305, 'Person', 255, 'create', NULL, NULL, '2015-02-24 15:30:51.290699');
INSERT INTO versions VALUES (306, 'Person', 256, 'create', NULL, NULL, '2015-02-24 15:31:15.049025');
INSERT INTO versions VALUES (307, 'Person', 257, 'create', NULL, NULL, '2015-02-24 15:31:36.907533');
INSERT INTO versions VALUES (308, 'Person', 258, 'create', NULL, NULL, '2015-02-24 15:31:57.72166');
INSERT INTO versions VALUES (309, 'Person', 259, 'create', NULL, NULL, '2015-02-24 15:32:15.705645');
INSERT INTO versions VALUES (310, 'Person', 260, 'create', NULL, NULL, '2015-02-24 15:32:33.982301');
INSERT INTO versions VALUES (311, 'Person', 252, 'destroy', NULL, '---
id: 252
salutation: 
name: ''Noel Y. ''
lastnames: Pachecho Alvarez
sex: true
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 96
created_at: 2015-02-24 15:18:21.472994000 Z
updated_at: 2015-02-24 15:18:21.472994000 Z
', '2015-02-24 15:36:22.857055');
INSERT INTO versions VALUES (312, 'Person', 261, 'create', NULL, NULL, '2015-02-24 15:36:45.083292');
INSERT INTO versions VALUES (313, 'Person', 262, 'create', NULL, NULL, '2015-02-24 15:36:59.767852');
INSERT INTO versions VALUES (314, 'Person', 263, 'create', NULL, NULL, '2015-02-24 15:37:12.576007');
INSERT INTO versions VALUES (315, 'Person', 264, 'create', NULL, NULL, '2015-02-24 15:37:27.836773');
INSERT INTO versions VALUES (316, 'Person', 265, 'create', NULL, NULL, '2015-02-24 15:40:47.635891');
INSERT INTO versions VALUES (317, 'Person', 266, 'create', NULL, NULL, '2015-02-24 15:41:10.185748');
INSERT INTO versions VALUES (318, 'Person', 174, 'update', NULL, '---
id: 174
salutation: 0
name: ''Rosalba ''
lastnames: Velez
sex: false
role: 1
description: ''''
attended: false
printed: false
materials: false
church_id: 24
created_at: 2015-02-24 14:01:17.186728000 Z
updated_at: 2015-02-24 14:01:55.517084000 Z
', '2015-02-24 15:42:41.682034');
INSERT INTO versions VALUES (319, 'Person', 267, 'create', NULL, NULL, '2015-02-24 17:29:51.387223');
INSERT INTO versions VALUES (320, 'Person', 268, 'create', NULL, NULL, '2015-02-24 17:33:42.66097');
INSERT INTO versions VALUES (321, 'Person', 269, 'create', NULL, NULL, '2015-02-24 17:40:29.028543');
INSERT INTO versions VALUES (322, 'Person', 270, 'create', NULL, NULL, '2015-02-24 17:41:40.123577');
INSERT INTO versions VALUES (323, 'Person', 271, 'create', NULL, NULL, '2015-02-24 17:43:15.015575');
INSERT INTO versions VALUES (324, 'Person', 2, 'update', NULL, '---
id: 2
salutation: 
name: ''Susana ''
lastnames: ''Luzunaris ''
sex: false
role: 3
description: ''''
attended: false
printed: false
materials: false
church_id: 108
created_at: 2015-02-23 22:22:37.697968000 Z
updated_at: 2015-02-23 22:22:37.697968000 Z
', '2015-02-24 17:44:05.229226');
INSERT INTO versions VALUES (325, 'Person', 265, 'update', NULL, '---
id: 265
salutation: 
name: ''Angel M. ''
lastnames: García
sex: true
role: 5
description: ''''
attended: false
printed: false
materials: false
church_id: 69
created_at: 2015-02-24 15:40:47.634235000 Z
updated_at: 2015-02-24 15:40:47.634235000 Z
', '2015-02-24 17:46:07.912253');
INSERT INTO versions VALUES (326, 'Person', 174, 'update', NULL, '---
id: 174
salutation: 0
name: ''Rosalba ''
lastnames: Velez
sex: false
role: 5
description: ''''
attended: false
printed: false
materials: false
church_id: 24
created_at: 2015-02-24 14:01:17.186728000 Z
updated_at: 2015-02-24 15:42:41.679711000 Z
', '2015-02-24 17:48:37.173496');
INSERT INTO versions VALUES (327, 'Person', 223, 'update', NULL, '---
id: 223
salutation: 1
name: ''Myrna I. ''
lastnames: Ramos
sex: false
role: 5
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 15:00:38.844886000 Z
updated_at: 2015-02-24 15:00:38.844886000 Z
', '2015-02-24 17:49:13.573554');
INSERT INTO versions VALUES (328, 'Person', 224, 'update', NULL, '---
id: 224
salutation: 1
name: ''Efrain ''
lastnames: Figueroa
sex: true
role: 5
description: ''''
attended: false
printed: false
materials: false
church_id: 1
created_at: 2015-02-24 15:01:02.222804000 Z
updated_at: 2015-02-24 15:01:02.222804000 Z
', '2015-02-24 17:49:30.481476');
INSERT INTO versions VALUES (329, 'Person', 272, 'create', NULL, NULL, '2015-02-24 18:10:46.126249');
INSERT INTO versions VALUES (330, 'Person', 273, 'create', NULL, NULL, '2015-02-25 13:22:35.135787');
INSERT INTO versions VALUES (331, 'Person', 274, 'create', NULL, NULL, '2015-02-25 13:22:58.908577');
INSERT INTO versions VALUES (332, 'Person', 275, 'create', NULL, NULL, '2015-02-25 13:23:22.913372');
INSERT INTO versions VALUES (333, 'Person', 276, 'create', NULL, NULL, '2015-02-25 13:23:47.198443');
INSERT INTO versions VALUES (334, 'Person', 277, 'create', NULL, NULL, '2015-02-25 13:25:23.920632');
INSERT INTO versions VALUES (335, 'Person', 278, 'create', NULL, NULL, '2015-02-25 14:45:14.4178');
INSERT INTO versions VALUES (336, 'Person', 279, 'create', NULL, NULL, '2015-02-25 14:45:41.270174');
INSERT INTO versions VALUES (337, 'Person', 280, 'create', NULL, NULL, '2015-02-25 14:46:00.735577');
INSERT INTO versions VALUES (338, 'Person', 281, 'create', NULL, NULL, '2015-02-25 14:46:16.168164');
INSERT INTO versions VALUES (339, 'Person', 282, 'create', NULL, NULL, '2015-02-25 14:47:11.253243');
INSERT INTO versions VALUES (340, 'Person', 283, 'create', NULL, NULL, '2015-02-25 14:48:04.170148');
INSERT INTO versions VALUES (341, 'Person', 284, 'create', NULL, NULL, '2015-02-25 14:49:00.281499');
INSERT INTO versions VALUES (342, 'Person', 285, 'create', NULL, NULL, '2015-02-25 14:49:25.743587');
INSERT INTO versions VALUES (343, 'Person', 286, 'create', NULL, NULL, '2015-02-25 14:50:38.257691');
INSERT INTO versions VALUES (344, 'Person', 192, 'update', NULL, '---
id: 192
salutation: 0
name: ''Abigail ''
lastnames: Castro
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 19
created_at: 2015-02-24 14:28:11.784210000 Z
updated_at: 2015-02-24 14:28:11.784210000 Z
', '2015-02-25 15:59:25.132557');
INSERT INTO versions VALUES (345, 'Person', 192, 'update', NULL, '---
id: 192
salutation: 0
name: ''Abigail ''
lastnames: Castro
sex: false
role: 0
description: ''''
attended: true
printed: false
materials: false
church_id: 19
created_at: 2015-02-24 14:28:11.784210000 Z
updated_at: 2015-02-25 15:59:25.129215000 Z
', '2015-02-25 16:00:44.664447');
INSERT INTO versions VALUES (346, 'Person', 287, 'create', NULL, NULL, '2015-02-27 02:29:25.419496');
INSERT INTO versions VALUES (347, 'Person', 288, 'create', NULL, NULL, '2015-02-27 02:30:14.501311');
INSERT INTO versions VALUES (348, 'Person', 289, 'create', NULL, NULL, '2015-02-27 02:34:55.183835');
INSERT INTO versions VALUES (349, 'Person', 290, 'create', NULL, NULL, '2015-02-27 02:35:45.395556');
INSERT INTO versions VALUES (350, 'Person', 291, 'create', NULL, NULL, '2015-02-27 02:36:13.133725');
INSERT INTO versions VALUES (351, 'Person', 292, 'create', NULL, NULL, '2015-02-27 02:37:13.682411');
INSERT INTO versions VALUES (352, 'Person', 293, 'create', NULL, NULL, '2015-02-27 02:37:49.972586');
INSERT INTO versions VALUES (353, 'Person', 294, 'create', NULL, NULL, '2015-02-27 02:39:11.938511');
INSERT INTO versions VALUES (354, 'Check', 18, 'create', NULL, NULL, '2015-02-27 02:39:49.734162');
INSERT INTO versions VALUES (355, 'Person', 295, 'create', NULL, NULL, '2015-02-27 02:44:15.3983');
INSERT INTO versions VALUES (356, 'Person', 296, 'create', NULL, NULL, '2015-02-27 02:44:42.002263');
INSERT INTO versions VALUES (357, 'Person', 297, 'create', NULL, NULL, '2015-02-27 02:45:46.185789');
INSERT INTO versions VALUES (358, 'Person', 298, 'create', NULL, NULL, '2015-02-27 02:46:06.544391');
INSERT INTO versions VALUES (359, 'Person', 299, 'create', NULL, NULL, '2015-02-27 02:46:30.934281');
INSERT INTO versions VALUES (360, 'Church', 54, 'update', NULL, '---
id: 54
position: 91
nth: 
prefix: Iglesia Bautista de
name: Quebrada
nickname: ''''
town: Gurabo
size: 1
notes: El 7 marzo Malcom Diaz sustituyo a Misael
created_at: 2014-03-04 15:14:57.203929000 Z
updated_at: 2014-03-07 14:58:35.687457000 Z
', '2015-02-28 19:25:41.260291');
INSERT INTO versions VALUES (361, 'Church', 45, 'update', NULL, '---
id: 45
position: 46
nth: 1
prefix: Iglesia Bautista de
name: Guayama
nickname: ''''
town: Guayama
size: 2
notes: Felicita sustituyo a Maria el jueves.
created_at: 2014-03-04 15:14:57.194239000 Z
updated_at: 2014-03-07 14:01:39.723034000 Z
', '2015-02-28 19:25:58.595678');
INSERT INTO versions VALUES (362, 'Person', 192, 'update', NULL, '---
id: 192
salutation: 0
name: ''Abigail ''
lastnames: Castro
sex: false
role: 0
description: ''''
attended: false
printed: false
materials: false
church_id: 19
created_at: 2015-02-24 14:28:11.784210000 Z
updated_at: 2015-02-25 16:00:44.662146000 Z
', '2015-02-28 19:27:38.786914');
INSERT INTO versions VALUES (363, 'Person', 192, 'update', NULL, '---
id: 192
salutation: 0
name: ''Abigail ''
lastnames: Castro
sex: false
role: 0
description: ''''
attended: false
printed: true
materials: false
church_id: 19
created_at: 2015-02-24 14:28:11.784210000 Z
updated_at: 2015-02-28 19:27:38.784317000 Z
', '2015-02-28 19:27:39.695117');


--
-- Name: versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: registroibpr
--

SELECT pg_catalog.setval('versions_id_seq', 363, true);


--
-- PostgreSQL database dump complete
--

